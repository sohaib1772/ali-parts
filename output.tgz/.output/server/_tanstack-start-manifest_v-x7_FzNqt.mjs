//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-x7_FzNqt.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/react/ali-parts-pro/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/auth",
			"/best-sellers",
			"/contact",
			"/deals",
			"/delete-account",
			"/offers",
			"/privacy",
			"/products",
			"/search",
			"/terms",
			"/category/$id",
			"/order-success/$id",
			"/product/$id"
		],
		preloads: [
			"/assets/index-UzP7Rqtu.js",
			"/assets/rolldown-runtime-QTnfLwEv.js",
			"/assets/useRouter-CAlSMMd6.js",
			"/assets/createLucideIcon-CX0ia4Xd.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/redirect-DCb_aIiF.js",
			"/assets/jsx-runtime-By8HlURe.js",
			"/assets/useMatch-BeSSgiG8.js",
			"/assets/useSearch-CqUcoHIE.js",
			"/assets/useNavigate-D0psL8lk.js",
			"/assets/client-VpccseFy.js",
			"/assets/preload-helper-CZgWQFsJ.js",
			"/assets/queryOptions-Dfvzj6n2.js",
			"/assets/dist-iSjKo4yw.js",
			"/assets/utils-B6KiDbIe.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-UzP7Rqtu.js"
		} }]
	},
	"/": {
		filePath: "C:/react/ali-parts-pro/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-MWdVUXc3.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useInfiniteQuery-D_ODyn2g.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/flame-COs47oVf.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/timer-Dhvn_t3B.js",
			"/assets/volume-x-9jMCUmgC.js",
			"/assets/admin-Bly-JQ75.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/filter-bar-fSP7Vyix.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/account",
			"/_authenticated/addresses",
			"/_authenticated/admin",
			"/_authenticated/cart",
			"/_authenticated/checkout",
			"/_authenticated/favorites",
			"/_authenticated/messages",
			"/_authenticated/notifications",
			"/_authenticated/orders",
			"/_authenticated/replacements",
			"/_authenticated/orders_/$id",
			"/_authenticated/replacements_/$id"
		],
		preloads: ["/assets/route-CM-UgmWY.js", "/assets/profile-completion-QD7eYaKf.js"]
	},
	"/about": {
		filePath: "C:/react/ali-parts-pro/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-D7-ThLv_.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/users-COEBE2Sx.js",
			"/assets/admin-Bly-JQ75.js"
		]
	},
	"/auth": {
		filePath: "C:/react/ali-parts-pro/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-CEruevX8.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/admin-Bly-JQ75.js"
		]
	},
	"/best-sellers": {
		filePath: "C:/react/ali-parts-pro/src/routes/best-sellers.tsx",
		children: void 0,
		preloads: [
			"/assets/best-sellers-BpWkvYwI.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/flame-COs47oVf.js",
			"/assets/filter-bar-fSP7Vyix.js"
		]
	},
	"/contact": {
		filePath: "C:/react/ali-parts-pro/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-CtGuq1gx.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/phone-UntyVTdD.js",
			"/assets/admin-Bly-JQ75.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/deals": {
		filePath: "C:/react/ali-parts-pro/src/routes/deals.tsx",
		children: void 0,
		preloads: [
			"/assets/deals-oFalAz2S.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/timer-Dhvn_t3B.js",
			"/assets/filter-bar-fSP7Vyix.js"
		]
	},
	"/delete-account": {
		filePath: "C:/react/ali-parts-pro/src/routes/delete-account.tsx",
		children: void 0,
		preloads: [
			"/assets/delete-account-50s2kTdG.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-DNmF4Pcy.js"
		]
	},
	"/offers": {
		filePath: "C:/react/ali-parts-pro/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-BYK6eTib.js",
			"/assets/admin.functions-D1UxcIEe.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/users-COEBE2Sx.js",
			"/assets/volume-x-9jMCUmgC.js",
			"/assets/admin-Bly-JQ75.js",
			"/assets/button-Dlrdz7ia.js"
		]
	},
	"/privacy": {
		filePath: "C:/react/ali-parts-pro/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-Dj0Z-526.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-DNmF4Pcy.js"
		]
	},
	"/products": {
		filePath: "C:/react/ali-parts-pro/src/routes/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-CzfylGcE.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useInfiniteQuery-D_ODyn2g.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/flame-COs47oVf.js",
			"/assets/filter-bar-fSP7Vyix.js"
		]
	},
	"/search": {
		filePath: "C:/react/ali-parts-pro/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-BBMr_ipN.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/filter-bar-fSP7Vyix.js"
		]
	},
	"/terms": {
		filePath: "C:/react/ali-parts-pro/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-BxT2pTlI.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-DNmF4Pcy.js"
		]
	},
	"/_authenticated/account": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-BFYPzYWS.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/input-C5BeVnhO.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/admin-Bly-JQ75.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-CkacPFAW.js"
		]
	},
	"/_authenticated/addresses": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/addresses.tsx",
		children: void 0,
		preloads: [
			"/assets/addresses-B3EmX55j.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-down-Bqab7lOs.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/trash-2-Bc4A27_9.js"
		]
	},
	"/_authenticated/admin": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-ChlZs1hf.js",
			"/assets/admin.functions-D1UxcIEe.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-down-Bqab7lOs.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/printable-invoice-C5FU7iH7.js",
			"/assets/image-De9brycf.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/phone-UntyVTdD.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/refresh-cw-CQf63W6J.js",
			"/assets/repeat-C3d4Cia4.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/input-C5BeVnhO.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/triangle-alert-CXE0Ni_i.js",
			"/assets/upload-P_j2OCqa.js",
			"/assets/user-PiYxEYaO.js",
			"/assets/users-COEBE2Sx.js",
			"/assets/admin-Bly-JQ75.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/dist-CfS4U4qI.js",
			"/assets/button-Dlrdz7ia.js",
			"/assets/alert-dialog-CkacPFAW.js"
		]
	},
	"/_authenticated/cart": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/cart.tsx",
		children: void 0,
		preloads: [
			"/assets/cart-BqwYXZNf.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/minus-J2I3ovAm.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/admin-Bly-JQ75.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/shipping-BZRBFfJB.js"
		]
	},
	"/_authenticated/checkout": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-DwVBgXlV.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/triangle-alert-CXE0Ni_i.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/admin-Bly-JQ75.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/shipping-BZRBFfJB.js"
		]
	},
	"/_authenticated/favorites": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/favorites.tsx",
		children: void 0,
		preloads: [
			"/assets/favorites-DsxYT6vv.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/filter-bar-fSP7Vyix.js"
		]
	},
	"/_authenticated/messages": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/messages.tsx",
		children: void 0,
		preloads: [
			"/assets/messages-BNVXKr-j.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/admin-Bly-JQ75.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/_authenticated/notifications": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-BQWsbcRj.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/notifications-F-ef98EQ.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/truck-DmOmjpyY.js"
		]
	},
	"/_authenticated/orders": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/orders.tsx",
		children: void 0,
		preloads: [
			"/assets/orders-DQZA7DFk.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/notifications-F-ef98EQ.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/format-tzvdlX4z.js"
		]
	},
	"/_authenticated/replacements": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/replacements.tsx",
		children: void 0,
		preloads: [
			"/assets/replacements-C96NtccE.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/repeat-C3d4Cia4.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/thumbs-up-DBYFGh6s.js"
		]
	},
	"/category/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/category.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/category._id-D_WKq2U2.js",
			"/assets/page-shell-npl31ELB.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/filter-bar-fSP7Vyix.js"
		]
	},
	"/order-success/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/order-success.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/order-success._id-B8A883yu.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/format-tzvdlX4z.js"
		]
	},
	"/product/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/product.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/product._id-DdL7DgyH.js",
			"/assets/product._id-DwK1NYM_.js",
			"/assets/product._id-UXBFj0tl.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/minus-J2I3ovAm.js",
			"/assets/progress-BtOfPUa-.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/refresh-cw-CQf63W6J.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/upload-with-progress-CkcOrscr.js",
			"/assets/admin-Bly-JQ75.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-CkacPFAW.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/_authenticated/orders_/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/orders_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/orders_._id-DH1Oykml.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/printable-invoice-C5FU7iH7.js",
			"/assets/notifications-F-ef98EQ.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/refresh-cw-CQf63W6J.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-CkacPFAW.js"
		]
	},
	"/_authenticated/replacements_/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/replacements_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/replacements_._id-DRf1W4Gr.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/image-De9brycf.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/progress-BtOfPUa-.js",
			"/assets/repeat-C3d4Cia4.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/thumbs-up-DBYFGh6s.js",
			"/assets/upload-P_j2OCqa.js",
			"/assets/upload-with-progress-CkcOrscr.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
