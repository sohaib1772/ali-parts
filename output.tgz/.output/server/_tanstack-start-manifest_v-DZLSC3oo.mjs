//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DZLSC3oo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/react/ali-parts-pro/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/auth",
			"/best-sellers",
			"/contact",
			"/deals",
			"/delete-account",
			"/offers",
			"/privacy",
			"/products",
			"/search",
			"/terms",
			"/category/$id",
			"/order-success/$id",
			"/product/$id"
		],
		preloads: [
			"/assets/index-Bja7kB1u.js",
			"/assets/rolldown-runtime-QTnfLwEv.js",
			"/assets/useRouter-CAlSMMd6.js",
			"/assets/createLucideIcon-CX0ia4Xd.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/redirect-DCb_aIiF.js",
			"/assets/jsx-runtime-By8HlURe.js",
			"/assets/useMatch-BeSSgiG8.js",
			"/assets/useSearch-CqUcoHIE.js",
			"/assets/useNavigate-D0psL8lk.js",
			"/assets/client-VpccseFy.js",
			"/assets/preload-helper-CZgWQFsJ.js",
			"/assets/queryOptions-Dfvzj6n2.js",
			"/assets/dist-iSjKo4yw.js",
			"/assets/utils-B6KiDbIe.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bja7kB1u.js"
		} }]
	},
	"/": {
		filePath: "C:/react/ali-parts-pro/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CspAfm6F.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useInfiniteQuery-D_ODyn2g.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/flame-COs47oVf.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/timer-Dhvn_t3B.js",
			"/assets/volume-x-9jMCUmgC.js",
			"/assets/admin-aWQvFR15.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/filter-bar-DsjIh-E1.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/account",
			"/_authenticated/addresses",
			"/_authenticated/admin",
			"/_authenticated/cart",
			"/_authenticated/checkout",
			"/_authenticated/favorites",
			"/_authenticated/messages",
			"/_authenticated/notifications",
			"/_authenticated/orders",
			"/_authenticated/replacements",
			"/_authenticated/orders_/$id",
			"/_authenticated/replacements_/$id"
		],
		preloads: ["/assets/route-BQQQeJsq.js", "/assets/profile-completion-CiJbVuwn.js"]
	},
	"/about": {
		filePath: "C:/react/ali-parts-pro/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-5a5iKoOo.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/users-COEBE2Sx.js",
			"/assets/admin-aWQvFR15.js"
		]
	},
	"/auth": {
		filePath: "C:/react/ali-parts-pro/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-C_2I060w.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/admin-aWQvFR15.js"
		]
	},
	"/best-sellers": {
		filePath: "C:/react/ali-parts-pro/src/routes/best-sellers.tsx",
		children: void 0,
		preloads: [
			"/assets/best-sellers-DbXZektk.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/flame-COs47oVf.js",
			"/assets/filter-bar-DsjIh-E1.js"
		]
	},
	"/contact": {
		filePath: "C:/react/ali-parts-pro/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-32F9uGOc.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/phone-UntyVTdD.js",
			"/assets/admin-aWQvFR15.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/deals": {
		filePath: "C:/react/ali-parts-pro/src/routes/deals.tsx",
		children: void 0,
		preloads: [
			"/assets/deals-Bs9lqbaJ.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/timer-Dhvn_t3B.js",
			"/assets/filter-bar-DsjIh-E1.js"
		]
	},
	"/delete-account": {
		filePath: "C:/react/ali-parts-pro/src/routes/delete-account.tsx",
		children: void 0,
		preloads: [
			"/assets/delete-account-CH2nP5TC.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-jl7PC0sY.js"
		]
	},
	"/offers": {
		filePath: "C:/react/ali-parts-pro/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-uvh0O5Xn.js",
			"/assets/admin.functions-OpS0ceh0.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/users-COEBE2Sx.js",
			"/assets/volume-x-9jMCUmgC.js",
			"/assets/admin-aWQvFR15.js",
			"/assets/button-BShFJ25x.js"
		]
	},
	"/privacy": {
		filePath: "C:/react/ali-parts-pro/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-BSbxvqbo.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-jl7PC0sY.js"
		]
	},
	"/products": {
		filePath: "C:/react/ali-parts-pro/src/routes/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-BBoTqzER.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useInfiniteQuery-D_ODyn2g.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/flame-COs47oVf.js",
			"/assets/filter-bar-DsjIh-E1.js"
		]
	},
	"/search": {
		filePath: "C:/react/ali-parts-pro/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-DKD4BStU.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/filter-bar-DsjIh-E1.js"
		]
	},
	"/terms": {
		filePath: "C:/react/ali-parts-pro/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-CsNzARth.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-jl7PC0sY.js"
		]
	},
	"/_authenticated/account": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-1jO71RJg.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/input-C5BeVnhO.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/admin-aWQvFR15.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-C8qumA91.js"
		]
	},
	"/_authenticated/addresses": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/addresses.tsx",
		children: void 0,
		preloads: [
			"/assets/addresses-CSHTwAu2.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-down-Bqab7lOs.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/trash-2-Bc4A27_9.js"
		]
	},
	"/_authenticated/admin": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-Cmx1Lanl.js",
			"/assets/admin.functions-OpS0ceh0.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-down-Bqab7lOs.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/printable-invoice-Daj4mlyK.js",
			"/assets/image-De9brycf.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/phone-UntyVTdD.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/refresh-cw-CQf63W6J.js",
			"/assets/repeat-C3d4Cia4.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/input-C5BeVnhO.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/triangle-alert-CXE0Ni_i.js",
			"/assets/upload-P_j2OCqa.js",
			"/assets/user-PiYxEYaO.js",
			"/assets/users-COEBE2Sx.js",
			"/assets/admin-aWQvFR15.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/dist-CfS4U4qI.js",
			"/assets/button-BShFJ25x.js",
			"/assets/alert-dialog-C8qumA91.js"
		]
	},
	"/_authenticated/cart": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/cart.tsx",
		children: void 0,
		preloads: [
			"/assets/cart-CYDtssn4.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/minus-J2I3ovAm.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/admin-aWQvFR15.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/shipping-BZRBFfJB.js"
		]
	},
	"/_authenticated/checkout": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-DRmke_JA.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/triangle-alert-CXE0Ni_i.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/admin-aWQvFR15.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/shipping-BZRBFfJB.js"
		]
	},
	"/_authenticated/favorites": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/favorites.tsx",
		children: void 0,
		preloads: [
			"/assets/favorites-CL15clFd.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/filter-bar-DsjIh-E1.js"
		]
	},
	"/_authenticated/messages": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/messages.tsx",
		children: void 0,
		preloads: [
			"/assets/messages-Ciw1mG64.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/admin-aWQvFR15.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/_authenticated/notifications": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-CMuLhzyr.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/notifications-RufoZV13.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/truck-DmOmjpyY.js"
		]
	},
	"/_authenticated/orders": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/orders.tsx",
		children: void 0,
		preloads: [
			"/assets/orders-BFNN71lf.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/notifications-RufoZV13.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/format-tzvdlX4z.js"
		]
	},
	"/_authenticated/replacements": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/replacements.tsx",
		children: void 0,
		preloads: [
			"/assets/replacements-CI0Aq8AG.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/repeat-C3d4Cia4.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/thumbs-up-DBYFGh6s.js"
		]
	},
	"/category/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/category.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/category._id-CVxuZEck.js",
			"/assets/page-shell-BhxUdECv.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/filter-bar-DsjIh-E1.js"
		]
	},
	"/order-success/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/order-success.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/order-success._id-DDBkgG1A.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/format-tzvdlX4z.js"
		]
	},
	"/product/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/product.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/product._id-B5-d7Qna.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/minus-J2I3ovAm.js",
			"/assets/progress-BGFxdca5.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/refresh-cw-CQf63W6J.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/upload-with-progress-CkcOrscr.js",
			"/assets/admin-aWQvFR15.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-C8qumA91.js",
			"/assets/icons-tqznr91k.js",
			"/assets/product._id-DdL7DgyH.js",
			"/assets/product._id-DwK1NYM_.js"
		]
	},
	"/_authenticated/orders_/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/orders_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/orders_._id-4Em3uaBL.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/printable-invoice-Daj4mlyK.js",
			"/assets/notifications-RufoZV13.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/refresh-cw-CQf63W6J.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-C8qumA91.js"
		]
	},
	"/_authenticated/replacements_/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/replacements_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/replacements_._id-CF56rX2s.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/image-De9brycf.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/progress-BGFxdca5.js",
			"/assets/repeat-C3d4Cia4.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/thumbs-up-DBYFGh6s.js",
			"/assets/upload-P_j2OCqa.js",
			"/assets/upload-with-progress-CkcOrscr.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
