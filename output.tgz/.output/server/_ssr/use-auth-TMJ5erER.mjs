import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-auth-TMJ5erER.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var AuthContext = (0, import_react.createContext)(null);
function AuthProvider({ children }) {
	const [user, setUser] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		supabase.auth.getSession().then(({ data }) => {
			if (!mounted) return;
			setUser(data.session?.user ?? null);
			setLoading(false);
		});
		const { data: sub } = supabase.auth.onAuthStateChange((_evt, session) => {
			setUser(session?.user ?? null);
			setLoading(false);
		});
		return () => {
			mounted = false;
			sub.subscription.unsubscribe();
		};
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		user,
		loading,
		userId: user?.id ?? null
	}), [user, loading]);
	return (0, import_react.createElement)(AuthContext.Provider, { value }, children);
}
function useAuth() {
	return (0, import_react.useContext)(AuthContext) ?? {
		user: null,
		loading: true,
		userId: null
	};
}
//#endregion
export { useAuth as n, AuthProvider as t };
