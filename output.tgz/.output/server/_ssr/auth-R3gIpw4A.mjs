import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useSetting } from "./admin-DdF3xehS.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Rt as ArrowRight, X as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Capacitor } from "../_libs/@aparajita/capacitor-secure-storage+[...].mjs";
import { t as sessionRestorePromise } from "./session-bootstrap-hk3NyGqS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-R3gIpw4A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function resolvePostLoginPath(userId) {
	try {
		const [roleRes, staffRes] = await Promise.all([supabase.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle(), supabase.from("staff_permissions").select("can_orders,can_products,can_replacements,can_block").eq("user_id", userId).maybeSingle()]);
		if (roleRes.data) return "/admin";
		const s = staffRes.data;
		if (s && (s.can_orders || s.can_products || s.can_replacements || s.can_block)) return "/admin";
	} catch {}
	return "/";
}
function AuthPage() {
	const navigate = useNavigate();
	const storeName = useSetting("store_name", "Ali Parts");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const navigatedRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		const goIfSession = async (userId) => {
			if (!userId || navigatedRef.current || !mounted) return;
			navigatedRef.current = true;
			const to = await resolvePostLoginPath(userId);
			navigate({
				to,
				replace: true
			});
		};
		const { data: sub } = supabase.auth.onAuthStateChange((_evt, session) => {
			goIfSession(session?.user?.id);
		});
		(async () => {
			await sessionRestorePromise;
			const { data } = await supabase.auth.getSession();
			goIfSession(data.session?.user?.id);
		})();
		return () => {
			mounted = false;
			sub.subscription.unsubscribe();
		};
	}, [navigate]);
	const oauth = async (provider, label) => {
		if (loading) return;
		setLoading(true);
		if (Capacitor.isNativePlatform()) {
			const { signInWithProviderNative } = await import("./native-oauth-r8XAo6Rm.mjs");
			const result = await signInWithProviderNative(provider);
			if (result.status === "signed-in") return;
			if (result.status === "error") toast.error(`تعذّر تسجيل الدخول عبر ${label}`, { description: result.message });
			setLoading(false);
			return;
		}
		const { error } = await supabase.auth.signInWithOAuth({
			provider,
			options: { redirectTo: window.location.origin + "/auth" }
		});
		if (error) {
			toast.error(`تعذّر تسجيل الدخول عبر ${label} — حاول مرة أخرى`);
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen w-full overflow-hidden bg-gradient-to-b from-[#0f172a] to-[#1e293b] text-white flex flex-col items-center justify-center p-6 selection:bg-gold/30",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none fixed top-[-10%] left-[-10%] w-[45%] h-[45%] rounded-full bg-amber-500/12 blur-[120px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none fixed bottom-[-10%] right-[-10%] w-[45%] h-[45%] rounded-full bg-blue-400/8 blur-[120px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none fixed inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:32px_32px] opacity-[0.02]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative w-full max-w-[420px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "absolute -top-14 start-0 inline-flex items-center gap-1.5 text-xs text-white/50 hover:text-gold transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" }), " العودة للرئيسية"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-[2.5rem] border border-white/10 bg-gradient-to-b from-[#1a2332] to-[#111827] p-8 shadow-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-gold/70 to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center mb-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "font-luxury text-2xl font-semibold mb-2",
									children: ["مرحباً بك في ", storeName]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-body-lux text-sm text-white/50",
									children: "شوفرليت — قطع غيار سيارات مستعمل و جديد"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => oauth("google", "Google"),
								disabled: loading,
								className: "w-full flex items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white text-[#1f2937] hover:bg-white/90 py-4 font-bold transition disabled:opacity-50",
								children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin text-gold" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleG, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-body-lux text-sm",
									children: "المتابعة مع Google"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => oauth("apple", "Apple"),
								disabled: loading,
								className: "mt-3 w-full flex items-center justify-center gap-3 rounded-2xl border border-white/15 bg-black text-white hover:bg-black/80 py-4 font-bold transition disabled:opacity-50",
								children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin text-white" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppleLogo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-body-lux text-sm",
									children: "المتابعة مع Apple"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-5 text-center text-[11px] leading-relaxed text-white/40 font-body-lux",
								children: [
									"بالمتابعة أنت توافق على الشروط والأحكام وسياسة الخصوصية.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"سنطلب رقم هاتفك بعد الدخول لاستخدامه في التوصيل فقط."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex justify-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-8 h-1 rounded-full bg-gold/30" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-2 h-1 rounded-full bg-white/10" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-2 h-1 rounded-full bg-white/10" })
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-center gap-6 mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 opacity-50 hover:opacity-100 transition-opacity",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1.5 h-1.5 rounded-full bg-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-white/60 uppercase tracking-[0.2em] font-body-lux",
								children: "قطع أصلية"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 opacity-50 hover:opacity-100 transition-opacity",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1.5 h-1.5 rounded-full bg-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-white/60 uppercase tracking-[0.2em] font-body-lux",
								children: "توصيل سريع"
							})]
						})]
					})
				]
			})
		]
	});
}
function GoogleG() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "size-5",
		viewBox: "0 0 24 24",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#4285F4",
				d: "M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.44c-.28 1.4-1.09 2.6-2.31 3.42v2.84h3.72c2.18-2.01 3.44-4.97 3.44-8.5z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#34A853",
				d: "M12 24c3.13 0 5.75-1.04 7.66-2.81l-3.72-2.84c-1.03.69-2.35 1.09-3.94 1.09-3.03 0-5.6-2.05-6.51-4.81H1.63v2.93A11.99 11.99 0 0012 24z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#FBBC05",
				d: "M5.49 14.63c-.23-.69-.35-1.42-.35-2.17s.13-1.48.35-2.17V7.36H1.63A11.99 11.99 0 000 12.46c0 1.93.46 3.75 1.27 5.36l4.22-3.19z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#EA4335",
				d: "M12 4.75c1.7 0 3.23.59 4.43 1.74l3.32-3.32C17.74 1.19 15.12 0 12 0 7.31 0 3.26 2.69 1.27 6.6l4.22 3.19C6.4 6.8 8.97 4.75 12 4.75z"
			})
		]
	});
}
function AppleLogo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		className: "size-5",
		viewBox: "0 0 24 24",
		fill: "white",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" })
	});
}
//#endregion
export { AuthPage as component };
