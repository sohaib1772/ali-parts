import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { n as requireAdminOtp } from "./require-admin-otp-DgUpC_62.mjs";
import { a as objectType, o as stringType, t as booleanType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-BAJfHN1_.js
async function assertAdmin(ctx) {
	const { data, error } = await ctx.supabase.rpc("has_role", {
		_user_id: ctx.userId,
		_role: "admin"
	});
	if (error || !data) throw new Error("Forbidden");
}
async function assertModerator(ctx) {
	const [{ data: isAdmin }, { data: canBlock }] = await Promise.all([ctx.supabase.rpc("has_role", {
		_user_id: ctx.userId,
		_role: "admin"
	}), ctx.supabase.rpc("staff_can", {
		_uid: ctx.userId,
		_perm: "block"
	})]);
	if (!isAdmin && !canBlock) throw new Error("Forbidden");
}
var SetPasswordInput = objectType({
	user_id: stringType().uuid(),
	password: stringType().min(6).max(72)
});
var SetBlockedInput = objectType({
	user_id: stringType().uuid(),
	blocked: booleanType(),
	reason: stringType().trim().max(500).optional()
});
var adminSetUserPassword_createServerFn_handler = createServerRpc({
	id: "b34af10cfb0cf6e0465afe0ba898bf162e25ef86c235c103c7203e6db0c8ea54",
	name: "adminSetUserPassword",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSetUserPassword.__executeServer(opts));
var adminSetUserPassword = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => SetPasswordInput.parse(d)).handler(adminSetUserPassword_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { error } = await supabaseAdmin.auth.admin.updateUserById(data.user_id, { password: data.password });
	if (error) throw new Error(error.message);
	return { ok: true };
});
var adminSetUserBlocked_createServerFn_handler = createServerRpc({
	id: "95b6aa2b4978dfa32791d4aec5b5df227e7607e3a64ad55178ad66bc334781df",
	name: "adminSetUserBlocked",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminSetUserBlocked.__executeServer(opts));
var adminSetUserBlocked = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => SetBlockedInput.parse(d)).handler(adminSetUserBlocked_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	if (data.user_id === context.userId) throw new Error("لا يمكنك حظر حسابك الإداري.");
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const blocked = data.blocked;
	const title = blocked ? "تم حظر حسابك من التعليقات" : "تم رفع الحظر عن حسابك";
	const body = data.reason || (blocked ? "تم حظرك بسبب تعليق مخالف لقوانين المجتمع. يرجى الالتزام بالكلام المحترم وتجنب الإساءة أو السبام أو المحتوى غير اللائق." : "تم رفع الحظر عن حسابك، يمكنك الآن التفاعل والتعليق بشكل طبيعي مع الالتزام بالقوانين.");
	const { error: profileError } = await supabaseAdmin.from("profiles").upsert({
		id: data.user_id,
		is_blocked: blocked
	}, { onConflict: "id" });
	if (profileError) throw new Error(profileError.message);
	const { error: logError } = await supabaseAdmin.from("user_block_log").insert({
		user_id: data.user_id,
		actor_id: context.userId,
		action: blocked ? "block" : "unblock"
	});
	if (logError) throw new Error(logError.message);
	const { error: notificationError } = await supabaseAdmin.from("notifications").insert({
		user_id: data.user_id,
		type: "account_status",
		title,
		body
	});
	if (notificationError) throw new Error(notificationError.message);
	return {
		ok: true,
		blocked
	};
});
var adminListUsers_createServerFn_handler = createServerRpc({
	id: "35cf6cc28f61c798a570ec39672552de8ed250f60706565e25b34a66f0c5b240",
	name: "adminListUsers",
	filename: "src/lib/admin.functions.ts"
}, (opts) => adminListUsers.__executeServer(opts));
var adminListUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(adminListUsers_createServerFn_handler, async ({ context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	return await listUsersImpl(context);
});
var moderatorListUsers_createServerFn_handler = createServerRpc({
	id: "d6e6d14870d9b01fd5e0c1a5d24a1171cb6e0826067e577a07edc0da371647cf",
	name: "moderatorListUsers",
	filename: "src/lib/admin.functions.ts"
}, (opts) => moderatorListUsers.__executeServer(opts));
var moderatorListUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(moderatorListUsers_createServerFn_handler, async ({ context }) => {
	await assertModerator(context);
	await requireAdminOtp(context);
	return await listUsersImpl(context);
});
async function listUsersImpl(context) {
	let all = [];
	let fetchedFromAuth = false;
	try {
		const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
		const perPage = 200;
		for (let page = 1; page <= 20; page++) {
			const { data, error } = await supabaseAdmin.auth.admin.listUsers({
				page,
				perPage
			});
			if (error) throw new Error(error.message);
			const users = data?.users ?? [];
			for (const u of users) all.push({
				id: u.id,
				email: u.email ?? null,
				phone: u.user_metadata?.phone ?? u.phone ?? null,
				created_at: u.created_at ?? null,
				last_sign_in_at: u.last_sign_in_at ?? null
			});
			if (users.length < perPage) break;
		}
		fetchedFromAuth = true;
	} catch (err) {
		console.warn("[adminListUsers] Service role admin auth listing failed or key missing, falling back to profiles table:", err);
	}
	let profileMap = /* @__PURE__ */ new Map();
	if (fetchedFromAuth) {
		const ids = all.map((u) => u.id);
		if (ids.length > 0) {
			const { data: profiles } = await context.supabase.from("profiles").select("id, full_name, phone, is_blocked").in("id", ids);
			for (const p of profiles ?? []) profileMap.set(p.id, {
				full_name: p.full_name,
				phone: p.phone,
				is_blocked: p.is_blocked
			});
		}
	} else {
		const { data: profiles } = await context.supabase.from("profiles").select("id, full_name, phone, is_blocked, created_at");
		for (const p of profiles ?? []) {
			profileMap.set(p.id, {
				full_name: p.full_name,
				phone: p.phone,
				is_blocked: p.is_blocked,
				created_at: p.created_at
			});
			all.push({
				id: p.id,
				email: null,
				phone: p.phone ?? null,
				created_at: p.created_at ?? null,
				last_sign_in_at: p.created_at ?? null
			});
		}
	}
	const now = Date.now();
	const ACTIVE_MS = 900 * 1e3;
	let activeCount = 0;
	const enriched = all.map((u) => {
		const prof = profileMap.get(u.id);
		const last = u.last_sign_in_at ? Date.parse(u.last_sign_in_at) : 0;
		const isActive = last > 0 && now - last <= ACTIVE_MS;
		if (isActive) activeCount++;
		return {
			...u,
			full_name: prof?.full_name ?? null,
			profile_phone: prof?.phone ?? null,
			is_blocked: prof?.is_blocked ?? false,
			is_active: isActive
		};
	});
	enriched.sort((a, b) => {
		const ta = a.last_sign_in_at ? Date.parse(a.last_sign_in_at) : 0;
		return (b.last_sign_in_at ? Date.parse(b.last_sign_in_at) : 0) - ta;
	});
	return {
		total: enriched.length,
		active: activeCount,
		users: enriched
	};
}
//#endregion
export { adminListUsers_createServerFn_handler, adminSetUserBlocked_createServerFn_handler, adminSetUserPassword_createServerFn_handler, moderatorListUsers_createServerFn_handler };
