import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useSetting } from "./admin-DdF3xehS.mjs";
import { l as TriangleAlert } from "../_libs/lucide-react.mjs";
import { o as formatIraqiWhatsAppNumber } from "./format-CTK49jpu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/legal-contact-Cir7kLl-.js
var import_jsx_runtime = require_jsx_runtime();
/**
* Shared contact block for the legal pages (/privacy and /terms).
*
* Contact details come from admin settings (Settings: owner name, address,
* email, WhatsApp number). Each falls back to a known-good value so a customer
* never sees a blank contact detail; the amber banner is driven by the RAW
* settings, so the operator is still told which ones are unset.
*/
var FALLBACK_OWNER = "Maktab Ali Chevrolet";
var FALLBACK_ADDRESS = "Erbil, Kurdistan Region, Iraq";
var FALLBACK_EMAIL = "aliskida816@gmail.com";
var FALLBACK_WA = "9647737959595";
function useLegalContact() {
	const rawOwner = useSetting("store_owner", "").trim();
	const rawAddress = useSetting("store_address", "").trim();
	const rawEmail = useSetting("store_email", "").trim();
	const rawWa = useSetting("whatsapp_number", "").trim();
	return {
		storeName: useSetting("store_name", "").trim() || FALLBACK_OWNER,
		ownerName: rawOwner || FALLBACK_OWNER,
		address: rawAddress || FALLBACK_ADDRESS,
		supportEmail: rawEmail || FALLBACK_EMAIL,
		waNumber: formatIraqiWhatsAppNumber(rawWa || FALLBACK_WA),
		missing: !rawOwner || !rawAddress || !rawEmail || !rawWa
	};
}
function MissingSettingsNotice() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 flex items-start gap-2 rounded-xl border border-amber-500/40 bg-amber-500/10 text-amber-800 dark:text-amber-200 p-3 text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Store owner details are not fully filled in yet. Please update them in the admin panel (Settings: owner name, address, email, WhatsApp number). Fallback values are shown below in the meantime." })]
	});
}
function ContactList({ ownerName, address, supportEmail, waNumber }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
		className: "list-none ps-0 space-y-1 mt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: ownerName }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: address }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
				"Email:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "text-gold underline",
					href: `mailto:${supportEmail}`,
					children: supportEmail
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
				"Phone:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "text-gold underline",
					href: `tel:+${waNumber}`,
					dir: "ltr",
					children: ["+", waNumber]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
				"WhatsApp:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "text-gold underline",
					href: `https://wa.me/${waNumber}`,
					target: "_blank",
					rel: "noopener noreferrer",
					dir: "ltr",
					children: ["+", waNumber]
				})
			] })
		]
	});
}
//#endregion
export { MissingSettingsNotice as n, useLegalContact as r, ContactList as t };
