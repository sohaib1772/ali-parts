import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Tt as ChevronLeft, ot as Flame, u as TrendingUp } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { r as bestSellersQuery } from "./queries-CNdOTkej.mjs";
import { r as useStorefrontFilters, t as applyStorefrontFilters } from "./storefront-filters-DpSWbFTB.mjs";
import { n as ProductCard, t as FilterBar } from "./filter-bar-BVrvoEnx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/best-sellers-BJnMgTac.js
var import_jsx_runtime = require_jsx_runtime();
function BestSellersPage() {
	const { data: allProducts } = useSuspenseQuery(bestSellersQuery());
	const { filters } = useStorefrontFilters();
	const products = applyStorefrontFilters(allProducts, filters);
	const sold = products.filter((p) => (p.sales_count ?? 0) > 0);
	const others = products.filter((p) => (p.sales_count ?? 0) === 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "الأكثر مبيعاً",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-1 text-xs text-muted-foreground mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-3.5 rotate-180" }), " الرئيسية"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 mb-4 p-3 rounded-2xl bg-destructive/10 border border-destructive/20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-10 rounded-xl bg-destructive/20 border border-destructive/30 grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-5 text-destructive" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-base font-extrabold leading-tight",
							children: "الأكثر مبيعاً"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground",
							children: "مرتبة حسب المبيعات الفعلية"
						})]
					})]
				}),
				sold.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-sm font-extrabold",
						children: [
							"الأعلى مبيعاً (",
							sold.length,
							")"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mb-6",
					children: sold.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							i < 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute -top-1 -start-1 z-10 size-7 rounded-full bg-gradient-gold text-navy text-xs font-black grid place-items-center shadow-gold border-2 border-card",
								children: i + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute top-2 end-2 z-10 px-2 py-0.5 rounded-full bg-navy/90 text-primary-foreground text-[10px] font-bold",
								children: [
									"بيع ",
									p.sales_count,
									"×"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p })
						]
					}, p.id))
				})] }),
				others.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-extrabold mb-3",
					children: "منتجات أخرى"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 pb-8",
					children: others.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				})] }),
				products.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center text-muted-foreground text-sm py-16",
					children: "لا توجد منتجات حالياً."
				})
			]
		})
	});
}
//#endregion
export { BestSellersPage as component };
