import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { W as MessageCircle } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { s as whatsappLink } from "./format-CTK49jpu.mjs";
import { n as MissingSettingsNotice, r as useLegalContact, t as ContactList } from "./legal-contact-Cir7kLl-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-Dlv6De7c.js
var import_jsx_runtime = require_jsx_runtime();
var LAST_UPDATED = "21 July 2026";
function TermsPage() {
	const { storeName, ownerName, address, supportEmail, waNumber, missing } = useLegalContact();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "الشروط والأحكام",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 pt-4 pb-8 md:max-w-2xl md:mx-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				dir: "ltr",
				className: "bg-card rounded-2xl border border-border p-5 shadow-card space-y-5 text-sm leading-relaxed text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-lg font-black text-navy mb-1",
						children: "Terms and Conditions"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Last updated:" }),
							" ",
							LAST_UPDATED
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Welcome to the ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: storeName }),
						" app. By using the app you agree to the following terms and conditions. Please read them carefully; if you do not agree to any provision, please do not use the app."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "1. Definitions",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"\"The App\": the ",
									storeName,
									" application on mobile and web."
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "\"The User\": any person who creates an account or uses the App." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "\"The Order\": any purchase submitted through the App." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									"\"The Operator\": ",
									ownerName,
									", the legal owner and operator of the App."
								] })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "2. Use of the App",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You must be 18 years of age or older to create an account." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You undertake to provide true and accurate information about your identity and address." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Using the App for any unlawful purpose, or for any purpose contrary to Apple App Store or Google Play policies, is prohibited." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Attempting to hack the App, misusing the Service, or posting offensive content is prohibited." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The Operator may suspend or delete any account that violates these Terms without prior notice." })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "3. Orders and Prices",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "All prices are in Iraqi Dinars and cover what is stated on the product page." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Prices are subject to change at any time without prior notice; the price displayed at the time the order is confirmed is the price that applies." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Product availability depends on stock; we reserve the right to cancel or amend an order if a product is out of stock." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "An order is considered confirmed once you receive a confirmation message from the Operator by WhatsApp or by telephone." })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "4. Payment and Delivery",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Payment is made on delivery, in cash, in Iraqi Dinars." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Delivery time and cost vary by governorate, as shown on the shipping page." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The User must ensure that the delivery address and phone number are correct and that they are available to receive the order. If an order cannot be delivered because the User provided an incorrect address or an incorrect phone number, or because the User was unreachable or unavailable to receive it, the User is responsible for the delivery cost of that failed attempt." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "An unpaid delivery cost of this kind is added to the User's next order, and the Operator may decline to accept further orders from the User until it has been settled." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The User has the right to inspect the part in front of the delivery agent before paying." })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "5. Replacement and Returns",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A part bought from stock may be replaced or returned within three (3) days of the date of receipt, provided it is in its original condition, not installed and not used, and in its complete packaging." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Replacement does not cover electrical parts once the packaging has been opened." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Special orders are not returnable." }),
									" A special order is either of the following, and in each case the three (3) day right of return above does not apply:",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "list-[circle] ps-6 space-y-1 mt-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A part arranged directly with us by telephone or WhatsApp, rather than ordered through the normal ordering flow in the App." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A part that was not in stock at the time of ordering and was brought in from a supplier specifically to fulfil the User's order — including where that order was placed through the App." })]
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A part that was in stock at the time of ordering and bought through the App in the normal way is not a special order, and keeps the three (3) day right of return set out above." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A part with a manufacturing defect is replaced free of charge after inspection." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "To request a replacement, use the \"Replacement Requests\" section inside the App or contact us by WhatsApp." })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "6. Warranty",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The warranty is limited to what is expressly stated on the product page or on the purchase invoice. The warranty does not cover damage resulting from incorrect installation, improper use, modification, or accidents." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "7. Intellectual Property",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "All contents of the App (logo, text, images, design, code) are the property of the Operator and are protected under copyright law." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Copying or reusing any content from the App without prior written permission is prohibited." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Trade names (Chevrolet, GMC, Cadillac and others) are registered trademarks of their respective owners. We use them solely to describe part compatibility, without any claim of affiliation with, or official sponsorship by, those companies." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "We are not an authorised official agent of any of these companies unless expressly stated otherwise." })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "8. User-Submitted Content",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Any comment, image or review you post within the App grants the Operator a non-exclusive licence to display it within the App. You are responsible for the legality of what you post, and you may not post offensive content or content that infringes the rights of others." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "9. Limitation of Liability",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The App is provided \"as is\", without any implied warranties as to the continuity of the Service or that it will be free of errors." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The Operator bears no liability for indirect or consequential damages arising from use of the App." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The Operator's maximum liability in respect of any order is the amount paid for that order." })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "10. Compliance with App Store Policies",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The App complies with Apple App Store and Google Play policies, including their requirements for transparency, data protection, and user rights. Any provision of these Terms that conflicts with the stores' policies is automatically amended so as to conform with them." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "11. Governing Law and Dispute Resolution",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "These Terms are governed by the laws of the Republic of Iraq. Any dispute arising from use of the App shall first be the subject of efforts to resolve it amicably; failing that, it shall be referred to the competent Iraqi courts." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "12. Changes to These Terms",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The Operator may amend these Terms at any time. Any amendment will be published within the App together with an updated \"Last updated\" date, and your continued use of the App constitutes acceptance of the amended version." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "13. Contact",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "For any enquiry or legal complaint:" }),
							missing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissingSettingsNotice, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactList, {
								ownerName,
								address,
								supportEmail,
								waNumber
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappLink("I have a legal enquiry", waNumber),
								target: "_blank",
								rel: "noopener noreferrer",
								className: "mt-3 inline-flex items-center gap-2 bg-navy text-primary-foreground text-xs font-bold px-4 py-2 rounded-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5" }), " Contact us on WhatsApp"]
							})
						]
					})
				]
			})
		})
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-bold text-gold mb-2",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm leading-relaxed",
		children
	})] });
}
//#endregion
export { TermsPage as component };
