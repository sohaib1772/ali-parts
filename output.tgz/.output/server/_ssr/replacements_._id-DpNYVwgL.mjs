import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as uploadWithProgress } from "./upload-with-progress-B1YdROuk.mjs";
import { g as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Repeat, B as PackageX, O as Search, R as Paperclip, Rt as ArrowRight, St as CircleCheck, X as LoaderCircle, ct as File, et as Image, gt as Clock, h as ThumbsDown, lt as FileText, m as ThumbsUp, pt as Download, s as Upload, t as X, v as StickyNote } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as Progress } from "./progress-DOIEKRJF.mjs";
import { t as Route } from "./replacements_._id-BREYh5lP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/replacements_._id-DpNYVwgL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS_META = {
	pending: {
		label: "بانتظار المراجعة",
		icon: Clock,
		color: "amber"
	},
	in_review: {
		label: "قيد المراجعة",
		icon: Search,
		color: "blue"
	},
	approved: {
		label: "مقبول",
		icon: ThumbsUp,
		color: "emerald"
	},
	rejected: {
		label: "مرفوض",
		icon: ThumbsDown,
		color: "rose"
	},
	resolved: {
		label: "منجز",
		icon: CircleCheck,
		color: "navy"
	}
};
function iconTone(color, active) {
	if (!active) return "bg-muted text-muted-foreground";
	switch (color) {
		case "amber": return "bg-amber-500 text-white shadow-md";
		case "blue": return "bg-blue-500 text-white shadow-md";
		case "emerald": return "bg-emerald-500 text-white shadow-md";
		case "rose": return "bg-rose-500 text-white shadow-md";
		case "navy": return "bg-gradient-gold text-navy shadow-gold";
		default: return "bg-navy text-primary-foreground";
	}
}
function formatDT(iso) {
	return new Date(iso).toLocaleString("ar-IQ", {
		dateStyle: "medium",
		timeStyle: "short"
	});
}
function ReplacementDetail() {
	const { id } = Route.useParams();
	const router = useRouter();
	const qc = useQueryClient();
	const { data: request, isLoading, error } = useQuery({
		queryKey: ["replacement", id],
		queryFn: async () => {
			const { data, error } = await supabase.from("replacement_requests").select("*").eq("id", id).maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	const { data: log = [] } = useQuery({
		queryKey: ["replacement-log", id],
		queryFn: async () => {
			const { data, error } = await supabase.from("replacement_status_log").select("*").eq("request_id", id).order("created_at", { ascending: true });
			if (error) throw error;
			return data ?? [];
		}
	});
	(0, import_react.useEffect)(() => {
		const ch = supabase.channel(`replacement-${id}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "replacement_requests",
			filter: `id=eq.${id}`
		}, () => {
			qc.invalidateQueries({ queryKey: ["replacement", id] });
		}).on("postgres_changes", {
			event: "INSERT",
			schema: "public",
			table: "replacement_status_log",
			filter: `request_id=eq.${id}`
		}, () => {
			qc.invalidateQueries({ queryKey: ["replacement-log", id] });
		}).subscribe();
		return () => {
			supabase.removeChannel(ch);
		};
	}, [id, qc]);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen grid place-items-center text-muted-foreground",
		children: "جاري التحميل..."
	});
	if (error || !request) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen grid place-items-center px-4 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageX, { className: "size-12 text-muted-foreground mx-auto mb-3" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-lg font-bold mb-1",
				children: "لم يتم العثور على الطلب"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/replacements",
				className: "text-gold text-sm font-bold",
				children: "عودة لطلبات الاستبدال"
			})
		] })
	});
	const meta = STATUS_META[request.status];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "sticky top-0 z-20 bg-gradient-navy text-primary-foreground shadow-luxe",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-md md:max-w-3xl lg:max-w-5xl px-4 py-4 flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => router.history.back(),
						className: "size-9 rounded-full bg-white/10 grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-bold",
							children: "تفاصيل طلب الاستبدال"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[10px] text-gold font-mono",
							children: ["#", String(request.id).slice(0, 8)]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-5 text-gold" })
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-md md:max-w-3xl lg:max-w-5xl px-4 pt-4 space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card rounded-2xl border border-border p-4 shadow-card flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `size-12 rounded-full grid place-items-center ${iconTone(meta.color, true)}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(meta.icon, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "الحالة الحالية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base font-black text-navy",
							children: meta.label
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card rounded-2xl border border-border p-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-bold text-gold mb-1",
						children: "المنتج المطلوب استبداله"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-bold",
						children: request.product_name_ar ?? "منتج غير معروف"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card rounded-2xl border border-border p-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold text-gold",
							children: "سبب الاستبدال"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm whitespace-pre-wrap",
						children: request.reason
					})]
				}),
				request.admin_notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card rounded-2xl border border-gold/30 p-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "size-4 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold text-gold",
							children: "رد قسم الاستبدال"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm whitespace-pre-wrap",
						children: request.admin_notes
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttachmentsSection, { request }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card rounded-2xl border border-border p-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-bold text-gold mb-4",
						children: "سجل الحالات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute start-5 top-2 bottom-2 w-px bg-border",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-4",
							children: log.map((entry, i) => {
								const em = STATUS_META[entry.status];
								const isLast = i === log.length - 1;
								const Icon = em?.icon ?? Clock;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-start gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `relative z-10 size-10 rounded-full grid place-items-center shrink-0 ${iconTone(em?.color ?? "navy", true)}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 pt-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: `text-sm font-bold ${isLast ? "text-navy" : "text-foreground"}`,
												children: em?.label ?? entry.status
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] text-muted-foreground mt-0.5",
												children: formatDT(entry.created_at)
											}),
											entry.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-1.5 text-xs bg-muted/50 rounded-lg p-2 whitespace-pre-wrap",
												children: entry.note
											}),
											isLast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[10px] text-gold font-bold mt-1",
												children: "الحالة الحالية"
											})
										]
									})]
								}, entry.id);
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center text-[11px] text-muted-foreground",
					children: ["أُنشئ الطلب في ", formatDT(request.created_at)]
				})
			]
		})]
	});
}
var MAX_ATTACHMENTS = 6;
var MAX_FILE_MB = 10;
var ACCEPT = "image/*,application/pdf,.doc,.docx,.xls,.xlsx,.txt";
function fileExt(name) {
	const i = name.lastIndexOf(".");
	return i >= 0 ? name.slice(i + 1).toLowerCase() : "";
}
function isImageExt(ext) {
	return [
		"png",
		"jpg",
		"jpeg",
		"webp",
		"gif",
		"heic"
	].includes(ext);
}
function baseName(p) {
	const parts = p.split("/");
	return parts[parts.length - 1] ?? p;
}
function AttachmentsSection({ request }) {
	const qc = useQueryClient();
	const { userId } = useAuth();
	const inputRef = (0, import_react.useRef)(null);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [removing, setRemoving] = (0, import_react.useState)(null);
	const [urls, setUrls] = (0, import_react.useState)({});
	const [uploadQueue, setUploadQueue] = (0, import_react.useState)([]);
	const paths = (0, import_react.useMemo)(() => Array.isArray(request.attachments) ? request.attachments : [], [request.attachments]);
	const isOwner = userId === request.user_id;
	const canUpload = isOwner && paths.length < MAX_ATTACHMENTS;
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			if (paths.length === 0) {
				setUrls({});
				return;
			}
			const { data, error } = await supabase.storage.from("replacement-attachments").createSignedUrls(paths, 3600);
			if (error || cancelled) return;
			const map = {};
			data?.forEach((d) => {
				if (d.path && d.signedUrl) map[d.path] = d.signedUrl;
			});
			setUrls(map);
		})();
		return () => {
			cancelled = true;
		};
	}, [paths]);
	const handlePick = () => inputRef.current?.click();
	const handleFiles = async (files) => {
		if (!files || files.length === 0 || !userId || uploading) return;
		const slots = MAX_ATTACHMENTS - paths.length;
		const list = Array.from(files).slice(0, slots);
		if (list.length === 0) {
			toast.error(`الحد الأقصى ${MAX_ATTACHMENTS} ملفات`);
			return;
		}
		setUploading(true);
		const initialQueue = list.map((f) => ({
			name: f.name,
			size: f.size,
			progress: 0,
			status: "uploading"
		}));
		setUploadQueue(initialQueue);
		const uploaded = [];
		for (let i = 0; i < list.length; i++) {
			const file = list[i];
			if (file.size > MAX_FILE_MB * 1024 * 1024) {
				toast.error(`${file.name}: يتجاوز ${MAX_FILE_MB} ميغابايت`);
				setUploadQueue((q) => q.map((it, idx) => idx === i ? {
					...it,
					status: "error"
				} : it));
				continue;
			}
			const ext = fileExt(file.name) || "bin";
			const safeName = file.name.replace(/[^\w.\-]+/g, "_").slice(0, 80);
			const key = `${userId}/${request.id}/${Date.now()}-${crypto.randomUUID().slice(0, 6)}-${safeName || "file." + ext}`;
			try {
				await uploadWithProgress("replacement-attachments", key, file, (pct) => {
					setUploadQueue((q) => q.map((it, idx) => idx === i ? {
						...it,
						progress: Math.round(pct * 100)
					} : it));
				});
				setUploadQueue((q) => q.map((it, idx) => idx === i ? {
					...it,
					progress: 100,
					status: "done"
				} : it));
				uploaded.push(key);
			} catch {
				toast.error(`تعذّر رفع ${file.name}`);
				setUploadQueue((q) => q.map((it, idx) => idx === i ? {
					...it,
					status: "error"
				} : it));
				continue;
			}
		}
		if (uploaded.length > 0) {
			const next = [...paths, ...uploaded];
			const { error } = await supabase.from("replacement_requests").update({ attachments: next }).eq("id", request.id);
			if (error) toast.error("تعذّر حفظ المرفقات");
			else {
				toast.success("تم رفع المرفقات");
				qc.invalidateQueries({ queryKey: ["replacement", request.id] });
			}
		}
		setUploading(false);
		setTimeout(() => setUploadQueue([]), 1200);
		if (inputRef.current) inputRef.current.value = "";
	};
	const removeAttachment = async (path) => {
		if (!isOwner) return;
		setRemoving(path);
		await supabase.storage.from("replacement-attachments").remove([path]);
		const next = paths.filter((p) => p !== path);
		const { error } = await supabase.from("replacement_requests").update({ attachments: next }).eq("id", request.id);
		setRemoving(null);
		if (error) {
			toast.error("تعذّر حذف المرفق");
			return;
		}
		toast.success("تم حذف المرفق");
		qc.invalidateQueries({ queryKey: ["replacement", request.id] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-card rounded-2xl border border-border p-4 shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 mb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-4 text-gold" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-bold text-gold",
						children: "مرفقات (صور / مستندات)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[10px] text-muted-foreground ms-auto",
						children: [
							paths.length,
							"/",
							MAX_ATTACHMENTS
						]
					})
				]
			}),
			paths.length === 0 && !canUpload && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted-foreground text-center py-3",
				children: "لا توجد مرفقات"
			}),
			paths.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2 mb-3",
				children: paths.map((p) => {
					const img = isImageExt(fileExt(p));
					const url = urls[p];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative group aspect-square rounded-xl border border-border overflow-hidden bg-muted",
						children: [img && url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: url,
							target: "_blank",
							rel: "noreferrer",
							className: "block size-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: url,
								alt: "",
								className: "size-full object-cover"
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: url,
							target: "_blank",
							rel: "noreferrer",
							className: "size-full flex flex-col items-center justify-center gap-1 p-2 text-center hover:bg-muted/70",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(File, { className: "size-6 text-muted-foreground" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground line-clamp-2 break-all",
									children: baseName(p).slice(baseName(p).indexOf("-", 15) + 1) || baseName(p)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3 text-gold" })
							]
						}), isOwner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => removeAttachment(p),
							disabled: removing === p,
							"aria-label": "حذف المرفق",
							className: "absolute top-1 start-1 size-6 rounded-full bg-black/60 text-white grid place-items-center hover:bg-destructive disabled:opacity-50",
							children: removing === p ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
						})]
					}, p);
				})
			}),
			canUpload && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: inputRef,
					type: "file",
					accept: ACCEPT,
					multiple: true,
					className: "hidden",
					onChange: (e) => handleFiles(e.target.files),
					disabled: uploading
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: handlePick,
					disabled: uploading,
					className: "w-full h-11 rounded-xl border-2 border-dashed border-gold/50 text-navy text-sm font-bold flex items-center justify-center gap-2 hover:bg-gold/5 disabled:opacity-50",
					children: uploading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), " جاري الرفع..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4 text-gold" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-4 text-gold" }),
						"إرفاق صور أو مستندات"
					] })
				}),
				uploadQueue.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2",
					children: [uploadQueue.map((it, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-muted/40 p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(File, { className: "size-3.5 text-gold shrink-0" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 truncate text-[11px] font-bold text-navy",
									children: it.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-muted-foreground",
									children: it.status === "error" ? "فشل" : it.status === "done" ? "تم ✓" : `${it.progress}%`
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: it.status === "error" ? 0 : it.progress,
							className: `h-1.5 ${it.status === "error" ? "bg-rose-100" : ""}`
						})]
					}, idx)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2 pt-1",
						children: uploadQueue.filter((it) => it.status === "uploading").map((_, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-square rounded-xl" }, idx))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[10px] text-muted-foreground text-center mt-1.5",
					children: [
						"صور، PDF، Word، Excel — حتى ",
						MAX_FILE_MB,
						" ميغابايت لكل ملف"
					]
				})
			] })
		]
	});
}
//#endregion
export { ReplacementDetail as component };
