import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { m as productsByCategoryQuery, s as categoriesQuery } from "./queries-CNdOTkej.mjs";
import { r as useStorefrontFilters, t as applyStorefrontFilters } from "./storefront-filters-DpSWbFTB.mjs";
import { n as ProductCard, t as FilterBar } from "./filter-bar-DjQwTwqA.mjs";
import { t as Route } from "./category._id-Brwap3Nn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category._id-CplIa7wC.js
var import_jsx_runtime = require_jsx_runtime();
function CategoryPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const { data: products } = useSuspenseQuery(productsByCategoryQuery(id));
	const { data: categories } = useSuspenseQuery(categoriesQuery());
	const cat = categories.find((c) => c.id === id);
	const { filters } = useStorefrontFilters();
	const filtered = applyStorefrontFilters(products, {
		...filters,
		category: ""
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: cat?.name_ar ?? "التصنيف",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, { categoryOverride: {
						value: id,
						onChange: (newId) => newId ? navigate({
							to: "/category/$id",
							params: { id: newId }
						}) : navigate({ to: "/products" })
					} })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground mb-3",
					children: [filtered.length, " منتج"]
				}),
				filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center text-muted-foreground py-16 text-sm",
					children: "لا توجد منتجات مطابقة في هذا التصنيف"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3",
					children: filtered.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				})
			]
		})
	});
}
//#endregion
export { CategoryPage as component };
