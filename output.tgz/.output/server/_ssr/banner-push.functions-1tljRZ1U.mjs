import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import { n as requireAdminOtp } from "./require-admin-otp-DgUpC_62.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/banner-push.functions-1tljRZ1U.js
var broadcastBannerPush_createServerFn_handler = createServerRpc({
	id: "b9e529f0850c2850bc6f721791444437b5b772c146c5078346159706e568634b",
	name: "broadcastBannerPush",
	filename: "src/lib/banner-push.functions.ts"
}, (opts) => broadcastBannerPush.__executeServer(opts));
var broadcastBannerPush = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => {
	if (!input || typeof input.bannerId !== "string" || !input.bannerId) throw new Error("bannerId required");
	return input;
}).handler(broadcastBannerPush_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: isAdmin } = await supabase.rpc("has_role", {
		_user_id: userId,
		_role: "admin"
	});
	if (!isAdmin) throw new Error("Forbidden");
	await requireAdminOtp(context);
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { sendBroadcastPush } = await import("./web-push.server-CiXMek4O.mjs");
	const { data: banner, error } = await supabaseAdmin.from("banners").select("id, title_ar, subtitle_ar, video_url").eq("id", data.bannerId).maybeSingle();
	if (error || !banner) throw new Error(error?.message ?? "Banner not found");
	const isReel = !!banner.video_url;
	const title = isReel ? "ريلز جديد 🎬" : "عرض حصري جديد 🎉";
	const body = banner.title_ar || banner.subtitle_ar || (isReel ? "شاهد أحدث الريلز الآن" : "شاهد أحدث العروض الحصرية الآن");
	try {
		return {
			ok: true,
			...await sendBroadcastPush({
				title,
				body,
				url: "/offers",
				tag: `banner-${banner.id}`
			})
		};
	} catch (err) {
		console.error("[push] broadcast failed", err);
		return { ok: false };
	}
});
//#endregion
export { broadcastBannerPush_createServerFn_handler };
