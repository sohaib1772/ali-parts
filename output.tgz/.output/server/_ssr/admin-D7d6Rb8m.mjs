import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as useAdminAccessStatus, c as useSetting, l as useStaffPermissions, n as uploadMediaFile, o as useIsAdmin, r as uploadProductImage, t as settingsQuery } from "./admin-DdF3xehS.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Repeat, Bt as Activity, C as ShieldCheck, Ct as CircleCheckBig, Dt as Check, E as Settings, Et as ChevronDown, G as Megaphone, I as Phone, J as MailCheck, K as MapPin, L as Pencil, Lt as ArrowUp, M as Receipt, O as Search, P as Plus, Pt as Ban, St as CircleCheck, X as LoaderCircle, Z as KeyRound, _t as ClipboardList, a as Users, bt as CircleX, d as Trash, et as Image, f as Trash2, g as Tags, gt as Clock, ht as Copy, j as RefreshCw, kt as Boxes, l as TriangleAlert, n as Webhook, nt as History, o as User, q as MailX, s as Upload, st as Film, v as StickyNote, w as ShieldAlert, wt as ChevronUp, y as Sparkles, z as Package, zt as ArrowDown } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { a as carModelsQuery, i as brandsQuery, n as bannersQuery, s as categoriesQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD } from "./format-CTK49jpu.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Button } from "./button-Ccjfysxk.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-DTjZvKIx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { a as objectType, i as numberType, n as enumType, o as stringType, t as booleanType } from "../_libs/zod.mjs";
import { a as clearVideoCache, f as useServerFn, i as adminSetUserPassword, n as adminListUsers, o as createSsrRpc, r as adminSetUserBlocked, s as getVideoCacheSize, t as Textarea } from "./admin.functions-ByyqQhlH.mjs";
import { r as validateExternalApiConfig } from "./external-api-D6j_ceOa.mjs";
import { n as broadcastPricesChanged, t as Label } from "./label-DUtvElRz.mjs";
import { r as statusLabel, t as statusColor } from "./order-status-Chx_uF3Y.mjs";
import { a as InvoicePreviewDialog, i as DialogTitle, n as DialogContent, o as PrintableInvoice, r as DialogHeader, t as Dialog } from "./printable-invoice-DqxFZT5I.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
import { a as SelectItemIndicator, c as SelectPortal, d as SelectSeparator$1, f as SelectTrigger$1, i as SelectItem$1, l as SelectScrollDownButton$1, m as SelectViewport, n as SelectContent$1, o as SelectItemText, p as SelectValue$1, r as SelectIcon, s as SelectLabel$1, t as Select$1, u as SelectScrollUpButton$1 } from "../_libs/@radix-ui/react-select+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-D7d6Rb8m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0") })
}));
Switch.displayName = Switch$1.displayName;
var Select = Select$1;
var SelectValue = SelectValue$1;
var SelectTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger$1, {
	ref,
	className: cn("flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectIcon, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 opacity-50" })
	})]
}));
SelectTrigger.displayName = SelectTrigger$1.displayName;
var SelectScrollUpButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-4 w-4" })
}));
SelectScrollUpButton.displayName = SelectScrollUpButton$1.displayName;
var SelectScrollDownButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })
}));
SelectScrollDownButton.displayName = SelectScrollDownButton$1.displayName;
var SelectContent = import_react.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent$1, {
	ref,
	className: cn("relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
	position,
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewport, {
			className: cn("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton, {})
	]
}) }));
SelectContent.displayName = SelectContent$1.displayName;
var SelectLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectLabel$1, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", className),
	...props
}));
SelectLabel.displayName = SelectLabel$1.displayName;
var SelectItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem$1, {
	ref,
	className: cn("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemText, { children })]
}));
SelectItem.displayName = SelectItem$1.displayName;
var SelectSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectSeparator$1, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
SelectSeparator.displayName = SelectSeparator$1.displayName;
var runDiagnostics = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("ed83d164a000008d15ac777f49b39247f1ec8df8ace47eb0795109e67db92d76"));
var VALID_STATUSES = [
	"pending",
	"in_review",
	"approved",
	"rejected",
	"resolved"
];
var adminUpdateReplacementStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => {
	if (!input || typeof input.id !== "string" || !input.id) throw new Error("id required");
	if (!VALID_STATUSES.includes(input.status)) throw new Error("invalid status");
	return input;
}).handler(createSsrRpc("b0a7f145ec6f9b1777b18bc17b2fe54867b63e8839a7fc7e84b771672fe5cdfa"));
var listAdminOtpEvents = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ limit: numberType().int().min(1).max(200).optional() }).parse(d ?? {})).handler(createSsrRpc("6b480379be9faee628a1ae09930e0d23e93af156b0dc47bfbe8800f864a21dc0"));
var StatusInput = objectType({ device_id: stringType().min(1).max(128).optional() });
var adminOtpStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => StatusInput.parse(d ?? {})).handler(createSsrRpc("954ddf5580f8b50b7142bf512d02f1885aa19e6737aad84b9b959c7c55e1079d"));
var requestAdminOtp = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("eccc50d0c1265695454be6c92edd19ad35bed234a6f04e5f9417c322311058bb"));
var VerifyInput = objectType({
	code: stringType().regex(/^\d{6}$/, "رمز غير صالح"),
	remember: booleanType().optional(),
	device_id: stringType().min(1).max(128)
});
var verifyAdminOtp = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => VerifyInput.parse(d)).handler(createSsrRpc("e9609cac5294c8f30c4907805bb986c53cdef123f23e21f6511a6689f7883a79"));
var getExternalApiConfig = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("6c49bb0238b91b871165aa77feb8aee3320ff6649c3acb78372f82b46f763ec2"));
var TestInput = objectType({ endpointId: stringType() });
var testExternalApi = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => TestInput.parse(d)).handler(createSsrRpc("52dc8af364db74059a235f303e6179f5005b9ae2df01dc0ac1d56a836f25d925"));
/**
* Detect whether an MP4 is "faststart" — its `moov` atom (the index) sits before
* the `mdat` atom (the media data). Faststart lets the browser begin playback
* while the file is still downloading (progressive streaming). If `moov` is at
* the END (the default for many editors/phone exports), the browser must
* download the WHOLE file before it can play — no streaming, no seeking until
* fully loaded.
*
* Reads only box HEADERS via File.slice (8–16 bytes each) and returns as soon as
* it sees `moov` or `mdat`, so it is effectively O(1) in file size — a 50MB file
* costs a couple of tiny reads.
*
* WebM has no `moov`/faststart concept (it is inherently streamable), so callers
* should only run this for MP4 and allow WebM through.
*/
async function isFaststartMp4(file) {
	const fileSize = file.size;
	let offset = 0;
	for (let guard = 0; guard < 64 && offset + 8 <= fileSize; guard++) {
		const head = await file.slice(offset, offset + 16).arrayBuffer();
		const dv = new DataView(head);
		if (dv.byteLength < 8) break;
		let size = dv.getUint32(0);
		const type = String.fromCharCode(dv.getUint8(4), dv.getUint8(5), dv.getUint8(6), dv.getUint8(7));
		let headerSize = 8;
		if (size === 1) {
			if (dv.byteLength < 16) break;
			const hi = dv.getUint32(8);
			const lo = dv.getUint32(12);
			size = hi * 2 ** 32 + lo;
			headerSize = 16;
		} else if (size === 0) size = fileSize - offset;
		if (!/^[\x20-\x7e]{4}$/.test(type)) break;
		if (type === "moov") return true;
		if (type === "mdat") return false;
		if (size < headerSize) break;
		offset += size;
	}
	return true;
}
/** Audiences understood by `admin_broadcast_recipients`. Extending targeting
*  means adding a branch there and a member here — no change to the call shape. */
var AudienceInput = objectType({
	audience: enumType([
		"all_customers",
		"all_users",
		"single_user"
	]).default("all_customers"),
	user_id: stringType().uuid().nullable().optional()
});
var SendInput = AudienceInput.extend({
	title: stringType().trim().min(1, "العنوان مطلوب").max(80),
	body: stringType().trim().max(300).default("")
});
/** How many recipients the current audience resolves to. Drives the count the
*  admin sees before confirming. */
var adminBroadcastAudienceCount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => AudienceInput.parse(d ?? {})).handler(createSsrRpc("ea9d5bed95151a7f8492684ea3271028165a9bc6902355796758b7de4a06fa27"));
/** Send the broadcast. Returns the number of rows actually written. */
var sendAdminBroadcast = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => SendInput.parse(d)).handler(createSsrRpc("bc748e03115448b8d6104579748f984dfee1b28b5bb7fe47d0603e7a9fcb2e37"));
function getAdminDeviceId() {
	if (typeof window === "undefined") return "";
	try {
		const KEY = "admin_device_id";
		let id = window.localStorage.getItem(KEY);
		if (!id) {
			id = crypto.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
			window.localStorage.setItem(KEY, id);
		}
		return id;
	} catch {
		return "";
	}
}
var STATUSES = [
	"received",
	"preparing",
	"packed",
	"shipped",
	"out_for_delivery",
	"delivered",
	"cancelled"
];
var OTP_EVENT_LABEL = {
	request: {
		text: "طلب رمز",
		tone: "info"
	},
	request_rate_limited: {
		text: "طلب متكرر (حد المعدل)",
		tone: "warn"
	},
	request_failed: {
		text: "فشل الإرسال",
		tone: "err"
	},
	verify_success: {
		text: "تحقق ناجح",
		tone: "ok"
	},
	verify_wrong_code: {
		text: "رمز خاطئ",
		tone: "warn"
	},
	verify_no_active: {
		text: "لا يوجد رمز نشط",
		tone: "warn"
	},
	verify_expired: {
		text: "رمز منتهي",
		tone: "warn"
	},
	verify_max_attempts: {
		text: "تجاوز المحاولات",
		tone: "err"
	},
	revoke: {
		text: "إلغاء الجلسة",
		tone: "info"
	}
};
function AdminOtpEventsLog() {
	const listFn = useServerFn(listAdminOtpEvents);
	const { data: rows = [], isLoading, refetch, isFetching } = useQuery({
		queryKey: ["admin", "otp-events"],
		queryFn: () => listFn({ data: { limit: 200 } })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-bold",
				children: "سجل أحداث OTP للإدارة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] text-muted-foreground",
				children: "آخر 200 حدث. يشمل الطلبات، النجاح، الأخطاء، وتجاوز المحاولات."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				onClick: () => refetch(),
				disabled: isFetching,
				children: [isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ms-1",
					children: "تحديث"
				})]
			})]
		}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "py-8 text-center text-muted-foreground text-sm",
			children: "جارٍ التحميل…"
		}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "py-8 text-center text-muted-foreground text-sm",
			children: "لا توجد أحداث بعد."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-1.5",
			children: rows.map((r) => {
				const label = OTP_EVENT_LABEL[r.event] ?? {
					text: r.event,
					tone: "info"
				};
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border p-2.5 text-xs bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 flex-wrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-medium ${label.tone === "ok" ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" : label.tone === "warn" ? "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30" : label.tone === "err" ? "bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/30" : "bg-muted text-foreground/80 border-border"}`,
							children: label.text
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground tabular-nums",
							dir: "ltr",
							children: new Date(r.created_at).toLocaleString("ar-IQ")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1.5 grid grid-cols-1 sm:grid-cols-2 gap-1 text-[11px] text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								dir: "ltr",
								className: "truncate",
								children: ["user: ", r.user_id ? r.user_id.slice(0, 8) : "—"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								dir: "ltr",
								className: "truncate",
								children: ["device: ", r.device_id ? r.device_id.slice(0, 10) : "—"]
							}),
							r.detail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-full truncate",
								dir: "auto",
								children: ["تفاصيل: ", r.detail]
							})
						]
					})]
				}, r.id);
			})
		})]
	});
}
function BlockLogAdmin() {
	const qc = useQueryClient();
	const [unblockingId, setUnblockingId] = (0, import_react.useState)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const { data: blocked = [], isLoading: loadingBlocked } = useQuery({
		queryKey: ["admin", "blocked-users"],
		queryFn: async () => {
			const { data, error } = await supabase.from("profiles").select("id, full_name, phone").eq("is_blocked", true).order("full_name", { ascending: true });
			if (error) throw error;
			return data ?? [];
		}
	});
	const unblock = async (uid) => {
		if (unblockingId) return;
		setUnblockingId(uid);
		try {
			await adminSetUserBlocked({ data: {
				user_id: uid,
				blocked: false
			} });
			toast.success("تم رفع الحظر");
			qc.invalidateQueries({ queryKey: ["admin", "blocked-users"] });
			qc.invalidateQueries({ queryKey: ["admin", "block-log"] });
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "تعذر رفع الحظر");
		} finally {
			setUnblockingId(null);
		}
	};
	const { data: entries = [], isLoading } = useQuery({
		queryKey: ["admin", "block-log"],
		queryFn: async () => {
			const { data, error } = await supabase.from("user_block_log").select("id, user_id, actor_id, action, created_at").order("created_at", { ascending: false }).limit(200);
			if (error) throw error;
			return data ?? [];
		}
	});
	const ids = Array.from(new Set(entries.flatMap((e) => [e.user_id, e.actor_id]).filter(Boolean)));
	const { data: profiles = [] } = useQuery({
		queryKey: [
			"admin",
			"block-log-profiles",
			ids
		],
		enabled: ids.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("profiles").select("id, full_name, phone").in("id", ids);
			if (error) throw error;
			return data ?? [];
		}
	});
	const nameMap = new Map(profiles.map((p) => [p.id, p]));
	const userIds = Array.from(new Set(entries.map((e) => e.user_id).filter(Boolean)));
	const { data: notifs = [] } = useQuery({
		queryKey: [
			"admin",
			"block-log-notifs",
			userIds
		],
		enabled: userIds.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("notifications").select("id, user_id, title, read_at, created_at").eq("type", "account_status").in("user_id", userIds).order("created_at", { ascending: false }).limit(500);
			if (error) throw error;
			return data ?? [];
		}
	});
	const matchNotif = (uid, iso) => {
		const t = new Date(iso).getTime();
		let best = null;
		let bestDiff = Infinity;
		for (const n of notifs) {
			if (n.user_id !== uid) continue;
			const diff = Math.abs(new Date(n.created_at).getTime() - t);
			if (diff < bestDiff && diff <= 1e4) {
				bestDiff = diff;
				best = n;
			}
		}
		return best;
	};
	const fmt = (iso) => {
		try {
			return new Date(iso).toLocaleString("en-GB", {
				day: "2-digit",
				month: "2-digit",
				year: "numeric",
				hour: "2-digit",
				minute: "2-digit",
				hour12: false
			});
		} catch {
			return iso;
		}
	};
	const fmtRelative = (iso) => {
		const diff = Date.now() - new Date(iso).getTime();
		const s = Math.round(diff / 1e3);
		if (s < 60) return "قبل ثوانٍ";
		const m = Math.round(s / 60);
		if (m < 60) return `قبل ${m} دقيقة`;
		const h = Math.round(m / 60);
		if (h < 24) return `قبل ${h} ساعة`;
		const d = Math.round(h / 24);
		if (d < 30) return `قبل ${d} يوم`;
		const mo = Math.round(d / 30);
		if (mo < 12) return `قبل ${mo} شهر`;
		return `قبل ${Math.round(mo / 12)} سنة`;
	};
	const nameOf = (id) => {
		if (!id) return "—";
		const p = nameMap.get(id);
		return p?.full_name || p?.phone || id.slice(0, 8);
	};
	const filtered = entries.filter((e) => {
		if (filter !== "all" && e.action !== filter) return false;
		if (search.trim()) {
			const q = search.trim().toLowerCase();
			const targetName = String(nameOf(e.user_id)).toLowerCase();
			const actorName = String(nameOf(e.actor_id)).toLowerCase();
			if (!targetName.includes(q) && !actorName.includes(q)) return false;
		}
		return true;
	});
	const blockCount = entries.filter((e) => e.action === "block").length;
	const unblockCount = entries.filter((e) => e.action === "unblock").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm font-extrabold flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4 text-destructive" }),
						" المحظورون حاليًا",
						blocked.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-normal text-muted-foreground",
							children: [
								"(",
								blocked.length,
								")"
							]
						})
					]
				}), loadingBlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center text-xs text-muted-foreground py-4",
					children: "جاري التحميل…"
				}) : blocked.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center text-xs text-muted-foreground py-4 bg-muted/40 rounded-2xl",
					children: "لا يوجد مستخدمون محظورون"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: blocked.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card border border-border rounded-2xl p-3 flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-9 rounded-full bg-destructive/10 text-destructive grid place-items-center shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold truncate",
									children: u.full_name || u.phone || u.id.slice(0, 8)
								}), u.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground truncate",
									children: u.phone
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "secondary",
								onClick: () => unblock(u.id),
								disabled: unblockingId === u.id,
								className: "gap-1",
								children: [unblockingId === u.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), "رفع الحظر"]
							})
						]
					}, u.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-sm font-extrabold flex items-center gap-2 pt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4" }),
					" سجل التدقيق",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs font-normal text-muted-foreground",
						children: [
							"(",
							entries.length,
							")"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 flex-wrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex rounded-xl border border-border bg-muted/40 p-0.5 text-[11px] font-semibold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setFilter("all"),
							className: `px-3 py-1.5 rounded-lg transition-colors ${filter === "all" ? "bg-card shadow-sm" : "text-muted-foreground"}`,
							children: [
								"الكل (",
								entries.length,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setFilter("block"),
							className: `px-3 py-1.5 rounded-lg transition-colors ${filter === "block" ? "bg-destructive/10 text-destructive" : "text-muted-foreground"}`,
							children: [
								"حظر (",
								blockCount,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setFilter("unblock"),
							className: `px-3 py-1.5 rounded-lg transition-colors ${filter === "unblock" ? "bg-success/10 text-success" : "text-muted-foreground"}`,
							children: [
								"رفع حظر (",
								unblockCount,
								")"
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: search,
					onChange: (e) => setSearch(e.target.value),
					placeholder: "بحث باسم الزبون أو المشرف…",
					className: "h-9 text-xs flex-1 min-w-[160px]"
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "جاري التحميل…"
			}) : !entries.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "لا توجد سجلات بعد"
			}) : !filtered.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "لا نتائج مطابقة للتصفية"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 md:grid md:grid-cols-2 md:gap-3 md:space-y-0",
				children: filtered.map((e) => {
					const isBlock = e.action === "block";
					const n = matchNotif(e.user_id, e.created_at);
					const delivery = !n ? {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailX, { className: "size-3" }),
						label: "لم يُرسل الإشعار",
						cls: "bg-destructive/10 text-destructive"
					} : n.read_at ? {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailCheck, { className: "size-3" }),
						label: `تم الاستلام • ${fmt(n.read_at)}`,
						cls: "bg-success/10 text-success"
					} : {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" }),
						label: "أُرسل — لم يُقرأ بعد",
						cls: "bg-muted text-muted-foreground"
					};
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card border border-border rounded-2xl p-3 flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `size-9 rounded-full grid place-items-center shrink-0 ${isBlock ? "bg-destructive/10 text-destructive" : "bg-success/10 text-success"}`,
							children: isBlock ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 flex-wrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold",
										children: isBlock ? "حظر زبون" : "رفع الحظر عن زبون"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[10px] font-bold px-2 py-0.5 rounded-full ${isBlock ? "bg-destructive/10 text-destructive" : "bg-success/10 text-success"}`,
										children: isBlock ? "BLOCK" : "UNBLOCK"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: ["الزبون: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-foreground",
										children: nameOf(e.user_id)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: ["بواسطة: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-foreground",
										children: nameOf(e.actor_id)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-muted-foreground mt-1 flex items-center gap-1.5",
									dir: "ltr",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono",
											children: fmt(e.created_at)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground/70",
											children: ["• ", fmtRelative(e.created_at)]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `inline-flex items-center gap-1 mt-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold ${delivery.cls}`,
									children: [delivery.icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: delivery.label })]
								})
							]
						})]
					}, e.id);
				})
			})
		]
	});
}
/**
* Staff management is HIDDEN, not deleted.
*
* createStaff() provisions a phone+password account (p<phone>@aliparts.app),
* but sign-in is Google/Apple only — there is no password login UI anywhere in
* the app. Any staff member created this way therefore CANNOT SIGN IN, and
* nothing warned the admin about it. Hiding the tab prevents creating those
* dead accounts.
*
* Nothing is removed: StaffAdmin, staff.functions.ts, the staff_permissions
* table, existing staff rows and all `staff_can()` permission checks are
* untouched — staff who already exist keep working exactly as before.
*
* TO RE-ENABLE: set this to true. Only do that once staff can actually sign
* in — i.e. after either adding an email/password login path or moving staff
* onto Google/Apple accounts.
*/
var STAFF_TAB_ENABLED = false;
/**
* Banner video cap. Raised to 50MB now that playback is fully deferred
* (preload="none" → 0 bytes on home load) and progressive-streaming (faststart
* MP4 + HTTP range requests), so a customer only downloads what they actually
* watch after tapping — never on page load.
*/
var MAX_BANNER_VIDEO_BYTES = 50 * 1024 * 1024;
function AdminOtpGate({ email, onVerified }) {
	const requestFn = useServerFn(requestAdminOtp);
	const verifyFn = useServerFn(verifyAdminOtp);
	const [sending, setSending] = (0, import_react.useState)(false);
	const [verifying, setVerifying] = (0, import_react.useState)(false);
	const [sent, setSent] = (0, import_react.useState)(false);
	const [code, setCode] = (0, import_react.useState)("");
	const [cooldown, setCooldown] = (0, import_react.useState)(0);
	const [remember, setRemember] = (0, import_react.useState)(false);
	const send = async () => {
		if (sending || cooldown > 0) return;
		setSending(true);
		try {
			await requestFn();
			setSent(true);
			setCooldown(30);
			toast.success("تم إرسال رمز التحقق إلى بريد الإدارة");
			const t = setInterval(() => {
				setCooldown((c) => {
					if (c <= 1) {
						clearInterval(t);
						return 0;
					}
					return c - 1;
				});
			}, 1e3);
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "تعذر الإرسال");
		} finally {
			setSending(false);
		}
	};
	const verify = async () => {
		if (verifying) return;
		if (!/^\d{6}$/.test(code)) {
			toast.error("أدخل رمزاً مكوّناً من 6 أرقام");
			return;
		}
		setVerifying(true);
		try {
			await verifyFn({ data: {
				code,
				remember,
				device_id: getAdminDeviceId()
			} });
			toast.success("تم التحقق بنجاح");
			onVerified();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "رمز غير صحيح");
		} finally {
			setVerifying(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 pt-8 pb-10 max-w-md mx-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-3xl border border-border bg-card p-6 flex flex-col items-center text-center gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-16 rounded-full bg-primary/10 grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-8 text-primary" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-lg font-extrabold",
					children: "تحقق دخول الإدارة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: [
						"لحماية اللوحة، نرسل رمزاً مكوناً من 6 أرقام إلى بريد الإدارة",
						email ? ` (${email})` : "",
						"."
					]
				})] }),
				!sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "w-full",
					onClick: send,
					disabled: sending,
					children: [sending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailCheck, { className: "size-4" }), "إرسال رمز التحقق"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						inputMode: "numeric",
						maxLength: 6,
						value: code,
						onChange: (e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6)),
						placeholder: "——————",
						className: "text-center text-2xl tracking-[0.5em] font-bold h-14",
						dir: "ltr"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "w-full",
						onClick: verify,
						disabled: verifying || code.length !== 6,
						children: [verifying ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), "تأكيد الدخول"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-xs text-muted-foreground select-none cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: remember,
							onChange: (e) => setRemember(e.target.checked),
							className: "size-4 accent-primary"
						}), "تذكّر هذا الجهاز لمدة 30 يوم"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: send,
						disabled: sending || cooldown > 0,
						className: "text-xs",
						children: cooldown > 0 ? `إعادة الإرسال بعد ${cooldown}s` : "إعادة إرسال الرمز"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-muted-foreground",
					children: "الرمز صالح لمدة 10 دقائق. جلسة التحقق تدوم 10 دقائق، أو 30 يوم عند اختيار \"تذكّر هذا الجهاز\"."
				})
			]
		})
	});
}
function AdminPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPageInner, {});
}
function PermissionsBadge({ isAdmin, canOrders, canProducts, canReplacements, canBlock }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const perms = [
		{
			key: "admin",
			label: "مدير",
			on: isAdmin,
			cls: "bg-primary/10 text-primary border-primary/30"
		},
		{
			key: "orders",
			label: "الطلبات (can_orders)",
			on: canOrders,
			cls: "bg-blue-500/10 text-blue-600 border-blue-500/30"
		},
		{
			key: "products",
			label: "المنتجات (can_products)",
			on: canProducts,
			cls: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30"
		},
		{
			key: "replacements",
			label: "الاستبدال (can_replacements)",
			on: canReplacements,
			cls: "bg-amber-500/10 text-amber-600 border-amber-500/30"
		},
		{
			key: "block",
			label: "حظر المستخدمين (can_block)",
			on: canBlock,
			cls: "bg-rose-500/10 text-rose-600 border-rose-500/30"
		}
	];
	const activeCount = perms.filter((p) => p.on).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3 rounded-2xl border border-border bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => setOpen((v) => !v),
			className: "w-full flex items-center gap-2 px-3 py-2 text-sm font-bold",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "صلاحياتي" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[11px] font-normal text-muted-foreground",
					children: [
						"(",
						activeCount,
						" مُفعّلة)"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ms-auto text-muted-foreground",
					children: open ? "▲" : "▼"
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-3 pb-3 flex flex-wrap gap-1.5",
			children: perms.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: `inline-flex items-center gap-1 text-[11px] font-bold rounded-full px-2 py-1 border ${p.on ? p.cls : "bg-muted/40 text-muted-foreground border-border"}`,
				children: [p.on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-3" }), p.label]
			}, p.key))
		})]
	});
}
function AdminPageInner() {
	const { isAdmin, canOrders, canProducts, canReplacements, canBlock, hasAnyAccess, isLoading, isError } = useAdminAccessStatus();
	const navigate = useNavigate();
	const otpStatusFn = useServerFn(adminOtpStatus);
	const { data: otp, isLoading: otpLoading, refetch: refetchOtp } = useQuery({
		queryKey: ["admin-otp-status"],
		queryFn: () => otpStatusFn({ data: { device_id: getAdminDeviceId() } }),
		enabled: hasAnyAccess && !isLoading,
		staleTime: 6e4,
		refetchOnWindowFocus: false
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "لوحة الإدارة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-16 flex flex-col items-center text-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-8 animate-spin text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "جاري التحقق من الصلاحيات…"
			})]
		})
	});
	if (isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "لوحة الإدارة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-10 flex flex-col items-center text-center gap-3",
			role: "alert",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-16 rounded-full bg-amber-500/10 grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-8 text-amber-600" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-extrabold text-lg",
					children: "تعذر التحقق من الصلاحيات"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "حدث خلل في الاتصال بالخادم. تحقق من الإنترنت ثم أعد المحاولة."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => window.location.reload(),
					children: "إعادة المحاولة"
				})
			]
		})
	});
	if (!hasAnyAccess) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "لوحة الإدارة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-10 flex flex-col items-center text-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-16 rounded-full bg-destructive/10 grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-8 text-destructive" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-extrabold text-lg",
					children: "ليس لديك صلاحية"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "هذه اللوحة مخصصة للمدراء فقط."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => navigate({ to: "/" }),
					children: "العودة للرئيسية"
				})
			]
		})
	});
	if (otpLoading || !otp) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "لوحة الإدارة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-16 flex flex-col items-center text-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-8 animate-spin text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "جاري التحقق…"
			})]
		})
	});
	if (otp.required && !otp.verified) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "تحقق ثنائي",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminOtpGate, {
			email: otp.email ?? "",
			onVerified: () => refetchOtp()
		})
	});
	const defaultTab = isAdmin ? "products" : canOrders ? "orders" : canProducts ? "products" : canReplacements ? "replacements" : "block-log";
	const tabTriggerCls = "flex-col gap-1 py-2 text-[10px] md:flex-row md:justify-start md:gap-2 md:text-sm md:py-2.5 md:px-3 md:w-full";
	const tabContentCls = "mt-4 md:mt-0 md:flex-1 md:min-w-0";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "لوحة الإدارة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-3 pb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionsBadge, {
				isAdmin,
				canOrders,
				canProducts,
				canReplacements,
				canBlock
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: defaultTab,
				className: "md:flex md:flex-row md:gap-4 md:items-start",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "w-full grid grid-cols-4 h-auto gap-1 md:flex md:flex-col md:w-52 md:shrink-0 md:items-stretch md:gap-1 md:sticky md:top-4 md:self-start",
						children: [
							canProducts && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "products",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-4" }), "منتجات"]
							}),
							isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "banners",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-4" }), "عروض"]
							}),
							isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "taxonomy",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tags, { className: "size-4" }), "تصنيفات"]
							}),
							canOrders && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "orders",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-4" }), "طلبات"]
							}),
							canReplacements && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "replacements",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-4" }), "استبدال"]
							}),
							isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "users",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }), "مستخدمون"]
							}),
							STAFF_TAB_ENABLED,
							canBlock && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "block-log",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4" }), "سجل الحظر"]
							}),
							canProducts && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "stock",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boxes, { className: "size-4" }), "سجل المخزون"]
							}),
							isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "broadcast",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-4" }), "إشعار جماعي"]
							}),
							isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "settings",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }), "إعدادات"]
							}),
							isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "diagnostics",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4" }), "تشخيص"]
							}),
							isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "otp-log",
								className: tabTriggerCls,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4" }), "سجل OTP"]
							})
						]
					}),
					canProducts && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "products",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductsAdmin, {})
					}),
					isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "banners",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BannersAdmin, {})
					}),
					isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "taxonomy",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaxonomyAdmin, {})
					}),
					canOrders && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "orders",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrdersAdmin, {})
					}),
					canReplacements && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "replacements",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReplacementsAdmin, {})
					}),
					isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "users",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersAdmin, {})
					}),
					STAFF_TAB_ENABLED,
					canBlock && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "block-log",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlockLogAdmin, {})
					}),
					canProducts && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "stock",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockMovementsAdmin, {})
					}),
					isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "broadcast",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BroadcastAdmin, {})
					}),
					isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "settings",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsAdmin, {})
					}),
					isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "diagnostics",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiagnosticsAdmin, {})
					}),
					isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "otp-log",
						className: tabContentCls,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminOtpEventsLog, {})
					})
				]
			})]
		})
	});
}
function UsersAdmin() {
	const [search, setSearch] = (0, import_react.useState)("");
	const [pwOpen, setPwOpen] = (0, import_react.useState)(false);
	const [pwUser, setPwUser] = (0, import_react.useState)(null);
	const [pw, setPw] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const { data, isLoading, refetch, isFetching, error: queryError } = useQuery({
		queryKey: ["admin", "users"],
		queryFn: async () => {
			let serverErr = null;
			try {
				const res = await adminListUsers();
				if (res && Array.isArray(res.users) && res.users.length > 0) return res;
				serverErr = "Server returned 0 users";
			} catch (err) {
				serverErr = err?.message ?? String(err);
				console.warn("[UsersAdmin] adminListUsers serverFn failed:", serverErr);
			}
			let clientErr = null;
			try {
				const { data: profs, error: profErr } = await supabase.from("profiles").select("id, full_name, phone, is_blocked, created_at, points_balance").order("created_at", { ascending: false });
				if (profErr) {
					clientErr = profErr.message;
					console.error("[UsersAdmin] direct profiles fetch error:", profErr);
				} else if (profs && profs.length > 0) {
					const mapped = profs.map((p) => ({
						id: p.id,
						email: null,
						phone: p.phone ?? null,
						profile_phone: p.phone ?? null,
						full_name: p.full_name ?? null,
						is_blocked: p.is_blocked ?? false,
						created_at: p.created_at ?? null,
						last_sign_in_at: p.created_at ?? null,
						is_active: false
					}));
					return {
						total: mapped.length,
						active: 0,
						users: mapped
					};
				} else clientErr = "profiles query returned empty";
			} catch (err) {
				clientErr = err?.message ?? String(err);
				console.error("[UsersAdmin] direct profiles fetch threw:", clientErr);
			}
			try {
				const { data: sessionData } = await supabase.auth.getUser();
				if (!sessionData?.user) throw new Error(`لم يتم التعرف على جلسة المستخدم. الرجاء تسجيل الخروج وإعادة الدخول. (server: ${serverErr}, client: ${clientErr})`);
			} catch {}
			throw new Error(`تعذر جلب المستخدمين.\nالسيرفر: ${serverErr ?? "لم يُحاول"}\nقاعدة البيانات: ${clientErr ?? "لم يُحاول"}\nالرجاء التأكد من صلاحيات الأدمن أو تسجيل الخروج وإعادة الدخول.`);
		},
		refetchInterval: 3e4,
		retry: 2,
		retryDelay: 1e3
	});
	const users = data?.users ?? [];
	const filtered = (() => {
		const s = search.trim().toLowerCase();
		if (!s) return users;
		return users.filter((u) => [
			u.full_name,
			u.email,
			u.phone,
			u.profile_phone
		].filter(Boolean).some((v) => String(v).toLowerCase().includes(s)));
	})();
	const fmt = (iso) => {
		if (!iso) return "—";
		try {
			return new Date(iso).toLocaleString("ar-IQ", {
				dateStyle: "short",
				timeStyle: "short"
			});
		} catch {
			return iso;
		}
	};
	const openPw = (u) => {
		setPwUser({
			id: u.id,
			label: u.full_name || u.profile_phone || u.phone || u.email || u.id.slice(0, 8)
		});
		setPw("");
		setPwOpen(true);
	};
	const submitPw = async () => {
		if (!pwUser) return;
		if (pw.length < 6) {
			toast.error("كلمة السر يجب أن تكون 6 أحرف على الأقل");
			return;
		}
		setSaving(true);
		try {
			await adminSetUserPassword({ data: {
				user_id: pwUser.id,
				password: pw
			} });
			toast.success("تم تحديث كلمة السر");
			setPwOpen(false);
		} catch (e) {
			toast.error(e?.message ?? "تعذر التحديث");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-gradient-navy text-primary-foreground rounded-2xl p-4 shadow-luxe",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] text-gold font-bold",
						children: "إجمالي المستخدمين"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-3xl font-black leading-tight mt-0.5",
						children: data?.total ?? "—"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-gradient-gold text-navy rounded-2xl p-4 shadow-gold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold opacity-70",
							children: "متصلون الآن"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-3xl font-black leading-tight mt-0.5 flex items-center gap-2",
							children: [data?.active ?? "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-success animate-pulse" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] opacity-70 mt-1",
							children: "آخر دخول خلال 15 دقيقة"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 bg-card border border-border rounded-xl px-3 py-2 focus-within:border-gold",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: search,
						onChange: (e) => setSearch(e.target.value),
						placeholder: "ابحث بالاسم أو الهاتف أو الإيميل…",
						className: "flex-1 bg-transparent outline-none text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => refetch(),
						className: "text-xs text-gold font-bold px-2 disabled:opacity-50",
						disabled: isFetching,
						children: isFetching ? "..." : "تحديث"
					})
				]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "جاري التحميل…"
			}) : queryError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-destructive/10 border border-destructive/30 rounded-2xl p-4 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-bold text-destructive",
						children: "⚠️ خطأ في جلب المستخدمين"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-destructive/80 whitespace-pre-wrap",
						dir: "ltr",
						children: queryError.message
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => refetch(),
						className: "text-xs bg-destructive text-white rounded-lg px-3 py-1.5 font-bold mt-1",
						disabled: isFetching,
						children: isFetching ? "جاري المحاولة…" : "إعادة المحاولة"
					})
				]
			}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "لا يوجد مستخدمون مطابقون"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 md:grid md:grid-cols-2 md:gap-3 md:space-y-0",
				children: filtered.map((u) => {
					const displayPhone = u.profile_phone || u.phone;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card border border-border rounded-2xl p-3 flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `size-11 rounded-full grid place-items-center font-black text-lg shrink-0 ${u.is_active ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`,
								children: (u.full_name?.[0] ?? u.email?.[0] ?? "?").toUpperCase()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-bold truncate flex items-center gap-1.5",
										children: [
											u.full_name || "بلا اسم",
											u.is_blocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-3.5 text-destructive" }),
											u.is_active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[9px] font-black text-success bg-success/10 px-1.5 py-0.5 rounded-full",
												children: "متصل"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground truncate",
										dir: "ltr",
										children: displayPhone ? `+${String(displayPhone).replace(/\D/g, "")}` : u.email ?? "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[10px] text-muted-foreground",
										children: ["آخر دخول: ", fmt(u.last_sign_in_at)]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => openPw(u),
								className: "h-9 px-3 rounded-lg border border-gold/40 text-gold text-xs font-bold flex items-center gap-1 hover:bg-gold/10 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3.5" }), " كلمة السر"]
							})
						]
					}, u.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: pwOpen,
				onOpenChange: setPwOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["تغيير كلمة سر: ", pwUser?.label] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "كلمة السر الجديدة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "text",
								value: pw,
								onChange: (e) => setPw(e.target.value),
								placeholder: "6 أحرف على الأقل",
								dir: "ltr"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "سيتمكن المستخدم من تسجيل الدخول بكلمة السر الجديدة فوراً. ذكّره بها بشكل آمن."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: submitPw,
							disabled: saving,
							children: saving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 me-1 animate-spin" }), " جاري الحفظ…"] }) : "حفظ كلمة السر الجديدة"
						})
					]
				})] })
			})
		]
	});
}
function CompatibleModelsField({ models, selected, savedVehicle, onChange }) {
	const toggle = (id) => {
		onChange(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "السيارات المتوافقة" }), savedVehicle && !selected.includes(savedVehicle.modelId) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onChange([...selected, savedVehicle.modelId]),
					className: "text-[11px] font-bold text-gold hover:underline",
					children: [
						"+ اضف ",
						savedVehicle.brandName,
						" ",
						savedVehicle.modelName
					]
				})]
			}),
			savedVehicle && selected.includes(savedVehicle.modelId) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-xs text-gold font-semibold",
				children: [
					"متوافق مع المركبة المختارة: ",
					savedVehicle.brandName,
					" ",
					savedVehicle.modelName,
					" (",
					savedVehicle.year,
					") · ",
					savedVehicle.engine
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-40 overflow-y-auto border border-border rounded-xl p-2 space-y-1 bg-card",
				children: models.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground text-center py-2",
					children: "لا توجد موديلات مسجلة"
				}) : models.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 p-2 rounded-lg hover:bg-muted cursor-pointer",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: selected.includes(m.id),
							onChange: () => toggle(m.id),
							className: "size-4 accent-navy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm flex-1",
							children: m.name_ar
						}),
						m.name_en && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: m.name_en
						})
					]
				}, m.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-xs text-muted-foreground",
				children: [selected.length, " موديل محدد"]
			})
		]
	});
}
var emptyProduct = {
	name_ar: "",
	name_en: "",
	description_ar: "",
	oem_number: "",
	price_usd: "",
	compare_price_iqd: "",
	shipping_iqd: "",
	merge_delivery: true,
	delivery_group: "",
	category_id: "",
	brand_id: "",
	images: [],
	in_stock: true,
	is_featured: false,
	is_deal: false,
	compatible_models: [],
	deal_expires_at: "",
	stock_qty: "0",
	condition: "new"
};
function ProductsAdmin() {
	const qc = useQueryClient();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)(emptyProduct);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [imgUploading, setImgUploading] = (0, import_react.useState)(false);
	const [search, setSearch] = (0, import_react.useState)("");
	const [deleteProduct, setDeleteProduct] = (0, import_react.useState)(null);
	const [deleting, setDeleting] = (0, import_react.useState)(false);
	const usdRate = Number(useSetting("usd_exchange_rate", "1500")) || 1500;
	const usdRounding = Number(useSetting("usd_rounding", "500")) || 0;
	const previewIqd = (() => {
		const u = Number(form.price_usd);
		if (!Number.isFinite(u) || u <= 0) return 0;
		const raw = u * usdRate;
		return usdRounding > 0 ? Math.round(raw / usdRounding) * usdRounding : Math.round(raw);
	})();
	const { data: products = [], isLoading } = useQuery({
		queryKey: ["admin", "products"],
		staleTime: 6e4,
		queryFn: async () => {
			const { data, error } = await supabase.from("products").select("*").order("created_at", { ascending: false }).limit(1e3);
			if (error) throw error;
			return data ?? [];
		}
	});
	const filteredProducts = (() => {
		const s = search.trim().toLowerCase();
		if (!s) return products;
		return products.filter((p) => [
			p.name_ar,
			p.name_en,
			p.oem_number
		].filter(Boolean).some((v) => String(v).toLowerCase().includes(s)));
	})();
	const { data: categories = [] } = useQuery(categoriesQuery());
	const { data: brands = [] } = useQuery(brandsQuery());
	const { data: carModels = [] } = useQuery(carModelsQuery());
	const savedVehicle = null;
	const openNew = () => {
		setForm(emptyProduct);
		setOpen(true);
	};
	const openEdit = (p) => {
		setForm({
			id: p.id,
			name_ar: p.name_ar ?? "",
			name_en: p.name_en ?? "",
			description_ar: p.description_ar ?? "",
			oem_number: p.oem_number ?? "",
			price_usd: p.price_usd ? String(p.price_usd) : "",
			compare_price_iqd: String(p.compare_price_iqd ?? ""),
			shipping_iqd: String(p.shipping_iqd ?? ""),
			merge_delivery: p.merge_delivery !== false,
			delivery_group: p.delivery_group ?? "",
			category_id: p.category_id ?? "",
			brand_id: p.brand_id ?? "",
			images: p.images ?? [],
			in_stock: !!p.in_stock,
			stock_qty: String(p.stock_qty ?? 0),
			is_featured: !!p.is_featured,
			is_deal: !!p.is_deal,
			compatible_models: p.compatible_models ?? [],
			deal_expires_at: p.deal_expires_at ? new Date(p.deal_expires_at).toISOString().slice(0, 16) : "",
			condition: p.condition === "used" ? "used" : "new"
		});
		setOpen(true);
	};
	const save = async () => {
		if (!form.name_ar.trim() || !form.price_usd) {
			toast.error("الاسم والسعر بالدولار مطلوبان");
			return;
		}
		if (imgUploading) {
			toast.error("انتظر حتى اكتمال رفع الصور");
			return;
		}
		setSaving(true);
		try {
			const payload = {
				name_ar: form.name_ar,
				name_en: form.name_en || null,
				description_ar: form.description_ar || null,
				oem_number: form.oem_number || null,
				price_usd: Number(form.price_usd),
				compare_price_iqd: form.compare_price_iqd ? Number(form.compare_price_iqd) : null,
				shipping_iqd: form.shipping_iqd ? Number(form.shipping_iqd) : 0,
				merge_delivery: form.merge_delivery,
				delivery_group: form.delivery_group.trim() || null,
				category_id: form.category_id || null,
				brand_id: form.brand_id || null,
				images: form.images,
				in_stock: form.in_stock,
				stock_qty: form.stock_qty ? Math.max(0, Math.floor(Number(form.stock_qty))) : 0,
				is_featured: form.is_featured,
				is_deal: form.is_deal,
				compatible_models: form.compatible_models.length > 0 ? form.compatible_models : null,
				deal_expires_at: form.is_deal && form.deal_expires_at ? new Date(form.deal_expires_at).toISOString() : null,
				condition: form.condition
			};
			const res = form.id ? await supabase.from("products").update(payload).eq("id", form.id) : await supabase.from("products").insert(payload);
			if (res.error) throw res.error;
			toast.success(form.id ? "تم التحديث" : "تم إضافة المنتج");
			setOpen(false);
			qc.invalidateQueries({ queryKey: ["admin", "products"] });
			qc.invalidateQueries({ queryKey: ["products"] });
		} catch (e) {
			toast.error(e.message ?? "حدث خطأ");
		} finally {
			setSaving(false);
		}
	};
	const remove = async (id) => {
		setDeleting(true);
		const { error, count } = await supabase.from("products").delete({ count: "exact" }).eq("id", id);
		if (error) {
			console.error("[admin] delete product failed", error);
			toast.error("تعذّر حذف المنتج", { description: error.message });
			setDeleting(false);
			return;
		}
		if (!count) {
			toast.error("لم يتم الحذف — تحقق من صلاحيات المشرف");
			setDeleting(false);
			return;
		}
		toast.success("تم حذف المنتج");
		setDeleteProduct(null);
		setDeleting(false);
		qc.invalidateQueries({ queryKey: ["admin", "products"] });
		qc.invalidateQueries({ queryKey: ["products"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm text-muted-foreground",
					children: [search ? `${filteredProducts.length}/${products.length}` : products.length, " منتج"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: openNew,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 me-1" }), " إضافة منتج"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 bg-card border border-border rounded-xl px-3 py-2 focus-within:border-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: search,
					onChange: (e) => setSearch(e.target.value),
					placeholder: "ابحث بالاسم أو رقم OEM…",
					className: "flex-1 bg-transparent outline-none text-sm"
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "جاري التحميل..."
			}) : filteredProducts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "لا توجد منتجات بعد"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 md:grid md:grid-cols-2 lg:grid-cols-3 md:gap-3 md:space-y-0",
				children: filteredProducts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card border border-border rounded-2xl p-3 flex gap-3 items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-14 rounded-xl bg-muted overflow-hidden shrink-0",
							children: p.images?.[0] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: p.images[0],
								alt: "",
								className: "size-full object-cover"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-sm truncate",
									children: p.name_ar
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs flex items-center gap-2",
									dir: "ltr",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-bold text-gold",
										children: ["$", Number(p.price_usd ?? 0).toFixed(2)]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: ["≈ ", formatIQD(p.price_iqd)]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] text-muted-foreground",
									children: p.in_stock && (p.stock_qty ?? 0) > 0 ? `متوفر · ${p.stock_qty ?? 0} قطعة` : "غير متوفر"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								onClick: () => openEdit(p),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								onClick: () => setDeleteProduct({
									id: p.id,
									name: p.name_ar
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-destructive" })
							})]
						})
					]
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] overflow-y-auto md:max-w-2xl lg:max-w-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: form.id ? "تعديل منتج" : "إضافة منتج جديد" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 md:grid md:grid-cols-2 md:gap-x-4 md:gap-y-3 md:space-y-0 md:items-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "md:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
									images: form.images,
									onChange: (imgs) => setForm({
										...form,
										images: imgs
									}),
									onUploadingChange: setImgUploading
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الاسم بالعربي *",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.name_ar,
									onChange: (e) => setForm({
										...form,
										name_ar: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الاسم بالإنجليزي",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.name_en,
									onChange: (e) => setForm({
										...form,
										name_en: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "md:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "الوصف",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										value: form.description_ar,
										onChange: (e) => setForm({
											...form,
											description_ar: e.target.value
										}),
										rows: 3
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "رقم القطعة (OEM)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.oem_number,
									onChange: (e) => setForm({
										...form,
										oem_number: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
								label: "السعر بالدولار *",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.01",
									value: form.price_usd,
									onChange: (e) => setForm({
										...form,
										price_usd: e.target.value
									}),
									inputMode: "decimal",
									dir: "ltr",
									placeholder: "مثال: 12.50"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-muted-foreground mt-1 flex items-center justify-between",
									dir: "ltr",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"× ",
										usdRate,
										" IQD"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-gold font-bold",
										children: ["≈ ", previewIqd > 0 ? formatIQD(previewIqd) : "—"]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "السعر قبل الخصم (د.ع، اختياري)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: form.compare_price_iqd,
									onChange: (e) => setForm({
										...form,
										compare_price_iqd: e.target.value
									}),
									inputMode: "numeric",
									dir: "ltr"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "كلفة التوصيل لهذا المنتج (د.ع)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: form.shipping_iqd,
									onChange: (e) => setForm({
										...form,
										shipping_iqd: e.target.value
									}),
									inputMode: "numeric",
									dir: "ltr",
									placeholder: "0"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-border p-3 space-y-3 bg-muted/20 md:col-span-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold text-gold",
										children: "إعدادات التوصيل"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "block",
											children: "دمج التوصيل مع منتجات نفس المجموعة"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-muted-foreground mt-0.5",
											children: "عند التفعيل، تُحتسب أجرة التوصيل مرة واحدة لكل مجموعة. عند الإيقاف، تُحتسب مستقلة دائماً."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
											checked: form.merge_delivery,
											onCheckedChange: (v) => setForm({
												...form,
												merge_delivery: v
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "مجموعة التوصيل (مثال: Small Parts / Medium Parts / Large Parts)",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: form.delivery_group,
											onChange: (e) => setForm({
												...form,
												delivery_group: e.target.value
											}),
											placeholder: "اترك فارغاً لتوصيل مستقل لهذا المنتج"
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "التصنيف",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: form.category_id,
									onValueChange: (v) => setForm({
										...form,
										category_id: v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "اختر تصنيف" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: c.id,
										children: c.name_ar
									}, c.id)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الماركة",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: form.brand_id,
									onValueChange: (v) => setForm({
										...form,
										brand_id: v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "اختر ماركة" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: brands.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: b.id,
										children: b.name_ar
									}, b.id)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "md:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompatibleModelsField, {
									models: carModels,
									selected: form.compatible_models,
									savedVehicle,
									onChange: (ids) => setForm({
										...form,
										compatible_models: ids
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "متوفر" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: form.in_stock,
									onCheckedChange: (v) => setForm({
										...form,
										in_stock: v
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "عدد القطع المتوفرة",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									inputMode: "numeric",
									dir: "ltr",
									value: form.stock_qty,
									onChange: (e) => setForm({
										...form,
										stock_qty: e.target.value
									}),
									placeholder: "0"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "حالة المنتج",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setForm({
											...form,
											condition: "new"
										}),
										className: `h-11 rounded-xl font-black text-sm border-2 transition ${form.condition === "new" ? "bg-navy text-primary-foreground border-navy" : "bg-card text-navy border-border"}`,
										children: "جديد"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setForm({
											...form,
											condition: "used"
										}),
										className: `h-11 rounded-xl font-black text-sm border-2 transition ${form.condition === "used" ? "bg-gradient-gold text-navy border-gold" : "bg-card text-navy border-border"}`,
										children: "مستعمل"
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "مميز" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: form.is_featured,
									onCheckedChange: (v) => setForm({
										...form,
										is_featured: v
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "عرض / تخفيض" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: form.is_deal,
									onCheckedChange: (v) => setForm({
										...form,
										is_deal: v
									})
								})]
							}),
							form.is_deal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "ينتهي العرض في (اختياري)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "datetime-local",
									value: form.deal_expires_at,
									onChange: (e) => setForm({
										...form,
										deal_expires_at: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full md:col-span-2",
								onClick: save,
								disabled: saving || imgUploading,
								children: imgUploading ? "جاري رفع الصور..." : saving ? "جاري الحفظ..." : "حفظ"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!deleteProduct,
				onOpenChange: (v) => !v && setDeleteProduct(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "تأكيد حذف المنتج" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					"هل أنت متأكد من حذف المنتج «",
					deleteProduct?.name ?? "—",
					"»؟ لا يمكن التراجع عن هذا الإجراء."
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
					onClick: () => setDeleteProduct(null),
					children: "إلغاء"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					onClick: () => deleteProduct && remove(deleteProduct.id),
					disabled: deleting,
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					children: deleting ? "جاري الحذف..." : "حذف"
				})] })] })
			})
		]
	});
}
function BannersAdmin() {
	const qc = useQueryClient();
	const { data: banners = [] } = useQuery(bannersQuery());
	const [open, setOpen] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		title_ar: "",
		subtitle_ar: "",
		image_url: "",
		video_url: "",
		link: ""
	});
	const [uploadingVideo, setUploadingVideo] = (0, import_react.useState)(false);
	const [videoProgress, setVideoProgress] = (0, import_react.useState)(0);
	const videoInputRef = (0, import_react.useRef)(null);
	const save = async () => {
		if (!form.image_url && !form.video_url) {
			toast.error("الصورة أو الفيديو مطلوب");
			return;
		}
		if (form.video_url && !form.image_url) {
			toast.error("صورة الغلاف مطلوبة مع الفيديو", {
				description: "يرجى رفع صورة تظهر قبل تشغيل الفيديو — بدونها سيرى الزبون مساحة فارغة.",
				duration: 8e3
			});
			return;
		}
		const payload = {
			title_ar: form.title_ar || null,
			subtitle_ar: form.subtitle_ar || null,
			image_url: form.image_url || "",
			video_url: form.video_url || null,
			link: form.link || null,
			is_active: true,
			expires_at: null
		};
		const isNew = !form.id;
		let newId = null;
		if (isNew) {
			const res = await supabase.from("banners").insert(payload).select("id").single();
			if (res.error) {
				toast.error(res.error.message);
				return;
			}
			newId = res.data?.id ?? null;
		} else {
			const res = await supabase.from("banners").update(payload).eq("id", form.id);
			if (res.error) {
				toast.error(res.error.message);
				return;
			}
		}
		toast.success("تم الحفظ");
		setOpen(false);
		qc.invalidateQueries({ queryKey: ["banners"] });
		if (isNew && newId) try {
			const { broadcastBannerPush } = await import("./banner-push.functions-SCMn2Tr_.mjs");
			await broadcastBannerPush({ data: { bannerId: newId } });
		} catch (err) {
			console.error("[push] broadcast failed", err);
		}
	};
	const remove = async (id) => {
		if (!window.confirm("هل أنت متأكد من حذف هذا العرض؟")) return;
		const { error } = await supabase.from("banners").delete().eq("id", id);
		if (error) {
			toast.error("تعذّر الحذف: " + error.message);
			return;
		}
		toast.success("تم حذف العرض");
		qc.invalidateQueries({ queryKey: ["banners"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => {
						setForm({
							title_ar: "",
							subtitle_ar: "",
							image_url: "",
							video_url: "",
							link: ""
						});
						setOpen(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 me-1" }), " إضافة عرض"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3 md:grid md:grid-cols-2 md:gap-3 md:space-y-0",
				children: banners.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card border border-border rounded-2xl overflow-hidden",
					children: [b.video_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						src: b.video_url,
						className: "w-full h-32 object-cover bg-black",
						muted: true,
						playsInline: true,
						preload: "metadata",
						poster: b.image_url || void 0
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: b.image_url,
						alt: b.title_ar ?? "",
						className: "w-full h-32 object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-sm truncate",
									children: b.title_ar ?? "بدون عنوان"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground truncate",
									children: b.subtitle_ar ?? ""
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								onClick: () => {
									setForm({
										id: b.id,
										title_ar: b.title_ar ?? "",
										subtitle_ar: b.subtitle_ar ?? "",
										image_url: b.image_url ?? "",
										video_url: b.video_url ?? "",
										link: b.link ?? ""
									});
									setOpen(true);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "destructive",
								onClick: () => remove(b.id),
								className: "gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " حذف"]
							})
						]
					})]
				}, b.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: form.id ? "تعديل عرض" : "إضافة عرض" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
							images: form.image_url ? [form.image_url] : [],
							max: 1,
							onChange: (imgs) => setForm({
								...form,
								image_url: imgs[0] ?? ""
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs mb-1 block",
								children: "فيديو (اختياري)"
							}),
							form.video_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative rounded-xl overflow-hidden border border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
									src: form.video_url,
									className: "w-full max-h-48 bg-black",
									controls: true,
									playsInline: true,
									preload: "metadata"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setForm({
										...form,
										video_url: ""
									}),
									className: "absolute top-1 end-1 size-7 rounded-full bg-destructive text-white grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => videoInputRef.current?.click(),
								disabled: uploadingVideo,
								className: "w-full h-24 rounded-xl border-2 border-dashed border-border grid place-items-center text-muted-foreground hover:bg-muted transition text-xs gap-1",
								children: uploadingVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-full px-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] font-bold mb-1",
										children: [
											"جاري الرفع… ",
											Math.round(videoProgress * 100),
											"%"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-1.5 rounded-full bg-muted overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-gold transition-all",
											style: { width: `${videoProgress * 100}%` }
										})
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5" }), " رفع فيديو"] })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: videoInputRef,
								type: "file",
								accept: "video/*",
								className: "hidden",
								onChange: async (e) => {
									const f = e.target.files?.[0];
									if (!f) return;
									if (!(/^video\/(mp4|webm)$/i.test(f.type) || /\.(mp4|webm)$/i.test(f.name))) {
										toast.error("صيغة الفيديو غير مدعومة", {
											description: "يرجى رفع فيديو بصيغة MP4 أو WebM فقط. صيغ مثل MOV كبيرة جداً ولا تعمل على كل الأجهزة.",
											duration: 8e3
										});
										e.target.value = "";
										return;
									}
									if (f.size > MAX_BANNER_VIDEO_BYTES) {
										toast.error("حجم الفيديو كبير جداً", {
											description: `الحد الأقصى ${Math.round(MAX_BANNER_VIDEO_BYTES / (1024 * 1024))} ميغابايت. حجم الملف ${(f.size / (1024 * 1024)).toFixed(1)} ميغابايت — يرجى ضغطه قبل الرفع حتى لا يستهلك بيانات الزبائن.`,
											duration: 9e3
										});
										e.target.value = "";
										return;
									}
									if ((/^video\/mp4$/i.test(f.type) || /\.mp4$/i.test(f.name)) && !await isFaststartMp4(f)) {
										toast.error("الفيديو غير مهيأ للتشغيل الفوري", {
											description: "هذا الفيديو يحتاج تحميله كاملاً قبل التشغيل. أعد تصديره كـ MP4 مع خيار \"faststart\" أو \"web optimized\" (يضع فهرس الفيديو في البداية) ليبدأ فوراً عند الضغط.",
											duration: 12e3
										});
										e.target.value = "";
										return;
									}
									setUploadingVideo(true);
									setVideoProgress(0);
									try {
										const url = await uploadMediaFile(f, setVideoProgress);
										setForm((prev) => ({
											...prev,
											video_url: url
										}));
										toast.success("تم رفع الفيديو");
									} catch (err) {
										toast.error(err?.message ?? "فشل رفع الفيديو");
									} finally {
										setUploadingVideo(false);
										setVideoProgress(0);
										if (videoInputRef.current) videoInputRef.current.value = "";
									}
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground mt-1",
								children: "عند وجود فيديو سيُعرض بدل الصورة، والصورة تُستخدم كصورة أولية."
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "العنوان",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.title_ar,
								onChange: (e) => setForm({
									...form,
									title_ar: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "العنوان الفرعي",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.subtitle_ar,
								onChange: (e) => setForm({
									...form,
									subtitle_ar: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "رابط (اختياري)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.link,
								onChange: (e) => setForm({
									...form,
									link: e.target.value
								}),
								placeholder: "/category/..."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							onClick: save,
							children: "حفظ"
						})
					]
				})] })
			})
		]
	});
}
var ICON_OPTIONS = [
	{
		key: "engine",
		label: "محرك"
	},
	{
		key: "brake",
		label: "فرامل"
	},
	{
		key: "electrical",
		label: "كهرباء"
	},
	{
		key: "filter",
		label: "فلتر"
	},
	{
		key: "oil",
		label: "زيوت"
	},
	{
		key: "suspension",
		label: "محرك/تعليق"
	},
	{
		key: "body",
		label: "بدي"
	},
	{
		key: "wheel",
		label: "إطار"
	},
	{
		key: "wiper",
		label: "مساحات"
	},
	{
		key: "light",
		label: "إنارة"
	},
	{
		key: "tool",
		label: "أدوات"
	}
];
function TaxonomyAdmin() {
	const qc = useQueryClient();
	const { data: categories = [] } = useQuery(categoriesQuery());
	const { data: brands = [] } = useQuery(brandsQuery());
	const { data: carModels = [] } = useQuery(carModelsQuery());
	const [catOpen, setCatOpen] = (0, import_react.useState)(false);
	const [catForm, setCatForm] = (0, import_react.useState)({
		name_ar: "",
		name_en: "",
		icon: "",
		image_url: ""
	});
	const [brandOpen, setBrandOpen] = (0, import_react.useState)(false);
	const [brandForm, setBrandForm] = (0, import_react.useState)({
		name_ar: "",
		name_en: "",
		logo_url: ""
	});
	const [modelOpen, setModelOpen] = (0, import_react.useState)(false);
	const [modelForm, setModelForm] = (0, import_react.useState)({
		brand_id: "",
		name_ar: "",
		name_en: ""
	});
	const openCat = (c) => {
		setCatForm({
			id: c?.id,
			name_ar: c?.name_ar ?? "",
			name_en: c?.name_en ?? "",
			icon: c?.icon ?? "",
			image_url: c?.image_url ?? ""
		});
		setCatOpen(true);
	};
	const saveCategory = async () => {
		if (!catForm.name_ar.trim()) {
			toast.error("اسم التصنيف مطلوب");
			return;
		}
		const payload = {
			name_ar: catForm.name_ar,
			name_en: catForm.name_en || catForm.name_ar,
			icon: catForm.icon || null,
			image_url: catForm.image_url || null
		};
		const res = catForm.id ? await supabase.from("categories").update(payload).eq("id", catForm.id) : await supabase.from("categories").insert(payload);
		if (res.error) {
			toast.error(res.error.message);
			return;
		}
		toast.success(catForm.id ? "تم التحديث" : "تمت الإضافة");
		setCatOpen(false);
		qc.invalidateQueries({ queryKey: ["categories"] });
	};
	const addCategory = () => openCat();
	const removeCategory = async (id) => {
		if (!confirm("حذف التصنيف؟")) return;
		const { error } = await supabase.from("categories").delete().eq("id", id);
		if (error) toast.error(error.message);
		else qc.invalidateQueries({ queryKey: ["categories"] });
	};
	const openBrand = (b) => {
		setBrandForm({
			id: b?.id,
			name_ar: b?.name_ar ?? "",
			name_en: b?.name_en ?? "",
			logo_url: b?.logo_url ?? ""
		});
		setBrandOpen(true);
	};
	const saveBrand = async () => {
		if (!brandForm.name_ar.trim()) {
			toast.error("اسم الماركة مطلوب");
			return;
		}
		const payload = {
			name_ar: brandForm.name_ar,
			name_en: brandForm.name_en || brandForm.name_ar,
			logo_url: brandForm.logo_url || null
		};
		const res = brandForm.id ? await supabase.from("brands").update(payload).eq("id", brandForm.id) : await supabase.from("brands").insert(payload);
		if (res.error) {
			toast.error(res.error.message);
			return;
		}
		toast.success(brandForm.id ? "تم التحديث" : "تمت الإضافة");
		setBrandOpen(false);
		qc.invalidateQueries({ queryKey: ["brands"] });
	};
	const addBrand = () => openBrand();
	const removeBrand = async (id) => {
		if (!confirm("حذف الماركة؟")) return;
		const { error } = await supabase.from("brands").delete().eq("id", id);
		if (error) toast.error(error.message);
		else qc.invalidateQueries({ queryKey: ["brands"] });
	};
	const openModel = (m) => {
		setModelForm({
			id: m?.id,
			brand_id: m?.brand_id ?? "",
			name_ar: m?.name_ar ?? "",
			name_en: m?.name_en ?? ""
		});
		setModelOpen(true);
	};
	const saveModel = async () => {
		if (!modelForm.brand_id) {
			toast.error("اختر الماركة");
			return;
		}
		if (!modelForm.name_ar.trim()) {
			toast.error("اسم نوع السيارة مطلوب");
			return;
		}
		const payload = {
			brand_id: modelForm.brand_id,
			name_ar: modelForm.name_ar,
			name_en: modelForm.name_en || modelForm.name_ar
		};
		const res = modelForm.id ? await supabase.from("car_models").update(payload).eq("id", modelForm.id) : await supabase.from("car_models").insert(payload);
		if (res.error) {
			toast.error(res.error.message);
			return;
		}
		toast.success(modelForm.id ? "تم التحديث" : "تمت الإضافة");
		setModelOpen(false);
		qc.invalidateQueries({ queryKey: ["car_models"] });
	};
	const removeModel = async (id) => {
		if (!confirm("حذف نوع السيارة؟")) return;
		const { error } = await supabase.from("car_models").delete().eq("id", id);
		if (error) toast.error(error.message);
		else qc.invalidateQueries({ queryKey: ["car_models"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold",
					children: "التصنيفات"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: addCategory,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 me-1" }), " جديد"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 md:grid md:grid-cols-2 md:gap-3 md:space-y-0",
				children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card border border-border rounded-xl p-3 flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-12 rounded-lg bg-muted overflow-hidden shrink-0 flex items-center justify-center",
							children: c.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: c.image_url,
								alt: "",
								className: "size-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xl",
								children: categoryEmoji(c.icon)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 text-sm font-semibold truncate",
							children: c.name_ar
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => openCat(c),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => removeCategory(c.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-destructive" })
						})
					]
				}, c.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: catOpen,
				onOpenChange: setCatOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: catForm.id ? "تعديل تصنيف" : "إضافة تصنيف" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
								images: catForm.image_url ? [catForm.image_url] : [],
								max: 1,
								resizeTo: 256,
								onChange: (imgs) => setCatForm({
									...catForm,
									image_url: imgs[0] ?? ""
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الاسم بالعربي *",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: catForm.name_ar,
									onChange: (e) => setCatForm({
										...catForm,
										name_ar: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الاسم بالإنجليزي",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: catForm.name_en,
									onChange: (e) => setCatForm({
										...catForm,
										name_en: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الأيقونة (اختياري)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: catForm.icon || "__none__",
									onValueChange: (v) => setCatForm({
										...catForm,
										icon: v === "__none__" ? "" : v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "اختر أيقونة" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "__none__",
										children: "بدون"
									}), ICON_OPTIONS.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: opt.key,
										children: opt.label
									}, opt.key))] })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full",
								onClick: saveCategory,
								children: "حفظ"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold",
					children: "الماركات"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: addBrand,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 me-1" }), " جديد"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 md:grid md:grid-cols-2 md:gap-3 md:space-y-0",
				children: brands.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card border border-border rounded-xl p-3 flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-12 rounded-lg bg-muted overflow-hidden shrink-0 flex items-center justify-center",
							children: b.logo_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: b.logo_url,
								alt: "",
								className: "size-full object-contain p-1"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-5 text-muted-foreground" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 text-sm font-semibold truncate",
							children: b.name_ar
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => openBrand(b),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => removeBrand(b.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-destructive" })
						})
					]
				}, b.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: brandOpen,
				onOpenChange: setBrandOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: brandForm.id ? "تعديل ماركة" : "إضافة ماركة" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
								images: brandForm.logo_url ? [brandForm.logo_url] : [],
								max: 1,
								resizeTo: 256,
								onChange: (imgs) => setBrandForm({
									...brandForm,
									logo_url: imgs[0] ?? ""
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الاسم بالعربي *",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: brandForm.name_ar,
									onChange: (e) => setBrandForm({
										...brandForm,
										name_ar: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الاسم بالإنجليزي",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: brandForm.name_en,
									onChange: (e) => setBrandForm({
										...brandForm,
										name_en: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full",
								onClick: saveBrand,
								children: "حفظ"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold",
					children: "أنواع السيارات"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => openModel(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 me-1" }), " جديد"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 md:grid md:grid-cols-2 md:gap-3 md:space-y-0",
				children: [carModels.map((m) => {
					const brand = brands.find((b) => b.id === m.brand_id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card border border-border rounded-xl p-3 flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex-1 text-sm font-semibold truncate",
								children: [m.name_ar, brand && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground font-normal",
									children: [" — ", brand.name_ar]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								onClick: () => openModel(m),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								onClick: () => removeModel(m.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-destructive" })
							})
						]
					}, m.id);
				}), carModels.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm text-muted-foreground py-2",
					children: "لا توجد أنواع سيارات مسجلة"
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: modelOpen,
				onOpenChange: setModelOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: modelForm.id ? "تعديل نوع سيارة" : "إضافة نوع سيارة" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الماركة *",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: modelForm.brand_id || "__none__",
									onValueChange: (v) => setModelForm({
										...modelForm,
										brand_id: v === "__none__" ? "" : v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "اختر الماركة" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "__none__",
										children: "اختر الماركة"
									}), brands.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: b.id,
										children: b.name_ar
									}, b.id))] })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الاسم بالعربي *",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: modelForm.name_ar,
									onChange: (e) => setModelForm({
										...modelForm,
										name_ar: e.target.value
									}),
									placeholder: "مثال: ماليبو"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الاسم بالإنجليزي",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: modelForm.name_en,
									onChange: (e) => setModelForm({
										...modelForm,
										name_en: e.target.value
									}),
									placeholder: "Malibu",
									dir: "ltr"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full",
								onClick: saveModel,
								children: "حفظ"
							})
						]
					})]
				})
			})
		]
	});
}
function categoryEmoji(icon) {
	return {
		engine: "⚙️",
		brake: "🛞",
		braking: "🛞",
		electrical: "⚡",
		filter: "🌀",
		oil: "🛢️",
		suspension: "🔩",
		body: "🚙",
		wheel: "🛞",
		wiper: "🌧️",
		light: "💡",
		tool: "🛠️"
	}[icon ?? ""] ?? "🏷️";
}
function OrdersAdmin() {
	const qc = useQueryClient();
	const { data: orders = [], isLoading } = useQuery({
		queryKey: ["admin", "orders"],
		queryFn: async () => {
			const { data, error } = await supabase.from("orders").select("*").order("created_at", { ascending: false }).limit(100);
			if (error) throw error;
			return data ?? [];
		}
	});
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const [confirmMode, setConfirmMode] = (0, import_react.useState)("single");
	const [confirmId, setConfirmId] = (0, import_react.useState)(null);
	const [deleting, setDeleting] = (0, import_react.useState)(false);
	const [range, setRange] = (0, import_react.useState)("24h");
	const now = Date.now();
	const cutoff24 = now - 1440 * 60 * 1e3;
	const cutoff7 = now - 10080 * 60 * 1e3;
	const count24 = orders.filter((o) => new Date(o.created_at).getTime() >= cutoff24).length;
	const count7 = orders.filter((o) => new Date(o.created_at).getTime() >= cutoff7).length;
	const filtered = orders.filter((o) => {
		const t = new Date(o.created_at).getTime();
		if (range === "24h") return t >= cutoff24;
		if (range === "7d") return t >= cutoff7;
		return true;
	});
	const sum24 = orders.filter((o) => new Date(o.created_at).getTime() >= cutoff24).reduce((s, o) => s + Number(o.total_iqd || 0), 0);
	const updateStatus = async (id, status) => {
		const { error } = await supabase.from("orders").update({ status }).eq("id", id);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("تم التحديث");
		qc.invalidateQueries({ queryKey: ["admin", "orders"] });
	};
	const openDeleteSingle = (id) => {
		setConfirmMode("single");
		setConfirmId(id);
		setConfirmOpen(true);
	};
	const openDeleteAll = () => {
		if (!orders.length) return;
		setConfirmMode("all");
		setConfirmId(null);
		setConfirmOpen(true);
	};
	const executeDelete = async () => {
		setDeleting(true);
		setConfirmOpen(false);
		if (confirmMode === "single" && confirmId) {
			const { error } = await supabase.from("orders").delete().eq("id", confirmId);
			setDeleting(false);
			if (error) {
				toast.error(error.message);
				return;
			}
			toast.success("تم حذف الطلب");
			qc.invalidateQueries({ queryKey: ["admin", "orders"] });
		} else {
			const ids = orders.map((o) => o.id);
			const { error } = await supabase.from("orders").delete().in("id", ids);
			setDeleting(false);
			if (error) {
				toast.error(error.message);
				return;
			}
			toast.success("تم حذف جميع الطلبات");
			qc.invalidateQueries({ queryKey: ["admin", "orders"] });
		}
		setConfirmId(null);
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-center text-sm text-muted-foreground py-8",
		children: "جاري التحميل..."
	});
	if (!orders.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-center text-sm text-muted-foreground py-8",
		children: "لا توجد طلبات"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-gold/40 bg-gradient-to-l from-gold/10 to-transparent p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between mb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] text-muted-foreground",
						children: "آخر 24 ساعة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-lg font-black text-navy",
						children: [count24, " طلب جديد"]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground",
							children: "إجمالي"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-bold text-navy",
							children: [new Intl.NumberFormat("ar-IQ").format(sum24), " د.ع"]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1.5",
					children: [
						{
							k: "24h",
							label: `24 ساعة (${count24})`
						},
						{
							k: "7d",
							label: `7 أيام (${count7})`
						},
						{
							k: "all",
							label: `الكل (${orders.length})`
						}
					].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setRange(t.k),
						className: `h-8 px-3 rounded-xl text-[11px] font-bold border transition ${range === t.k ? "bg-gold text-navy border-gold" : "bg-card border-border text-muted-foreground hover:bg-muted"}`,
						children: t.label
					}, t.k))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [filtered.length, " طلب معروض"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: openDeleteAll,
					disabled: deleting,
					className: "h-9 px-3 rounded-xl border border-destructive/40 text-destructive text-xs font-bold flex items-center gap-1.5 hover:bg-destructive/10 disabled:opacity-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " حذف جميع الطلبات"]
				})]
			}),
			filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "لا توجد طلبات ضمن هذه الفترة"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2 md:grid md:grid-cols-2 md:gap-3 md:space-y-0",
				children: filtered.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderAdminCard, {
					order: o,
					onStatusChange: updateStatus,
					onDelete: openDeleteSingle
				}, o.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: confirmOpen,
				onOpenChange: setConfirmOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					dir: "rtl",
					className: "max-w-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, {
						className: "items-center sm:items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-12 rounded-full bg-destructive/10 grid place-items-center mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-6 text-destructive" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
								className: "text-base sm:text-lg",
								children: confirmMode === "all" ? "حذف جميع الطلبات" : "حذف الطلب"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
								className: "text-center",
								children: confirmMode === "all" ? `سيتم حذف ${orders.length} طلب بشكل نهائي. لا يمكن التراجع عن هذا الإجراء.` : "سيتم حذف هذا الطلب بشكل نهائي. لا يمكن التراجع عن هذا الإجراء."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, {
						className: "flex-col-reverse sm:flex-col-reverse gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
							className: "w-full mt-0",
							children: "إلغاء"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
							className: "w-full bg-destructive text-destructive-foreground hover:bg-destructive/90",
							onClick: executeDelete,
							disabled: deleting,
							children: deleting ? "جاري الحذف..." : "حذف نهائي"
						})]
					})]
				})
			})
		]
	});
}
function OrderAdminCard({ order: o, onStatusChange, onDelete }) {
	const isAdminHere = useIsAdmin();
	const staffHere = useStaffPermissions();
	const canBlockHere = isAdminHere || !!staffHere?.can_block;
	const addr = o.address ?? {};
	const phoneDigits = String(addr.phone ?? "").replace(/\D/g, "");
	const copy = async (text, label) => {
		try {
			await navigator.clipboard.writeText(text);
			toast.success(`تم نسخ ${label}`);
		} catch {
			toast.error("تعذّر النسخ");
		}
	};
	const { data: items = [] } = useQuery({
		queryKey: [
			"admin",
			"order-items",
			o.id
		],
		queryFn: async () => {
			const { data, error } = await supabase.from("order_items").select("id,name_ar,oem_number,image_url,unit_price_iqd,quantity,side,note").eq("order_id", o.id);
			if (error) throw error;
			return data ?? [];
		}
	});
	const { data: customer } = useQuery({
		queryKey: [
			"admin",
			"order-customer",
			o.user_id
		],
		enabled: !!o.user_id,
		queryFn: async () => {
			const { data } = await supabase.from("profiles").select("full_name, phone, is_blocked, avatar_url").eq("id", o.user_id).maybeSingle();
			return data ?? null;
		}
	});
	const qcCard = useQueryClient();
	const [blockSaving, setBlockSaving] = (0, import_react.useState)(false);
	const isBlocked = !!customer?.is_blocked;
	const toggleBlock = async () => {
		if (!o.user_id || blockSaving) return;
		const next = !isBlocked;
		let reason = next ? "تم حظر حسابك لأنك قمت بإرسال أكثر من طلب وهمي. يرجى التواصل مع قسم المبيعات." : void 0;
		setBlockSaving(true);
		try {
			await adminSetUserBlocked({ data: {
				user_id: o.user_id,
				blocked: next,
				reason
			} });
			toast.success(next ? "تم حظر الزبون وإرسال الإشعار" : "تم رفع الحظر");
			qcCard.invalidateQueries({ queryKey: [
				"admin",
				"order-customer",
				o.user_id
			] });
			qcCard.invalidateQueries({ queryKey: ["admin", "block-log"] });
			qcCard.invalidateQueries({ queryKey: ["admin", "blocked-users"] });
			qcCard.invalidateQueries({ queryKey: ["admin", "users"] });
		} catch (e) {
			toast.error(e?.message || "تعذّر تحديث الحالة");
		} finally {
			setBlockSaving(false);
		}
	};
	const addressRows = [
		{
			key: "label",
			label: "التسمية",
			value: addr.label || "—"
		},
		{
			key: "full_name",
			label: "الاسم الكامل",
			value: addr.full_name || "—"
		},
		{
			key: "phone",
			label: "رقم الهاتف",
			value: phoneDigits ? `+${phoneDigits}` : "—",
			mono: true
		},
		{
			key: "city",
			label: "المحافظة",
			value: addr.city || "—"
		},
		{
			key: "area",
			label: "المنطقة / القضاء",
			value: addr.area || "—"
		},
		{
			key: "street",
			label: "الشارع / تفاصيل",
			value: addr.street || "—"
		},
		{
			key: "notes",
			label: "ملاحظات إضافية",
			value: addr.notes || "—",
			muted: true
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-card border border-border rounded-2xl p-3 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs font-mono text-muted-foreground",
						children: ["#", (o.order_number ?? o.id).toString().slice(0, 10)]
					}), o.admin_reviewed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-100 border border-emerald-300 rounded-full px-2 py-0.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }), " تمت المراجعة"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `text-xs font-bold px-2 py-0.5 rounded-full ${statusColor(o.status)}`,
					children: statusLabel(o.status)
				})]
			}),
			customer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 -mb-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-11 rounded-full overflow-hidden bg-gradient-gold text-navy font-black grid place-items-center shrink-0",
						children: customer.avatar_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: customer.avatar_url,
							alt: "",
							className: "size-full object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: (customer.full_name?.[0] ?? "?").toUpperCase() })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-bold truncate",
							children: customer.full_name || addr.full_name || "زبون"
						}), customer.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground font-mono truncate",
							children: customer.phone
						})]
					}),
					isBlocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-bold text-destructive bg-destructive/10 border border-destructive/30 rounded-full px-2 py-0.5",
						children: "محظور"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border/80 bg-muted/30 p-3 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-xs font-bold text-gold mb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), " تفاصيل عنوان التوصيل"]
					}),
					addressRows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground text-xs shrink-0",
							children: row.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `flex-1 text-end ${row.mono ? "font-mono" : ""} ${row.muted ? "text-muted-foreground text-xs" : "font-semibold"}`,
							children: row.value
						})]
					}, row.key)),
					phoneDigits && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => copy([
							addr.label,
							addr.full_name,
							`+${phoneDigits}`,
							addr.city,
							addr.area,
							addr.street,
							addr.notes
						].filter(Boolean).join("\n"), "تفاصيل العنوان"),
						className: "w-full mt-1 h-8 rounded-lg border border-border text-muted-foreground text-xs font-bold flex items-center justify-center gap-1.5 hover:text-gold hover:border-gold/50 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), " نسخ العنوان كاملاً"]
					})
				]
			}),
			items.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border/70 divide-y divide-border/60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-3 py-1.5 text-[11px] font-bold text-muted-foreground bg-muted/30 rounded-t-xl",
					children: [
						"القطع (",
						items.length,
						")"
					]
				}), items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 p-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-12 rounded-lg bg-muted overflow-hidden shrink-0",
						children: it.image_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: it.image_url,
							alt: "",
							className: "size-full object-cover"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold line-clamp-2",
								children: it.name_ar
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-1.5 mt-1",
								children: [it.side && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex items-center rounded-full bg-navy text-primary-foreground px-2 py-0.5 text-[10px] font-black",
									children: it.side === "LH" ? "LH · يسار" : it.side === "RH" ? "RH · يمين" : "تخم"
								}), it.oem_number && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-[10px] text-muted-foreground",
									children: ["OEM: ", it.oem_number]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["×", it.quantity]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: formatIQD(Number(it.unit_price_iqd) * it.quantity)
								})]
							}),
							it.note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 flex items-start gap-1 text-[10px] text-muted-foreground bg-gold/5 border border-gold/20 rounded p-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "size-3 text-gold shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "whitespace-pre-wrap",
									children: it.note
								})]
							})
						]
					})]
				}, it.id))]
			}),
			o.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-gold/30 bg-gold/5 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 text-xs font-bold text-gold mb-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "size-3.5" }), " ملاحظة الزبون على الطلب"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm whitespace-pre-wrap",
					children: o.notes
				})]
			}),
			phoneDigits && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: `tel:+${phoneDigits}`,
				className: "flex items-center justify-center gap-1.5 h-9 rounded-lg bg-navy text-primary-foreground text-xs font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), " اتصال"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground text-xs",
					children: "الإجمالي"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-bold",
					children: formatIQD(o.total_iqd)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: o.status,
				onValueChange: (v) => onStatusChange(o.id, v),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-8 text-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: STATUSES.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: k,
					children: statusLabel(k)
				}, k)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceActions, {
				order: o,
				items,
				customer: customer ?? null
			}),
			o.user_id && canBlockHere && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: toggleBlock,
				disabled: blockSaving,
				className: `w-full h-10 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition ${isBlocked ? "border-success/40 text-success bg-success/5 hover:bg-success/10" : "border-destructive/40 text-destructive bg-destructive/5 hover:bg-destructive/10"} disabled:opacity-60 disabled:cursor-not-allowed`,
				children: blockSaving ? "جاري التحديث…" : isBlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), " رفع الحظر عن الزبون"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4" }), " حظر الزبون من الطلبات"] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => onDelete(o.id),
				className: "w-full h-10 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border border-destructive/40 text-destructive bg-destructive/5 hover:bg-destructive/10 transition",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " حذف الطلب نهائياً"]
			})
		]
	});
}
function InvoiceActions({ order, items, customer }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const qc = useQueryClient();
	const domId = `admin-invoice-${order.id}`;
	const previewId = `admin-invoice-preview-${order.id}`;
	const saved = !!order.admin_reviewed;
	const handleSave = async () => {
		const { error } = await supabase.from("orders").update({
			admin_reviewed: true,
			reviewed_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", order.id);
		if (error) throw error;
		qc.invalidateQueries({ queryKey: ["admin", "orders"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => setOpen(true),
			className: "w-full flex items-center justify-center gap-1.5 h-9 rounded-lg bg-gradient-gold text-navy text-xs font-bold shadow-gold",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4" }),
				" معاينة الفاتورة ",
				saved && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-700" })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintableInvoice, {
			order,
			items,
			customer,
			domId
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoicePreviewDialog, {
			order,
			items,
			customer,
			open,
			onOpenChange: setOpen,
			domId: previewId,
			onSave: handleSave,
			saved
		})
	] });
}
function ExternalApiSettings() {
	const qc = useQueryClient();
	const getConfig = useServerFn(getExternalApiConfig);
	const testFn = useServerFn(testExternalApi);
	const { data: config, isLoading } = useQuery({
		queryKey: ["app_settings", "external_api"],
		queryFn: () => getConfig()
	});
	const [baseUrl, setBaseUrl] = (0, import_react.useState)("");
	const [keyHeader, setKeyHeader] = (0, import_react.useState)("Authorization");
	const [apiKey, setApiKey] = (0, import_react.useState)("");
	const [showKey, setShowKey] = (0, import_react.useState)(false);
	const [endpoints, setEndpoints] = (0, import_react.useState)([]);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [testing, setTesting] = (0, import_react.useState)(null);
	const [testResult, setTestResult] = (0, import_react.useState)(null);
	const [connTesting, setConnTesting] = (0, import_react.useState)(false);
	const [connResult, setConnResult] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (config) {
			setBaseUrl(config.baseUrl);
			setKeyHeader(config.keyHeader || "Authorization");
			setApiKey(config.apiKey || "");
			setEndpoints(config.endpoints || []);
		}
	}, [config]);
	const addEndpoint = () => {
		setEndpoints((prev) => [...prev, {
			id: crypto.randomUUID(),
			name: "",
			method: "GET",
			path: ""
		}]);
	};
	const updateEndpoint = (id, patch) => {
		setEndpoints((prev) => prev.map((e) => e.id === id ? {
			...e,
			...patch
		} : e));
	};
	const removeEndpoint = (id) => {
		setEndpoints((prev) => prev.filter((e) => e.id !== id));
	};
	const save = async () => {
		const errs = validateExternalApiConfig({
			baseUrl,
			keyHeader,
			apiKey,
			endpoints
		});
		if (errs.length > 0) {
			toast.error(errs[0].message);
			return;
		}
		setSaving(true);
		try {
			const rows = [
				{
					key: "external_api_base_url",
					value: baseUrl.trim()
				},
				{
					key: "external_api_key_header",
					value: keyHeader.trim() || "Authorization"
				},
				{
					key: "external_api_key",
					value: apiKey.trim()
				},
				{
					key: "external_api_endpoints",
					value: JSON.stringify(endpoints)
				}
			];
			const { error } = await supabase.from("app_settings").upsert(rows.map((r) => ({
				...r,
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			})));
			if (error) throw error;
			toast.success("تم حفظ إعدادات API الخارجي");
			qc.invalidateQueries({ queryKey: ["app_settings"] });
			qc.invalidateQueries({ queryKey: ["app_settings", "external_api"] });
		} catch (e) {
			toast.error(e.message ?? "حدث خطأ");
		} finally {
			setSaving(false);
		}
	};
	const testEndpoint = async (id) => {
		setTesting(id);
		setTestResult(null);
		try {
			const result = await testFn({ data: { endpointId: id } });
			setTestResult({
				endpointId: id,
				ok: result.ok,
				message: result.ok ? `نجاح (${result.status})` : `فشل (${result.status})`
			});
		} catch (e) {
			setTestResult({
				endpointId: id,
				ok: false,
				message: e.message ?? "فشل الاتصال"
			});
		} finally {
			setTesting(null);
		}
	};
	const testConnection = async () => {
		setConnResult(null);
		const first = endpoints[0];
		if (!first) {
			setConnResult({
				ok: false,
				message: "أضف endpoint واحدًا على الأقل ثم احفظ الإعدادات."
			});
			return;
		}
		if (!config || config.baseUrl.trim() !== baseUrl.trim() || config.apiKey.trim() !== apiKey.trim() || JSON.stringify(config.endpoints) !== JSON.stringify(endpoints)) {
			setConnResult({
				ok: false,
				message: "احفظ الإعدادات أولاً قبل الاختبار."
			});
			return;
		}
		setConnTesting(true);
		try {
			const r = await testFn({ data: { endpointId: first.id } });
			const preview = (r.body || "").slice(0, 240);
			setConnResult({
				ok: r.ok,
				status: r.status,
				endpoint: `${first.method} ${first.path}`,
				message: r.ok ? "تم الاتصال بنجاح" : "فشل الاتصال",
				body: preview
			});
		} catch (e) {
			setConnResult({
				ok: false,
				message: e?.message ?? "خطأ غير متوقع"
			});
		} finally {
			setConnTesting(false);
		}
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-center text-xs text-muted-foreground py-4",
		children: "جاري التحميل…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-muted/30 border border-border rounded-2xl p-3 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-sm font-bold text-gold flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Webhook, { className: "size-4" }), " ربط API خارجي"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Base URL",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: baseUrl,
					onChange: (e) => setBaseUrl(e.target.value),
					placeholder: "https://api.example.com/v1",
					dir: "ltr"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "API Key Header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: keyHeader,
					onChange: (e) => setKeyHeader(e.target.value),
					placeholder: "Authorization أو X-API-Key",
					dir: "ltr"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mt-1",
					children: "إذا كان Header = Authorization سيرسل تلقائياً كـ Bearer Token."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "مفتاح API (API Key)",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: showKey ? "text" : "password",
						value: apiKey,
						onChange: (e) => setApiKey(e.target.value),
						placeholder: "ألصق مفتاح API هنا",
						dir: "ltr",
						className: "flex-1"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "sm",
						variant: "outline",
						onClick: () => setShowKey((v) => !v),
						children: showKey ? "إخفاء" : "إظهار"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mt-1",
					children: "يُخزَّن المفتاح في قاعدة البيانات (app_settings). لا تشاركه مع أحد."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-bold",
						children: "الـ Endpoints"
					}),
					endpoints.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: "لا توجد endpoints مضافة."
					}),
					endpoints.map((ep) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-12 gap-2 items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-span-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: ep.name,
									onChange: (e) => updateEndpoint(ep.id, { name: e.target.value }),
									placeholder: "اسم",
									className: "h-8 text-xs"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: ep.method,
									onValueChange: (v) => updateEndpoint(ep.id, { method: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-8 text-xs",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
										"GET",
										"POST",
										"PUT",
										"DELETE",
										"PATCH"
									].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: m,
										children: m
									}, m)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-span-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: ep.path,
									onChange: (e) => updateEndpoint(ep.id, { path: e.target.value }),
									placeholder: "/endpoint",
									dir: "ltr",
									className: "h-8 text-xs"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-2 flex gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									className: "h-8 px-2",
									onClick: () => testEndpoint(ep.id),
									disabled: testing === ep.id,
									children: testing === ep.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-3" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									className: "h-8 px-2 text-destructive",
									onClick: () => removeEndpoint(ep.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" })
								})]
							}),
							testResult?.endpointId === ep.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `col-span-12 text-xs ${testResult.ok ? "text-emerald-600" : "text-destructive"}`,
								children: testResult.message
							})
						]
					}, ep.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: addEndpoint,
						className: "gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" }), " إضافة endpoint"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-background/60 p-3 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						className: "w-full gap-2",
						onClick: testConnection,
						disabled: connTesting,
						children: [connTesting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4" }), connTesting ? "جاري الاختبار..." : "اختبار الاتصال"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted-foreground",
						children: "يُجرَّب أول endpoint من السيرفر باستخدام Base URL ومفتاح API المحفوظين."
					}),
					connResult && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `rounded-lg border p-2 text-xs space-y-1 ${connResult.ok ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400" : "border-destructive/40 bg-destructive/10 text-destructive"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-bold flex items-center gap-1",
								children: [
									connResult.ok ? "✓" : "✕",
									" ",
									connResult.message,
									connResult.status != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "opacity-70",
										children: ["— HTTP ", connResult.status]
									})
								]
							}),
							connResult.endpoint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								dir: "ltr",
								className: "font-mono opacity-80",
								children: connResult.endpoint
							}),
							connResult.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								dir: "ltr",
								className: "mt-1 max-h-32 overflow-auto rounded bg-black/5 dark:bg-white/5 p-1.5 font-mono text-[10px] whitespace-pre-wrap break-all",
								children: connResult.body
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-full",
				onClick: save,
				disabled: saving,
				children: saving ? "جاري الحفظ..." : "حفظ إعدادات API"
			})
		]
	});
}
/** Typed into the confirm box before the send button unlocks. A broadcast writes
*  one row per customer and cannot be undone, so a stray Enter must not send it. */
var BROADCAST_CONFIRM_WORD = "إرسال";
function BroadcastAdmin() {
	const countFn = useServerFn(adminBroadcastAudienceCount);
	const sendFn = useServerFn(sendAdminBroadcast);
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const [confirmText, setConfirmText] = (0, import_react.useState)("");
	const [sending, setSending] = (0, import_react.useState)(false);
	const { data: audience, isLoading: countLoading, refetch: refetchCount } = useQuery({
		queryKey: [
			"admin",
			"broadcast",
			"count",
			"all_customers"
		],
		queryFn: () => countFn({ data: { audience: "all_customers" } }),
		staleTime: 3e4
	});
	const recipients = audience?.count ?? 0;
	const titleTrimmed = title.trim();
	const canOpenConfirm = titleTrimmed.length > 0 && recipients > 0 && !sending;
	const send = async () => {
		setSending(true);
		try {
			const res = await sendFn({ data: {
				title: titleTrimmed,
				body: body.trim(),
				audience: "all_customers"
			} });
			toast.success(`تم إرسال الإشعار إلى ${res.sent} عميل`);
			setTitle("");
			setBody("");
			setConfirmOpen(false);
			setConfirmText("");
			refetchCount();
		} catch (err) {
			toast.error("تعذّر إرسال الإشعار", { description: err?.message ?? "خطأ غير معروف" });
		} finally {
			setSending(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-muted/30 border border-border rounded-2xl p-3 space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm font-bold text-gold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-4" }), " إرسال إشعار لجميع العملاء"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground leading-relaxed",
					children: "يصل الإشعار داخل التطبيق فوراً لكل عميل، ويظهر في جرس الإشعارات. لا يمكن التراجع بعد الإرسال."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "العنوان",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value.slice(0, 80)),
						placeholder: "وصلت قطع جديدة 🎉",
						maxLength: 80
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-muted-foreground mt-1",
						children: [
							titleTrimmed.length,
							"/",
							80
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "نص الرسالة (اختياري)",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: body,
						onChange: (e) => setBody(e.target.value.slice(0, 300)),
						rows: 4,
						placeholder: "تفقّد أحدث قطع الغيار المتوفرة الآن في المتجر.",
						maxLength: 300
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-muted-foreground mt-1",
						children: [
							body.trim().length,
							"/",
							300
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2 pt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm",
						children: countLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "جاري حساب عدد المستلمين…"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-bold",
							children: [
								"سيتم الإرسال إلى ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gold",
									children: recipients
								}),
								" عميل"
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						disabled: !canOpenConfirm,
						onClick: () => {
							setConfirmText("");
							setConfirmOpen(true);
						},
						children: sending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-4 me-1" }), " مراجعة وإرسال"] })
					})]
				}),
				recipients === 0 && !countLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-destructive",
					children: "لا يوجد عملاء لإرسال الإشعار إليهم."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
			open: confirmOpen,
			onOpenChange: (v) => {
				if (!sending) {
					setConfirmOpen(v);
					if (!v) setConfirmText("");
				}
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "تأكيد الإرسال الجماعي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 text-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								"سيصل هذا الإشعار إلى",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold text-foreground",
									children: [recipients, " عميل"]
								}),
								" ",
								"ولا يمكن التراجع عنه."
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-border bg-muted/40 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-foreground",
									children: titleTrimmed || "—"
								}), body.trim() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm mt-1 whitespace-pre-wrap",
									children: body.trim()
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								"اكتب «",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-foreground",
									children: BROADCAST_CONFIRM_WORD
								}),
								"» للتأكيد:"
							] })
						]
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: confirmText,
					onChange: (e) => setConfirmText(e.target.value),
					placeholder: BROADCAST_CONFIRM_WORD,
					disabled: sending
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
					disabled: sending,
					children: "إلغاء"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					onClick: (e) => {
						e.preventDefault();
						send();
					},
					disabled: sending || confirmText.trim() !== BROADCAST_CONFIRM_WORD,
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					children: sending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : `إرسال إلى ${recipients} عميل`
				})] })
			] })
		})]
	});
}
function SettingsAdmin() {
	const qc = useQueryClient();
	const { data: settings = {} } = useQuery(settingsQuery());
	const [wa, setWa] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [tagline, setTagline] = (0, import_react.useState)("");
	const [logo, setLogo] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [locationLink, setLocationLink] = (0, import_react.useState)("");
	const [years, setYears] = (0, import_react.useState)("");
	const [frontImage, setFrontImage] = (0, import_react.useState)("");
	const [about, setAbout] = (0, import_react.useState)("");
	const [shipLocalName, setShipLocalName] = (0, import_react.useState)("");
	const [shipLocalCost, setShipLocalCost] = (0, import_react.useState)("");
	const [shipAramexName, setShipAramexName] = (0, import_react.useState)("");
	const [shipAramexCost, setShipAramexCost] = (0, import_react.useState)("");
	const [priceAdjust, setPriceAdjust] = (0, import_react.useState)(null);
	const [ptsRedeem, setPtsRedeem] = (0, import_react.useState)(null);
	const [ptsEarn, setPtsEarn] = (0, import_react.useState)(null);
	const [ptsCapPct, setPtsCapPct] = (0, import_react.useState)(null);
	const [ptsMin, setPtsMin] = (0, import_react.useState)(null);
	const [ptsCardText, setPtsCardText] = (0, import_react.useState)(null);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const waVal = wa || settings.whatsapp_number || "";
	const phoneVal = phone || settings.phone_number || "";
	const nameVal = name || settings.store_name || "";
	const taglineVal = tagline || settings.store_tagline || "";
	const logoVal = logo || settings.store_logo || "";
	const addressVal = address || settings.store_address || "";
	const locationLinkVal = locationLink || settings.store_location_link || "";
	const yearsVal = years || settings.store_years || "7";
	const frontImageVal = frontImage || settings.store_front_image || "";
	const aboutVal = about || settings.store_about || "";
	const shipLocalNameVal = shipLocalName || settings.ship_local_name || "التوصيل المحلي";
	const shipLocalCostVal = shipLocalCost || settings.ship_local_cost || "5000";
	const shipAramexNameVal = shipAramexName || settings.ship_aramex_name || "أرامكس";
	const shipAramexCostVal = shipAramexCost || settings.ship_aramex_cost || "10000";
	const priceAdjustVal = priceAdjust !== null ? priceAdjust : String(settings.global_price_adjustment_iqd ?? "0");
	const DEFAULT_POINTS_CARD = "كل 100 نقطة = 1,000 دينار خصم عند الشراء";
	const ptsRedeemVal = ptsRedeem !== null ? ptsRedeem : String(settings.points_redeem_iqd_per_point ?? "10");
	const ptsEarnVal = ptsEarn !== null ? ptsEarn : String(settings.points_earn_per_1000_iqd ?? "10");
	const ptsCapPctVal = ptsCapPct !== null ? ptsCapPct : String(settings.points_max_redeem_pct ?? "50");
	const ptsMinVal = ptsMin !== null ? ptsMin : String(settings.points_min_redeem ?? "100");
	const ptsCardTextVal = ptsCardText !== null ? ptsCardText : String(settings.points_card_text ?? DEFAULT_POINTS_CARD);
	const upsert = async (rows) => {
		const { error } = await supabase.from("app_settings").upsert(rows.map((r) => ({
			...r,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		})));
		if (error) throw error;
	};
	const save = async () => {
		const clean = waVal.replace(/\D/g, "");
		if (clean.length < 8) {
			toast.error("أدخل رقم واتساب صحيح");
			return;
		}
		setSaving(true);
		try {
			await upsert([
				{
					key: "whatsapp_number",
					value: clean
				},
				{
					key: "phone_number",
					value: phoneVal.replace(/\D/g, "")
				},
				{
					key: "store_name",
					value: nameVal
				},
				{
					key: "store_tagline",
					value: taglineVal
				},
				{
					key: "store_logo",
					value: logoVal
				},
				{
					key: "store_address",
					value: addressVal
				},
				{
					key: "store_location_link",
					value: locationLinkVal
				},
				{
					key: "store_years",
					value: String(Number(yearsVal) || 7)
				},
				{
					key: "store_front_image",
					value: frontImageVal
				},
				{
					key: "store_about",
					value: aboutVal
				},
				{
					key: "ship_local_name",
					value: shipLocalNameVal
				},
				{
					key: "ship_local_cost",
					value: String(Number(shipLocalCostVal) || 0)
				},
				{
					key: "ship_aramex_name",
					value: shipAramexNameVal
				},
				{
					key: "ship_aramex_cost",
					value: String(Number(shipAramexCostVal) || 0)
				},
				{
					key: "global_price_adjustment_iqd",
					value: String(priceAdjustVal.trim() === "" || priceAdjustVal.trim() === "-" ? 0 : Math.trunc(Number(priceAdjustVal)) || 0)
				},
				{
					key: "points_redeem_iqd_per_point",
					value: String(Math.max(1, Math.trunc(Number(ptsRedeemVal)) || 10))
				},
				{
					key: "points_earn_per_1000_iqd",
					value: String(Math.max(0, Math.trunc(Number(ptsEarnVal)) || 0))
				},
				{
					key: "points_max_redeem_pct",
					value: String(Math.min(100, Math.max(0, Math.trunc(Number(ptsCapPctVal)) || 0)))
				},
				{
					key: "points_min_redeem",
					value: String(Math.max(0, Math.trunc(Number(ptsMinVal)) || 0))
				},
				{
					key: "points_card_text",
					value: ptsCardTextVal.trim() || DEFAULT_POINTS_CARD
				}
			]);
			toast.success("تم حفظ الإعدادات");
			qc.invalidateQueries({ queryKey: ["app_settings"] });
		} catch (e) {
			toast.error(e.message ?? "حدث خطأ");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 md:grid md:grid-cols-2 md:gap-x-4 md:gap-y-4 md:space-y-0 md:items-start",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "اسم المتجر",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: nameVal,
					onChange: (e) => setName(e.target.value),
					placeholder: "Ali Parts"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "الشعار الفرعي (تحت الاسم)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: taglineVal,
					onChange: (e) => setTagline(e.target.value),
					placeholder: "قطع أصلية · العراق"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs mb-1 block",
						children: "شعار المتجر (لوگو)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
						images: logoVal ? [logoVal] : [],
						max: 1,
						onChange: (imgs) => setLogo(imgs[0] ?? "")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-1",
						children: "إذا لم يتم رفع صورة سيظهر الحرف الأول من اسم المتجر."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "رقم الواتساب (صيغة دولية بدون +)",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: waVal,
					onChange: (e) => setWa(e.target.value),
					placeholder: "9647701234567",
					inputMode: "numeric",
					dir: "ltr"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mt-1",
					children: "مثال: 9647701234567 (964 رمز العراق + الرقم بدون صفر)"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "رقم الاتصال الهاتفي (صيغة دولية بدون +)",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: phoneVal,
					onChange: (e) => setPhone(e.target.value),
					placeholder: "9647701234567",
					inputMode: "numeric",
					dir: "ltr"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground mt-1",
					children: "يظهر في زر \"اتصال هاتفي\" بصفحة اتصل بنا. اتركه فارغاً لاستخدام رقم الواتساب."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "العنوان (يظهر في صفحة اتصل بنا ومن نحن)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: addressVal,
					onChange: (e) => setAddress(e.target.value),
					placeholder: "بغداد، العراق"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "رابط موقع المحل على الخريطة (Google Maps)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: locationLinkVal,
					onChange: (e) => setLocationLink(e.target.value),
					placeholder: "https://maps.google.com/?q=...",
					dir: "ltr"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "عدد سنوات الخبرة في السوق",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: yearsVal,
					onChange: (e) => setYears(e.target.value),
					inputMode: "numeric"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs mb-1 block",
						children: "صورة واجهة المحل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
						images: frontImageVal ? [frontImageVal] : [],
						max: 1,
						onChange: (imgs) => setFrontImage(imgs[0] ?? "")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mt-1",
						children: "تظهر في صفحة من نحن."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "نبذة عن المتجر (يظهر في من نحن)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: aboutVal,
						onChange: (e) => setAbout(e.target.value),
						rows: 4,
						placeholder: "متجر متخصص في بيع قطع غيار..."
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-muted/30 border border-border rounded-2xl p-3 space-y-2 md:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-bold text-gold",
						children: "تعديل السعر العام (د.ع)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						value: priceAdjustVal,
						onChange: (e) => setPriceAdjust(e.target.value),
						inputMode: "numeric",
						dir: "ltr",
						placeholder: "0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "يُضاف هذا المبلغ (أو يُطرح إذا كان سالباً) إلى سعر كل منتج عند عرضه للزبائن. مثال: 1000 يعني رفع كل الأسعار 1000 د.ع، و -1000 يعني خصم 1000 د.ع. لا يغيّر الأسعار الأصلية المحفوظة في قاعدة البيانات."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-muted/30 border border-border rounded-2xl p-3 space-y-3 md:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-bold text-gold flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), " نظام نقاط الولاء"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "قيمة النقطة بالدينار عند الاستبدال",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: ptsRedeemVal,
									onChange: (e) => setPtsRedeem(e.target.value),
									inputMode: "numeric",
									dir: "ltr",
									placeholder: "10",
									min: 1
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "النقاط المكتسبة لكل 1000 دينار",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: ptsEarnVal,
									onChange: (e) => setPtsEarn(e.target.value),
									inputMode: "numeric",
									dir: "ltr",
									placeholder: "10",
									min: 0
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "أقصى نسبة خصم بالنقاط من الطلب %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: ptsCapPctVal,
									onChange: (e) => setPtsCapPct(e.target.value),
									inputMode: "numeric",
									dir: "ltr",
									placeholder: "50",
									min: 0,
									max: 100
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "أقل عدد نقاط للاستبدال",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: ptsMinVal,
									onChange: (e) => setPtsMin(e.target.value),
									inputMode: "numeric",
									dir: "ltr",
									placeholder: "100",
									min: 0
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "وصف بطاقة النقاط (يظهر للزبون)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: ptsCardTextVal,
							onChange: (e) => setPtsCardText(e.target.value),
							placeholder: "كل 100 نقطة = 1,000 دينار خصم عند الشراء"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "تغيير «قيمة النقطة» يُعيد تقييم رصيد كل الزبائن مباشرة عند الاستبدال (رصيدهم بالنقاط لا يتغيّر، لكن قيمته بالدينار تتغيّر). «النقاط المكتسبة» تؤثّر فقط على الطلبات المستقبلية."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExchangeRateSettings, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCacheSettings, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-muted/30 border border-border rounded-2xl p-3 space-y-3 md:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-bold text-gold flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-4" }), " إعدادات شركات التوصيل"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "اسم الخيار الأول",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: shipLocalNameVal,
								onChange: (e) => setShipLocalName(e.target.value),
								placeholder: "التوصيل المحلي"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "كلفة التوصيل (د.ع)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: shipLocalCostVal,
								onChange: (e) => setShipLocalCost(e.target.value),
								inputMode: "numeric",
								dir: "ltr"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "اسم الخيار الثاني",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: shipAramexNameVal,
								onChange: (e) => setShipAramexName(e.target.value),
								placeholder: "أرامكس"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "كلفة التوصيل (د.ع)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: shipAramexCostVal,
								onChange: (e) => setShipAramexCost(e.target.value),
								inputMode: "numeric",
								dir: "ltr"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "اترك الاسم فارغاً لإخفاء الخيار من صفحة الدفع."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "md:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalApiSettings, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-full md:col-span-2",
				onClick: save,
				disabled: saving,
				children: saving ? "جاري الحفظ..." : "حفظ"
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
		className: "text-xs mb-1 block",
		children: label
	}), children] });
}
async function invalidateAllPriceCaches(qc) {
	await Promise.all([
		qc.invalidateQueries({ queryKey: ["products"] }),
		qc.invalidateQueries({ queryKey: ["product"] }),
		qc.invalidateQueries({ queryKey: ["cart"] }),
		qc.invalidateQueries({ queryKey: ["admin", "products"] }),
		qc.invalidateQueries({ queryKey: ["favorites"] })
	]);
	await qc.refetchQueries({ type: "active" });
	broadcastPricesChanged().catch(() => {});
}
function ExchangeRateSettings() {
	const qc = useQueryClient();
	const { data: settings = {} } = useQuery(settingsQuery());
	const [rate, setRate] = (0, import_react.useState)(null);
	const [rounding, setRounding] = (0, import_react.useState)(null);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const rateVal = rate ?? String(settings.usd_exchange_rate ?? "1500");
	const roundingVal = rounding ?? String(settings.usd_rounding ?? "500");
	const save = async () => {
		const r = Number(rateVal);
		if (!(r > 0)) {
			toast.error("أدخل سعر صرف صحيح");
			return;
		}
		setSaving(true);
		try {
			const now = (/* @__PURE__ */ new Date()).toISOString();
			const { error } = await supabase.from("app_settings").upsert([{
				key: "usd_exchange_rate",
				value: String(r),
				updated_at: now
			}, {
				key: "usd_rounding",
				value: String(Number(roundingVal) || 0),
				updated_at: now
			}]);
			if (error) throw error;
			qc.invalidateQueries({ queryKey: ["app_settings"] });
			toast.success("تم حفظ سعر الصرف، وتم تحديث جميع أسعار المنتجات تلقائياً");
			setRate(null);
			setRounding(null);
			await invalidateAllPriceCaches(qc);
		} catch (e) {
			toast.error(e.message ?? "فشل الحفظ");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-muted/30 border border-border rounded-2xl p-3 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm font-bold text-gold flex items-center gap-2",
				children: "💵 سعر صرف الدولار"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "كل الأسعار محفوظة بالدولار. عند تغيير سعر الصرف هنا، تُحسب أسعار جميع المنتجات بالدينار تلقائياً وتظهر مباشرة للزبائن."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "سعر صرف الدولار (د.ع لكل 1$)",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "number",
					value: rateVal,
					onChange: (e) => setRate(e.target.value),
					inputMode: "numeric",
					dir: "ltr",
					placeholder: "1500"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[11px] text-muted-foreground mt-1",
					dir: "ltr",
					children: [
						"1 USD = ",
						Number(rateVal) || 0,
						" IQD"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "التقريب",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: roundingVal,
					onValueChange: (v) => setRounding(v),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "0",
							children: "بدون تقريب"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "250",
							children: "أقرب 250 د.ع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "500",
							children: "أقرب 500 د.ع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "1000",
							children: "أقرب 1000 د.ع"
						})
					] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-full",
				onClick: save,
				disabled: saving,
				children: saving ? "جاري الحفظ..." : "حفظ سعر الصرف وتحديث كل الأسعار"
			})
		]
	});
}
async function resizeImageFile(file, size) {
	try {
		const bitmap = await createImageBitmap(file);
		const canvas = document.createElement("canvas");
		canvas.width = size;
		canvas.height = size;
		const ctx = canvas.getContext("2d");
		if (!ctx) return file;
		ctx.clearRect(0, 0, size, size);
		const scale = Math.min(size / bitmap.width, size / bitmap.height);
		const w = bitmap.width * scale;
		const h = bitmap.height * scale;
		ctx.drawImage(bitmap, (size - w) / 2, (size - h) / 2, w, h);
		const blob = await new Promise((res) => canvas.toBlob(res, "image/png", .92));
		if (!blob) return file;
		return new File([blob], file.name.replace(/\.[^.]+$/, "") + ".png", { type: "image/png" });
	} catch {
		return file;
	}
}
function ImageUploader({ images, onChange, max = 6, resizeTo, onUploadingChange }) {
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [done, setDone] = (0, import_react.useState)(0);
	const [total, setTotal] = (0, import_react.useState)(0);
	const fileRef = (0, import_react.useRef)(null);
	const handleFiles = async (files) => {
		if (!files || files.length === 0) return;
		setUploading(true);
		onUploadingChange?.(true);
		const list = Array.from(files).slice(0, max - images.length);
		setTotal(list.length);
		setDone(0);
		setProgress(0);
		try {
			const urls = [];
			for (const f of list) {
				if (images.length + urls.length >= max) break;
				const url = await uploadProductImage(resizeTo ? await resizeImageFile(f, resizeTo) : f, setProgress);
				if (url) urls.push(url);
				setDone((d) => d + 1);
				setProgress(0);
			}
			onChange([...images, ...urls]);
			toast.success("تم رفع الصور");
		} catch (e) {
			toast.error(e.message ?? "فشل رفع الصور");
		} finally {
			setUploading(false);
			onUploadingChange?.(false);
			setProgress(0);
			setDone(0);
			setTotal(0);
			if (fileRef.current) fileRef.current.value = "";
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "text-xs mb-1 block",
			children: "الصور"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2 flex-wrap",
			children: [images.map((url, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative size-20 rounded-xl overflow-hidden border border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: url,
					alt: "",
					className: "size-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange(images.filter((_, j) => j !== i)),
					className: "absolute top-0.5 end-0.5 size-6 rounded-full bg-destructive text-white grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" })
				})]
			}, i)), images.length < max && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => fileRef.current?.click(),
				disabled: uploading,
				className: "size-20 rounded-xl border-2 border-dashed border-border grid place-items-center text-muted-foreground hover:bg-muted transition",
				children: uploading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[10px] font-bold",
						children: [Math.round(progress * 100), "%"]
					}), total > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-[9px] text-muted-foreground",
						children: [
							done + 1,
							"/",
							total
						]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5" })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: fileRef,
			type: "file",
			accept: "image/*",
			multiple: true,
			className: "hidden",
			onChange: (e) => handleFiles(e.target.files)
		})
	] });
}
function DiagnosticsAdmin() {
	const [report, setReport] = (0, import_react.useState)(null);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const run = async () => {
		if (running) return;
		setRunning(true);
		setError(null);
		try {
			const r = await runDiagnostics();
			setReport(r);
		} catch (e) {
			setError(e?.message || "تعذّر تشغيل الفحص");
		} finally {
			setRunning(false);
		}
	};
	const didRunRef = (0, import_react.useRef)(false);
	if (!didRunRef.current && !running && !report && !error) {
		didRunRef.current = true;
		run();
	}
	const statusMeta = (s) => s === "ok" ? {
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "size-4" }),
		cls: "bg-success/10 text-success",
		label: "سليم"
	} : s === "warn" ? {
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4" }),
		cls: "bg-amber-500/10 text-amber-600",
		label: "تحذير"
	} : {
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-4" }),
		cls: "bg-destructive/10 text-destructive",
		label: "فشل"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm font-extrabold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-4" }), " تشخيص النظام"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "secondary",
					onClick: run,
					disabled: running,
					className: "gap-1",
					children: [running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5" }), "إعادة الفحص"]
				})]
			}),
			report && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-success/10 text-success p-3 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xl font-extrabold",
							children: report.summary.ok
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px]",
							children: "سليم"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-amber-500/10 text-amber-600 p-3 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xl font-extrabold",
							children: report.summary.warn
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px]",
							children: "تحذير"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-destructive/10 text-destructive p-3 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xl font-extrabold",
							children: report.summary.fail
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px]",
							children: "فشل"
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-destructive/10 text-destructive rounded-2xl p-3 text-sm",
				children: error
			}),
			running && !report && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center text-xs text-muted-foreground py-8 flex flex-col items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin" }), "جاري تنفيذ الفحص الشامل…"]
			}),
			report?.sections.map((sec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs font-bold text-muted-foreground pt-2",
					children: sec.title
				}), sec.checks.map((c) => {
					const m = statusMeta(c.status);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card border border-border rounded-2xl p-3 flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `size-9 rounded-full grid place-items-center shrink-0 ${m.cls}`,
							children: m.icon
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-bold flex items-center gap-2",
								children: [c.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-[10px] px-1.5 py-0.5 rounded-full font-semibold ${m.cls}`,
									children: m.label
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-0.5",
								children: c.detail
							})]
						})]
					}, c.id);
				})]
			}, sec.title)),
			report && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-[11px] text-muted-foreground text-center pt-2",
				children: ["آخر فحص: ", new Date(report.ranAt).toLocaleString("ar-IQ", {
					dateStyle: "medium",
					timeStyle: "short"
				})]
			})
		]
	});
}
var REPLACEMENT_STATUSES = [
	"pending",
	"in_review",
	"approved",
	"rejected",
	"resolved"
];
function replacementStatusLabel(s) {
	switch (s) {
		case "pending": return "بانتظار المراجعة";
		case "in_review": return "قيد المراجعة";
		case "approved": return "مقبول";
		case "rejected": return "مرفوض";
		case "resolved": return "منجز";
		default: return s;
	}
}
function replacementStatusColor(s) {
	switch (s) {
		case "pending": return "bg-amber-100 text-amber-800 border-amber-300";
		case "in_review": return "bg-blue-100 text-blue-800 border-blue-300";
		case "approved": return "bg-emerald-100 text-emerald-800 border-emerald-300";
		case "rejected": return "bg-rose-100 text-rose-800 border-rose-300";
		case "resolved": return "bg-navy text-primary-foreground border-navy";
		default: return "bg-muted text-muted-foreground border-border";
	}
}
function ReplacementsAdmin() {
	const qc = useQueryClient();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [confirmDeleteId, setConfirmDeleteId] = (0, import_react.useState)(null);
	const runUpdateStatus = useServerFn(adminUpdateReplacementStatus);
	const { data: rows = [], isLoading } = useQuery({
		queryKey: ["admin", "replacements"],
		queryFn: async () => {
			const { data, error } = await supabase.from("replacement_requests").select("*").order("created_at", { ascending: false }).limit(200);
			if (error) throw error;
			return data ?? [];
		}
	});
	const userIds = Array.from(new Set(rows.map((r) => r.user_id).filter(Boolean)));
	const { data: profiles = [] } = useQuery({
		queryKey: [
			"admin",
			"replacement-profiles",
			userIds.sort().join(",")
		],
		enabled: userIds.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("profiles").select("id, full_name, phone").in("id", userIds);
			if (error) throw error;
			return data ?? [];
		}
	});
	const profileMap = new Map(profiles.map((p) => [p.id, p]));
	const filtered = filter === "all" ? rows : rows.filter((r) => r.status === filter);
	const changeStatus = async (id, status) => {
		try {
			await runUpdateStatus({ data: {
				id,
				status
			} });
			toast.success("تم تحديث الحالة وإرسال إشعار للزبون");
			qc.invalidateQueries({ queryKey: ["admin", "replacements"] });
		} catch (err) {
			toast.error(err?.message ?? "تعذّر تحديث الحالة");
		}
	};
	const saveNotes = async (id, notes) => {
		const { error } = await supabase.from("replacement_requests").update({ admin_notes: notes }).eq("id", id);
		if (error) {
			toast.error("تعذّر حفظ الملاحظات");
			return;
		}
		toast.success("تم حفظ الملاحظات");
		qc.invalidateQueries({ queryKey: ["admin", "replacements"] });
	};
	const executeDelete = async () => {
		if (!confirmDeleteId) return;
		const { error } = await supabase.from("replacement_requests").delete().eq("id", confirmDeleteId);
		setConfirmDeleteId(null);
		if (error) {
			toast.error("تعذّر حذف الطلب");
			return;
		}
		toast.success("تم حذف الطلب");
		qc.invalidateQueries({ queryKey: ["admin", "replacements"] });
	};
	const counts = rows.reduce((acc, r) => {
		acc[r.status] = (acc[r.status] ?? 0) + 1;
		return acc;
	}, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 flex-wrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setFilter("all"),
					className: `h-8 px-3 rounded-full text-xs font-bold border ${filter === "all" ? "bg-navy text-primary-foreground border-navy" : "border-border hover:bg-muted"}`,
					children: [
						"الكل (",
						rows.length,
						")"
					]
				}), REPLACEMENT_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setFilter(s),
					className: `h-8 px-3 rounded-full text-xs font-bold border ${filter === s ? "bg-navy text-primary-foreground border-navy" : "border-border hover:bg-muted"}`,
					children: [
						replacementStatusLabel(s),
						" (",
						counts[s] ?? 0,
						")"
					]
				}, s))]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "py-12 text-center text-muted-foreground text-sm",
				children: "جاري التحميل..."
			}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-12 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-16 rounded-full bg-muted grid place-items-center mx-auto mb-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-8 text-muted-foreground" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm text-muted-foreground",
					children: "لا توجد طلبات استبدال"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3 md:grid md:grid-cols-2 md:gap-3 md:space-y-0",
				children: filtered.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReplacementCard, {
					row: r,
					profile: profileMap.get(r.user_id),
					onStatusChange: changeStatus,
					onSaveNotes: saveNotes,
					onDelete: () => setConfirmDeleteId(r.id)
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!confirmDeleteId,
				onOpenChange: (o) => !o && setConfirmDeleteId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					dir: "rtl",
					className: "max-w-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, {
						className: "items-center sm:items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-12 rounded-full bg-destructive/10 grid place-items-center mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-6 text-destructive" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "حذف طلب الاستبدال" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
								className: "text-center",
								children: "سيتم حذف الطلب نهائياً. لا يمكن التراجع عن هذا الإجراء."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, {
						className: "flex-col-reverse gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
							className: "w-full mt-0",
							children: "إلغاء"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
							className: "w-full bg-destructive text-destructive-foreground hover:bg-destructive/90",
							onClick: executeDelete,
							children: "حذف نهائي"
						})]
					})]
				})
			})
		]
	});
}
function ReplacementCard({ row, profile, onStatusChange, onSaveNotes, onDelete }) {
	const [notes, setNotes] = (0, import_react.useState)(row.admin_notes ?? "");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const dirty = (notes ?? "") !== (row.admin_notes ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-card rounded-2xl border border-border p-4 shadow-card space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2 flex-wrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `text-[10px] font-bold px-2 py-1 rounded-full border ${replacementStatusColor(row.status)}`,
					children: replacementStatusLabel(row.status)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[10px] text-muted-foreground ms-auto",
					children: new Date(row.created_at).toLocaleString("ar-IQ", {
						dateStyle: "short",
						timeStyle: "short"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm font-bold text-navy",
				children: row.product_name_ar ?? "منتج غير معروف"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-[11px] text-muted-foreground font-mono",
				children: ["طلب #", String(row.order_id).slice(0, 8)]
			})] }),
			profile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-xs flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: profile.full_name ?? "بدون اسم"
					}),
					profile.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `tel:${profile.phone}`,
						dir: "ltr",
						className: "ms-auto inline-flex items-center gap-1 font-mono font-semibold text-navy hover:text-gold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3" }),
							" ",
							profile.phone
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-muted/40 p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] font-bold text-gold mb-1",
					children: "سبب الاستبدال"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm whitespace-pre-wrap",
					children: row.reason
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-[11px] font-bold text-gold mb-1 block",
					children: "ملاحظات الإدارة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: notes,
					onChange: (e) => setNotes(e.target.value),
					placeholder: "ملاحظات داخلية عن المتابعة...",
					rows: 2,
					className: "text-sm",
					dir: "rtl"
				}),
				dirty && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					className: "mt-2",
					disabled: saving,
					onClick: async () => {
						setSaving(true);
						await onSaveNotes(row.id, notes);
						setSaving(false);
					},
					children: saving ? "جاري الحفظ..." : "حفظ الملاحظات"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 flex-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: row.status,
						onValueChange: (v) => onStatusChange(row.id, v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "h-9 w-auto min-w-40 text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: REPLACEMENT_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: s,
							children: replacementStatusLabel(s)
						}, s)) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/replacements/$id",
						params: { id: row.id },
						className: "h-9 px-3 rounded-xl border border-border text-xs font-bold flex items-center gap-1.5 hover:bg-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-3.5" }), " السجل"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onDelete,
						className: "h-9 px-3 rounded-xl border border-destructive/40 text-destructive text-xs font-bold flex items-center gap-1.5 hover:bg-destructive/10 ms-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), " حذف"]
					})
				]
			})
		]
	});
}
var REASON_LABEL = {
	order_placed: "طلب جديد",
	order_cancelled: "إلغاء طلب",
	order_uncancelled: "إعادة تفعيل طلب",
	order_deleted: "حذف طلب"
};
var REASON_TONE = {
	order_placed: "bg-rose-50 text-rose-700 border-rose-200",
	order_cancelled: "bg-emerald-50 text-emerald-700 border-emerald-200",
	order_uncancelled: "bg-amber-50 text-amber-700 border-amber-200",
	order_deleted: "bg-blue-50 text-blue-700 border-blue-200"
};
function StockMovementsAdmin() {
	const [reasonFilter, setReasonFilter] = (0, import_react.useState)("all");
	const [search, setSearch] = (0, import_react.useState)("");
	const { data: rows = [], isLoading } = useQuery({
		queryKey: [
			"admin",
			"stock-movements",
			reasonFilter
		],
		queryFn: async () => {
			let q = supabase.from("stock_movements").select("id, product_id, product_name_ar, delta, reason, order_id, order_number, actor_id, note, created_at").order("created_at", { ascending: false }).limit(300);
			if (reasonFilter !== "all") q = q.eq("reason", reasonFilter);
			const { data, error } = await q;
			if (error) throw error;
			return data ?? [];
		}
	});
	const actorIds = Array.from(new Set(rows.map((r) => r.actor_id).filter(Boolean)));
	const { data: actors = [] } = useQuery({
		queryKey: [
			"admin",
			"stock-movements-actors",
			actorIds.join("|")
		],
		enabled: actorIds.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.rpc("get_public_profiles", { _ids: actorIds });
			if (error) return [];
			return data ?? [];
		}
	});
	const actorName = (id) => actors.find((a) => a.id === id)?.full_name || (id ? id.slice(0, 8) : "—");
	const filtered = rows.filter((r) => {
		if (!search.trim()) return true;
		const s = search.trim().toLowerCase();
		return (r.product_name_ar ?? "").toLowerCase().includes(s) || (r.order_number ?? "").toLowerCase().includes(s) || (r.note ?? "").toLowerCase().includes(s);
	});
	const totals = filtered.reduce((acc, r) => {
		if (r.delta > 0) acc.in += r.delta;
		else acc.out += -r.delta;
		return acc;
	}, {
		in: 0,
		out: 0
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-emerald-200 bg-emerald-50/50 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 text-emerald-700 text-[11px] font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3.5" }), " إعادة إلى المخزون"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xl font-black text-emerald-700 mt-1",
						children: ["+", totals.in]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-rose-200 bg-rose-50/50 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 text-rose-700 text-[11px] font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5" }), " خصم من المخزون"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xl font-black text-rose-700 mt-1",
						children: ["−", totals.out]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5 absolute start-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: search,
						onChange: (e) => setSearch(e.target.value),
						placeholder: "ابحث بالمنتج، رقم الطلب، أو الملاحظة",
						className: "h-9 ps-8 text-xs"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: reasonFilter,
					onValueChange: setReasonFilter,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "h-9 w-36 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "كل الأسباب"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "order_placed",
							children: "طلب جديد"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "order_cancelled",
							children: "إلغاء طلب"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "order_uncancelled",
							children: "إعادة تفعيل"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "order_deleted",
							children: "حذف طلب"
						})
					] })]
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center py-8 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin inline-block me-1" }), " جاري التحميل..."]
			}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center py-10 text-xs text-muted-foreground bg-muted/40 rounded-2xl",
				children: "لا توجد حركات مخزون"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2 md:grid md:grid-cols-2 md:gap-3 md:space-y-0",
				children: filtered.map((r) => {
					const positive = r.delta > 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-2xl border border-border bg-card p-3 shadow-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `shrink-0 size-10 rounded-xl grid place-items-center font-black text-sm ${positive ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"}`,
								children: [positive ? "+" : "−", Math.abs(r.delta)]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-sm text-navy truncate",
											children: r.product_name_ar ?? "منتج محذوف"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `text-[10px] px-2 py-0.5 rounded-full border ${REASON_TONE[r.reason] ?? "bg-muted text-muted-foreground border-border"}`,
											children: REASON_LABEL[r.reason] ?? r.reason
										})]
									}),
									r.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground mt-0.5",
										children: r.note
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" }), new Date(r.created_at).toLocaleString("ar-IQ")]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3" }), actorName(r.actor_id)]
											}),
											r.order_number && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-3" }),
													"#",
													r.order_number
												]
											})
										]
									})
								]
							})]
						})
					}, r.id);
				})
			})
		]
	});
}
function VideoCacheSettings() {
	const [size, setSize] = (0, import_react.useState)(0);
	const [clearing, setClearing] = (0, import_react.useState)(false);
	const refresh = () => {
		getVideoCacheSize().then(setSize).catch(() => setSize(0));
	};
	(0, import_react.useEffect)(() => {
		refresh();
	}, []);
	const handleClear = async () => {
		setClearing(true);
		try {
			const removed = await clearVideoCache();
			toast.success(removed > 0 ? `تم مسح ${removed} فيديو من التخزين المؤقت` : "لا يوجد فيديو مخزّن");
			refresh();
		} catch {
			toast.error("تعذّر مسح كاش الفيديوهات");
		} finally {
			setClearing(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-muted/30 border border-border rounded-2xl p-3 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-sm font-bold text-gold flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-4" }), " كاش الفيديوهات"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "يتم تخزين الفيديوهات محلياً في المتصفح لتشغيلها بسرعة عند تكرار الفتح. امسح الكاش لتحرير المساحة أو لإجبار التطبيق على جلب أحدث نسخة من الفيديو."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: "عدد الفيديوهات المخزّنة: "
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-bold",
						children: size
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: handleClear,
					disabled: clearing,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, { className: "size-4 ms-1" }), clearing ? "جاري المسح..." : "مسح الكاش"]
				})]
			})
		]
	});
}
//#endregion
export { AdminPage as component };
