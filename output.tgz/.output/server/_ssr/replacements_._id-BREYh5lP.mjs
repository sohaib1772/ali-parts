import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/replacements_._id-BREYh5lP.js
var $$splitComponentImporter = () => import("./replacements_._id-DpNYVwgL.mjs");
var Route = createFileRoute("/_authenticated/replacements_/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
