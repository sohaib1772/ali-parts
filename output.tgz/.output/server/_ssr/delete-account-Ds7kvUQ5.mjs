import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { W as MessageCircle, f as Trash2 } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { s as whatsappLink } from "./format-CTK49jpu.mjs";
import { n as MissingSettingsNotice, r as useLegalContact, t as ContactList } from "./legal-contact-Cir7kLl-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/delete-account-Ds7kvUQ5.js
var import_jsx_runtime = require_jsx_runtime();
var LAST_UPDATED = "21 July 2026";
/**
* Public account-deletion page.
*
* Google Play requires a publicly reachable URL — no login — that explains how
* to request account deletion, what is deleted and what is retained. This URL
* goes in the Play Console data-safety form. It is deliberately OUTSIDE the
* _authenticated route group so a signed-out visitor (or a Play reviewer) can
* open it.
*/
function DeleteAccountPage() {
	const { storeName, ownerName, address, supportEmail, waNumber, missing } = useLegalContact();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "حذف الحساب",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 pt-4 pb-8 md:max-w-2xl md:mx-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				dir: "ltr",
				className: "bg-card rounded-2xl border border-border p-5 shadow-card space-y-5 text-sm leading-relaxed text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-12 rounded-full bg-destructive/15 grid place-items-center mb-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-6 text-destructive" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-lg font-black text-navy mb-1",
							children: "Delete Your Account"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Last updated:" }),
								" ",
								LAST_UPDATED
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"This page explains how to delete your ",
						storeName,
						" account and what happens to your data. It applies to the ",
						storeName,
						" mobile app and to maktabali.com."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Delete your account from inside the app",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The fastest way is to delete the account yourself. It takes effect immediately." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
								className: "list-decimal ps-6 space-y-1 mt-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open the app and sign in." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										"Go to ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "الحساب" }),
										" (Account)."
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										"Scroll to the bottom and tap ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "حذف الحساب" }),
										" (Delete account)."
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										"Read the summary, type ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "حذف" }),
										" to confirm, and tap",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "حذف حسابي نهائياً" }),
										"."
									] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2",
								children: "Your account and personal data are deleted straight away and you are signed out. This cannot be undone."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/account",
								className: "mt-3 inline-flex items-center gap-2 bg-navy text-primary-foreground text-xs font-bold px-4 py-2 rounded-xl",
								children: "Go to my account"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Request deletion by contacting us",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "If you cannot sign in — for example you have lost access to your Google or Apple account — contact us using the details at the bottom of this page and ask us to delete your account. Tell us the email address or phone number you used, so we can find the right account. We will verify your identity before deleting anything, and complete the request within 30 days." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "What is deleted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your profile: name, phone number and profile picture" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your saved delivery addresses" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your shopping cart and favourites" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your notifications and any device notification tokens" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your loyalty points balance" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your sign-in account itself (Google or Apple), so you can no longer sign in" })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "What is kept, and why",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Records of orders you have already placed are kept for accounting, tax and legal purposes, as described in our",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/privacy",
								className: "text-gold underline",
								children: "Privacy Policy"
							}),
							". Before your account is removed, those order records are ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "disconnected from it" }),
							" — they no longer identify you as a user of the app, and cannot be linked back to a deleted account."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: "This is the only data we retain. It is not used to contact you or to build any profile of you."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Contact us",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "To request deletion, or to ask what data we hold about you:" }),
							missing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissingSettingsNotice, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactList, {
								ownerName,
								address,
								supportEmail,
								waNumber
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappLink("I would like to delete my account", waNumber),
								target: "_blank",
								rel: "noopener noreferrer",
								className: "mt-3 inline-flex items-center gap-2 bg-navy text-primary-foreground text-xs font-bold px-4 py-2 rounded-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5" }), " Contact us on WhatsApp"]
							})
						]
					})
				]
			})
		})
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-bold text-gold mb-2",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm leading-relaxed",
		children
	})] });
}
//#endregion
export { DeleteAccountPage as component };
