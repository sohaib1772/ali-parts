import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, v as useSearch } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as objectType, n as enumType, o as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/storefront-filters-DpSWbFTB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Storefront filter state — the browse-first replacement for the old forced
* vehicle picker. Filters live in the URL (shareable, back-button friendly) and
* are mirrored to localStorage so a returning visitor keeps their last selection
* — but nothing is ever forced.
*
* Phase 1 filters: search + Category + Brand + Model. Year/Engine come later
* (they need product fitment data that does not exist yet).
*/
/** Shared search schema applied as `validateSearch` on every listing route, so
*  these params survive navigation (a bare z.object strips unknown keys) and are
*  typed. `mode` is kept for the existing /search OEM mode. */
var filterSearchSchema = objectType({
	q: stringType().optional(),
	cat: stringType().optional(),
	brand: stringType().optional(),
	model: stringType().optional(),
	mode: enumType(["oem"]).optional()
});
var EMPTY_FILTERS = {
	q: "",
	category: "",
	brand: "",
	model: ""
};
var STORAGE_KEY = "aliparts_filters";
var LEGACY_VEHICLE_KEY = "alsaaer_vehicle";
function readStored() {
	if (typeof window === "undefined") return {};
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (raw) return JSON.parse(raw);
		const legacy = window.localStorage.getItem(LEGACY_VEHICLE_KEY);
		if (legacy) {
			const v = JSON.parse(legacy);
			return {
				brand: v.brandId ?? "",
				model: v.modelId ?? ""
			};
		}
	} catch {}
	return {};
}
function writeStored(f) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify(f));
	} catch {}
}
function searchToFilters(s) {
	return {
		q: s.q ?? "",
		category: s.cat ?? "",
		brand: s.brand ?? "",
		model: s.model ?? ""
	};
}
/** Empty string → undefined so the key drops out of the URL entirely. */
function filtersToSearch(f) {
	return {
		q: f.q || void 0,
		cat: f.category || void 0,
		brand: f.brand || void 0,
		model: f.model || void 0
	};
}
/**
* Read + update the storefront filters. Route-agnostic (uses non-strict search),
* so the one FilterBar works on every listing screen. Every update writes both
* the URL and localStorage; `replace: true` keeps the back button meaningful
* (filter tweaks don't pile up history entries).
*/
function useStorefrontFilters() {
	const search = useSearch({ strict: false });
	const navigate = useNavigate();
	const filters = searchToFilters(search);
	const hydrated = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (hydrated.current) return;
		hydrated.current = true;
		if (!!(search.q || search.cat || search.brand || search.model)) return;
		const stored = readStored();
		const seeded = {
			...EMPTY_FILTERS,
			...stored
		};
		if (seeded.q || seeded.category || seeded.brand || seeded.model) navigate({
			search: (prev) => ({
				...prev,
				...filtersToSearch(seeded)
			}),
			replace: true
		});
	}, []);
	const apply = (0, import_react.useCallback)((next) => {
		writeStored(next);
		navigate({
			search: (prev) => ({
				...prev,
				...filtersToSearch(next)
			}),
			replace: true
		});
	}, [navigate]);
	return {
		filters,
		setFilter: (0, import_react.useCallback)((patch) => {
			const next = {
				...filters,
				...patch
			};
			apply(next);
		}, [filters, apply]),
		clearFilters: (0, import_react.useCallback)(() => {
			writeStored(EMPTY_FILTERS);
			navigate({
				search: (prev) => ({
					...prev,
					q: void 0,
					cat: void 0,
					brand: void 0,
					model: void 0
				}),
				replace: true
			});
		}, [navigate]),
		activeCount: (filters.category ? 1 : 0) + (filters.brand ? 1 : 0) + (filters.model ? 1 : 0) + (filters.q.trim() ? 1 : 0)
	};
}
/**
* The single, canonical, null-tolerant filter. Every listing screen runs its
* fetched products through this so behavior is identical everywhere and provably
* safe.
*
* Null-tolerance is the launch safeguard: a product is never hidden for lacking
* the data a filter targets.
*   - Category: strict — the primary browse axis; a product not in the chosen
*     category is excluded (uncategorised products are assumed complete).
*   - Brand: null-tolerant — a product with NO brand_id matches any brand.
*   - Model: null-tolerant — a product with empty/absent compatible_models is a
*     universal part and always shown; otherwise it must list the model.
*   - Search: name_ar / name_en / oem_number substring.
*/
function applyStorefrontFilters(products, filters) {
	const q = filters.q.trim().toLowerCase();
	return products.filter((p) => {
		if (filters.category && p.category_id !== filters.category) return false;
		if (filters.brand && p.brand_id && p.brand_id !== filters.brand) return false;
		if (filters.model) {
			const cm = p.compatible_models;
			if (!(!cm || cm.length === 0) && !cm.includes(filters.model)) return false;
		}
		if (q) {
			if (!`${p.name_ar ?? ""} ${p.name_en ?? ""} ${p.oem_number ?? ""}`.toLowerCase().includes(q)) return false;
		}
		return true;
	});
}
//#endregion
export { filterSearchSchema as n, useStorefrontFilters as r, applyStorefrontFilters as t };
