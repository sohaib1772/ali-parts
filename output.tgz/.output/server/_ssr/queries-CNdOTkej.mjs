import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { i as queryOptions, r as infiniteQueryOptions } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/queries-CNdOTkej.js
var PRODUCT_LIST_COLUMNS = "id, name_ar, name_en, oem_number, price_iqd, price_usd, compare_price_iqd, shipping_iqd, merge_delivery, delivery_group, category_id, brand_id, compatible_models, images, in_stock, stock_qty, is_featured, is_deal, deal_expires_at, sales_count, condition, created_at";
var categoriesQuery = () => queryOptions({
	queryKey: ["categories"],
	staleTime: 5 * 6e4,
	queryFn: async () => {
		const { data, error } = await supabase.from("categories").select("*").order("sort_order");
		if (error) throw error;
		return data ?? [];
	}
});
var brandsQuery = () => queryOptions({
	queryKey: ["brands"],
	staleTime: 5 * 6e4,
	queryFn: async () => {
		const { data, error } = await supabase.from("brands").select("*").order("sort_order");
		if (error) throw error;
		return data ?? [];
	}
});
var carModelsQuery = () => queryOptions({
	queryKey: ["car_models"],
	staleTime: 5 * 6e4,
	queryFn: async () => {
		const { data, error } = await supabase.from("car_models").select("*").order("sort_order");
		if (error) throw error;
		return data ?? [];
	}
});
var bannersQuery = () => queryOptions({
	queryKey: ["banners"],
	staleTime: 6e4,
	queryFn: async () => {
		const { data, error } = await supabase.from("banners").select("*").eq("is_active", true).order("created_at", { ascending: false });
		if (error) throw error;
		const now = Date.now();
		return (data ?? []).filter((b) => !b.expires_at || new Date(b.expires_at).getTime() > now);
	}
});
var featuredProductsQuery = () => queryOptions({
	queryKey: ["products", "featured"],
	staleTime: 2 * 6e4,
	queryFn: async () => {
		const { data, error } = await supabase.from("products").select(PRODUCT_LIST_COLUMNS).eq("is_featured", true).order("created_at", { ascending: false }).limit(10);
		if (error) throw error;
		return data ?? [];
	}
});
var dealsQuery = () => queryOptions({
	queryKey: ["products", "deals"],
	staleTime: 6e4,
	queryFn: async () => {
		const { data, error } = await supabase.from("products").select(PRODUCT_LIST_COLUMNS).eq("is_deal", true).order("created_at", { ascending: false }).limit(20);
		if (error) throw error;
		const now = Date.now();
		return (data ?? []).filter((p) => !p.deal_expires_at || new Date(p.deal_expires_at).getTime() > now);
	}
});
var bestSellersQuery = () => queryOptions({
	queryKey: ["products", "best-sellers"],
	staleTime: 2 * 6e4,
	queryFn: async () => {
		const { data, error } = await supabase.from("products").select(PRODUCT_LIST_COLUMNS).order("sales_count", { ascending: false }).order("created_at", { ascending: false }).limit(20);
		if (error) throw error;
		return data ?? [];
	}
});
var PRODUCTS_PAGE_SIZE = 12;
var productsInfiniteQuery = (condition) => infiniteQueryOptions({
	queryKey: [
		"products",
		"all",
		"infinite",
		condition ?? "all"
	],
	staleTime: 2 * 6e4,
	queryFn: async ({ pageParam = 0 }) => {
		let q = supabase.from("products").select(PRODUCT_LIST_COLUMNS).order("created_at", { ascending: true }).range(pageParam, pageParam + PRODUCTS_PAGE_SIZE - 1);
		if (condition) q = q.eq("condition", condition);
		const { data, error } = await q;
		if (error) {
			console.error("[productsInfiniteQuery] فشل جلب المنتجات", {
				pageParam,
				condition: condition ?? "all",
				code: error.code,
				message: error.message,
				details: error.details,
				hint: error.hint
			});
			throw new Error(`تعذّر تحميل المنتجات. يرجى التحقق من الاتصال والمحاولة مجدداً. (${error.message})`);
		}
		return data ?? [];
	},
	initialPageParam: 0,
	getNextPageParam: (lastPage, allPages) => lastPage.length === PRODUCTS_PAGE_SIZE ? allPages.length * PRODUCTS_PAGE_SIZE : void 0
});
var productByIdQuery = (id) => queryOptions({
	queryKey: ["product", id],
	staleTime: 2 * 6e4,
	queryFn: async () => {
		const { data, error } = await supabase.from("products").select("*").eq("id", id).single();
		if (error) throw error;
		return data;
	}
});
var productsByCategoryQuery = (categoryId) => queryOptions({
	queryKey: [
		"products",
		"category",
		categoryId
	],
	staleTime: 2 * 6e4,
	queryFn: async () => {
		const { data, error } = await supabase.from("products").select(PRODUCT_LIST_COLUMNS).eq("category_id", categoryId).order("in_stock", { ascending: false }).order("created_at", { ascending: false }).limit(60);
		if (error) throw error;
		return data ?? [];
	}
});
var storefrontSearchQuery = (filters) => {
	const q = (filters.q ?? "").trim();
	const category = filters.category ?? "";
	const brand = filters.brand ?? "";
	const model = filters.model ?? "";
	const hasFilter = Boolean(q || category || brand || model);
	return queryOptions({
		queryKey: [
			"products",
			"storefront-search",
			q,
			category,
			brand,
			model
		],
		staleTime: 6e4,
		queryFn: async () => {
			if (!hasFilter) return [];
			let req = supabase.from("products").select(PRODUCT_LIST_COLUMNS);
			if (q) {
				const pattern = `%${q}%`;
				req = req.or(`name_ar.ilike.${pattern},oem_number.ilike.${pattern},name_en.ilike.${pattern}`);
			}
			if (category) req = req.eq("category_id", category);
			if (brand) req = req.eq("brand_id", brand);
			req = req.order("in_stock", { ascending: false }).order("created_at", { ascending: false }).limit(60);
			const { data, error } = await req;
			if (error) throw error;
			return data ?? [];
		},
		enabled: hasFilter
	});
};
var cartQuery = (userId) => queryOptions({
	queryKey: ["cart", userId],
	queryFn: async () => {
		if (!userId) return [];
		const { data, error } = await supabase.from("cart_items").select("id, quantity, side, note, product_id, product:products(*)").eq("user_id", userId);
		if (error) throw error;
		return data ?? [];
	},
	enabled: !!userId
});
var favoritesQuery = (userId) => queryOptions({
	queryKey: ["favorites", userId],
	queryFn: async () => {
		if (!userId) return [];
		const { data, error } = await supabase.from("favorites").select("id, product:products(*)").eq("user_id", userId);
		if (error) throw error;
		return data ?? [];
	},
	enabled: !!userId
});
var ordersQuery = (userId) => queryOptions({
	queryKey: ["orders", userId],
	queryFn: async () => {
		if (!userId) return [];
		const { data, error } = await supabase.from("orders").select("id, user_id, order_number, status, total_iqd, subtotal_iqd, shipping_iqd, points_used, points_earned, payment_method, created_at, updated_at").eq("user_id", userId).order("created_at", { ascending: false }).limit(30);
		if (error) throw error;
		return data ?? [];
	},
	enabled: !!userId
});
var orderByIdQuery = (id) => queryOptions({
	queryKey: ["order", id],
	queryFn: async () => {
		const { data: order, error } = await supabase.from("orders").select("*").eq("id", id).single();
		if (error) throw error;
		const { data: items } = await supabase.from("order_items").select("*").eq("order_id", id);
		let customer = null;
		if (order?.user_id) {
			const { data: profile } = await supabase.from("profiles").select("full_name, phone").eq("id", order.user_id).maybeSingle();
			if (profile) customer = {
				full_name: profile.full_name,
				phone: profile.phone
			};
		}
		return {
			order,
			items: items ?? [],
			customer
		};
	}
});
var addressesQuery = (userId) => queryOptions({
	queryKey: ["addresses", userId],
	queryFn: async () => {
		if (!userId) return [];
		const { data, error } = await supabase.from("addresses").select("*").eq("user_id", userId).order("created_at", { ascending: false });
		if (error) throw error;
		return data ?? [];
	},
	enabled: !!userId
});
var profileQuery = (userId) => queryOptions({
	queryKey: ["profile", userId],
	queryFn: async () => {
		if (!userId) return null;
		const { data } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
		return data;
	},
	enabled: !!userId
});
//#endregion
export { storefrontSearchQuery as _, carModelsQuery as a, dealsQuery as c, orderByIdQuery as d, ordersQuery as f, profileQuery as g, productsInfiniteQuery as h, brandsQuery as i, favoritesQuery as l, productsByCategoryQuery as m, bannersQuery as n, cartQuery as o, productByIdQuery as p, bestSellersQuery as r, categoriesQuery as s, addressesQuery as t, featuredProductsQuery as u };
