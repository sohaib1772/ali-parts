import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { M as require_jsx_runtime, d as DialogContent$1, f as DialogDescription$1, h as DialogTitle$1, l as Dialog$1, m as DialogPortal$1, p as DialogOverlay$1, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { N as Printer, St as CircleCheck, et as Image, t as X, ut as FileDown } from "../_libs/lucide-react.mjs";
import { a as formatIQDEn, r as formatDateEn } from "./format-CTK49jpu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as statusLabel } from "./order-status-Chx_uF3Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/printable-invoice-DqxFZT5I.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute end-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var LOGO_URL = "/icon-512.png";
function PrintableInvoice({ order, items, domId, customer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: domId,
		className: "print-only invoice-print",
		dir: "rtl",
		style: { fontFamily: "'IBM Plex Sans Arabic', system-ui, sans-serif" },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceBody, {
			order,
			items,
			customer
		})
	});
}
var thStyle = {
	padding: "6px 8px",
	textAlign: "center",
	fontSize: "10px",
	fontWeight: 800,
	letterSpacing: "0.1em"
};
var tdStyle = {
	padding: "6px 8px",
	verticalAlign: "middle"
};
function TotalRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "flex",
			justifyContent: "space-between",
			padding: "3px 0",
			fontSize: "11px",
			color: "#334063"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			style: {
				fontFamily: "ui-monospace, monospace",
				color: "#0a1a3a",
				fontWeight: 700
			},
			children: value
		})]
	});
}
function InfoRow({ label, value, bold, mono, muted, highlight }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "flex",
			justifyContent: "space-between",
			alignItems: "baseline",
			gap: "10px",
			padding: highlight ? "5px 8px" : "3px 0",
			margin: highlight ? "4px 0" : 0,
			background: highlight ? "linear-gradient(90deg,#0a1a3a,#142451)" : "transparent",
			borderRadius: highlight ? "5px" : 0,
			color: highlight ? "#f5c96a" : muted ? "#5c6c8a" : "#334063",
			fontSize: highlight ? "13px" : "11px"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			style: {
				fontSize: highlight ? "10px" : "10px",
				fontWeight: highlight ? 800 : 600,
				letterSpacing: "0.05em",
				opacity: highlight ? .9 : 1
			},
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			style: {
				fontFamily: mono ? "ui-monospace, monospace" : "inherit",
				fontWeight: bold || highlight ? 900 : 700,
				color: highlight ? "#ffffff" : "#0a1a3a",
				textAlign: "left",
				direction: mono ? "ltr" : "inherit"
			},
			children: value
		})]
	});
}
/**
* inlineImagesAsDataUrls — replaces every <img src> under `root` with a
* base64 data URL, returning an undo function.
*
* WHY: rasterising to a canvas taints it if any drawn image is cross-origin
* without valid CORS, and a tainted canvas throws SecurityError on export.
* The invoice draws product photos from api.maktabali.com while the page is
* maktabali.com. Storage does send `Access-Control-Allow-Origin: *`, but the
* same photo is also rendered elsewhere (the order detail list) WITHOUT
* crossOrigin, so it can already sit in the HTTP cache as a non-CORS response.
* Safari will happily reuse that cached opaque response for the crossOrigin
* request and taint the canvas — which is why this failed on iOS but not
* desktop Chrome.
*
* Data URLs are same-origin by definition, so inlining removes the entire
* class of failure rather than relying on cache behaviour we don't control.
* A failed fetch drops the image (kept out of the canvas) instead of poisoning
* the whole export.
*/
async function inlineImagesAsDataUrls(root) {
	const imgs = Array.from(root.querySelectorAll("img"));
	const restores = [];
	await Promise.all(imgs.map(async (img) => {
		const original = img.getAttribute("src") ?? "";
		if (!original || original.startsWith("data:")) return;
		try {
			const res = await fetch(original, {
				mode: "cors",
				credentials: "omit"
			});
			if (!res.ok) throw new Error(`HTTP ${res.status}`);
			const blob = await res.blob();
			const dataUrl = await new Promise((resolve, reject) => {
				const fr = new FileReader();
				fr.onload = () => resolve(String(fr.result));
				fr.onerror = () => reject(/* @__PURE__ */ new Error("read failed"));
				fr.readAsDataURL(blob);
			});
			img.setAttribute("src", dataUrl);
			restores.push(() => img.setAttribute("src", original));
		} catch {
			const prevDisplay = img.style.display;
			img.style.display = "none";
			restores.push(() => {
				img.style.display = prevDisplay;
			});
		}
	}));
	return () => restores.forEach((fn) => fn());
}
async function downloadInvoicePdf(elementId, filename) {
	const source = document.getElementById(elementId);
	if (!source) return;
	const restoreImages = await inlineImagesAsDataUrls(source);
	try {
		return await renderInvoicePdf(source, filename);
	} finally {
		restoreImages();
	}
}
async function renderInvoicePdf(source, filename) {
	const [{ toPng }, { jsPDF }] = await Promise.all([import("../_libs/html-to-image.mjs").then((n) => n.t), import("../_libs/jspdf.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))]);
	const frame = document.createElement("iframe");
	frame.setAttribute("aria-hidden", "true");
	frame.style.cssText = [
		"position:fixed",
		"left:-10000px",
		"top:0",
		"width:900px",
		"height:1300px",
		"border:0",
		"background:#ffffff"
	].join(";");
	document.body.appendChild(frame);
	const frameDoc = frame.contentDocument;
	if (!frameDoc) {
		frame.remove();
		throw new Error("PDF frame unavailable");
	}
	frameDoc.open();
	frameDoc.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
    html,body{margin:0;padding:0;background:#fff;color:#0a1a3a;font-family:'IBM Plex Sans Arabic',Arial,sans-serif;}
    *{box-sizing:border-box;box-shadow:none!important;text-shadow:none!important;}
    table{border-collapse:collapse;}
  </style></head><body></body></html>`);
	frameDoc.close();
	const captureNode = source.cloneNode(true);
	captureNode.removeAttribute("id");
	captureNode.className = "";
	captureNode.style.cssText = [
		"display:block!important",
		"position:relative!important",
		"width:820px!important",
		"min-height:1123px!important",
		"background:#ffffff!important",
		"color:#0a1a3a!important",
		"opacity:1!important",
		"transform:none!important",
		"font-family:'IBM Plex Sans Arabic', system-ui, sans-serif!important"
	].join(";");
	captureNode.querySelectorAll("*").forEach((node) => {
		node.style.borderColor ||= "#e6e2d5";
		node.style.outlineColor ||= "#e6e2d5";
	});
	frameDoc.body.appendChild(captureNode);
	try {
		await frameDoc.fonts?.ready;
		await new Promise((r) => requestAnimationFrame(() => r(null)));
		const captureWidth = captureNode.scrollWidth || 820;
		const captureHeight = captureNode.scrollHeight || 1123;
		const imgData = await toPng(captureNode, {
			backgroundColor: "#ffffff",
			cacheBust: true,
			pixelRatio: 2,
			width: captureWidth,
			height: captureHeight
		});
		const pdf = new jsPDF({
			unit: "mm",
			format: "a4",
			orientation: "portrait"
		});
		const pageW = pdf.internal.pageSize.getWidth();
		const pageH = pdf.internal.pageSize.getHeight();
		const margin = 8;
		const imgW = pageW - margin * 2;
		const imgH = captureHeight * imgW / captureWidth;
		let heightLeft = imgH;
		let position = margin;
		pdf.addImage(imgData, "PNG", margin, position, imgW, imgH);
		heightLeft -= pageH - margin * 2;
		while (heightLeft > 0) {
			pdf.addPage();
			position = margin - (imgH - heightLeft);
			pdf.addImage(imgData, "PNG", margin, position, imgW, imgH);
			heightLeft -= pageH - margin * 2;
		}
		const blob = pdf.output("blob");
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = filename;
		document.body.appendChild(link);
		link.click();
		link.remove();
		setTimeout(() => URL.revokeObjectURL(url), 1e3);
	} finally {
		frame.remove();
	}
}
/**
* downloadInvoicePng — renders the invoice DOM to a high-resolution PNG
* and triggers a download. Uses the same offscreen iframe technique as the
* PDF export so the capture is not affected by dialog scaling.
*/
async function downloadInvoicePng(elementId, filename) {
	const source = document.getElementById(elementId);
	if (!source) return;
	const restoreImages = await inlineImagesAsDataUrls(source);
	try {
		return await renderInvoicePng(source, filename);
	} finally {
		restoreImages();
	}
}
async function renderInvoicePng(source, filename) {
	const { toPng } = await import("../_libs/html-to-image.mjs").then((n) => n.t);
	const imgs = Array.from(source.querySelectorAll("img"));
	await Promise.all(imgs.map((img) => {
		if (img.complete && img.naturalWidth > 0) return Promise.resolve();
		return new Promise((resolve) => {
			img.addEventListener("load", () => resolve(), { once: true });
			img.addEventListener("error", () => resolve(), { once: true });
			setTimeout(() => resolve(), 4e3);
		});
	}));
	await document.fonts?.ready?.catch?.(() => {});
	const dataUrl = await toPng(source, {
		backgroundColor: "#ffffff",
		cacheBust: true,
		pixelRatio: 2,
		width: source.scrollWidth || 820,
		height: source.scrollHeight || 1123,
		skipFonts: true
	});
	try {
		const { Capacitor } = await import("../_libs/@aparajita/capacitor-secure-storage+[...].mjs").then((n) => n.a);
		if (Capacitor.isNativePlatform()) {
			const base64 = dataUrl.split(",")[1] ?? "";
			const platform = Capacitor.getPlatform();
			try {
				const { Media } = await import("../_libs/capacitor-community__media.mjs").then((n) => n.t);
				const albumName = "Ali Chevrolet";
				let albumIdentifier;
				try {
					const found = (await Media.getAlbums()).albums?.find((a) => a.name === albumName);
					if (found) albumIdentifier = found.identifier ?? found.id ?? albumName;
					else {
						await Media.createAlbum({ name: albumName });
						const created = (await Media.getAlbums()).albums?.find((a) => a.name === albumName);
						albumIdentifier = created?.identifier ?? created?.id ?? albumName;
					}
				} catch {
					albumIdentifier = platform === "android" ? albumName : void 0;
				}
				try {
					await Media.savePhoto({
						path: `data:image/png;base64,${base64}`,
						albumIdentifier,
						fileName: filename
					});
				} catch (saveErr) {
					console.warn("[invoice] savePhoto with album failed, retrying without album", saveErr);
					await Media.savePhoto({
						path: `data:image/png;base64,${base64}`,
						fileName: filename
					});
				}
				return "native";
			} catch (mediaErr) {
				console.warn("[invoice] Media.savePhoto failed, falling back to Share", mediaErr);
			}
			const [{ Filesystem, Directory }, { Share }] = await Promise.all([import("../_libs/@capacitor/filesystem+[...].mjs").then((n) => n.t), import("../_libs/capacitor__share.mjs").then((n) => n.t)]);
			const written = await Filesystem.writeFile({
				path: filename,
				data: base64,
				directory: Directory.Documents
			});
			await Share.share({
				title: filename,
				text: "فاتورة",
				url: written.uri,
				dialogTitle: "حفظ الفاتورة في الاستوديو"
			});
			return "native-share";
		}
	} catch (err) {
		console.warn("[invoice] native save failed, falling back to browser download", err);
	}
	const isIOS = /iP(hone|ad|od)/.test(navigator.userAgent) || navigator.userAgent.includes("Macintosh") && "ontouchend" in document;
	try {
		if (isIOS) {
			const blob = await (await fetch(dataUrl)).blob();
			const file = new File([blob], filename, { type: "image/png" });
			const nav = navigator;
			if (typeof nav.share === "function" && nav.canShare?.({ files: [file] })) {
				await nav.share({
					files: [file],
					title: filename
				});
				return "web-share";
			}
		}
	} catch (err) {
		if (err instanceof Error && err.name === "AbortError") return "cancelled";
		console.warn("[invoice] web share failed, falling back to download", err);
	}
	const link = document.createElement("a");
	link.href = dataUrl;
	link.download = filename;
	document.body.appendChild(link);
	link.click();
	link.remove();
	return "browser";
}
/**
* InvoicePreviewDialog — opens a modal with a live preview of the invoice
* and buttons for printing / downloading PDF. Renders the actual
* PrintableInvoice inside a scaled viewport so the user can inspect it
* before saving.
*/
function InvoicePreviewDialog({ order, items, customer, open, onOpenChange, domId, onSave, saved }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const handlePdf = async () => {
		setBusy(true);
		try {
			await downloadInvoicePdf(domId, `invoice-${order.order_number ?? order.id}.pdf`);
			toast.success("تم تنزيل الفاتورة");
		} catch (err) {
			console.error("[invoice] PDF generation failed", err);
			toast.error("تعذّر توليد ملف PDF");
		} finally {
			setBusy(false);
		}
	};
	const handlePng = async () => {
		setBusy(true);
		try {
			const result = await downloadInvoicePng(domId, `invoice-${order.order_number ?? order.id}.png`);
			if (result === "native") toast.success("تم حفظ صورة الفاتورة بنجاح ✓", {
				description: "تم إضافتها إلى معرض الصور — ألبوم Ali Chevrolet",
				duration: 5e3
			});
			else if (result === "native-share") toast.success("تم إنشاء صورة الفاتورة ✓", {
				description: "اختر «حفظ الصورة» من قائمة المشاركة لإضافتها للاستوديو",
				duration: 5e3
			});
			else if (result === "web-share") toast.success("تم إنشاء صورة الفاتورة ✓", {
				description: "اختر «حفظ الصورة» من قائمة المشاركة",
				duration: 5e3
			});
			else if (result === "cancelled") {} else toast.success("تم حفظ الفاتورة كصورة ✓", { description: "تم تنزيل الملف على جهازك" });
		} catch (err) {
			console.error("[invoice] save as image failed", err);
			toast.error("تعذّر حفظ الصورة");
		} finally {
			setBusy(false);
		}
	};
	const handlePrint = () => {
		printOnlyThisInvoice(domId);
	};
	const handleSave = async () => {
		if (!onSave) return;
		setSaving(true);
		try {
			await onSave();
			toast.success("تم حفظ الفاتورة ووضع علامة صح على الطلب");
		} catch {
			toast.error("تعذّر الحفظ");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-3xl p-0 gap-0 overflow-hidden bg-[#f4efe4]",
			dir: "rtl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
				className: "px-4 py-3 border-b border-border bg-gradient-navy text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "text-sm font-black text-gold flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: LOGO_URL,
							alt: "",
							className: "size-7 rounded-md object-contain",
							onError: (e) => {
								e.currentTarget.style.display = "none";
							}
						}), "معاينة الفاتورة"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							onSave && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: handleSave,
								disabled: saving,
								className: `inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-xs font-black border disabled:opacity-50 ${saved ? "bg-emerald-500/20 border-emerald-400/60 text-emerald-200" : "bg-emerald-500 border-emerald-400 text-white hover:bg-emerald-600"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }),
									" ",
									saving ? "..." : saved ? "محفوظ ✓" : "حفظ"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: handlePrint,
								className: "inline-flex items-center gap-1.5 h-8 px-3 rounded-md bg-gradient-gold text-navy text-xs font-black shadow-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3.5" }), " طباعة"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: handlePng,
								disabled: busy,
								className: "inline-flex items-center gap-1.5 h-8 px-3 rounded-md bg-white/10 border border-white/20 text-white text-xs font-black hover:bg-white/15 disabled:opacity-50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-3.5" }),
									" ",
									busy ? "..." : "حفظ كصورة"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: handlePdf,
								disabled: busy,
								className: "inline-flex items-center gap-1.5 h-8 px-3 rounded-md bg-white/10 border border-white/20 text-white text-xs font-black hover:bg-white/15 disabled:opacity-50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "size-3.5" }),
									" ",
									busy ? "جاري..." : "تنزيل PDF"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => onOpenChange(false),
								className: "size-8 grid place-items-center rounded-md bg-white/10 hover:bg-white/15 text-white",
								"aria-label": "إغلاق",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})
						]
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-[75vh] overflow-auto p-4 bg-[radial-gradient(ellipse_at_top,#eae2cc_0%,#f4efe4_60%)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto bg-white shadow-2xl rounded-md overflow-hidden ring-1 ring-navy/10",
					style: {
						width: "780px",
						transformOrigin: "top center"
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						id: domId,
						dir: "rtl",
						style: { fontFamily: "'IBM Plex Sans Arabic', system-ui, sans-serif" },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceBody, {
							order,
							items,
							customer
						})
					})
				})
			})]
		})
	});
}
/**
* printOnlyThisInvoice — clones the invoice DOM into a dedicated hidden
* container flagged with the .print-only.pdf-capture combo. The CSS in
* src/styles.css hides every OTHER .print-only during print, so only this
* clone appears on paper — no other admin cards, no dialog chrome, no
* neighbouring invoices.
*/
function printOnlyThisInvoice(sourceId) {
	const src = document.getElementById(sourceId);
	if (!src) {
		window.print();
		return;
	}
	const host = document.createElement("div");
	host.className = "print-only pdf-capture invoice-print";
	host.setAttribute("dir", "rtl");
	host.style.fontFamily = "'IBM Plex Sans Arabic', system-ui, sans-serif";
	const clone = src.cloneNode(true);
	clone.removeAttribute("id");
	host.appendChild(clone);
	document.body.appendChild(host);
	const cleanup = () => host.remove();
	const onAfter = () => {
		window.removeEventListener("afterprint", onAfter);
		cleanup();
	};
	window.addEventListener("afterprint", onAfter);
	setTimeout(() => {
		window.print();
		setTimeout(cleanup, 2e3);
	}, 50);
}
/**
* Shared invoice body that the printable and preview both render.
* Extracted so preview shows the exact same layout without the
* display:none .print-only wrapper.
*/
function InvoiceBody({ order, items, customer }) {
	const addr = order.address ?? {};
	const pointsDiscount = Math.max(0, Number(order.subtotal_iqd ?? 0) + Number(order.shipping_iqd ?? 0) - Number(order.total_iqd ?? 0));
	const registeredPhone = customer?.phone?.trim() || null;
	const registeredName = customer?.full_name?.trim() || null;
	const primaryPhone = (addr.phone?.trim() || registeredPhone) ?? "-";
	const showRegisteredFallback = registeredPhone && registeredPhone !== (addr.phone?.trim() || "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			maxWidth: "780px",
			margin: "0 auto",
			padding: "0",
			color: "#0a1a3a",
			background: "#ffffff",
			position: "relative",
			overflow: "hidden"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					position: "absolute",
					inset: 0,
					display: "flex",
					alignItems: "center",
					justifyContent: "center",
					pointerEvents: "none",
					opacity: .05,
					zIndex: 0
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: LOGO_URL,
					alt: "",
					style: {
						width: "520px",
						height: "520px",
						objectFit: "contain"
					},
					onError: (e) => {
						e.currentTarget.style.display = "none";
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					position: "relative",
					zIndex: 1,
					background: "linear-gradient(135deg, #0a1a3a 0%, #142451 55%, #0a1a3a 100%)",
					color: "#f5c96a",
					padding: "18px 22px",
					borderBottom: "4px solid #c9a24a",
					display: "flex",
					justifyContent: "space-between",
					alignItems: "center",
					marginBottom: "18px"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						alignItems: "center",
						gap: "14px"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							width: "82px",
							height: "82px",
							borderRadius: "12px",
							background: "#000",
							padding: "4px",
							boxShadow: "0 6px 18px rgba(0,0,0,0.35)",
							display: "grid",
							placeItems: "center"
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: LOGO_URL,
							alt: "Ali Chevrolet",
							crossOrigin: "anonymous",
							style: {
								width: "100%",
								height: "100%",
								objectFit: "contain",
								borderRadius: "8px"
							},
							onError: (e) => {
								e.currentTarget.style.display = "none";
							}
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								fontSize: "24px",
								fontWeight: 900,
								letterSpacing: "0.02em",
								color: "#ffffff"
							},
							children: "ALI CHEVROLET"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								fontSize: "11px",
								color: "#f5c96a",
								fontWeight: 700,
								letterSpacing: "0.25em",
								marginTop: "3px"
							},
							children: "PREMIUM AUTO PARTS"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								fontSize: "10px",
								color: "#cfd6e6",
								marginTop: "4px",
								lineHeight: 1.5
							},
							children: "قطع غيار السيارات الأصلية · العراق"
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: { textAlign: "left" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							display: "inline-block",
							padding: "6px 14px",
							background: "linear-gradient(135deg,#f5c96a,#c9a24a)",
							color: "#0a1a3a",
							fontWeight: 900,
							fontSize: "12px",
							letterSpacing: "0.18em",
							borderRadius: "4px",
							boxShadow: "0 3px 10px rgba(201,162,74,0.4)"
						},
						children: "INVOICE · فاتورة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							marginTop: "10px",
							fontSize: "11px",
							color: "#cfd6e6"
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["رقم الفاتورة: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: {
									fontFamily: "ui-monospace, monospace",
									color: "#f5c96a",
									fontWeight: 700
								},
								children: order.order_number
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["التاريخ: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: {
									color: "#ffffff",
									fontWeight: 700
								},
								children: formatDateEn(order.created_at)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["الحالة: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: {
									color: "#ffffff",
									fontWeight: 700
								},
								children: statusLabel(order.status)
							})] })
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					position: "relative",
					zIndex: 1,
					padding: "0 22px 22px"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							border: "1px solid #e6e2d5",
							borderRadius: "8px",
							background: "#fff",
							marginBottom: "14px",
							overflow: "hidden"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								background: "linear-gradient(90deg,#f8f3e3,#fff)",
								padding: "6px 12px",
								fontSize: "9px",
								fontWeight: 800,
								letterSpacing: "0.22em",
								color: "#8a6a1a",
								borderBottom: "1px solid #eee5c9"
							},
							children: "CUSTOMER · معلومات الزبون"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "grid",
								gridTemplateColumns: "1.1fr 1fr",
								gap: 0
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: {
									padding: "12px 14px",
									borderLeft: "1px solid #eee5c9"
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
										label: "الاسم",
										value: addr.full_name ?? registeredName ?? "-",
										bold: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
										label: "📞 رقم الهاتف",
										value: primaryPhone,
										mono: true,
										highlight: true
									}),
									showRegisteredFallback && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
										label: "هاتف الحساب المسجّل",
										value: registeredPhone,
										mono: true,
										muted: true
									}),
									addr.label && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
										label: "التسمية",
										value: addr.label
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								style: { padding: "12px 14px" },
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
										label: "المحافظة",
										value: addr.city ?? "-",
										bold: true
									}),
									addr.area && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
										label: "القضاء",
										value: addr.area
									}),
									addr.street && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
										label: "الشارع",
										value: addr.street
									}),
									addr.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
										label: "ملاحظة العنوان",
										value: addr.notes,
										muted: true
									})
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							fontSize: "10px",
							fontWeight: 900,
							letterSpacing: "0.22em",
							color: "#8a6a1a",
							margin: "0 0 6px 0"
						},
						children: "ITEMS · المنتجات"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						style: {
							width: "100%",
							borderCollapse: "collapse",
							marginBottom: "14px",
							fontSize: "12px",
							background: "#fff"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							style: {
								background: "#0a1a3a",
								color: "#f5c96a"
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									style: thStyle,
									children: "#"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									style: thStyle,
									children: "الصورة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									style: {
										...thStyle,
										textAlign: "right"
									},
									children: "الوصف"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									style: thStyle,
									children: "الجهة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									style: thStyle,
									children: "الكمية"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									style: {
										...thStyle,
										textAlign: "left"
									},
									children: "سعر الوحدة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									style: {
										...thStyle,
										textAlign: "left"
									},
									children: "الإجمالي"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((it, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							style: { borderBottom: "1px solid #eee" },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									style: tdStyle,
									children: idx + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									style: {
										...tdStyle,
										textAlign: "center",
										width: "56px"
									},
									children: it.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: it.image_url,
										alt: "",
										crossOrigin: "anonymous",
										style: {
											width: "48px",
											height: "48px",
											objectFit: "cover",
											borderRadius: "6px",
											border: "1px solid #e6e2d5",
											background: "#f8f8f8"
										}
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
										width: "48px",
										height: "48px",
										borderRadius: "6px",
										background: "#f4efe4",
										border: "1px dashed #e6e2d5"
									} })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									style: {
										...tdStyle,
										textAlign: "right"
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											style: {
												fontWeight: 800,
												lineHeight: 1.25,
												color: "#0a1a3a"
											},
											children: it.name_ar
										}),
										it.oem_number && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											style: {
												fontSize: "9px",
												color: "#5c6c8a",
												fontFamily: "ui-monospace, monospace",
												direction: "ltr",
												textAlign: "right",
												marginTop: "1px"
											},
											children: ["OEM: ", it.oem_number]
										}),
										it.note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											style: {
												fontSize: "10px",
												color: "#8a6a1a",
												marginTop: "1px",
												lineHeight: 1.3
											},
											children: ["ملاحظة: ", it.note]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									style: {
										...tdStyle,
										textAlign: "center",
										fontWeight: 700
									},
									children: it.side ?? "-"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									style: {
										...tdStyle,
										textAlign: "center"
									},
									children: ["× ", it.quantity]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									style: {
										...tdStyle,
										textAlign: "left",
										fontFamily: "ui-monospace, monospace"
									},
									children: formatIQDEn(Number(it.unit_price_iqd))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									style: {
										...tdStyle,
										textAlign: "left",
										fontFamily: "ui-monospace, monospace",
										fontWeight: 800
									},
									children: formatIQDEn(Number(it.unit_price_iqd) * it.quantity)
								})
							]
						}, it.id)) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							display: "grid",
							gridTemplateColumns: "1fr 260px",
							gap: "14px",
							alignItems: "start"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: order.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								border: "1px dashed #c9a24a",
								borderRadius: "6px",
								padding: "10px 12px",
								background: "#fff8e6"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: {
									fontSize: "9px",
									fontWeight: 800,
									letterSpacing: "0.2em",
									color: "#8a6a1a",
									marginBottom: "4px"
								},
								children: "NOTE · ملاحظة الزبون"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: {
									fontSize: "11px",
									color: "#0a1a3a",
									whiteSpace: "pre-wrap"
								},
								children: order.notes
							})]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								border: "1px solid #e6e2d5",
								borderRadius: "6px",
								padding: "10px 12px",
								fontSize: "12px",
								background: "#fff"
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TotalRow, {
									label: "المجموع الفرعي",
									value: formatIQDEn(order.subtotal_iqd)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TotalRow, {
									label: "التوصيل",
									value: formatIQDEn(order.shipping_iqd)
								}),
								pointsDiscount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TotalRow, {
									label: `خصم نقاط (${order.points_used})`,
									value: `- ${formatIQDEn(pointsDiscount)}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: {
										borderTop: "2px solid #0a1a3a",
										marginTop: "6px",
										paddingTop: "8px",
										display: "flex",
										justifyContent: "space-between",
										alignItems: "baseline"
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										style: { fontWeight: 900 },
										children: "الإجمالي"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										style: {
											fontSize: "18px",
											fontWeight: 900,
											color: "#0a1a3a",
											fontFamily: "ui-monospace, monospace"
										},
										children: formatIQDEn(order.total_iqd)
									})]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							marginTop: "22px",
							paddingTop: "12px",
							borderTop: "1px solid #e6e2d5",
							display: "flex",
							justifyContent: "space-between",
							alignItems: "flex-end"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								fontSize: "10px",
								color: "#5c6c8a",
								lineHeight: 1.6
							},
							children: [
								"شكراً لتسوقكم من ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									style: { color: "#0a1a3a" },
									children: "ALI CHEVROLET"
								}),
								" — قطع أصلية ١٠٠٪",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"للاستفسار تواصل مع خدمة الزبائن"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: { textAlign: "left" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
								borderTop: "1px solid #0a1a3a",
								width: "160px",
								marginBottom: "4px"
							} }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: {
									fontSize: "10px",
									color: "#5c6c8a"
								},
								children: "التوقيع / الختم"
							})]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { InvoicePreviewDialog as a, DialogTitle as i, DialogContent as n, PrintableInvoice as o, DialogHeader as r, Dialog as t };
