import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/label-DUtvElRz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHANNEL = "price-updates";
var EVENT = "prices_changed";
var BC_NAME = "app-price-sync";
var LOG_KEY = "price_sync_log";
var MAX_LOG = 100;
function getTabId() {
	if (typeof window === "undefined") return "ssr";
	const w = window;
	if (!w.__priceSyncTabId) w.__priceSyncTabId = Math.random().toString(36).slice(2, 8);
	return w.__priceSyncTabId;
}
function logEntry(kind, info) {
	const entry = {
		ts: Date.now(),
		tab: getTabId(),
		kind,
		info
	};
	console.info(`[price-sync] ${new Date(entry.ts).toISOString()} tab=${entry.tab} ${kind}`, info ?? "");
	try {
		if (typeof sessionStorage !== "undefined") {
			const raw = sessionStorage.getItem(LOG_KEY);
			const arr = raw ? JSON.parse(raw) : [];
			arr.push(entry);
			while (arr.length > MAX_LOG) arr.shift();
			sessionStorage.setItem(LOG_KEY, JSON.stringify(arr));
		}
	} catch {}
	try {
		const w = window;
		if (!w.__priceSync) w.__priceSync = { log: [] };
		w.__priceSync.log.push(entry);
		if (w.__priceSync.log.length > MAX_LOG) w.__priceSync.log.shift();
	} catch {}
}
var PRICE_KEYS = [
	["products"],
	["product"],
	["cart"],
	["admin", "products"],
	["favorites"]
];
function invalidateAll(qc, source) {
	const t0 = performance.now();
	for (const key of PRICE_KEYS) qc.invalidateQueries({ queryKey: key });
	qc.refetchQueries({ type: "active" }).finally(() => {
		logEntry("invalidated", {
			source,
			duration_ms: Math.round(performance.now() - t0),
			keys: PRICE_KEYS.map((k) => k.join(":"))
		});
	});
}
/**
* Broadcast a "prices changed" event to all connected clients (other tabs,
* other devices) and to the same browser via BroadcastChannel. Call this
* from the admin panel after a bulk price update or restore succeeds.
*/
async function broadcastPricesChanged() {
	const startedAt = Date.now();
	try {
		const ch = supabase.channel(CHANNEL);
		await new Promise((resolve) => {
			ch.subscribe((status) => {
				if (status === "SUBSCRIBED") resolve();
			});
			setTimeout(() => resolve(), 1500);
		});
		await ch.send({
			type: "broadcast",
			event: EVENT,
			payload: { at: Date.now() }
		});
		await supabase.removeChannel(ch);
		logEntry("broadcast_sent", {
			transport: "realtime",
			elapsed_ms: Date.now() - startedAt
		});
	} catch {
		logEntry("broadcast_sent", {
			transport: "realtime",
			error: true
		});
	}
	try {
		if (typeof BroadcastChannel !== "undefined") {
			const bc = new BroadcastChannel(BC_NAME);
			bc.postMessage({
				event: EVENT,
				at: Date.now()
			});
			bc.close();
			logEntry("broadcast_sent", { transport: "broadcast_channel" });
		}
	} catch {}
}
/**
* Subscribe every client to price-change broadcasts and refresh the caches
* that render prices (product cards, product detail, cart, checkout).
* Also refetches on tab focus so a tab returning from background catches up.
*/
function usePriceSyncListener() {
	const qc = useQueryClient();
	(0, import_react.useEffect)(() => {
		const ch = supabase.channel(CHANNEL);
		ch.on("broadcast", { event: EVENT }, (msg) => {
			const at = (msg?.payload)?.at;
			logEntry("received_realtime", { latency_ms: typeof at === "number" ? Date.now() - at : void 0 });
			invalidateAll(qc, "realtime");
		}).subscribe();
		let bc = null;
		try {
			if (typeof BroadcastChannel !== "undefined") {
				bc = new BroadcastChannel(BC_NAME);
				bc.onmessage = (ev) => {
					const at = ev.data?.at;
					logEntry("received_broadcast_channel", { latency_ms: typeof at === "number" ? Date.now() - at : void 0 });
					invalidateAll(qc, "broadcast_channel");
				};
			}
		} catch {}
		const onFocus = () => {
			if (document.visibilityState === "visible") {
				logEntry("received_visibility");
				invalidateAll(qc, "visibility");
			}
		};
		document.addEventListener("visibilitychange", onFocus);
		return () => {
			supabase.removeChannel(ch);
			bc?.close();
			document.removeEventListener("visibilitychange", onFocus);
		};
	}, [qc]);
}
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
//#endregion
export { broadcastPricesChanged as n, usePriceSyncListener as r, Label as t };
