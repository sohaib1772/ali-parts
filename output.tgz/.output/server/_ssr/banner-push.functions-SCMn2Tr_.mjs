import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { o as createSsrRpc } from "./admin.functions-ByyqQhlH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/banner-push.functions-SCMn2Tr_.js
var broadcastBannerPush = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => {
	if (!input || typeof input.bannerId !== "string" || !input.bannerId) throw new Error("bannerId required");
	return input;
}).handler(createSsrRpc("b9e529f0850c2850bc6f721791444437b5b772c146c5078346159706e568634b"));
//#endregion
export { broadcastBannerPush };
