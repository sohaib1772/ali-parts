//#region node_modules/.nitro/vite/services/ssr/assets/shipping-leVkJgrK.js
function computeShipping(items) {
	if (!items || !Array.isArray(items)) return 0;
	const groups = /* @__PURE__ */ new Map();
	let anon = 0;
	for (const i of items) {
		const p = i?.product;
		if (!p) continue;
		const rawFee = Number(p.shipping_iqd ?? 0);
		const fee = Number.isFinite(rawFee) && rawFee > 0 ? rawFee : 0;
		const merge = p.merge_delivery !== false;
		const id = typeof p.id === "string" || typeof p.id === "number" ? String(p.id) : `__anon_${anon++}`;
		const key = merge ? "g:__merged__" : `p:${id}`;
		groups.set(key, Math.max(groups.get(key) ?? 0, fee));
	}
	let sum = 0;
	for (const v of groups.values()) sum += v;
	return sum;
}
function shipmentCount(items) {
	if (!items || !Array.isArray(items)) return 0;
	const keys = /* @__PURE__ */ new Set();
	let anon = 0;
	for (const i of items) {
		const p = i?.product;
		if (!p) continue;
		const merge = p.merge_delivery !== false;
		const id = typeof p.id === "string" || typeof p.id === "number" ? String(p.id) : `__anon_${anon++}`;
		keys.add(merge ? "g:__merged__" : `p:${id}`);
	}
	return keys.size;
}
//#endregion
export { shipmentCount as n, computeShipping as t };
