import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as useAdjustedPrice } from "./admin-DdF3xehS.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as Plus, U as Minus, f as Trash2, v as StickyNote, x as ShoppingBag } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { o as cartQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD } from "./format-CTK49jpu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as computeShipping } from "./shipping-leVkJgrK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cart-CuhvO_7Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CartPage() {
	const { userId } = useAuth();
	const { data: items = [], isLoading, isError, refetch } = useQuery(cartQuery(userId));
	const qc = useQueryClient();
	const navigate = useNavigate();
	const [pendingIds, setPendingIds] = (0, import_react.useState)({});
	const markPending = (id, on) => setPendingIds((p) => ({
		...p,
		[id]: on
	}));
	const adjust = useAdjustedPrice();
	const total = items.reduce((s, i) => s + adjust(i.product?.price_iqd) * i.quantity, 0);
	const shippingCost = computeShipping(items);
	const grandTotal = total + shippingCost;
	const setQty = async (id, q) => {
		if (q <= 0) return remove(id);
		markPending(id, true);
		const { error } = await supabase.from("cart_items").update({ quantity: q }).eq("id", id);
		if (error) toast.error("تعذر تحديث الكمية. حاول مرة أخرى.");
		else await qc.invalidateQueries({ queryKey: ["cart"] });
		markPending(id, false);
	};
	const remove = async (id) => {
		markPending(id, true);
		const { error } = await supabase.from("cart_items").delete().eq("id", id);
		if (error) {
			toast.error("تعذر حذف المنتج. حاول مرة أخرى.");
			markPending(id, false);
			return;
		}
		toast.success("أزيل من السلة");
		await qc.invalidateQueries({ queryKey: ["cart"] });
		markPending(id, false);
	};
	const saveNote = async (id, note) => {
		const value = note.trim() || null;
		const { error } = await supabase.from("cart_items").update({ note: value }).eq("id", id);
		if (error) {
			toast.error("تعذر حفظ الملاحظة.");
			return;
		}
		qc.invalidateQueries({ queryKey: ["cart"] });
	};
	const changeSide = async (row, newSide) => {
		if (row.side === newSide) return;
		let existingQuery = supabase.from("cart_items").select("id, quantity").eq("user_id", userId).eq("product_id", row.product_id);
		existingQuery = newSide ? existingQuery.eq("side", newSide) : existingQuery.is("side", null);
		const { data: existing } = await existingQuery.maybeSingle();
		if (existing && existing.id !== row.id) {
			await supabase.from("cart_items").update({ quantity: existing.quantity + row.quantity }).eq("id", existing.id);
			await supabase.from("cart_items").delete().eq("id", row.id);
			toast.success("تم دمج السطر مع نفس الجهة");
		} else {
			const { error } = await supabase.from("cart_items").update({ side: newSide }).eq("id", row.id);
			if (error) {
				toast.error("تعذر تغيير الجهة");
				return;
			}
			toast.success(newSide ? `تم التغيير إلى ${newSide}` : "أُلغيت الجهة");
		}
		qc.invalidateQueries({ queryKey: ["cart"] });
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "السلة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 pb-6 space-y-3",
			children: [[
				0,
				1,
				2
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-card rounded-2xl border border-border p-3 shadow-card flex gap-3 animate-pulse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-20 rounded-xl bg-muted flex-shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 bg-muted rounded w-3/4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 bg-muted rounded w-1/2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 bg-muted rounded w-24 mt-3" })
					]
				})]
			}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-card rounded-2xl border border-border p-4 shadow-card space-y-2 animate-pulse",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 bg-muted rounded w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 bg-muted rounded w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 bg-muted rounded w-1/2 mt-3" })
				]
			})]
		})
	});
	if (isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "السلة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-6 py-20 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold mb-2 text-destructive",
					children: "تعذر تحميل السلة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mb-6",
					children: "تحقق من الاتصال ثم أعد المحاولة."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => refetch(),
					className: "px-6 py-3 rounded-2xl bg-gradient-gold text-navy font-bold shadow-gold",
					children: "إعادة المحاولة"
				})
			]
		})
	});
	if (items.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "السلة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-6 py-20 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-20 rounded-full bg-muted grid place-items-center mx-auto mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-10 text-muted-foreground" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold mb-2",
					children: "سلتك فارغة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mb-6",
					children: "أضف قطعاً لبدء التسوق"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "inline-flex items-center px-6 py-3 rounded-2xl bg-gradient-gold text-navy font-bold shadow-gold",
					children: "تصفح المنتجات"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "السلة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 pb-6 space-y-3 md:space-y-0 md:grid md:grid-cols-[1fr_20rem] md:gap-4 md:items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `relative bg-card rounded-2xl border border-border p-3 shadow-card flex gap-3 transition ${pendingIds[it.id] ? "opacity-60 pointer-events-none" : ""}`,
					children: [
						pendingIds[it.id] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 grid place-items-center rounded-2xl bg-background/40 z-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-6 border-2 border-gold border-t-transparent rounded-full animate-spin" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-20 rounded-xl bg-muted overflow-hidden flex-shrink-0",
							children: it.product?.images?.[0] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: it.product.images[0],
								alt: "",
								loading: "lazy",
								decoding: "async",
								className: "size-full object-cover"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-bold line-clamp-2",
									children: it.product?.name_ar
								}),
								it.product?.oem_number && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] text-muted-foreground font-mono",
									children: ["OEM: ", it.product.oem_number]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1.5 inline-flex items-center gap-1 rounded-full bg-muted p-0.5",
									children: [[
										"LH",
										"RH",
										"PAIR"
									].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => changeSide(it, it.side === s ? null : s),
										className: `px-2.5 py-0.5 rounded-full text-[10px] font-black transition ${it.side === s ? "bg-navy text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"}`,
										children: s === "LH" ? "LH · يسار" : s === "RH" ? "RH · يمين" : "تخم"
									}, s)), !it.side && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-2 text-[10px] text-muted-foreground",
										children: "اختياري"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-navy font-extrabold text-sm mt-1",
									children: formatIQD(adjust(it.product?.price_iqd))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center bg-muted rounded-lg",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setQty(it.id, it.quantity - 1),
												className: "size-7 grid place-items-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-8 text-center text-sm font-bold",
												children: it.quantity
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setQty(it.id, it.quantity + 1),
												className: "size-7 grid place-items-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => remove(it.id),
										className: "ms-auto size-8 grid place-items-center text-destructive",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemNote, {
									initial: it.note ?? "",
									onSave: (v) => saveNote(it.id, v)
								})
							]
						})
					]
				}, it.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 md:sticky md:top-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card rounded-2xl border border-border p-4 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-sm mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "المجموع الفرعي"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold",
								children: formatIQD(total)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-sm mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "التوصيل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold",
								children: shippingCost > 0 ? formatIQD(shippingCost) : "مجاني"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-border pt-3 flex justify-between items-baseline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold",
								children: "الإجمالي"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xl font-black text-navy",
								children: formatIQD(grandTotal)
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => navigate({ to: "/checkout" }),
					className: "w-full h-14 rounded-2xl bg-gradient-gold text-navy font-black shadow-gold hover:brightness-105 transition",
					children: "متابعة الدفع"
				})]
			})]
		})
	});
}
function ItemNote({ initial, onSave }) {
	const [open, setOpen] = (0, import_react.useState)(!!initial);
	const [value, setValue] = (0, import_react.useState)(initial);
	const original = (0, import_react.useRef)(initial);
	(0, import_react.useEffect)(() => {
		setValue(initial);
		original.current = initial;
	}, [initial]);
	const commit = () => {
		if (value === original.current) return;
		original.current = value;
		onSave(value);
	};
	if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setOpen(true),
		className: "mt-2 inline-flex items-center gap-1 text-[11px] text-gold font-bold",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "size-3.5" }), " إضافة ملاحظة"]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1 text-[11px] text-muted-foreground mb-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "size-3.5 text-gold" }), " ملاحظة لهذا المنتج"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value,
			onChange: (e) => setValue(e.target.value),
			onBlur: commit,
			rows: 2,
			maxLength: 300,
			placeholder: "لون، مقاس، تفاصيل إضافية...",
			className: "w-full rounded-lg border border-border bg-background p-2 text-xs resize-none focus:outline-none focus:ring-1 focus:ring-gold"
		})]
	});
}
//#endregion
export { CartPage as component };
