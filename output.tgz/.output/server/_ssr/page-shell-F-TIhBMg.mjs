import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { r as useUnreadCounts } from "./notifications-DFPiacgQ.mjs";
import { c as useSetting } from "./admin-DdF3xehS.mjs";
import { g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as Search, W as MessageCircle, b as ShoppingCart, jt as Bell, o as User, rt as Heart, tt as House, z as Package } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-shell-F-TIhBMg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function isTextInput(el) {
	if (!el) return false;
	const tag = el.tagName.toLowerCase();
	if (tag === "textarea") return true;
	if (tag === "input") {
		const type = (el.getAttribute("type") || "text").toLowerCase();
		return ![
			"checkbox",
			"radio",
			"button",
			"submit",
			"hidden",
			"file",
			"image",
			"reset"
		].includes(type);
	}
	if (el.getAttribute("contenteditable") === "true") return true;
	return false;
}
function useIsKeyboardOpen() {
	const [isOpen, setIsOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		const handleFocusIn = (e) => {
			if (isTextInput(e.target)) {
				setIsOpen(true);
				document.body.setAttribute("data-keyboard", "open");
			}
		};
		const handleFocusOut = () => {
			setTimeout(() => {
				const active = document.activeElement;
				if (!isTextInput(active)) {
					setIsOpen(false);
					document.body.removeAttribute("data-keyboard");
				}
			}, 60);
		};
		window.addEventListener("focusin", handleFocusIn);
		window.addEventListener("focusout", handleFocusOut);
		let cleanupCapacitor;
		import("../_libs/capacitor__keyboard.mjs").then((n) => n.t).then(({ Keyboard }) => {
			const showSub = Keyboard.addListener("keyboardWillShow", () => {
				setIsOpen(true);
				document.body.setAttribute("data-keyboard", "open");
			});
			const didShowSub = Keyboard.addListener("keyboardDidShow", () => {
				setIsOpen(true);
				document.body.setAttribute("data-keyboard", "open");
			});
			const hideSub = Keyboard.addListener("keyboardWillHide", () => {
				setIsOpen(false);
				document.body.removeAttribute("data-keyboard");
			});
			const didHideSub = Keyboard.addListener("keyboardDidHide", () => {
				setIsOpen(false);
				document.body.removeAttribute("data-keyboard");
			});
			cleanupCapacitor = () => {
				showSub.then((s) => s.remove()).catch(() => {});
				didShowSub.then((s) => s.remove()).catch(() => {});
				hideSub.then((s) => s.remove()).catch(() => {});
				didHideSub.then((s) => s.remove()).catch(() => {});
			};
		}).catch(() => {});
		const handleViewportResize = () => {
			if (window.visualViewport) {
				if (window.visualViewport.height < window.innerHeight * .75) {
					setIsOpen(true);
					document.body.setAttribute("data-keyboard", "open");
				} else if (!isTextInput(document.activeElement)) {
					setIsOpen(false);
					document.body.removeAttribute("data-keyboard");
				}
			}
		};
		window.visualViewport?.addEventListener("resize", handleViewportResize);
		return () => {
			window.removeEventListener("focusin", handleFocusIn);
			window.removeEventListener("focusout", handleFocusOut);
			cleanupCapacitor?.();
			window.visualViewport?.removeEventListener("resize", handleViewportResize);
			document.body.removeAttribute("data-keyboard");
		};
	}, []);
	return isOpen;
}
var items = [
	{
		to: "/",
		label: "الرئيسية",
		icon: House
	},
	{
		to: "/favorites",
		label: "المفضلة",
		icon: Heart
	},
	{
		to: "/orders",
		label: "طلباتي",
		icon: Package
	},
	{
		to: "/messages",
		label: "الرسائل",
		icon: MessageCircle
	},
	{
		to: "/account",
		label: "الحساب",
		icon: User
	}
];
function BottomNav() {
	const isKeyboardOpen = useIsKeyboardOpen();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const { userId } = useAuth();
	const { orders: unseenCount } = useUnreadCounts();
	const qc = useQueryClient();
	(0, import_react.useEffect)(() => {
		if (!userId) return;
		const ch = supabase.channel(`nav-orders-${userId}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "orders",
			filter: `user_id=eq.${userId}`
		}, (payload) => {
			qc.invalidateQueries({ queryKey: ["orders", userId] });
			try {
				const oldRow = payload?.old ?? {};
				const newRow = payload?.new ?? {};
				if (payload?.eventType === "UPDATE" && oldRow.status !== "delivered" && newRow.status === "delivered" && typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted") {
					const pts = Number(newRow.points_earned || 0);
					const body = pts > 0 ? `تم تسليم طلبك 🎉 وربحت ${pts} نقطة` : `تم تسليم طلبك 🎉`;
					const n = new Notification("Ali Parts — تم التسليم", {
						body,
						icon: "/icon-192.png",
						badge: "/icon-192.png",
						tag: `order-${newRow.id}`
					});
					n.onclick = () => {
						window.focus();
						window.location.href = `/orders/${newRow.id}`;
					};
				}
			} catch {}
		}).subscribe();
		return () => {
			supabase.removeChannel(ch);
		};
	}, [userId, qc]);
	if (isKeyboardOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "bottom-nav sticky bottom-0 inset-x-0 z-40 border-t border-border/60 bg-card/95 backdrop-blur-lg pb-[env(safe-area-inset-bottom)] shadow-luxe",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full grid grid-cols-5 md:max-w-md md:mx-auto",
			children: items.map((it) => {
				const active = pathname === it.to || it.to !== "/" && pathname.startsWith(it.to);
				const Icon = it.icon;
				const showBadge = it.to === "/orders" && unseenCount > 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: it.to,
					className: "relative flex flex-col items-center justify-center gap-1 py-2.5 text-xs font-medium transition-colors",
					children: [
						active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 h-0.5 w-8 rounded-full bg-gold" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: `size-5 transition-colors ${active ? "text-gold" : "text-muted-foreground"}`,
								strokeWidth: active ? 2.4 : 1.8
							}), showBadge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute -top-1.5 -start-1.5 min-w-4 h-4 px-1 rounded-full bg-red-500 text-white text-[9px] font-bold grid place-items-center shadow",
								children: unseenCount > 9 ? "9+" : unseenCount
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: active ? "text-navy" : "text-muted-foreground",
							children: it.label
						})
					]
				}, it.to);
			})
		})
	});
}
function AppHeader({ title }) {
	const [count, setCount] = (0, import_react.useState)(0);
	const { total: unread } = useUnreadCounts();
	const [cartBump, setCartBump] = (0, import_react.useState)(false);
	const [cartIconJump, setCartIconJump] = (0, import_react.useState)(false);
	const [bumpKey, setBumpKey] = (0, import_react.useState)(0);
	const storeName = useSetting("store_name", "Ali Parts");
	const storeTagline = useSetting("store_tagline", "قطع أصلية · العراق");
	const storeLogo = useSetting("store_logo", "");
	(0, import_react.useEffect)(() => {
		let mounted = true;
		let channel = null;
		let currentUid = null;
		const refreshCounts = async (uid) => {
			const { data: cartItems } = await supabase.from("cart_items").select("quantity").eq("user_id", uid);
			if (mounted) setCount((cartItems ?? []).reduce((sum, item) => sum + Number(item.quantity ?? 0), 0));
		};
		const setup = async (uid) => {
			if (uid === currentUid) {
				if (uid) refreshCounts(uid);
				return;
			}
			currentUid = uid;
			if (channel) {
				supabase.removeChannel(channel);
				channel = null;
			}
			if (!uid) {
				if (mounted) setCount(0);
				return;
			}
			refreshCounts(uid);
			const channelName = `cart-badge-${uid}-${crypto.randomUUID()}`;
			channel = supabase.channel(channelName).on("postgres_changes", {
				event: "*",
				schema: "public",
				table: "cart_items",
				filter: `user_id=eq.${uid}`
			}, () => refreshCounts(uid)).subscribe();
		};
		(async () => {
			const { data } = await supabase.auth.getSession();
			setup(data.session?.user.id ?? null);
		})();
		const { data: sub } = supabase.auth.onAuthStateChange((_evt, session) => setup(session?.user.id ?? null));
		const onCartChanged = (e) => {
			const detail = e.detail;
			const delta = detail?.delta ?? 1;
			const bump = detail?.bump ?? delta > 0;
			if (mounted) {
				setCount((c) => Math.max(0, c + delta));
				if (bump) {
					setBumpKey((k) => k + 1);
					setCartBump(true);
					setCartIconJump(true);
					window.setTimeout(() => {
						if (mounted) setCartBump(false);
					}, 360);
					window.setTimeout(() => {
						if (mounted) setCartIconJump(false);
					}, 420);
				}
			}
			if (currentUid) window.setTimeout(() => currentUid && refreshCounts(currentUid), 600);
		};
		window.addEventListener("cart:changed", onCartChanged);
		return () => {
			mounted = false;
			sub.subscription.unsubscribe();
			if (channel) supabase.removeChannel(channel);
			window.removeEventListener("cart:changed", onCartChanged);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-30 bg-gradient-navy text-primary-foreground shadow-luxe pt-[env(safe-area-inset-top)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-md md:max-w-3xl lg:max-w-5xl px-4 py-3 flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2",
				children: [storeLogo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-11 rounded-xl overflow-hidden shadow-gold bg-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: storeLogo,
						alt: storeName,
						className: "size-full object-cover"
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-11 rounded-xl bg-gradient-gold flex items-center justify-center font-black text-navy text-xl shadow-gold",
					children: storeName.charAt(0).toUpperCase()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "leading-tight",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-extrabold text-base",
						children: title ?? storeName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] text-gold tracking-wide",
						children: storeTagline
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ms-auto flex items-center gap-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/search",
						"aria-label": "بحث",
						className: "size-10 rounded-full grid place-items-center hover:bg-white/10 transition",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/notifications",
						"aria-label": "الإشعارات",
						className: "relative size-10 rounded-full grid place-items-center hover:bg-white/10 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" }), unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -top-0.5 -start-0.5 min-w-5 h-5 px-1 rounded-full bg-gold text-navy text-[10px] font-bold grid place-items-center",
							children: unread > 99 ? "99+" : unread
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/cart",
						"aria-label": "السلة",
						className: "relative size-10 rounded-full grid place-items-center hover:bg-white/10 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: cn("size-5 transition-transform", cartIconJump && "animate-cart-jump") }, `icon-${bumpKey}`), count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("absolute -top-0.5 -start-0.5 min-w-5 h-5 px-1 rounded-full bg-gold text-navy text-[10px] font-bold grid place-items-center origin-center", cartBump && "animate-badge-pop"),
							children: count
						}, `badge-${bumpKey}`)]
					})
				]
			})]
		})
	});
}
/**
* Unified app shell used by every user-facing route.
*
* - On mobile it fills the whole viewport (edge-to-edge).
* - On tablet/desktop it renders as a centered phone-like frame so the app
*   never looks like a narrow web page floating over an empty desktop.
* - Header sits sticky at the top; BottomNav sits sticky at the bottom of
*   the frame, so both stay pinned without covering content permanently.
*/
function PageShell({ children, title, showHeader = true, showNav = true, wide = false }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 bg-muted/30 flex items-center justify-center overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `relative w-full max-w-md bg-background flex flex-col h-full md:h-[calc(100vh-2rem)] md:my-4 md:rounded-[2rem] md:shadow-2xl md:border md:border-border/40 md:overflow-hidden${wide ? " md:max-w-3xl lg:max-w-5xl" : ""}`,
			style: { paddingTop: showHeader ? void 0 : "env(safe-area-inset-top)" },
			children: [
				showHeader && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, { title })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 w-full overflow-y-auto overflow-x-hidden overscroll-contain animate-fade-in",
					style: {
						WebkitOverflowScrolling: "touch",
						paddingBottom: showNav ? void 0 : "env(safe-area-inset-bottom)"
					},
					children
				}, pathname),
				showNav && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "shrink-0 bottom-nav-wrapper",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})
				})
			]
		})
	});
}
//#endregion
export { PageShell as t };
