import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { a as objectType, i as numberType, o as stringType, t as booleanType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import { t as adminOtpEnabled } from "./require-admin-otp-DgUpC_62.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-otp.functions-CpVaP7L6.js
var VERIFICATION_TTL_SECONDS = 600;
var REMEMBER_DEVICE_TTL_SECONDS = 720 * 60 * 60;
var CHALLENGE_TTL_SECONDS = 600;
var MAX_ATTEMPTS = 5;
async function isAdminOrStaff(ctx) {
	const [{ data: isAdmin }, { data: isStaff }] = await Promise.all([ctx.supabase.rpc("has_role", {
		_user_id: ctx.userId,
		_role: "admin"
	}), ctx.supabase.rpc("is_staff", { _uid: ctx.userId })]);
	return {
		isAdmin: !!isAdmin,
		isStaff: !!isStaff
	};
}
async function hashCode(code, userId) {
	const salt = process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";
	const enc = new TextEncoder().encode(`${userId}:${code}:${salt}`);
	const buf = await crypto.subtle.digest("SHA-256", enc);
	return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function maskEmail(e) {
	const [u, d] = e.split("@");
	if (!u || !d) return e;
	const shown = u.slice(0, Math.min(2, u.length));
	return `${shown}${"*".repeat(Math.max(1, u.length - shown.length))}@${d}`;
}
async function logOtpEvent(params) {
	try {
		const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
		await supabaseAdmin.from("admin_otp_events").insert({
			event: params.event,
			user_id: params.user_id ?? null,
			device_id: params.device_id ?? null,
			detail: params.detail ?? null
		});
	} catch (e) {
		console.error("logOtpEvent failed", e);
	}
}
var listAdminOtpEvents_createServerFn_handler = createServerRpc({
	id: "6b480379be9faee628a1ae09930e0d23e93af156b0dc47bfbe8800f864a21dc0",
	name: "listAdminOtpEvents",
	filename: "src/lib/admin-otp.functions.ts"
}, (opts) => listAdminOtpEvents.__executeServer(opts));
var listAdminOtpEvents = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ limit: numberType().int().min(1).max(200).optional() }).parse(d ?? {})).handler(listAdminOtpEvents_createServerFn_handler, async ({ data, context }) => {
	const { isAdmin } = await isAdminOrStaff(context);
	if (!isAdmin) throw new Error("Forbidden");
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { data: rows, error } = await supabaseAdmin.from("admin_otp_events").select("id, event, user_id, device_id, detail, created_at").order("created_at", { ascending: false }).limit(data.limit ?? 100);
	if (error) throw new Error(error.message);
	return rows ?? [];
});
var StatusInput = objectType({ device_id: stringType().min(1).max(128).optional() });
var adminOtpStatus_createServerFn_handler = createServerRpc({
	id: "954ddf5580f8b50b7142bf512d02f1885aa19e6737aad84b9b959c7c55e1079d",
	name: "adminOtpStatus",
	filename: "src/lib/admin-otp.functions.ts"
}, (opts) => adminOtpStatus.__executeServer(opts));
var adminOtpStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => StatusInput.parse(d ?? {})).handler(adminOtpStatus_createServerFn_handler, async ({ data, context }) => {
	if (!adminOtpEnabled()) return {
		required: false,
		verified: true,
		email: null
	};
	const { isAdmin, isStaff } = await isAdminOrStaff(context);
	if (!isAdmin && !isStaff) return {
		required: false,
		verified: true,
		email: null
	};
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const deviceId = data.device_id ?? "";
	const { data: v } = await supabaseAdmin.from("admin_otp_verifications").select("expires_at").eq("user_id", context.userId).eq("device_id", deviceId).maybeSingle();
	const verified = !!v && new Date(v.expires_at).getTime() > Date.now();
	const email = process.env.ADMIN_OTP_EMAIL ?? "";
	return {
		required: true,
		verified,
		expiresAt: v?.expires_at ?? null,
		email: email ? maskEmail(email) : null,
		hasEmail: !!email
	};
});
var requestAdminOtp_createServerFn_handler = createServerRpc({
	id: "eccc50d0c1265695454be6c92edd19ad35bed234a6f04e5f9417c322311058bb",
	name: "requestAdminOtp",
	filename: "src/lib/admin-otp.functions.ts"
}, (opts) => requestAdminOtp.__executeServer(opts));
var requestAdminOtp = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(requestAdminOtp_createServerFn_handler, async ({ context }) => {
	const { isAdmin, isStaff } = await isAdminOrStaff(context);
	if (!isAdmin && !isStaff) throw new Error("Forbidden");
	const resendKey = process.env.RESEND_API_KEY;
	if (!resendKey) throw new Error("لم يتم إعداد مفتاح البريد");
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { data: actor } = await supabaseAdmin.auth.admin.getUserById(context.userId);
	const toEmail = process.env.ADMIN_OTP_EMAIL;
	if (!toEmail) throw new Error("لم يتم إعداد بريد الإدارة");
	const { data: recent } = await supabaseAdmin.from("admin_otp_challenges").select("created_at").eq("user_id", context.userId).is("consumed_at", null).order("created_at", { ascending: false }).limit(1).maybeSingle();
	if (recent) {
		const age = Date.now() - new Date(recent.created_at).getTime();
		if (age < 3e4) {
			const wait = Math.ceil((3e4 - age) / 1e3);
			await logOtpEvent({
				event: "request_rate_limited",
				user_id: context.userId,
				detail: `wait ${wait}s`
			});
			throw new Error(`الرجاء الانتظار ${wait} ثانية قبل طلب رمز جديد`);
		}
	}
	const code = String(Math.floor(1e5 + Math.random() * 9e5));
	const code_hash = await hashCode(code, context.userId);
	const expires_at = new Date(Date.now() + CHALLENGE_TTL_SECONDS * 1e3).toISOString();
	await supabaseAdmin.from("admin_otp_challenges").update({ consumed_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("user_id", context.userId).is("consumed_at", null);
	const { error: insErr } = await supabaseAdmin.from("admin_otp_challenges").insert({
		user_id: context.userId,
		code_hash,
		expires_at
	});
	if (insErr) throw new Error(insErr.message);
	const html = `
<!doctype html><html dir="rtl" lang="ar"><body style="font-family:Tahoma,Arial,sans-serif;background:#f6f7fb;padding:24px;margin:0">
  <div style="max-width:480px;margin:0 auto;background:#fff;border-radius:16px;padding:28px;border:1px solid #e5e7eb">
    <h2 style="margin:0 0 8px;color:#0f172a">رمز تحقق دخول الإدارة</h2>
    <p style="color:#475569;margin:0 0 16px">تم طلب دخول لوحة الإدارة بواسطة: <b>${(actor?.user?.user_metadata)?.full_name || actor?.user?.email || actor?.user?.phone || context.userId.slice(0, 8)}</b></p>
    <div style="font-size:34px;letter-spacing:8px;font-weight:800;background:#0f172a;color:#fff;text-align:center;border-radius:12px;padding:18px 12px;margin:12px 0">${code}</div>
    <p style="color:#64748b;font-size:13px;margin:12px 0 0">صالح لمدة 10 دقائق. لا تشاركه مع أي شخص.</p>
    <p style="color:#94a3b8;font-size:12px;margin-top:16px">إذا لم يكن هذا الطلب منك، تجاهل الرسالة وغيّر كلمة المرور فوراً.</p>
  </div>
</body></html>`;
	const resp = await fetch("https://api.resend.com/emails", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${resendKey}`
		},
		body: JSON.stringify({
			from: "Admin Login <onboarding@resend.dev>",
			to: [toEmail],
			subject: `رمز دخول الإدارة: ${code}`,
			html
		})
	});
	if (!resp.ok) {
		const text = await resp.text();
		console.error("Resend send failed", resp.status, text);
		let detail = text;
		try {
			const j = JSON.parse(text);
			detail = j?.message || j?.error || text;
		} catch {}
		await logOtpEvent({
			event: "request_failed",
			user_id: context.userId,
			detail: String(detail).slice(0, 500)
		});
		throw new Error(`تعذر إرسال رمز التحقق: ${detail}`);
	}
	await logOtpEvent({
		event: "request",
		user_id: context.userId,
		detail: maskEmail(toEmail)
	});
	return {
		ok: true,
		email: maskEmail(toEmail),
		expiresAt: expires_at
	};
});
var VerifyInput = objectType({
	code: stringType().regex(/^\d{6}$/, "رمز غير صالح"),
	remember: booleanType().optional(),
	device_id: stringType().min(1).max(128)
});
var verifyAdminOtp_createServerFn_handler = createServerRpc({
	id: "e9609cac5294c8f30c4907805bb986c53cdef123f23e21f6511a6689f7883a79",
	name: "verifyAdminOtp",
	filename: "src/lib/admin-otp.functions.ts"
}, (opts) => verifyAdminOtp.__executeServer(opts));
var verifyAdminOtp = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => VerifyInput.parse(d)).handler(verifyAdminOtp_createServerFn_handler, async ({ data, context }) => {
	const { isAdmin, isStaff } = await isAdminOrStaff(context);
	if (!isAdmin && !isStaff) throw new Error("Forbidden");
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { data: ch, error } = await supabaseAdmin.from("admin_otp_challenges").select("id, code_hash, expires_at, consumed_at, attempts").eq("user_id", context.userId).is("consumed_at", null).order("created_at", { ascending: false }).limit(1).maybeSingle();
	if (error) throw new Error(error.message);
	if (!ch) {
		await logOtpEvent({
			event: "verify_no_active",
			user_id: context.userId,
			device_id: data.device_id
		});
		throw new Error("لا يوجد رمز نشط. اطلب رمزاً جديداً.");
	}
	if (new Date(ch.expires_at).getTime() < Date.now()) {
		await logOtpEvent({
			event: "verify_expired",
			user_id: context.userId,
			device_id: data.device_id
		});
		throw new Error("انتهت صلاحية الرمز. اطلب رمزاً جديداً.");
	}
	if ((ch.attempts ?? 0) >= MAX_ATTEMPTS) {
		await supabaseAdmin.from("admin_otp_challenges").update({ consumed_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", ch.id);
		await logOtpEvent({
			event: "verify_max_attempts",
			user_id: context.userId,
			device_id: data.device_id,
			detail: `attempts=${ch.attempts}`
		});
		throw new Error("عدد المحاولات تجاوز الحد. اطلب رمزاً جديداً.");
	}
	if (await hashCode(data.code, context.userId) !== ch.code_hash) {
		await supabaseAdmin.from("admin_otp_challenges").update({ attempts: (ch.attempts ?? 0) + 1 }).eq("id", ch.id);
		await logOtpEvent({
			event: "verify_wrong_code",
			user_id: context.userId,
			device_id: data.device_id,
			detail: `attempt=${(ch.attempts ?? 0) + 1}`
		});
		throw new Error("رمز غير صحيح");
	}
	const nowIso = (/* @__PURE__ */ new Date()).toISOString();
	const ttl = data.remember ? REMEMBER_DEVICE_TTL_SECONDS : VERIFICATION_TTL_SECONDS;
	const expires_at = new Date(Date.now() + ttl * 1e3).toISOString();
	await supabaseAdmin.from("admin_otp_challenges").update({ consumed_at: nowIso }).eq("id", ch.id);
	await supabaseAdmin.from("admin_otp_verifications").upsert({
		user_id: context.userId,
		device_id: data.device_id,
		verified_at: nowIso,
		expires_at
	}, { onConflict: "user_id,device_id" });
	await logOtpEvent({
		event: "verify_success",
		user_id: context.userId,
		device_id: data.device_id,
		detail: data.remember ? "remember=30d" : "session=10m"
	});
	return {
		ok: true,
		expiresAt: expires_at
	};
});
//#endregion
export { adminOtpStatus_createServerFn_handler, listAdminOtpEvents_createServerFn_handler, requestAdminOtp_createServerFn_handler, verifyAdminOtp_createServerFn_handler };
