import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { f as Outlet, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Capacitor } from "../_libs/@aparajita/capacitor-secure-storage+[...].mjs";
import { n as ProfilePhonePrompt } from "./profile-completion-BdIKZ-EV.mjs";
import { t as Route } from "./route-C61HYUqK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-CRW3OpiI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* FCM push registration for the native (Capacitor) shell.
*
* Mounted from the AUTHENTICATED layout (src/routes/_authenticated/route.tsx),
* not from /auth and not from the app root. That layout's beforeLoad awaits the
* session restore and guarantees a signed-in user before it renders, so this
* runs for EVERY logged-in session — fresh Google login via Custom Tab, an
* existing session, or a cold launch while already signed in — without
* depending on which auth event fired (SIGNED_IN vs INITIAL_SESSION).
*
* Web/browser users never reach any of this: every entry returns early unless
* Capacitor.isNativePlatform(), and @capacitor/push-notifications is only ever
* dynamically imported inside that branch, so it is absent from the web bundle.
*/
/** Where a tapped notification should land, given the FCM `data` payload the
*  server attaches. Kept here so the routing rules live in one place. */
function deepLinkForPush(data) {
	const orderId = typeof data?.order_id === "string" ? data.order_id : "";
	const replacementId = typeof data?.replacement_id === "string" ? data.replacement_id : "";
	const url = typeof data?.url === "string" ? data.url : "";
	if (orderId) return `/orders/${orderId}`;
	if (replacementId) return `/replacements/${replacementId}`;
	if (url.startsWith("/")) return url;
	return "/notifications";
}
var listenersWired = false;
var attemptedForUser = null;
var inFlight = false;
/**
* Request permission (once), obtain the FCM token, and upsert it. Idempotent and
* cheap to call on every authenticated mount:
*
*  - Same user, already attempted this session  -> returns immediately.
*  - A DIFFERENT user (shared device re-login)   -> re-runs so the token is
*    reassigned to whoever is now signed in.
*  - Permission DENIED                           -> skips gracefully: no loop,
*    no throw, and marked attempted so it does not re-prompt every navigation.
*    A denied user who enables notifications in Android settings is picked up on
*    the next cold launch.
*
* @param userId     the signed-in user's id (from the authenticated route context)
* @param onNavigate deep-link handler, given a path like "/orders/123"
*/
async function registerNativePush(userId, onNavigate) {
	if (!Capacitor.isNativePlatform()) return;
	if (!userId) return;
	if (attemptedForUser === userId) return;
	if (inFlight) return;
	inFlight = true;
	attemptedForUser = userId;
	try {
		const { PushNotifications } = await import("../_libs/capacitor__push-notifications.mjs").then((n) => n.t);
		if (!listenersWired) {
			listenersWired = true;
			await PushNotifications.addListener("registration", (token) => {
				const platform = Capacitor.getPlatform() === "ios" ? "ios" : "android";
				supabase.rpc("register_device_token", {
					p_token: token.value,
					p_platform: platform
				}).then(({ error }) => {
					if (error) console.error("[push] register_device_token failed", error.message);
				});
			});
			await PushNotifications.addListener("registrationError", (err) => {
				console.error("[push] registration error", err);
			});
			await PushNotifications.addListener("pushNotificationActionPerformed", (action) => {
				const data = action.notification?.data;
				onNavigate(deepLinkForPush(data));
			});
		}
		let receive = (await PushNotifications.checkPermissions()).receive;
		if (receive === "prompt" || receive === "prompt-with-rationale") receive = (await PushNotifications.requestPermissions()).receive;
		if (receive !== "granted") return;
		await PushNotifications.register();
	} catch (err) {
		console.error("[push] init failed", err);
	} finally {
		inFlight = false;
	}
}
function AuthedLayout() {
	const { user } = Route.useRouteContext();
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		if (!Capacitor.isNativePlatform() || !user?.id) return;
		const navigate = (path) => {
			router.navigate({ to: path });
		};
		registerNativePush(user.id, navigate);
	}, [user?.id, router]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfilePhonePrompt, {})] });
}
//#endregion
export { AuthedLayout as component };
