import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._id-B0hqY12O.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "p-8 text-center",
	children: "المنتج غير موجود"
});
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
