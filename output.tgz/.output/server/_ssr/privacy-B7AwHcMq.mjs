import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { W as MessageCircle } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { s as whatsappLink } from "./format-CTK49jpu.mjs";
import { n as MissingSettingsNotice, r as useLegalContact, t as ContactList } from "./legal-contact-Cir7kLl-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-B7AwHcMq.js
var import_jsx_runtime = require_jsx_runtime();
var LAST_UPDATED = "20 July 2026";
function PrivacyPage() {
	const { ownerName, address, supportEmail, waNumber, missing } = useLegalContact();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "سياسة الخصوصية",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 pt-4 pb-8 md:max-w-2xl md:mx-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				dir: "ltr",
				className: "bg-card rounded-2xl border border-border p-5 shadow-card space-y-5 text-sm leading-relaxed text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-lg font-black text-navy mb-1",
						children: "Privacy Policy"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Last updated:" }),
							" ",
							LAST_UPDATED
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [ownerName, " (\"we\", \"us\", \"our\") operates the online store at maktabali.com and its mobile applications (the \"Service\"). This policy explains what personal information we collect, why we collect it, and what we do with it."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Data controller:" }),
						" ",
						ownerName,
						", ",
						address,
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "1. Information We Collect",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Account information." }), " When you create an account you sign in using Google or Apple. From them we receive your email address, your name, and your profile picture if you have one. We never receive or store your Google or Apple password."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Contact and delivery information." }), " After signing in we ask for a phone number so we can contact you about your order. When you place an order you provide a delivery address. Please note we do not verify phone numbers."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Order information." }), " The products you order, quantities, prices, order status, delivery method, and your order history. Because we sell on a cash-on-delivery basis, we do not collect or store bank card or payment card details of any kind."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Shopping activity." }), " Items in your cart, products you save to favourites, and loyalty points earned on orders."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Vehicle information." }), " The vehicle make, model, year and engine size you select, so we can show you parts compatible with your car."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Replacement requests." }), " If you request a replacement for a part, any photographs and description you submit with that request."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Technical information." }), " Your device sends standard technical data such as IP address and browser type when you use the Service. If you enable notifications, we store a device notification token so we can send you updates about your orders."]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "2. How We Use Your Information",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We use your information to:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1 mt-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Create and maintain your account" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Process, prepare and deliver your orders" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Contact you about an order, by phone or WhatsApp" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Show you parts compatible with your vehicle" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Handle replacement requests" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Send you order notifications, if you have enabled them" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Keep records of our sales" })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "3. What We Do Not Do",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "We do not sell, rent or trade your personal information to anyone." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "We do not use advertising networks or advertising trackers." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "We do not use analytics services that follow you across other websites." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "We do not collect payment card information. We accept cash on delivery only." })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "4. Who We Share Information With",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Sign-in providers." }), " Google and Apple, solely to sign you in. Their handling of your data is governed by their own privacy policies."] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Delivery." }), " We share your name, phone number and delivery address with the delivery service or driver bringing your order, only as needed to complete the delivery."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Technical services." }), " Our website and database run on servers we rent from Contabo. Some technical components load from a public content delivery network (jsDelivr), which may receive your IP address as part of a normal web request."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Legal." }), " We may disclose information where required by law or a lawful order."]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "5. Where Your Data Is Stored",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Your information is stored on servers located in Germany. As this is outside Iraq, your data is transferred and stored outside your country." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "6. How Long We Keep Your Information",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We keep your account information for as long as your account is open. We keep order records after that where we need them for business and accounting purposes. If you ask us to delete your account, we will delete your personal account data, though we may retain order records we are required to keep." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "7. Security",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We protect your information using encrypted connections (HTTPS), access controls on our database, and restricted administrative access. However, no method of transmission or storage is completely secure, and we cannot guarantee absolute security." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "8. Your Choices and Rights",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "list-disc ps-6 space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Access and correct." }), " You can view and update your name, phone number, addresses and vehicle details at any time in the Account section of the app."] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Delete your account." }),
									" You can delete your account yourself, at any time, from the Account section of the app (",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										dir: "rtl",
										children: "الحساب ← حذف الحساب"
									}),
									"). Deletion takes effect immediately and cannot be undone. It removes your profile (name, phone number and picture), your saved delivery addresses, your cart and favourites, your notifications and device notification tokens, your loyalty points, and your sign-in account itself.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Records of orders you have already placed are ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "kept" }),
									" for the accounting, tax and legal purposes described in section 6, but they are disconnected from your account first, so they no longer identify you. That retained order data is not used to contact you or to build a profile of you.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"If you cannot sign in, contact us using the details below and we will delete your account within 30 days, after verifying your identity. Full details are on our",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "text-gold underline",
										href: "/delete-account",
										children: "account deletion page"
									}),
									"."
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Notifications." }), " You can turn notifications off at any time in your device settings."] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Sign out." }), " You can sign out of your account at any time."] })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "9. Children",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The Service is not directed at children. We do not knowingly collect personal information from anyone under 18. If you believe a child has provided us with personal information, please contact us and we will delete it." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "10. Changes to This Policy",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We may update this policy from time to time. When we do, we will change the \"Last updated\" date at the top of this page. Your continued use of the Service after a change means you accept the updated policy." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "11. Contact Us",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "If you have any questions about this policy or about your personal information, contact us:" }),
							missing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissingSettingsNotice, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactList, {
								ownerName,
								address,
								supportEmail,
								waNumber
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappLink("I have a question about privacy", waNumber),
								target: "_blank",
								rel: "noopener noreferrer",
								className: "mt-3 inline-flex items-center gap-2 bg-navy text-primary-foreground text-xs font-bold px-4 py-2 rounded-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5" }), " Contact us on WhatsApp"]
							})
						]
					})
				]
			})
		})
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-bold text-gold mb-2",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm leading-relaxed",
		children
	})] });
}
//#endregion
export { PrivacyPage as component };
