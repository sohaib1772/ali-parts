import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._id-CsWThkaB.js
var import_jsx_runtime = require_jsx_runtime();
function ProductErrorFallback({ reset }) {
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-8 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4",
			children: "حدث خطأ في تحميل المنتج"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => {
				router.invalidate();
				reset();
			},
			className: "px-4 py-2 rounded-xl bg-navy text-primary-foreground",
			children: "إعادة المحاولة"
		})]
	});
}
var SplitErrorComponent = ({ reset }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductErrorFallback, { reset });
//#endregion
export { SplitErrorComponent as errorComponent };
