import { t as require_src } from "../_libs/google-auth-library+jwa+jws.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fcm-dispatch.server-D3VeuKl7.js
var import_src = require_src();
var cachedClient;
async function loadServiceAccount() {
	const inline = process.env.FCM_SERVICE_ACCOUNT_JSON;
	if (inline) return JSON.parse(inline);
	const file = process.env.FCM_SERVICE_ACCOUNT_FILE;
	if (!file) throw new Error("Missing FCM_SERVICE_ACCOUNT_FILE (or FCM_SERVICE_ACCOUNT_JSON)");
	const { readFile } = await import("node:fs/promises");
	return JSON.parse(await readFile(file, "utf8"));
}
async function getClient() {
	if (cachedClient) return cachedClient;
	const sa = await loadServiceAccount();
	const jwt = new import_src.JWT({
		email: sa.client_email,
		key: sa.private_key,
		scopes: ["https://www.googleapis.com/auth/firebase.messaging"]
	});
	cachedClient = {
		projectId: sa.project_id,
		jwt
	};
	return cachedClient;
}
/** True for the FCM v1 errors that mean "this token is permanently dead". */
function isDeadTokenError(status, body) {
	if (status === 404) return true;
	if (status === 400 && body.includes("INVALID_ARGUMENT")) return true;
	return body.includes("UNREGISTERED") || body.includes("NOT_FOUND");
}
/**
* Send one payload to every device token a user has. Returns counts. Dead tokens
* (UNREGISTERED / invalid) are deleted so the table self-heals. All network
* errors are swallowed per-token — one bad token never blocks the rest, and push
* failure never propagates to the caller (the in-app notification already landed).
*/
async function sendFcmToUser(userId, payload) {
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { data: rows, error } = await supabaseAdmin.from("device_tokens").select("token").eq("user_id", userId);
	if (error) throw new Error(error.message);
	const tokens = (rows ?? []).map((r) => r.token);
	if (tokens.length === 0) return {
		sent: 0,
		removed: 0,
		tokens: 0
	};
	const { projectId, jwt } = await getClient();
	const accessToken = (await jwt.getAccessToken()).token;
	const url = `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`;
	let sent = 0;
	const dead = [];
	await Promise.all(tokens.map(async (token) => {
		const message = { message: {
			token,
			notification: {
				title: payload.title,
				body: payload.body
			},
			data: payload.data ?? {},
			android: {
				priority: "HIGH",
				notification: { sound: "default" }
			}
		} };
		try {
			const res = await fetch(url, {
				method: "POST",
				headers: {
					Authorization: `Bearer ${accessToken}`,
					"Content-Type": "application/json"
				},
				body: JSON.stringify(message)
			});
			if (res.ok) {
				sent++;
				return;
			}
			const text = await res.text().catch(() => "");
			if (isDeadTokenError(res.status, text)) dead.push(token);
			else console.error("[fcm] send failed", res.status, text.slice(0, 300));
		} catch (err) {
			console.error("[fcm] network error", err);
		}
	}));
	if (dead.length > 0) await supabaseAdmin.from("device_tokens").delete().in("token", dead);
	return {
		sent,
		removed: dead.length,
		tokens: tokens.length
	};
}
/**
* Internal endpoint the DB calls (async, via net.http_post) once per inserted
* notification row. It is NOT a user-facing route: it authenticates with a
* shared secret (FCM_DISPATCH_SECRET), not a user session, because the caller is
* Postgres, not a browser. See migration 20260725120000 (dispatch_notification_push).
*
* Flow: {notification_id, secret} -> load the row with the service role ->
* derive the tap deep-link from its type/order_id -> fan out to that user's FCM
* tokens. Because every in-app notification funnels through public.notifications,
* this one endpoint mirrors order, replacement, banner, broadcast and block
* events without knowing anything about them individually.
*/
function timingSafeEqual(a, b) {
	if (a.length !== b.length) return false;
	let diff = 0;
	for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
	return diff === 0;
}
/** Map a notification row to the FCM `data` the client uses for deep-linking. */
function dataForNotification(row) {
	const data = { type: row.type ?? "" };
	if (row.order_id) data.order_id = row.order_id;
	else if ((row.type ?? "").startsWith("replacement")) data.url = "/replacements";
	else data.url = "/notifications";
	return data;
}
async function handleFcmDispatch(request) {
	if (request.method !== "POST") return new Response("Method Not Allowed", { status: 405 });
	const secret = process.env.FCM_DISPATCH_SECRET;
	if (!secret) {
		console.error("[fcm-dispatch] FCM_DISPATCH_SECRET is not set");
		return new Response(JSON.stringify({
			ok: false,
			reason: "not_configured"
		}), {
			status: 503,
			headers: { "content-type": "application/json" }
		});
	}
	let payload;
	try {
		payload = await request.json();
	} catch {
		return new Response("Bad Request", { status: 400 });
	}
	if (!timingSafeEqual(typeof payload.secret === "string" ? payload.secret : "", secret)) return new Response("Forbidden", { status: 403 });
	const notificationId = typeof payload.notification_id === "string" ? payload.notification_id : "";
	if (!notificationId) return new Response("Bad Request", { status: 400 });
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { data: row, error } = await supabaseAdmin.from("notifications").select("id, user_id, type, title, body, order_id").eq("id", notificationId).maybeSingle();
	if (error) {
		console.error("[fcm-dispatch] load failed", error.message);
		return new Response(JSON.stringify({ ok: false }), {
			status: 500,
			headers: { "content-type": "application/json" }
		});
	}
	if (!row) return new Response(JSON.stringify({
		ok: true,
		sent: 0
	}), {
		status: 200,
		headers: { "content-type": "application/json" }
	});
	const fcm = {
		title: row.title ?? "إشعار",
		body: row.body ?? "",
		data: dataForNotification(row)
	};
	try {
		const result = await sendFcmToUser(row.user_id, fcm);
		return new Response(JSON.stringify({
			ok: true,
			...result
		}), {
			status: 200,
			headers: { "content-type": "application/json" }
		});
	} catch (err) {
		console.error("[fcm-dispatch] send failed", err);
		return new Response(JSON.stringify({ ok: false }), {
			status: 500,
			headers: { "content-type": "application/json" }
		});
	}
}
//#endregion
export { handleFcmDispatch };
