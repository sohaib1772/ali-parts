import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { a as objectType, n as enumType, o as stringType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import { n as requireAdminOtp } from "./require-admin-otp-DgUpC_62.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/broadcast.functions-BQ8WQArZ.js
/**
* Admin broadcast — the in-app delivery layer.
*
* The actual write is `public.admin_broadcast_notification`, a SECURITY DEFINER
* function, because `notifications` has RLS on with no INSERT policy for any
* client role. The checks are deliberately doubled up:
*
*   - here, so the request is rejected before it reaches the database and so the
*     admin-OTP gate applies exactly as it does to every other privileged action;
*   - in SQL, on `auth.uid()`, so the RPC is still safe if called directly with a
*     signed-in non-admin token.
*
* The RPC is invoked with `context.supabase` (the caller's authenticated client),
* NOT the service-role client — `auth.uid()` must resolve to the admin for the
* in-database check to mean anything. Using supabaseAdmin here would make
* auth.uid() NULL and the SQL guard would reject it.
*/
/** Mirrors the limits enforced in SQL. Kept in sync deliberately: the client
*  gets a fast, localized error; the database is what actually guarantees it. */
var BROADCAST_TITLE_MAX = 80;
var BROADCAST_BODY_MAX = 300;
async function assertAdmin(ctx) {
	const { data, error } = await ctx.supabase.rpc("has_role", {
		_user_id: ctx.userId,
		_role: "admin"
	});
	if (error || !data) throw new Error("Forbidden");
}
var AudienceInput = objectType({
	audience: enumType([
		"all_customers",
		"all_users",
		"single_user"
	]).default("all_customers"),
	user_id: stringType().uuid().nullable().optional()
});
var SendInput = AudienceInput.extend({
	title: stringType().trim().min(1, "العنوان مطلوب").max(BROADCAST_TITLE_MAX),
	body: stringType().trim().max(BROADCAST_BODY_MAX).default("")
});
/** How many recipients the current audience resolves to. Drives the count the
*  admin sees before confirming. */
var adminBroadcastAudienceCount_createServerFn_handler = createServerRpc({
	id: "ea9d5bed95151a7f8492684ea3271028165a9bc6902355796758b7de4a06fa27",
	name: "adminBroadcastAudienceCount",
	filename: "src/lib/broadcast.functions.ts"
}, (opts) => adminBroadcastAudienceCount.__executeServer(opts));
var adminBroadcastAudienceCount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => AudienceInput.parse(d ?? {})).handler(adminBroadcastAudienceCount_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	const { data: count, error } = await context.supabase.rpc("admin_broadcast_audience_count", {
		p_audience: data.audience,
		p_user_id: data.user_id ?? void 0
	});
	if (error) throw new Error(error.message);
	return { count: count ?? 0 };
});
var sendAdminBroadcast_createServerFn_handler = createServerRpc({
	id: "bc748e03115448b8d6104579748f984dfee1b28b5bb7fe47d0603e7a9fcb2e37",
	name: "sendAdminBroadcast",
	filename: "src/lib/broadcast.functions.ts"
}, (opts) => sendAdminBroadcast.__executeServer(opts));
var sendAdminBroadcast = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => SendInput.parse(d)).handler(sendAdminBroadcast_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	const { data: sent, error } = await context.supabase.rpc("admin_broadcast_notification", {
		p_title: data.title,
		p_body: data.body,
		p_audience: data.audience,
		p_user_id: data.user_id ?? void 0
	});
	if (error) throw new Error(error.message);
	return {
		ok: true,
		sent: sent ?? 0
	};
});
//#endregion
export { adminBroadcastAudienceCount_createServerFn_handler, sendAdminBroadcast_createServerFn_handler };
