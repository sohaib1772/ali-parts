import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useSuspenseQuery, c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as uploadWithProgress } from "./upload-with-progress-B1YdROuk.mjs";
import { c as useSetting, i as useAdjustedPrice } from "./admin-DdF3xehS.mjs";
import { _ as useNavigate, g as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as Plus, R as Paperclip, Rt as ArrowRight, S as Shield, St as CircleCheck, T as Share2, U as Minus, X as LoaderCircle, b as ShoppingCart, bt as CircleX, c as Truck, dt as Facebook, f as Trash2, gt as Clock, j as RefreshCw, rt as Heart, t as X } from "../_libs/lucide-react.mjs";
import { a as carModelsQuery, i as brandsQuery, m as productsByCategoryQuery, p as productByIdQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD, s as whatsappLink } from "./format-CTK49jpu.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-DTjZvKIx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as WhatsappIcon } from "./icons-kUk6pI7L.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as Route } from "./product._id-Be5MzFca.mjs";
import { t as Progress } from "./progress-DOIEKRJF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._id-UytBMz0y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { id } = Route.useParams();
	const { data: product } = useSuspenseQuery(productByIdQuery(id));
	const { userId } = useAuth();
	const qc = useQueryClient();
	const [qty, setQty] = (0, import_react.useState)(1);
	const [activeImg, setActiveImg] = (0, import_react.useState)(0);
	const [side, setSide] = (0, import_react.useState)(null);
	const router = useRouter();
	const navigate = useNavigate();
	const goBack = () => {
		if (typeof window !== "undefined" && window.history.length > 1) router.history.back();
		else navigate({ to: "/" });
	};
	const waNumber = useSetting("whatsapp_number");
	const adjust = useAdjustedPrice();
	const { data: deliveredOrder, isPending: deliveredPending } = useQuery({
		queryKey: [
			"product-delivered-order",
			id,
			userId
		],
		enabled: !!userId,
		queryFn: async () => {
			const { data, error } = await supabase.from("order_items").select("id, order_id, orders!inner(id, user_id, status, order_number, created_at)").eq("product_id", id).eq("orders.user_id", userId).eq("orders.status", "delivered").order("created_at", {
				ascending: false,
				referencedTable: "orders"
			}).limit(1).maybeSingle();
			if (error) return null;
			return data;
		}
	});
	const deliveredOrderId = deliveredOrder?.order_id ?? null;
	const deliveredOrderItemId = deliveredOrder?.id ?? null;
	const img = product.images?.[activeImg];
	const stockQty = product.stock_qty ?? 0;
	const available = product.in_stock && stockQty > 0;
	const condition = product.condition === "used" ? "used" : "new";
	const requireAuth = () => {
		if (!userId) {
			toast.error("سجّل الدخول أولاً");
			return false;
		}
		return true;
	};
	const addToCart = async () => {
		if (!requireAuth()) return false;
		const q = supabase.from("cart_items").select("id, quantity, side").eq("user_id", userId).eq("product_id", product.id);
		const { data: existing } = await (side ? q.eq("side", side) : q.is("side", null)).maybeSingle();
		if (existing && existing.quantity === qty) {
			toast.error("هذا المنتج مضاف مسبقاً بنفس الكمية، غيّر الكمية أولاً");
			return false;
		}
		const { error } = await supabase.rpc("add_cart_item", {
			p_product_id: product.id,
			p_quantity: qty,
			p_side: side ?? null
		});
		if (error) {
			toast.error("تعذر إضافة المنتج للسلة");
			return false;
		}
		window.dispatchEvent(new CustomEvent("cart:changed", { detail: {
			delta: qty,
			bump: true
		} }));
		toast.success("تمت الإضافة إلى السلة");
		qc.invalidateQueries({ queryKey: ["cart"] });
		return true;
	};
	const buyNow = async () => {
		if (!requireAuth()) return;
		if (await addToCart()) router.navigate({ to: "/checkout" });
	};
	const toggleFav = async () => {
		if (!requireAuth()) return;
		const { data: existing } = await supabase.from("favorites").select("id").eq("user_id", userId).eq("product_id", product.id).maybeSingle();
		if (existing) {
			await supabase.from("favorites").delete().eq("id", existing.id);
			toast.success("أزيل من المفضلة");
		} else {
			await supabase.from("favorites").insert({
				user_id: userId,
				product_id: product.id
			});
			toast.success("أضيف للمفضلة");
		}
		qc.invalidateQueries({ queryKey: ["favorites"] });
	};
	const share = async () => {
		setShareOpen(true);
	};
	const [shareOpen, setShareOpen] = (0, import_react.useState)(false);
	const shareUrl = typeof window !== "undefined" ? window.location.href : "";
	const waShareHref = whatsappLink(`${`${product.name_ar}${product.oem_number ? ` (OEM: ${product.oem_number})` : ""}`}\n${shareUrl}`, "");
	const REASON_PRESETS = [
		"المنتج معطوب أو مكسور",
		"لا يطابق المواصفات",
		"المقاس أو الجهة (LH/RH) خطأ",
		"استلمت منتجًا مختلفًا"
	];
	const MAX_FILES = 6;
	const MAX_FILE_MB = 10;
	const [replaceOpen, setReplaceOpen] = (0, import_react.useState)(false);
	const [reasonChoice, setReasonChoice] = (0, import_react.useState)(REASON_PRESETS[0]);
	const [reasonText, setReasonText] = (0, import_react.useState)("");
	const [pickedFiles, setPickedFiles] = (0, import_react.useState)([]);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [submittedId, setSubmittedId] = (0, import_react.useState)(null);
	const [uploadProgress, setUploadProgress] = (0, import_react.useState)([]);
	const fileInputRef = (0, import_react.useRef)(null);
	const openReplaceQuick = () => {
		if (!userId) {
			toast.error("سجّل الدخول أولاً");
			return;
		}
		setReasonChoice(REASON_PRESETS[0]);
		setReasonText("");
		setPickedFiles([]);
		setSubmittedId(null);
		setUploadProgress([]);
		setReplaceOpen(true);
	};
	const onPickFiles = (list) => {
		if (!list) return;
		const slots = MAX_FILES - pickedFiles.length;
		const next = [];
		for (const f of Array.from(list).slice(0, slots)) {
			if (f.size > MAX_FILE_MB * 1024 * 1024) {
				toast.error(`${f.name}: يتجاوز ${MAX_FILE_MB} ميغابايت`);
				continue;
			}
			next.push(f);
		}
		setPickedFiles((prev) => [...prev, ...next]);
		if (fileInputRef.current) fileInputRef.current.value = "";
	};
	const submitQuickReplace = async () => {
		if (submitting) return;
		if (!userId || !deliveredOrderId || !deliveredOrderItemId) return;
		const finalReason = (reasonChoice === "أخرى" ? reasonText : `${reasonChoice}${reasonText ? " — " + reasonText : ""}`).trim();
		if (finalReason.length < 5) {
			toast.error("يرجى كتابة سبب الاستبدال (5 أحرف على الأقل)");
			return;
		}
		setSubmitting(true);
		setUploadProgress(pickedFiles.map((f) => ({
			name: f.name,
			progress: 0,
			status: "pending"
		})));
		const { data: inserted, error: insertErr } = await supabase.from("replacement_requests").insert({
			user_id: userId,
			order_id: deliveredOrderId,
			order_item_id: deliveredOrderItemId,
			product_id: product.id,
			product_name_ar: product.name_ar,
			reason: finalReason
		}).select("id").single();
		if (insertErr || !inserted) {
			setSubmitting(false);
			setUploadProgress([]);
			toast.error("تعذّر إرسال طلب الاستبدال");
			return;
		}
		const reqId = inserted.id;
		const uploaded = [];
		for (let i = 0; i < pickedFiles.length; i++) {
			const file = pickedFiles[i];
			const extMatch = file.name.match(/\.([a-zA-Z0-9]+)$/);
			const ext = extMatch ? extMatch[1] : "bin";
			const safeName = file.name.replace(/[^\w.\-]+/g, "_").slice(0, 80) || `file.${ext}`;
			const key = `${userId}/${reqId}/${Date.now()}-${crypto.randomUUID().slice(0, 6)}-${safeName}`;
			setUploadProgress((q) => q.map((it, idx) => idx === i ? {
				...it,
				status: "uploading"
			} : it));
			try {
				await uploadWithProgress("replacement-attachments", key, file, (pct) => {
					setUploadProgress((q) => q.map((it, idx) => idx === i ? {
						...it,
						progress: Math.round(pct * 100)
					} : it));
				});
				setUploadProgress((q) => q.map((it, idx) => idx === i ? {
					...it,
					progress: 100,
					status: "done"
				} : it));
				uploaded.push(key);
			} catch {
				setUploadProgress((q) => q.map((it, idx) => idx === i ? {
					...it,
					status: "error"
				} : it));
			}
		}
		if (uploaded.length > 0) await supabase.from("replacement_requests").update({ attachments: uploaded }).eq("id", reqId);
		setSubmitting(false);
		setSubmittedId(reqId);
		toast.success("تم إرسال طلب الاستبدال");
	};
	const fbShareHref = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
	const copyLink = async () => {
		try {
			await navigator.clipboard.writeText(shareUrl);
			toast.success("نُسخ الرابط");
		} catch {
			toast.error("تعذّر النسخ");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-[100dvh] overflow-y-auto overflow-x-hidden overscroll-contain bg-background pb-32",
		style: { WebkitOverflowScrolling: "touch" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:mx-auto md:max-w-3xl lg:max-w-5xl md:flex md:flex-row-reverse md:gap-6 md:px-4 md:pt-4 md:items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative bg-card md:w-1/2 md:self-start md:sticky md:top-4 md:rounded-3xl md:overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: goBack,
							"aria-label": "رجوع",
							className: "absolute top-4 start-4 z-20 size-10 rounded-full bg-white/90 shadow-card grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: share,
							className: "absolute top-4 end-4 z-10 size-10 rounded-full bg-white/90 shadow-card grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-square bg-muted grid place-items-center select-none",
							onContextMenu: (e) => e.preventDefault(),
							style: {
								WebkitTouchCallout: "none",
								WebkitUserSelect: "none",
								userSelect: "none"
							},
							children: img ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: img,
								alt: product.name_ar,
								draggable: false,
								decoding: "async",
								fetchPriority: "high",
								onContextMenu: (e) => e.preventDefault(),
								onDragStart: (e) => e.preventDefault(),
								className: "size-full object-cover pointer-events-none select-none",
								style: {
									WebkitTouchCallout: "none",
									WebkitUserSelect: "none",
									userSelect: "none"
								}
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-8xl opacity-30",
								children: "⚙️"
							})
						}),
						product.images && product.images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2 px-4 py-3 overflow-x-auto no-scrollbar",
							children: product.images.map((im, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setActiveImg(i),
								className: `size-14 rounded-xl overflow-hidden border-2 flex-shrink-0 ${activeImg === i ? "border-gold" : "border-transparent"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: im,
									alt: "",
									draggable: false,
									loading: "lazy",
									decoding: "async",
									onContextMenu: (e) => e.preventDefault(),
									onDragStart: (e) => e.preventDefault(),
									className: "size-full object-cover pointer-events-none select-none"
								})
							}, i))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-md px-4 pt-4 space-y-4 md:mx-0 md:max-w-none md:w-1/2 md:px-0 md:pt-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-xl font-extrabold leading-tight",
							children: product.name_ar
						}), product.oem_number && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 inline-flex items-center gap-2 bg-muted rounded-lg px-3 py-1 text-xs font-mono",
							children: ["OEM: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold",
								children: product.oem_number
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-black text-navy",
								children: formatIQD(adjust(product.price_iqd))
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ms-auto flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full border ${condition === "used" ? "text-amber-700 bg-amber-500/10 border-amber-500/40" : "text-emerald-700 bg-emerald-500/10 border-emerald-500/40"}`,
									children: condition === "used" ? "مستعمل" : "جديد"
								}), available ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 text-success text-xs font-bold bg-success/10 border border-success/30 px-2.5 py-1 rounded-full",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }),
										" متوفر · ",
										stockQty,
										" قطعة"
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 text-destructive text-xs font-bold bg-destructive/10 border border-destructive/30 px-2.5 py-1 rounded-full",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3.5" }), " غير متوفر"]
								})]
							})]
						}),
						product.description_ar && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-card rounded-2xl border border-border p-4 shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold text-gold mb-2",
								children: "الوصف"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-foreground/80 leading-relaxed",
								children: product.description_ar
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-card rounded-2xl border border-border p-4 shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs font-bold text-gold",
									children: ["الجهة ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground font-normal",
										children: "(اختياري)"
									})]
								}), side && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setSide(null),
									className: "text-[10px] font-bold text-muted-foreground hover:text-destructive",
									children: "إلغاء الاختيار"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setSide("LH"),
										className: `h-11 rounded-xl font-black text-sm border-2 transition ${side === "LH" ? "bg-navy text-primary-foreground border-navy" : "bg-card text-navy border-border"}`,
										children: "LH · يسار"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setSide("RH"),
										className: `h-11 rounded-xl font-black text-sm border-2 transition ${side === "RH" ? "bg-navy text-primary-foreground border-navy" : "bg-card text-navy border-border"}`,
										children: "RH · يمين"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setSide("PAIR"),
										className: `h-11 rounded-xl font-black text-sm border-2 transition ${side === "PAIR" ? "bg-gradient-gold text-navy border-gold" : "bg-card text-navy border-border"}`,
										children: "تخم · طقم"
									})
								]
							})]
						}),
						product.compatible_models && product.compatible_models.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
							fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompatibleModelsSkeleton, { count: product.compatible_models.length }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompatibleModels, { modelIds: product.compatible_models })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-card rounded-2xl border border-border p-3 shadow-card text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-5 text-gold mx-auto mb-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-bold",
									children: "قطع أصلية"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-card rounded-2xl border border-border p-3 shadow-card text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-5 text-gold mx-auto mb-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-bold",
									children: "توصيل سريع"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-gradient-to-br from-gold/15 to-gold/5 rounded-2xl border-2 border-gold/40 p-4 shadow-card",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-11 rounded-xl bg-gradient-gold text-navy grid place-items-center shrink-0 shadow-gold",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-extrabold text-navy",
										children: "التوصيل خلال 72 ساعة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-foreground/70 mt-0.5 leading-relaxed",
										children: "يصلك المنتج خلال 72 ساعة كحد أقصى من وقت تأكيد الطلب."
									})]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: whatsappLink(`السلام عليكم، لدي استفسار/مشكلة بخصوص: ${product.name_ar}`, waNumber),
							target: "_blank",
							rel: "noreferrer",
							className: "block bg-card rounded-2xl border border-border p-4 shadow-card hover:border-whatsapp/60 transition",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-11 rounded-xl bg-whatsapp text-white grid place-items-center shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappIcon, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-extrabold",
										children: "عندك مشكلة أو استفسار؟"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-foreground/70 mt-0.5 leading-relaxed",
										children: "تواصل مع قسم المبيعات مباشرة عبر واتساب وسنساعدك فوراً."
									})]
								})]
							})
						}),
						userId && deliveredPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-card rounded-2xl border border-border p-4 shadow-card",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-11 rounded-xl shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-2/3" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-full" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-5/6" })
									]
								})]
							})
						}),
						deliveredOrderId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: openReplaceQuick,
							className: "w-full text-start block bg-card rounded-2xl border border-gold/60 p-4 shadow-card hover:bg-gold/5 transition",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-11 rounded-xl bg-gold/15 text-gold grid place-items-center shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-extrabold text-navy",
										children: "استبدل هذا المنتج بخطوات سريعة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-foreground/70 mt-0.5 leading-relaxed",
										children: "اختر السبب وأرفق صورة أو مستند، ونرسل الطلب مباشرة — بدون التنقل بين الصفحات."
									})]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold",
									children: "الكمية:"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center bg-card border border-border rounded-xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setQty(Math.max(1, qty - 1)),
											className: "size-9 grid place-items-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-10 text-center font-bold",
											children: qty
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setQty(qty + 1),
											className: "size-9 grid place-items-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: toggleFav,
									className: "ms-auto size-10 rounded-xl bg-card border border-border grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: whatsappLink(`استفسار: ${product.name_ar}`, waNumber),
									target: "_blank",
									rel: "noreferrer",
									className: "size-10 rounded-xl bg-whatsapp text-white grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappIcon, { className: "size-5" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "text-xs text-muted-foreground text-center block pt-2",
							children: "عد للرئيسية"
						})
					]
				})]
			}),
			product.category_id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-md px-4 pt-2 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-sm font-extrabold mb-3 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block w-1 h-4 bg-gold rounded" }), "منتجات مشابهة"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
					fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelatedProductsSkeleton, {}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelatedProducts, {
						categoryId: product.category_id,
						excludeId: product.id
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed bottom-0 inset-x-0 z-30 bg-card border-t border-border p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:bg-transparent md:border-transparent md:p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-md flex items-center gap-2 md:max-w-3xl lg:max-w-5xl md:bg-card md:border md:border-border md:rounded-2xl md:shadow-luxe md:px-4 md:py-3 md:mb-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-shrink-0",
							children: available ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 text-success text-xs font-bold bg-success/10 border border-success/30 px-2 py-1 rounded-full",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }),
									" ",
									stockQty,
									" قطعة"
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 text-destructive text-xs font-bold bg-destructive/10 border border-destructive/30 px-2 py-1 rounded-full",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3.5" }), " غير متوفر"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: addToCart,
							disabled: !available,
							className: "flex-1 h-12 rounded-2xl border-2 border-navy text-navy font-bold flex items-center justify-center gap-2 disabled:opacity-40 transition hover:bg-navy hover:text-primary-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "size-4" }), " أضف للسلة"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: buyNow,
							disabled: !available,
							className: "flex-1 h-12 rounded-2xl bg-gradient-gold text-navy font-black shadow-gold disabled:opacity-40 hover:brightness-105 transition",
							children: "اشترِ الآن"
						})
					]
				})
			}),
			shareOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-navy/60 backdrop-blur-sm grid place-items-end sm:place-items-center",
				onClick: () => setShareOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full sm:max-w-sm bg-card rounded-t-3xl sm:rounded-3xl p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] shadow-luxe animate-in slide-in-from-bottom",
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-extrabold",
							children: "مشاركة المنتج"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShareOpen(false),
							className: "size-8 rounded-full bg-muted grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: waShareHref,
								target: "_blank",
								rel: "noreferrer",
								onClick: () => setShareOpen(false),
								className: "flex flex-col items-center gap-2 p-3 rounded-2xl bg-muted hover:bg-whatsapp/10 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-12 rounded-full bg-whatsapp text-white grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappIcon, { className: "size-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold",
									children: "واتساب"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: fbShareHref,
								target: "_blank",
								rel: "noreferrer",
								onClick: () => setShareOpen(false),
								className: "flex flex-col items-center gap-2 p-3 rounded-2xl bg-muted hover:bg-[#1877F2]/10 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-12 rounded-full bg-[#1877F2] text-white grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Facebook, { className: "size-6" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold",
									children: "فيسبوك"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									copyLink();
									setShareOpen(false);
								},
								className: "flex flex-col items-center gap-2 p-3 rounded-2xl bg-muted hover:bg-navy/10 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-12 rounded-full bg-navy text-primary-foreground grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold",
									children: "نسخ الرابط"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: replaceOpen,
				onOpenChange: (o) => {
					if (!submitting) setReplaceOpen(o);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					className: "rounded-3xl max-w-md p-0 overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-5 pb-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
								className: "text-navy",
								children: submittedId ? "تم إرسال طلب الاستبدال" : "طلب استبدال سريع"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: submittedId ? "سيتواصل معك قسم متابعة الاستبدال خلال 72 ساعة." : product.name_ar })] })
						}),
						!submittedId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-5 pb-4 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-bold text-navy mb-2",
									children: "1) سبب الاستبدال"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-1.5",
									children: [...REASON_PRESETS, "أخرى"].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: `flex items-center gap-2 px-3 py-2 rounded-xl border cursor-pointer text-xs font-bold ${reasonChoice === r ? "bg-navy/5 border-navy" : "border-border hover:bg-muted"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "radio",
											name: "reason",
											value: r,
											checked: reasonChoice === r,
											onChange: () => setReasonChoice(r),
											className: "accent-navy"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r })]
									}, r))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: reasonText,
									onChange: (e) => setReasonText(e.target.value.slice(0, 500)),
									placeholder: reasonChoice === "أخرى" ? "اكتب السبب بالتفصيل..." : "تفاصيل إضافية (اختياري)",
									className: "mt-2 w-full min-h-[64px] rounded-xl border border-border bg-background p-2 text-xs"
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-bold text-navy",
										children: "2) مرفقات (اختياري)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] text-muted-foreground",
										children: [
											pickedFiles.length,
											"/",
											MAX_FILES,
											" · حتى ",
											MAX_FILE_MB,
											"MB"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: fileInputRef,
									type: "file",
									multiple: true,
									accept: "image/*,application/pdf,.doc,.docx,.xls,.xlsx,.txt",
									className: "hidden",
									onChange: (e) => onPickFiles(e.target.files),
									disabled: submitting
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => fileInputRef.current?.click(),
									disabled: pickedFiles.length >= MAX_FILES || submitting,
									className: "w-full h-10 rounded-xl border border-dashed border-gold/60 text-navy text-xs font-bold flex items-center justify-center gap-2 hover:bg-gold/5 disabled:opacity-50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-4 text-gold" }), "إضافة صور أو مستندات"]
								}),
								pickedFiles.length > 0 && uploadProgress.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-2 space-y-1",
									children: pickedFiles.map((f, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-2 text-[11px] bg-muted rounded-lg px-2 py-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "flex-1 truncate",
												children: f.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-muted-foreground",
												children: [(f.size / 1024 / 1024).toFixed(2), "MB"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setPickedFiles((prev) => prev.filter((_, i) => i !== idx)),
												disabled: submitting,
												className: "size-6 rounded-md grid place-items-center hover:bg-background",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5 text-rose-600" })
											})
										]
									}, idx))
								}),
								uploadProgress.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 space-y-2",
									children: [uploadProgress.map((it, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg border border-border bg-muted/40 p-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 mb-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-3 text-gold shrink-0" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex-1 truncate text-[10px] font-bold text-navy",
													children: it.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-muted-foreground",
													children: it.status === "error" ? "فشل" : it.status === "done" ? "تم ✓" : it.status === "pending" ? "…" : `${it.progress}%`
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
											value: it.status === "error" ? 0 : it.progress,
											className: "h-1.5"
										})]
									}, idx)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-3 gap-2 pt-1",
										children: uploadProgress.filter((it) => it.status === "uploading" || it.status === "pending").map((_, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "aspect-square rounded-lg" }, idx))
									})]
								})
							] })]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-5 pb-2 text-xs text-muted-foreground",
							children: "يمكنك متابعة حالة الطلب من صفحة الاستبدال."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogFooter, {
							className: "p-4 pt-2 gap-2",
							children: submittedId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
								className: "rounded-xl",
								children: "إغلاق"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/replacements/$id",
								params: { id: submittedId },
								className: "inline-flex items-center justify-center h-10 px-4 rounded-xl bg-navy text-primary-foreground text-xs font-bold hover:bg-navy/90",
								children: "عرض تفاصيل الطلب"
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
								disabled: submitting,
								className: "rounded-xl",
								children: "إلغاء"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: submitQuickReplace,
								disabled: submitting,
								className: "inline-flex items-center justify-center h-10 px-4 rounded-xl bg-navy text-primary-foreground text-xs font-bold hover:bg-navy/90 disabled:opacity-60",
								children: submitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : "إرسال الطلب"
							})] })
						})
					]
				})
			})
		]
	});
}
function CompatibleModelsSkeleton({ count }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-card rounded-2xl border border-border p-4 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-bold text-gold mb-2",
			children: "السيارات المتوافقة"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: Array.from({ length: Math.min(count, 6) }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-20 rounded-full" }, i))
		})]
	});
}
function CompatibleModels({ modelIds }) {
	const { data: models } = useSuspenseQuery(carModelsQuery());
	const { data: brands } = useSuspenseQuery(brandsQuery());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-card rounded-2xl border border-border p-4 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-bold text-gold mb-2",
			children: "السيارات المتوافقة"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: modelIds.map((mid) => {
				const model = models.find((x) => x.id === mid);
				const brand = model ? brands.find((b) => b.id === model.brand_id) : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs px-2.5 py-1 rounded-full bg-navy text-primary-foreground",
					children: model ? `${brand ? (brand.name_ar || brand.name_en) + " " : ""}${model.name_ar || model.name_en}` : mid
				}, mid);
			})
		})]
	});
}
function RelatedProductsSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-3",
		children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-border overflow-hidden bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "w-full aspect-square" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-3 space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-2/3" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-1/2" })
				]
			})]
		}, i))
	});
}
function RelatedProducts({ categoryId, excludeId }) {
	const { data: products } = useSuspenseQuery(productsByCategoryQuery(categoryId));
	const related = products.filter((p) => p.id !== excludeId).slice(0, 4);
	const adjust = useAdjustedPrice();
	if (related.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-xs text-muted-foreground text-center py-4",
		children: "لا توجد منتجات مشابهة"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-3",
		children: related.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/product/$id",
			params: { id: p.id },
			className: "rounded-2xl border border-border overflow-hidden bg-card hover:shadow-luxe transition",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "aspect-square bg-muted overflow-hidden",
				children: p.images?.[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: p.images[0],
					alt: p.name_ar,
					loading: "lazy",
					decoding: "async",
					width: 200,
					height: 200,
					sizes: "50vw",
					className: "size-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-full grid place-items-center text-3xl opacity-30",
					children: "⚙️"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs font-semibold line-clamp-2 leading-tight min-h-[2.2rem]",
					children: p.name_ar
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-extrabold text-navy mt-1",
					children: formatIQD(adjust(p.price_iqd))
				})]
			})]
		}, p.id))
	});
}
//#endregion
export { ProductPage as component };
