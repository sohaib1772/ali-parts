import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { c as useQueryClient, i as queryOptions, o as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-DFPiacgQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Badges cap their display well below this, so a bound is safe here. */
var UNREAD_FETCH_LIMIT = 200;
var unreadNotificationsKey = (userId) => [
	"notifications",
	"unread",
	userId
];
var unreadNotificationsQuery = (userId) => queryOptions({
	queryKey: unreadNotificationsKey(userId),
	queryFn: async () => {
		if (!userId) return [];
		const { data, error } = await supabase.from("notifications").select("id, order_id, type").eq("user_id", userId).is("read_at", null).order("created_at", { ascending: false }).limit(UNREAD_FETCH_LIMIT);
		if (error) throw error;
		return data ?? [];
	},
	enabled: !!userId,
	staleTime: 3e4
});
/**
* One realtime channel per user, shared by every component that renders a
* badge. Without the ref-counting each consumer (header bell, bottom nav,
* orders list) would open its own duplicate subscription to the same rows.
*/
var listeners = /* @__PURE__ */ new Map();
var channels = /* @__PURE__ */ new Map();
function subscribeUnread(userId, cb) {
	let set = listeners.get(userId);
	if (!set) {
		set = /* @__PURE__ */ new Set();
		listeners.set(userId, set);
		const ch = supabase.channel(`notifications-unread-${userId}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "notifications",
			filter: `user_id=eq.${userId}`
		}, () => listeners.get(userId)?.forEach((l) => l())).subscribe();
		channels.set(userId, ch);
	}
	set.add(cb);
	return () => {
		const current = listeners.get(userId);
		if (!current) return;
		current.delete(cb);
		if (current.size > 0) return;
		listeners.delete(userId);
		const ch = channels.get(userId);
		if (ch) {
			supabase.removeChannel(ch);
			channels.delete(userId);
		}
	};
}
/** Live list of the signed-in user's unread notifications. */
function useUnreadNotifications() {
	const { userId } = useAuth();
	const qc = useQueryClient();
	const { data } = useQuery(unreadNotificationsQuery(userId));
	(0, import_react.useEffect)(() => {
		if (!userId) return;
		return subscribeUnread(userId, () => {
			qc.invalidateQueries({ queryKey: unreadNotificationsKey(userId) });
		});
	}, [userId, qc]);
	return data ?? [];
}
function useUnreadCounts() {
	const unread = useUnreadNotifications();
	return (0, import_react.useMemo)(() => {
		const orderIds = /* @__PURE__ */ new Set();
		for (const n of unread) if (n.order_id) orderIds.add(n.order_id);
		return {
			total: unread.length,
			orders: unread.reduce((sum, n) => sum + (n.order_id ? 1 : 0), 0),
			orderIds
		};
	}, [unread]);
}
/**
* Mark every unread notification for one order as read. Called when the user
* opens that order — the server-side `read_at` write is what makes the badge
* clear on their other devices too.
*/
async function markOrderNotificationsRead(userId, orderId) {
	const { error } = await supabase.from("notifications").update({ read_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("user_id", userId).eq("order_id", orderId).is("read_at", null);
	if (error) throw error;
}
//#endregion
export { unreadNotificationsKey as n, useUnreadCounts as r, markOrderNotificationsRead as t };
