import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { O as Search, t as X } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { _ as storefrontSearchQuery } from "./queries-CNdOTkej.mjs";
import { r as useStorefrontFilters, t as applyStorefrontFilters } from "./storefront-filters-DpSWbFTB.mjs";
import { n as ProductCard, t as FilterBar } from "./filter-bar-DXDobEud.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-BikvWiev.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SearchPage() {
	const { filters, setFilter } = useStorefrontFilters();
	const q = filters.q;
	const [qLocal, setQLocal] = (0, import_react.useState)(q);
	(0, import_react.useEffect)(() => setQLocal(q), [q]);
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => {
			if (qLocal.trim() !== q.trim()) setFilter({ q: qLocal });
		}, 300);
		return () => clearTimeout(t);
	}, [qLocal]);
	const deferredQ = (0, import_react.useDeferredValue)(q);
	const searchFilterParams = (0, import_react.useMemo)(() => ({
		q: deferredQ,
		category: filters.category,
		brand: filters.brand,
		model: filters.model
	}), [
		deferredQ,
		filters.category,
		filters.brand,
		filters.model
	]);
	const hasAnyFilter = Boolean(deferredQ.trim() || filters.category || filters.brand || filters.model);
	const { data: results, isFetching } = useQuery(storefrontSearchQuery(searchFilterParams));
	const filtered = applyStorefrontFilters(results ?? [], {
		...filters,
		q: deferredQ
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, {
		wide: true,
		title: "بحث",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 bg-card border border-border rounded-2xl px-4 h-11 shadow-card focus-within:border-gold",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-5 text-muted-foreground shrink-0" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value: qLocal,
						onChange: (e) => setQLocal(e.target.value),
						placeholder: "ابحث عن قطعة، اسم أو رقم OEM…",
						className: "flex-1 bg-transparent outline-none text-base md:text-sm",
						inputMode: "search"
					}),
					qLocal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setQLocal(""),
						"aria-label": "مسح البحث",
						className: "text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 px-4",
			children: (() => {
				const SkeletonGrid = ({ n }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3",
					children: Array.from({ length: n }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "skeleton rounded-2xl aspect-[3/4]" }, i))
				});
				if (!hasAnyFilter) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center text-muted-foreground text-sm py-16 space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-10 mx-auto text-muted-foreground/30 mb-2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-foreground text-base",
							children: "ابحث عن القطع أو اختر تصنيفاً"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground max-w-xs mx-auto",
							children: "اختر التصنيف، الماركة أو نوع السيارة من الفلاتر أعلاه، أو اكتب اسم القطعة أو رقمها."
						})
					]
				});
				if (isFetching) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonGrid, { n: 4 });
				if (filtered.length > 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [filtered.length, " نتيجة"] }), isFetching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold animate-pulse text-[11px]",
						children: "جاري التحديث…"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3",
					children: filtered.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				})] });
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center text-muted-foreground text-sm py-16 space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold text-foreground",
						children: "لا توجد نتائج مطابقة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground max-w-xs mx-auto",
						children: "جرّب تغيير الصنف أو نوع السيارة أو البحث برقم الـ OEM، أو تواصل معنا مباشرة عبر واتساب للمساعدة."
					})]
				});
			})()
		})]
	});
}
//#endregion
export { SearchPage as component };
