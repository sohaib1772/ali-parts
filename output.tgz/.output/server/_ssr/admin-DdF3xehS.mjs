import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { i as queryOptions, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as uploadWithProgress } from "./upload-with-progress-B1YdROuk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DdF3xehS.js
var isAdminQuery = (userId) => queryOptions({
	queryKey: ["is_admin", userId],
	queryFn: async () => {
		if (!userId) return false;
		const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
		if (error) throw error;
		return !!data;
	},
	enabled: !!userId
});
function useIsAdmin() {
	const { userId } = useAuth();
	const { data } = useQuery(isAdminQuery(userId));
	return !!data;
}
function useIsAdminStatus() {
	const { userId, loading: authLoading } = useAuth();
	const q = useQuery(isAdminQuery(userId));
	return {
		isAdmin: !!q.data,
		isLoading: authLoading || !!userId && q.data === void 0 && !q.isError,
		isError: q.isError,
		error: q.error
	};
}
var staffPermissionsQuery = (userId) => queryOptions({
	queryKey: ["staff_permissions", userId],
	queryFn: async () => {
		if (!userId) return null;
		const { data, error } = await supabase.from("staff_permissions").select("can_orders, can_products, can_replacements, can_block").eq("user_id", userId).maybeSingle();
		if (error) throw error;
		if (!data) return null;
		return data;
	},
	enabled: !!userId,
	staleTime: 6e4
});
function useStaffPermissions() {
	const { userId } = useAuth();
	const { data } = useQuery(staffPermissionsQuery(userId));
	return data ?? null;
}
function useStaffPermissionsStatus() {
	const { userId, loading: authLoading } = useAuth();
	const q = useQuery(staffPermissionsQuery(userId));
	return {
		staff: q.data ?? null,
		isLoading: authLoading || !!userId && q.data === void 0 && q.isLoading && !q.isError,
		isError: q.isError,
		error: q.error
	};
}
function useAdminAccessStatus() {
	const admin = useIsAdminStatus();
	const staffStatus = useStaffPermissionsStatus();
	const staff = staffStatus.staff;
	const canOrders = admin.isAdmin || !!staff?.can_orders;
	const canProducts = admin.isAdmin || !!staff?.can_products;
	const canReplacements = admin.isAdmin || !!staff?.can_replacements;
	const canBlock = admin.isAdmin || !!staff?.can_block;
	return {
		isAdmin: admin.isAdmin,
		staff,
		canOrders,
		canProducts,
		canReplacements,
		canBlock,
		hasAnyAccess: admin.isAdmin || canOrders || canProducts || canReplacements || canBlock,
		isLoading: admin.isLoading || staffStatus.isLoading,
		isError: admin.isError || staffStatus.isError,
		error: admin.error ?? staffStatus.error
	};
}
var settingsQuery = () => queryOptions({
	queryKey: ["app_settings"],
	queryFn: async () => {
		const { data, error } = await supabase.from("app_settings").select("*");
		if (error) throw error;
		const map = {};
		for (const row of data ?? []) map[row.key] = row.value ?? "";
		return map;
	},
	staleTime: 6e4
});
function useSetting(key, fallback = "") {
	const { data } = useQuery(settingsQuery());
	return data?.[key] ?? fallback;
}
/**
* Global price adjustment (IQD) applied on top of every product's displayed
* price. Stored as `global_price_adjustment_iqd` in `app_settings`. Can be
* negative. Does NOT change the price stored in the database — only the
* number shown to customers in product listings and details.
*/
function useGlobalPriceAdjustment() {
	const { data } = useQuery(settingsQuery());
	const n = Number(data?.global_price_adjustment_iqd ?? 0);
	return Number.isFinite(n) ? n : 0;
}
/**
* Loyalty points configuration, read from app_settings with fallbacks that
* exactly match the server-side (place_order / handle_order_status_change)
* defaults. Keep these in lockstep with migration 20260801160000.
*   redeemRate  — IQD per point (≥1, guards divide-by-zero)
*   earnPer1000 — points earned per full 1000 IQD, on delivery
*   maxRedeemPct— max % of an order coverable by points (0–100)
*   minRedeem   — minimum points per redemption
*   cardText    — editable Arabic description on the account card
*/
function usePointsConfig() {
	const { data } = useQuery(settingsQuery());
	return {
		redeemRate: (() => {
			const n = Number(data?.points_redeem_iqd_per_point);
			return Number.isFinite(n) && n >= 1 ? n : 10;
		})(),
		earnPer1000: (() => {
			const n = Number(data?.points_earn_per_1000_iqd);
			return Number.isFinite(n) && n >= 0 ? n : 10;
		})(),
		maxRedeemPct: (() => {
			const n = Number(data?.points_max_redeem_pct);
			return Number.isFinite(n) ? Math.min(100, Math.max(0, n)) : 50;
		})(),
		minRedeem: (() => {
			const n = Number(data?.points_min_redeem);
			return Number.isFinite(n) && n >= 0 ? Math.trunc(n) : 100;
		})(),
		cardText: data?.points_card_text?.trim() || "كل 100 نقطة = 1,000 دينار خصم عند الشراء"
	};
}
function useAdjustedPrice() {
	const adj = useGlobalPriceAdjustment();
	return (price) => Math.max(0, Number(price ?? 0) + adj);
}
/**
* Compress an image in the browser before upload.
* Downscales to fit within `maxDim` and re-encodes as JPEG (or keeps PNG for
* transparency). Cuts payloads 3–10x, so uploads finish much faster on mobile.
*/
async function compressImageFile(file, maxDim = 1200, quality = .75) {
	if (!file.type.startsWith("image/")) return file;
	if (file.size < 200 * 1024) return file;
	if (/gif|svg/.test(file.type)) return file;
	const keepPng = file.type === "image/png";
	try {
		const bitmap = await createImageBitmap(file).catch(async () => {
			const url = URL.createObjectURL(file);
			const img = await new Promise((resolve, reject) => {
				const el = new Image();
				el.onload = () => resolve(el);
				el.onerror = reject;
				el.src = url;
			});
			URL.revokeObjectURL(url);
			return img;
		});
		const w = bitmap.width;
		const h = bitmap.height;
		const scale = Math.min(1, maxDim / Math.max(w, h));
		const nw = Math.round(w * scale);
		const nh = Math.round(h * scale);
		const canvas = document.createElement("canvas");
		canvas.width = nw;
		canvas.height = nh;
		const ctx = canvas.getContext("2d");
		if (!ctx) return file;
		ctx.drawImage(bitmap, 0, 0, nw, nh);
		const mime = keepPng ? "image/png" : "image/jpeg";
		const blob = await new Promise((resolve) => canvas.toBlob(resolve, mime, keepPng ? void 0 : quality));
		if (!blob || blob.size >= file.size) return file;
		const ext = keepPng ? "png" : "jpg";
		return new File([blob], file.name.replace(/\.[^.]+$/, "") + "." + ext, { type: mime });
	} catch {
		return file;
	}
}
async function uploadProductImage(file, onProgress) {
	const compressed = await compressImageFile(file);
	const ext = (compressed.name.split(".").pop() || "jpg").toLowerCase();
	const path = `${crypto.randomUUID()}.${ext}`;
	await uploadWithProgress("product-images", path, compressed, onProgress);
	const { data } = await supabase.storage.from("product-images").createSignedUrl(path, 3600 * 24 * 365 * 10);
	return data?.signedUrl ?? "";
}
async function uploadMediaFile(file, onProgress) {
	let toUpload = file;
	if (file.type.startsWith("image/")) toUpload = await compressImageFile(file);
	else if (file.type.startsWith("video/")) toUpload = await compressVideoFile(file, onProgress);
	const isCompressedVideo = toUpload !== file && file.type.startsWith("video/");
	const ext = (toUpload.name.split(".").pop() || "bin").toLowerCase();
	const path = `${crypto.randomUUID()}.${ext}`;
	await uploadWithProgress("product-images", path, toUpload, isCompressedVideo && onProgress ? (p) => onProgress(.5 + p * .5) : onProgress);
	onProgress?.(1);
	const { data } = await supabase.storage.from("product-images").createSignedUrl(path, 3600 * 24 * 365 * 10);
	return data?.signedUrl ?? "";
}
/**
* Re-encode a video in the browser using MediaRecorder + captureStream at a
* bounded bitrate and width. This can cut phone-recorded clips (often
* 20–50 Mbps) down to a few megabytes so the upload is dramatically faster.
*
* `onProgress` (0..0.5) reflects the compression pass; the upload progress
* (0.5..1) is reported by the actual upload step afterwards.
* If anything fails or the browser lacks support, we return the original file.
*/
async function compressVideoFile(file, onProgress) {
	if (file.size < 3 * 1024 * 1024) return file;
	if (typeof MediaRecorder === "undefined") return file;
	const mimeType = [
		"video/webm;codecs=vp9,opus",
		"video/webm;codecs=vp8,opus",
		"video/webm",
		"video/mp4"
	].find((t) => {
		try {
			return MediaRecorder.isTypeSupported(t);
		} catch {
			return false;
		}
	});
	if (!mimeType) return file;
	const url = URL.createObjectURL(file);
	try {
		const video = document.createElement("video");
		video.src = url;
		video.muted = false;
		video.playsInline = true;
		video.preload = "auto";
		video.style.position = "fixed";
		video.style.opacity = "0";
		video.style.pointerEvents = "none";
		document.body.appendChild(video);
		await new Promise((res, rej) => {
			video.onloadedmetadata = () => res();
			video.onerror = () => rej(/* @__PURE__ */ new Error("metadata"));
		});
		const srcW = video.videoWidth;
		const srcH = video.videoHeight;
		if (!srcW || !srcH) {
			document.body.removeChild(video);
			return file;
		}
		const scale = Math.min(1, 1280 / srcW);
		Math.round(srcW * scale);
		Math.round(srcH * scale);
		const stream = video.captureStream?.() ?? video.mozCaptureStream?.();
		if (!stream) {
			document.body.removeChild(video);
			return file;
		}
		const videoBitsPerSecond = 22e5;
		const audioBitsPerSecond = 96e3;
		let recorder;
		try {
			recorder = new MediaRecorder(stream, {
				mimeType,
				videoBitsPerSecond,
				audioBitsPerSecond
			});
		} catch {
			document.body.removeChild(video);
			return file;
		}
		const chunks = [];
		recorder.ondataavailable = (e) => {
			if (e.data.size) chunks.push(e.data);
		};
		const duration = isFinite(video.duration) && video.duration > 0 ? video.duration : 0;
		let tick = null;
		if (duration > 0 && onProgress) tick = window.setInterval(() => {
			onProgress(Math.min(.5, video.currentTime / duration * .5));
		}, 200);
		recorder.start(500);
		try {
			video.currentTime = 0;
		} catch {}
		await video.play().catch(() => {});
		await new Promise((res) => {
			const done = () => {
				recorder.stop();
			};
			video.onended = done;
			const safety = window.setTimeout(done, Math.max(3e4, (duration + 5) * 1e3));
			recorder.onstop = () => {
				window.clearTimeout(safety);
				res();
			};
		});
		if (tick != null) window.clearInterval(tick);
		try {
			video.pause();
		} catch {}
		document.body.removeChild(video);
		const outType = mimeType.split(";")[0];
		const outBlob = new Blob(chunks, { type: outType });
		if (outBlob.size === 0 || outBlob.size >= file.size * .95) return file;
		const ext = outType === "video/mp4" ? "mp4" : "webm";
		const name = file.name.replace(/\.[^.]+$/, "") + "." + ext;
		return new File([outBlob], name, { type: outType });
	} catch {
		return file;
	} finally {
		URL.revokeObjectURL(url);
	}
}
//#endregion
export { useAdminAccessStatus as a, useSetting as c, useAdjustedPrice as i, useStaffPermissions as l, uploadMediaFile as n, useIsAdmin as o, uploadProductImage as r, usePointsConfig as s, settingsQuery as t };
