import { t as supabase } from "./client-Q2B4x7UN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/upload-with-progress-B1YdROuk.js
/**
* Upload a file to a Supabase Storage bucket, reporting real byte-level
* progress through onProgress (0..1).
*
* Primary path: request a signed upload URL and PUT the file with XHR so we
* can observe upload progress. If that path fails (CORS preflight hang, the
* server never responding, network hiccup, etc.), we fall back to the
* standard `supabase.storage.upload()` call so the upload still completes —
* we just lose the fine-grained progress ticks.
*/
async function uploadWithProgress(bucket, key, file, onProgress) {
	try {
		await uploadViaSignedUrl(bucket, key, file, onProgress);
		return;
	} catch (err) {
		console.warn("[upload] signed-url PUT failed, falling back to SDK upload", err);
	}
	const { error } = await supabase.storage.from(bucket).upload(key, file, {
		cacheControl: "3600",
		upsert: false,
		contentType: file.type || void 0
	});
	if (error) throw error;
	onProgress?.(1);
}
function uploadViaSignedUrl(bucket, key, file, onProgress) {
	return new Promise((resolve, reject) => {
		(async () => {
			try {
				const { data, error } = await supabase.storage.from(bucket).createSignedUploadUrl(key);
				if (error || !data?.signedUrl) {
					reject(error ?? /* @__PURE__ */ new Error("createSignedUploadUrl failed"));
					return;
				}
				const xhr = new XMLHttpRequest();
				let lastTick = Date.now();
				const watchdog = window.setInterval(() => {
					if (Date.now() - lastTick > 3e4) try {
						xhr.abort();
					} catch {}
				}, 5e3);
				const cleanup = () => window.clearInterval(watchdog);
				xhr.open("PUT", data.signedUrl);
				if (file.type) xhr.setRequestHeader("Content-Type", file.type);
				xhr.upload.onprogress = (e) => {
					lastTick = Date.now();
					if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total);
				};
				xhr.onload = () => {
					cleanup();
					if (xhr.status >= 200 && xhr.status < 300) {
						onProgress?.(1);
						resolve();
					} else reject(new Error(xhr.responseText || `Upload failed (${xhr.status})`));
				};
				xhr.onerror = () => {
					cleanup();
					reject(/* @__PURE__ */ new Error("network error"));
				};
				xhr.onabort = () => {
					cleanup();
					reject(/* @__PURE__ */ new Error("aborted"));
				};
				xhr.ontimeout = () => {
					cleanup();
					reject(/* @__PURE__ */ new Error("timeout"));
				};
				xhr.send(file);
			} catch (err) {
				reject(err);
			}
		})();
	});
}
//#endregion
export { uploadWithProgress as t };
