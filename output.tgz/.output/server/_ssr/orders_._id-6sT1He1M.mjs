import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as markOrderNotificationsRead } from "./notifications-DFPiacgQ.mjs";
import { g as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { H as PackageCheck, K as MapPin, M as Receipt, Rt as ArrowRight, V as PackageOpen, bt as CircleX, c as Truck, it as Headphones, j as RefreshCw, tt as House, v as StickyNote, z as Package } from "../_libs/lucide-react.mjs";
import { d as orderByIdQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD, n as formatArabicDate } from "./format-CTK49jpu.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-DTjZvKIx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as statusLabel } from "./order-status-Chx_uF3Y.mjs";
import { a as InvoicePreviewDialog, o as PrintableInvoice } from "./printable-invoice-DqxFZT5I.mjs";
import { t as Route } from "./orders_._id-BxweEGDk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders_._id-6sT1He1M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TIMELINE = [
	{
		key: "received",
		label: "تم استلام الطلب",
		icon: Package
	},
	{
		key: "preparing",
		label: "جاري التجهيز",
		icon: PackageOpen
	},
	{
		key: "packed",
		label: "تم التغليف",
		icon: PackageCheck
	},
	{
		key: "shipped",
		label: "تسليم للتوصيل",
		icon: Truck
	},
	{
		key: "out_for_delivery",
		label: "خرج للتوصيل",
		icon: MapPin
	},
	{
		key: "delivered",
		label: "تم التسليم",
		icon: House
	}
];
function AddressRow({ label, value, mono, muted }) {
	if (!value) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted-foreground shrink-0",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `text-end ${mono ? "font-mono" : ""} ${muted ? "text-muted-foreground text-xs" : "font-semibold"}`,
			children: value
		})]
	});
}
function OrderDetail() {
	const { id } = Route.useParams();
	const { data, isLoading, error } = useQuery(orderByIdQuery(id));
	const order = data?.order;
	const items = data?.items ?? [];
	const customer = data?.customer ?? null;
	const router = useRouter();
	const qc = useQueryClient();
	const [previewOpen, setPreviewOpen] = (0, import_react.useState)(false);
	const [replaceOpen, setReplaceOpen] = (0, import_react.useState)(false);
	const [replaceItem, setReplaceItem] = (0, import_react.useState)(null);
	const [replaceReason, setReplaceReason] = (0, import_react.useState)("");
	const [replaceSubmitting, setReplaceSubmitting] = (0, import_react.useState)(false);
	const [replaceDone, setReplaceDone] = (0, import_react.useState)(false);
	const { userId } = useAuth();
	const openReplace = (it) => {
		setReplaceItem(it);
		setReplaceReason("");
		setReplaceDone(false);
		setReplaceOpen(true);
	};
	const submitReplace = async () => {
		if (!userId || !replaceItem) return;
		const reason = replaceReason.trim();
		if (reason.length < 5) {
			toast.error("يرجى كتابة سبب الاستبدال (5 أحرف على الأقل)");
			return;
		}
		setReplaceSubmitting(true);
		const { error } = await supabase.from("replacement_requests").insert({
			user_id: userId,
			order_id: order.id,
			order_item_id: replaceItem.id,
			product_id: replaceItem.product_id,
			product_name_ar: replaceItem.name_ar,
			reason
		});
		setReplaceSubmitting(false);
		if (error) {
			toast.error("تعذّر إرسال طلب الاستبدال");
			return;
		}
		setReplaceDone(true);
	};
	(0, import_react.useEffect)(() => {
		const ch = supabase.channel(`order-${id}`).on("postgres_changes", {
			event: "UPDATE",
			schema: "public",
			table: "orders",
			filter: `id=eq.${id}`
		}, () => {
			qc.invalidateQueries({ queryKey: ["order", id] });
			qc.invalidateQueries({ queryKey: ["orders"] });
		}).subscribe();
		return () => {
			supabase.removeChannel(ch);
		};
	}, [id, qc]);
	(0, import_react.useEffect)(() => {
		if (!order || !userId) return;
		markOrderNotificationsRead(userId, order.id).catch(() => {});
	}, [order, userId]);
	const activeIdx = TIMELINE.findIndex((t) => t.key === order?.status);
	const cancelled = order?.status === "cancelled";
	const canCancel = order?.status === "received" || order?.status === "preparing";
	const canReplace = order?.status === "delivered";
	const [cancelling, setCancelling] = (0, import_react.useState)(false);
	const handleCancel = async () => {
		if (!confirm("هل تريد إلغاء هذا الطلب؟")) return;
		setCancelling(true);
		const { error } = await supabase.rpc("cancel_my_order", { p_order_id: order.id });
		setCancelling(false);
		if (error) toast.error(error.message || "تعذّر إلغاء الطلب");
		else {
			toast.success("تم إلغاء الطلب");
			qc.invalidateQueries({ queryKey: ["order", order.id] });
			qc.invalidateQueries({ queryKey: ["orders"] });
		}
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen grid place-items-center text-muted-foreground",
		children: "جاري التحميل..."
	});
	if (error || !order) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen grid place-items-center px-4 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-12 text-muted-foreground mx-auto mb-3" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-lg font-bold mb-1",
				children: "لم يتم العثور على الطلب"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/orders",
				className: "text-gold text-sm font-bold",
				children: "عودة لطلباتي"
			})
		] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-0 z-20 bg-gradient-navy text-primary-foreground shadow-luxe no-print",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-md md:max-w-3xl lg:max-w-5xl px-4 py-4 flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => router.history.back(),
							className: "size-9 rounded-full bg-white/10 grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold",
								children: "تفاصيل الطلب"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] text-gold font-mono",
								children: order.order_number
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setPreviewOpen(true),
							className: "inline-flex items-center gap-1.5 px-3 h-9 rounded-full bg-gradient-gold text-navy font-bold text-xs shadow-gold hover:brightness-105 transition",
							"aria-label": "معاينة الفاتورة",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4" }), " الفاتورة"]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-md md:max-w-3xl lg:max-w-5xl px-4 pt-4 space-y-4 no-print",
				children: [
					cancelled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-destructive/10 border border-destructive/30 rounded-2xl p-4 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-6 text-destructive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-destructive",
							children: "تم إلغاء الطلب"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "إذا كان لديك استفسار تواصل معنا"
						})] })]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card rounded-2xl border border-border p-4 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold text-gold mb-4",
							children: "حالة الطلب"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: TIMELINE.map((t, i) => {
								const done = i <= activeIdx;
								const active = i === activeIdx;
								const Icon = t.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `size-10 rounded-full grid place-items-center transition ${done ? "bg-gradient-gold text-navy shadow-gold" : "bg-muted text-muted-foreground"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `text-sm font-bold ${done ? "text-navy" : "text-muted-foreground"}`,
											children: t.label
										}), active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-gold",
											children: "الحالة الحالية"
										})]
									})]
								}, t.key);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card rounded-2xl border border-border p-4 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold text-gold mb-3",
							children: "المنتجات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-14 rounded-xl bg-muted overflow-hidden flex-shrink-0",
											children: it.image_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: it.image_url,
												alt: "",
												crossOrigin: "anonymous",
												className: "size-full object-cover"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 min-w-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-sm font-bold line-clamp-1",
													children: it.name_ar
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-xs text-muted-foreground flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["× ", it.quantity] }), it.side && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "inline-flex items-center px-1.5 py-0.5 rounded-full bg-navy text-primary-foreground text-[10px] font-black",
														children: it.side === "LH" ? "LH · يسار" : "RH · يمين"
													})]
												}),
												it.note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-1 flex items-start gap-1 text-[11px] text-muted-foreground bg-muted/50 rounded-md p-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "size-3 text-gold shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "whitespace-pre-wrap",
														children: it.note
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-bold self-center",
											children: formatIQD(Number(it.unit_price_iqd) * it.quantity)
										})
									]
								}), canReplace && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => openReplace(it),
									className: "mt-2 w-full h-9 rounded-xl border border-gold/50 text-navy text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-gold/10",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5 text-gold" }), "استبدال"]
								})]
							}, it.id))
						})]
					}),
					order.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card rounded-2xl border border-border p-4 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "size-4 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold text-gold",
								children: "ملاحظة الزبون على الطلب"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm whitespace-pre-wrap",
							children: order.notes
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card rounded-2xl border border-border p-4 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-bold text-gold mb-3",
							children: "عنوان التوصيل"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressRow, {
									label: "التسمية",
									value: order.address?.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressRow, {
									label: "الاسم الكامل",
									value: order.address?.full_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressRow, {
									label: "رقم الهاتف",
									value: order.address?.phone,
									mono: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressRow, {
									label: "المحافظة",
									value: order.address?.city
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressRow, {
									label: "المنطقة / القضاء",
									value: order.address?.area
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressRow, {
									label: "الشارع / تفاصيل",
									value: order.address?.street
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressRow, {
									label: "ملاحظات إضافية",
									value: order.address?.notes,
									muted: true
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card rounded-2xl border border-border p-4 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "المجموع الفرعي"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatIQD(order.subtotal_iqd) })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "التوصيل"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatIQD(order.shipping_iqd) })]
							}),
							Number(order.points_used ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: [
										"خصم نقاط (",
										order.points_used,
										")"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-success",
									children: ["- ", formatIQD(Math.max(0, Number(order.subtotal_iqd ?? 0) + Number(order.shipping_iqd ?? 0) - Number(order.total_iqd ?? 0)))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-border mt-2 pt-3 flex justify-between items-baseline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: "الإجمالي"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xl font-black text-navy",
									children: formatIQD(order.total_iqd)
								})]
							}),
							Number(order.points_earned ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 text-xs text-gold font-bold",
								children: [
									"🎉 كسبت ",
									order.points_earned,
									" نقطة من هذا الطلب"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center text-xs text-muted-foreground",
						children: [
							"تم الطلب في ",
							formatArabicDate(order.created_at),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"الحالة: ",
							statusLabel(order.status)
						]
					}),
					canCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: handleCancel,
						disabled: cancelling,
						className: "w-full h-12 rounded-2xl border-2 border-destructive text-destructive font-black flex items-center justify-center gap-2 hover:bg-destructive/10 disabled:opacity-50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-5" }), cancelling ? "جاري الإلغاء..." : "إلغاء الطلب"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintableInvoice, {
				order,
				items,
				customer,
				domId: "invoice-print-target"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoicePreviewDialog, {
				order,
				items,
				customer,
				open: previewOpen,
				onOpenChange: setPreviewOpen,
				domId: "invoice-preview-target"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: replaceOpen,
				onOpenChange: setReplaceOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					dir: "rtl",
					className: "max-w-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, {
							className: "items-center sm:items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-12 rounded-full bg-gold/15 grid place-items-center mb-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, { className: "size-6 text-gold" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
									className: "text-base sm:text-lg",
									children: replaceDone ? "تم استلام طلب الاستبدال" : "طلب استبدال"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
									className: "text-center leading-relaxed",
									children: replaceDone ? "سوف يتواصل معك قسم متابعة الاستبدال لمعرفة أسباب الخلل خلال 72 ساعة. نأسف على تأخر الرد بسبب الضغط." : "اكتب سبب طلب الاستبدال أو الخلل في المنتج، وسيتواصل معك قسم المتابعة خلال 72 ساعة."
								})
							]
						}),
						!replaceDone && replaceItem && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted-foreground text-center",
								children: ["المنتج: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-navy",
									children: replaceItem.name_ar
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: replaceReason,
								onChange: (e) => setReplaceReason(e.target.value),
								placeholder: "اذكر سبب الاستبدال بالتفصيل...",
								rows: 4,
								maxLength: 500,
								className: "w-full rounded-xl border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gold/40 resize-none",
								dir: "rtl"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogFooter, { children: replaceDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col-reverse gap-2 w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
								className: "w-full",
								children: "حسناً"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/replacements",
								className: "w-full h-10 rounded-xl bg-gradient-gold text-navy font-bold shadow-gold hover:brightness-105 flex items-center justify-center",
								children: "عرض طلبات الاستبدال"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col-reverse gap-2 w-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
								className: "w-full mt-0",
								children: "إلغاء"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: submitReplace,
								disabled: replaceSubmitting,
								className: "w-full h-10 rounded-xl bg-gradient-gold text-navy font-bold shadow-gold hover:brightness-105 disabled:opacity-50",
								children: replaceSubmitting ? "جاري الإرسال..." : "إرسال طلب الاستبدال"
							})]
						}) })
					]
				})
			})
		]
	});
}
//#endregion
export { OrderDetail as component };
