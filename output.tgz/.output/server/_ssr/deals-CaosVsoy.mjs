import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Tt as ChevronLeft, p as Timer } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { c as dealsQuery } from "./queries-CNdOTkej.mjs";
import { r as useStorefrontFilters, t as applyStorefrontFilters } from "./storefront-filters-DpSWbFTB.mjs";
import { n as ProductCard, t as FilterBar } from "./filter-bar-DjQwTwqA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/deals-CaosVsoy.js
var import_jsx_runtime = require_jsx_runtime();
function DealsPage() {
	const { data: allDeals } = useSuspenseQuery(dealsQuery());
	const { filters } = useStorefrontFilters();
	const deals = applyStorefrontFilters(allDeals, filters);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "عروض لفترة محدودة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-1 text-xs text-muted-foreground mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-3.5 rotate-180" }), " الرئيسية"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 mb-4 p-3 rounded-2xl bg-gold/10 border border-gold/30",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-10 rounded-xl bg-gold/20 border border-gold/40 grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-5 text-gold" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-base font-extrabold leading-tight",
							children: "عروض لفترة محدودة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground",
							children: "أسعار خاصة لفترة قصيرة — سارع قبل انتهاء العرض"
						})]
					})]
				}),
				deals.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center text-muted-foreground text-sm py-16",
					children: "لا توجد عروض حالياً. تابعنا لاحقاً!"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 pb-8",
					children: deals.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				})
			]
		})
	});
}
//#endregion
export { DealsPage as component };
