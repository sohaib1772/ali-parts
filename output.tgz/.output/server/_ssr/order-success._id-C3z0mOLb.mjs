import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { St as CircleCheck, z as Package } from "../_libs/lucide-react.mjs";
import { d as orderByIdQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD } from "./format-CTK49jpu.mjs";
import { t as Route } from "./order-success._id-BBh3k7J8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-success._id-C3z0mOLb.js
var import_jsx_runtime = require_jsx_runtime();
function OrderSuccess() {
	const { id } = Route.useParams();
	const { data } = useSuspenseQuery(orderByIdQuery(id));
	const { order } = data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-gradient-hero text-primary-foreground flex flex-col",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-md px-6 pt-16 pb-8 flex-1 flex flex-col items-center text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-24 rounded-full bg-gradient-gold text-navy grid place-items-center shadow-gold mb-6 animate-in zoom-in duration-500",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
						className: "size-14",
						strokeWidth: 2.5
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-black mb-2",
					children: "شكراً لثقتك بنا!"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-primary-foreground/80 mb-6",
					children: "تم استلام طلبك بنجاح، سنبدأ بتجهيزه فوراً."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full bg-white/10 border border-white/20 rounded-2xl p-4 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-gold mb-1",
						children: "رقم الطلب"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-mono font-bold text-lg",
						children: order.order_number
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full bg-white/10 border border-white/20 rounded-2xl p-4 mb-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-gold mb-1",
						children: "الإجمالي"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-black text-2xl text-gold",
						children: formatIQD(order.total_iqd)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/orders/$id",
					params: { id: order.id },
					className: "w-full h-12 rounded-2xl bg-gradient-gold text-navy font-black flex items-center justify-center gap-2 shadow-gold mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-4" }), " تتبع الطلب"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-sm text-gold font-bold",
					children: "العودة للرئيسية"
				})
			]
		})
	});
}
//#endregion
export { OrderSuccess as component };
