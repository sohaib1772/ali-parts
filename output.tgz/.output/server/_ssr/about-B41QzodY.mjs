import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useSetting } from "./admin-DdF3xehS.mjs";
import { Ft as BadgeCheck, It as Award, K as MapPin, S as Shield, _ as Store, a as Users, at as Gem, c as Truck, gt as Clock } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-B41QzodY.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	const storeName = useSetting("store_name", "Ali Parts");
	const aboutText = useSetting("store_about", "متجر متخصص في بيع قطع غيار سيارات شفروليه، GMC، وكاديلاك الأصلية داخل العراق. نلتزم بتوفير قطع عالية الجودة مع خدمة عملاء متميزة وتوصيل سريع.");
	const storeAddress = useSetting("store_address", "");
	const locationLink = useSetting("store_location_link", "");
	const storeFrontImage = useSetting("store_front_image", "");
	const years = useSetting("store_years", "7");
	const items = [
		{
			icon: Shield,
			title: "قطع أصلية 100%",
			desc: "نضمن أصالة كل قطعة نبيعها"
		},
		{
			icon: Truck,
			title: "توصيل سريع",
			desc: "لكل محافظات العراق"
		},
		{
			icon: Award,
			title: "خبرة موثوقة",
			desc: "سنوات في مجال قطع الغيار"
		},
		{
			icon: Users,
			title: "خدمة عملاء 7/24",
			desc: "دائماً بجانبك عبر واتساب"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "من نحن",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 md:max-w-2xl md:mx-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-gradient-hero text-primary-foreground rounded-3xl p-6 shadow-luxe",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-black mb-3",
						children: storeName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-primary-foreground/80 leading-relaxed whitespace-pre-line",
						children: aboutText
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 mt-4",
					children: [
						{
							icon: Clock,
							title: `${years}+ سنوات خبرة`,
							desc: "في سوق قطع غيار السيارات"
						},
						{
							icon: Gem,
							title: "جودة عالية",
							desc: "قطع أصلية ومكافئة للمواصفات"
						},
						{
							icon: BadgeCheck,
							title: "ضمان حقيقي",
							desc: "ضمان على كل قطعة تشريها"
						},
						{
							icon: Store,
							title: "موقع متميز",
							desc: storeAddress || "محلنا جاهز لاستقبالك"
						}
					].map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card rounded-2xl border border-border p-4 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 rounded-xl bg-gold/10 text-gold grid place-items-center mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(it.icon, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold",
								children: it.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: it.desc
							})
						]
					}, it.title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-bold mb-2 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { className: "size-4 text-gold" }), " واجهة المحل"]
					}), storeFrontImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-3xl overflow-hidden border border-border shadow-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: storeFrontImage,
							alt: "واجهة المحل",
							className: "w-full aspect-video object-cover"
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-3xl border border-dashed border-border bg-muted h-40 grid place-items-center text-muted-foreground text-sm",
						children: "لم يتم إضافة صورة واجهة المحل بعد"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 bg-card rounded-2xl border border-border p-4 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 rounded-xl bg-gold/10 text-gold grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold",
								children: "موقع المحل"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground mb-3",
							children: storeAddress || "—"
						}),
						locationLink && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: locationLink,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "inline-flex items-center gap-1 bg-navy text-primary-foreground text-xs font-bold px-4 py-2 rounded-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }), " فتح الموقع على الخريطة"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 mt-4",
					children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card rounded-2xl border border-border p-4 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 rounded-xl bg-gold/10 text-gold grid place-items-center mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(it.icon, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold",
								children: it.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: it.desc
							})
						]
					}, it.title))
				})
			]
		})
	});
}
//#endregion
export { AboutPage as component };
