//#region node_modules/.nitro/vite/services/ssr/assets/external-api-D6j_ceOa.js
var HEADER_NAME_RE = /^[A-Za-z0-9!#$%&'*+.^_`|~-]+$/;
var PATH_RE = /^\/[A-Za-z0-9\-._~!$&'()*+,;=:@/%?{}=&]*$/;
var METHODS = [
	"GET",
	"POST",
	"PUT",
	"DELETE",
	"PATCH"
];
function validateExternalApiConfig(cfg) {
	const errors = [];
	const baseUrl = cfg.baseUrl.trim();
	if (!baseUrl) errors.push({
		field: "baseUrl",
		message: "Base URL مطلوب"
	});
	else try {
		const u = new URL(baseUrl);
		if (u.protocol !== "https:" && u.protocol !== "http:") errors.push({
			field: "baseUrl",
			message: "Base URL يجب أن يبدأ بـ http أو https"
		});
		if (u.protocol === "http:" && u.hostname !== "localhost" && u.hostname !== "127.0.0.1") errors.push({
			field: "baseUrl",
			message: "استخدم https للأمان (http مسموح فقط لـ localhost)"
		});
	} catch {
		errors.push({
			field: "baseUrl",
			message: "صيغة Base URL غير صحيحة"
		});
	}
	const header = cfg.keyHeader.trim();
	if (!header) errors.push({
		field: "keyHeader",
		message: "اسم Header مطلوب"
	});
	else if (!HEADER_NAME_RE.test(header)) errors.push({
		field: "keyHeader",
		message: "اسم Header يحتوي رموزًا غير مسموحة"
	});
	else if (header.length > 128) errors.push({
		field: "keyHeader",
		message: "اسم Header طويل جداً"
	});
	const key = cfg.apiKey.trim();
	if (!key) errors.push({
		field: "apiKey",
		message: "مفتاح API مطلوب"
	});
	else if (key.length < 8) errors.push({
		field: "apiKey",
		message: "مفتاح API قصير جداً (٨ أحرف على الأقل)"
	});
	else if (key.length > 4096) errors.push({
		field: "apiKey",
		message: "مفتاح API طويل جداً"
	});
	else if (/\s/.test(key)) errors.push({
		field: "apiKey",
		message: "مفتاح API يحتوي على مسافات"
	});
	const seenIds = /* @__PURE__ */ new Set();
	const seenSigs = /* @__PURE__ */ new Set();
	cfg.endpoints.forEach((ep, i) => {
		const scope = `endpoints[${i}]`;
		if (!ep.id || seenIds.has(ep.id)) errors.push({
			field: `${scope}.id`,
			message: "معرّف endpoint مكرر"
		});
		else seenIds.add(ep.id);
		const name = (ep.name || "").trim();
		if (!name) errors.push({
			field: `${scope}.name`,
			message: `الاسم مطلوب (endpoint #${i + 1})`
		});
		else if (name.length > 60) errors.push({
			field: `${scope}.name`,
			message: `الاسم طويل جداً (endpoint #${i + 1})`
		});
		if (!METHODS.includes(ep.method)) errors.push({
			field: `${scope}.method`,
			message: `Method غير صالح (endpoint #${i + 1})`
		});
		const path = (ep.path || "").trim();
		if (!path) errors.push({
			field: `${scope}.path`,
			message: `المسار مطلوب (endpoint #${i + 1})`
		});
		else if (!path.startsWith("/")) errors.push({
			field: `${scope}.path`,
			message: `المسار يجب أن يبدأ بـ / (endpoint #${i + 1})`
		});
		else if (path.length > 500) errors.push({
			field: `${scope}.path`,
			message: `المسار طويل جداً (endpoint #${i + 1})`
		});
		else if (!PATH_RE.test(path)) errors.push({
			field: `${scope}.path`,
			message: `المسار يحتوي رموزًا غير صالحة (endpoint #${i + 1})`
		});
		const sig = `${ep.method} ${path}`;
		if (path && seenSigs.has(sig)) errors.push({
			field: `${scope}.path`,
			message: `Endpoint مكرر: ${sig}`
		});
		else if (path) seenSigs.add(sig);
	});
	if (cfg.endpoints.length > 50) errors.push({
		field: "endpoints",
		message: "الحد الأقصى ٥٠ endpoint"
	});
	return errors;
}
var EXTERNAL_API_SETTING_KEYS = {
	baseUrl: "external_api_base_url",
	keyHeader: "external_api_key_header",
	apiKey: "external_api_key",
	endpoints: "external_api_endpoints"
};
function parseExternalApiConfig(settings) {
	let endpoints = [];
	try {
		const parsed = JSON.parse(settings[EXTERNAL_API_SETTING_KEYS.endpoints] || "[]");
		if (Array.isArray(parsed)) endpoints = parsed;
	} catch {
		endpoints = [];
	}
	return {
		baseUrl: settings[EXTERNAL_API_SETTING_KEYS.baseUrl] || "",
		keyHeader: settings[EXTERNAL_API_SETTING_KEYS.keyHeader] || "Authorization",
		apiKey: settings[EXTERNAL_API_SETTING_KEYS.apiKey] || "",
		endpoints
	};
}
//#endregion
export { parseExternalApiConfig as n, validateExternalApiConfig as r, EXTERNAL_API_SETTING_KEYS as t };
