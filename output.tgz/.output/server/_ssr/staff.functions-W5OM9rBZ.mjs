import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { n as requireAdminOtp } from "./require-admin-otp-DgUpC_62.mjs";
import { a as objectType, o as stringType, r as literalType, t as booleanType } from "../_libs/zod.mjs";
import { n as phoneToEmail, t as normalizePhone } from "./phone-auth-C0NmdShV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/staff.functions-W5OM9rBZ.js
async function assertAdmin(ctx) {
	const { data, error } = await ctx.supabase.rpc("has_role", {
		_user_id: ctx.userId,
		_role: "admin"
	});
	if (error || !data) throw new Error("Forbidden");
}
var CreateInput = objectType({
	phone: stringType().trim().min(1).max(20),
	password: stringType().min(6).max(72),
	full_name: stringType().trim().min(1).max(100),
	can_orders: booleanType().default(false),
	can_products: booleanType().default(false),
	can_replacements: booleanType().default(false),
	can_block: booleanType().default(false)
});
var UpdateInput = objectType({
	user_id: stringType().uuid(),
	full_name: stringType().trim().min(1).max(100).optional(),
	password: stringType().min(6).max(72).optional().or(literalType("").transform(() => void 0)),
	can_orders: booleanType().optional(),
	can_products: booleanType().optional(),
	can_replacements: booleanType().optional(),
	can_block: booleanType().optional()
});
var IdInput = objectType({ user_id: stringType().uuid() });
var createStaff_createServerFn_handler = createServerRpc({
	id: "ce0a7596eda4f8af2410edf3c2a1dc6998869fc66949677095980a93f4f36224",
	name: "createStaff",
	filename: "src/lib/staff.functions.ts"
}, (opts) => createStaff.__executeServer(opts));
var createStaff = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => CreateInput.parse(d)).handler(createStaff_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const normalized = normalizePhone(data.phone);
	if (!normalized) throw new Error("رقم الهاتف غير صحيح — مثال: 07XX XXX XXXX");
	const email = phoneToEmail(normalized);
	const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
		email,
		password: data.password,
		email_confirm: true,
		user_metadata: {
			full_name: data.full_name,
			phone: "+" + normalized
		}
	});
	if (createErr || !created?.user) throw new Error(createErr?.message ?? "فشل إنشاء الحساب");
	const userId = created.user.id;
	await supabaseAdmin.from("profiles").upsert({
		id: userId,
		full_name: data.full_name
	}, { onConflict: "id" });
	const { error: permErr } = await supabaseAdmin.from("staff_permissions").insert({
		user_id: userId,
		full_name: data.full_name,
		can_orders: data.can_orders,
		can_products: data.can_products,
		can_replacements: data.can_replacements,
		can_block: data.can_block
	});
	if (permErr) {
		await supabaseAdmin.auth.admin.deleteUser(userId).catch(() => {});
		throw new Error(permErr.message);
	}
	return {
		ok: true,
		user_id: userId
	};
});
var updateStaff_createServerFn_handler = createServerRpc({
	id: "ebebbf17c1cd8b4c15de47bc9272ddf865e3cb26202367c75e382b3cb1f9918a",
	name: "updateStaff",
	filename: "src/lib/staff.functions.ts"
}, (opts) => updateStaff.__executeServer(opts));
var updateStaff = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => UpdateInput.parse(d)).handler(updateStaff_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	if (data.password) {
		const { error } = await supabaseAdmin.auth.admin.updateUserById(data.user_id, { password: data.password });
		if (error) throw new Error(error.message);
	}
	const patch = {};
	if (data.full_name !== void 0) patch.full_name = data.full_name;
	if (data.can_orders !== void 0) patch.can_orders = data.can_orders;
	if (data.can_products !== void 0) patch.can_products = data.can_products;
	if (data.can_replacements !== void 0) patch.can_replacements = data.can_replacements;
	if (data.can_block !== void 0) patch.can_block = data.can_block;
	if (Object.keys(patch).length > 0) {
		const { error } = await supabaseAdmin.from("staff_permissions").update(patch).eq("user_id", data.user_id);
		if (error) throw new Error(error.message);
		if (data.full_name !== void 0) await supabaseAdmin.from("profiles").update({ full_name: data.full_name }).eq("id", data.user_id);
	}
	return { ok: true };
});
var deleteStaff_createServerFn_handler = createServerRpc({
	id: "a378f291c8f7c7a43a7fa2bdf4564adccf7089e2734323ad3067a50c0680b3a3",
	name: "deleteStaff",
	filename: "src/lib/staff.functions.ts"
}, (opts) => deleteStaff.__executeServer(opts));
var deleteStaff = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => IdInput.parse(d)).handler(deleteStaff_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	if (data.user_id === context.userId) throw new Error("لا يمكنك حذف حسابك.");
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	await supabaseAdmin.from("staff_permissions").delete().eq("user_id", data.user_id);
	const { error } = await supabaseAdmin.auth.admin.deleteUser(data.user_id);
	if (error) throw new Error(error.message);
	return { ok: true };
});
function phoneFromEmail(email) {
	if (!email) return null;
	const m = email.match(/^p(\d+)@aliparts\.(app|local)$/);
	if (!m) return null;
	const n = m[1];
	if (n.length === 12 && n.startsWith("9647")) return n;
	return null;
}
var listStaff_createServerFn_handler = createServerRpc({
	id: "9578f35c0a244bf95606fdaac6fc342dde46ab59add0f88b90c0327138436385",
	name: "listStaff",
	filename: "src/lib/staff.functions.ts"
}, (opts) => listStaff.__executeServer(opts));
var listStaff = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listStaff_createServerFn_handler, async ({ context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { data: staff, error } = await supabaseAdmin.from("staff_permissions").select("user_id, full_name, can_orders, can_products, can_replacements, can_block, created_at").order("created_at", { ascending: false });
	if (error) throw new Error(error.message);
	const rows = staff ?? [];
	if (rows.length === 0) return { staff: [] };
	const phoneMap = /* @__PURE__ */ new Map();
	for (let page = 1; page <= 20; page++) {
		const { data, error: e } = await supabaseAdmin.auth.admin.listUsers({
			page,
			perPage: 200
		});
		if (e) break;
		for (const u of data?.users ?? []) {
			const fromMeta = u.user_metadata?.phone?.replace(/^\+/, "");
			phoneMap.set(u.id, fromMeta ?? phoneFromEmail(u.email) ?? null);
		}
		if ((data?.users ?? []).length < 200) break;
	}
	return { staff: rows.map((r) => ({
		user_id: r.user_id,
		full_name: r.full_name,
		phone: phoneMap.get(r.user_id) ?? null,
		can_orders: r.can_orders,
		can_products: r.can_products,
		can_replacements: r.can_replacements,
		can_block: r.can_block,
		created_at: r.created_at
	})) };
});
//#endregion
export { createStaff_createServerFn_handler, deleteStaff_createServerFn_handler, listStaff_createServerFn_handler, updateStaff_createServerFn_handler };
