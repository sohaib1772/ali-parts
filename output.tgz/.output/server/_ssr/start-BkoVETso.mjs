import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { n as createStart, t as createMiddleware } from "./createStart-Dt05N14y.mjs";
import { t as renderErrorPage } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/start-BkoVETso.js
var attachSupabaseAuth = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { data } = await supabase.auth.getSession();
	const token = data.session?.access_token;
	return next({ headers: token ? { Authorization: `Bearer ${token}` } : {} });
});
/**
* Global client function-middleware: attach the admin device id to every serverFn RPC as the
* `x-admin-device-id` header. It reuses the exact value the OTP flow stores in localStorage
* (`admin_device_id`, written by getAdminDeviceId in the admin route), so the server can
* verify the caller's OTP session for that device (see requireAdminOtp / admin_otp_verified).
*
* Registered in src/start.ts alongside attachSupabaseAuth. Client-only (no server imports).
*/
var attachAdminDeviceId = createMiddleware({ type: "function" }).client(async ({ next }) => {
	let deviceId = "";
	try {
		if (typeof window !== "undefined") deviceId = window.localStorage.getItem("admin_device_id") ?? "";
	} catch {}
	return next({ headers: deviceId ? { "x-admin-device-id": deviceId } : {} });
});
var errorMiddleware = createMiddleware().server(async ({ next }) => {
	try {
		return await next();
	} catch (error) {
		if (error != null && typeof error === "object" && "statusCode" in error) throw error;
		console.error(error);
		return new Response(renderErrorPage(), {
			status: 500,
			headers: { "content-type": "text/html; charset=utf-8" }
		});
	}
});
var startInstance = createStart(() => ({
	functionMiddleware: [attachSupabaseAuth, attachAdminDeviceId],
	requestMiddleware: [errorMiddleware]
}));
//#endregion
export { startInstance };
