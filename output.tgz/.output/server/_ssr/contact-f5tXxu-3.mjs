import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useSetting } from "./admin-DdF3xehS.mjs";
import { I as Phone, K as MapPin } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { o as formatIraqiWhatsAppNumber, s as whatsappLink, t as WHATSAPP_NUMBER } from "./format-CTK49jpu.mjs";
import { t as WhatsappIcon } from "./icons-kUk6pI7L.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-f5tXxu-3.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	const address = useSetting("store_address", "بغداد، العراق");
	const waNumber = formatIraqiWhatsAppNumber(useSetting("whatsapp_number", WHATSAPP_NUMBER));
	const phoneNumber = formatIraqiWhatsAppNumber(useSetting("phone_number", "") || waNumber);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "اتصل بنا",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 space-y-3 md:max-w-2xl md:mx-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: whatsappLink("مرحباً", waNumber),
					target: "_blank",
					rel: "noreferrer",
					className: "flex items-center gap-3 bg-card rounded-2xl border border-border p-4 shadow-card hover:shadow-luxe transition",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-12 rounded-xl bg-whatsapp/10 text-whatsapp grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappIcon, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold",
						children: "واتساب"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground",
						dir: "ltr",
						children: ["+", waNumber]
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `tel:+${phoneNumber}`,
					className: "flex items-center gap-3 bg-card rounded-2xl border border-border p-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-12 rounded-xl bg-gold/10 text-gold grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold",
						children: "اتصال هاتفي"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground",
						dir: "ltr",
						children: ["+", phoneNumber]
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 bg-card rounded-2xl border border-border p-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-12 rounded-xl bg-navy/10 text-navy grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold",
						children: "الموقع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: address
					})] })]
				})
			]
		})
	});
}
//#endregion
export { ContactPage as component };
