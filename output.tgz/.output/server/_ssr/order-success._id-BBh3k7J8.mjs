import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as orderByIdQuery } from "./queries-CNdOTkej.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-success._id-BBh3k7J8.js
var $$splitComponentImporter = () => import("./order-success._id-C3z0mOLb.mjs");
var Route = createFileRoute("/order-success/$id")({
	ssr: false,
	loader: ({ context, params }) => context.queryClient.ensureQueryData(orderByIdQuery(params.id)),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
