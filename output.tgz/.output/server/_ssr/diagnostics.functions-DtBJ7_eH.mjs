import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import { n as requireAdminOtp } from "./require-admin-otp-DgUpC_62.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/diagnostics.functions-DtBJ7_eH.js
var runDiagnostics_createServerFn_handler = createServerRpc({
	id: "ed83d164a000008d15ac777f49b39247f1ec8df8ace47eb0795109e67db92d76",
	name: "runDiagnostics",
	filename: "src/lib/diagnostics.functions.ts"
}, (opts) => runDiagnostics.__executeServer(opts));
var runDiagnostics = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(runDiagnostics_createServerFn_handler, async ({ context }) => {
	const { data: isAdmin } = await context.supabase.rpc("has_role", {
		_user_id: context.userId,
		_role: "admin"
	});
	if (!isAdmin) throw new Error("Forbidden");
	await requireAdminOtp(context);
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const auth = [];
	const rls = [];
	const notifs = [];
	const storage = [];
	try {
		const { data, error } = await supabaseAdmin.auth.admin.listUsers({
			page: 1,
			perPage: 1
		});
		if (error) throw error;
		auth.push({
			id: "auth-admin",
			label: "خدمة المصادقة (Auth API)",
			status: "ok",
			detail: `متصلة — عدد المستخدمين متاح للاستعلام${data?.users ? ` (عيّنة: ${data.users.length})` : ""}.`
		});
	} catch (e) {
		auth.push({
			id: "auth-admin",
			label: "خدمة المصادقة (Auth API)",
			status: "fail",
			detail: e?.message || "فشل الاتصال بـ Auth API"
		});
	}
	try {
		const { count } = await supabaseAdmin.from("user_roles").select("user_id", {
			count: "exact",
			head: true
		}).eq("role", "admin");
		const c = count ?? 0;
		auth.push({
			id: "auth-admins",
			label: "عدد المدراء",
			status: c > 0 ? "ok" : "warn",
			detail: c > 0 ? `${c} مدير مسجّل.` : "لا يوجد أي مستخدم بدور admin — لن يستطيع أحد إدارة اللوحة."
		});
	} catch (e) {
		auth.push({
			id: "auth-admins",
			label: "عدد المدراء",
			status: "fail",
			detail: e?.message || "تعذّر القراءة"
		});
	}
	const criticalTables = [
		"profiles",
		"orders",
		"order_items",
		"cart_items",
		"favorites",
		"notifications",
		"banner_comments",
		"banner_likes",
		"user_roles",
		"user_block_log",
		"addresses",
		"products",
		"banners"
	];
	try {
		const { data, error } = await supabaseAdmin.from("pg_tables").select("tablename, rowsecurity").eq("schemaname", "public");
		if (error) throw error;
		const map = /* @__PURE__ */ new Map();
		data.forEach((r) => map.set(r.tablename, !!r.rowsecurity));
		const missing = criticalTables.filter((t) => map.has(t) && !map.get(t));
		const unknown = criticalTables.filter((t) => !map.has(t));
		rls.push({
			id: "rls-enabled",
			label: "تفعيل RLS على الجداول الحساسة",
			status: missing.length === 0 ? "ok" : "fail",
			detail: missing.length === 0 ? `RLS مفعّل على ${criticalTables.length - unknown.length} جدول.` : `RLS غير مفعّل على: ${missing.join(", ")}`
		});
	} catch (e) {
		rls.push({
			id: "rls-enabled",
			label: "تفعيل RLS على الجداول الحساسة",
			status: "warn",
			detail: "تعذّر قراءة pg_tables عبر Data API — اعتبر أن RLS مفعّل على جداول الإنتاج (تحقّق يدوي)."
		});
	}
	try {
		const { count: total } = await supabaseAdmin.from("notifications").select("id", {
			count: "exact",
			head: true
		});
		const since = (/* @__PURE__ */ new Date(Date.now() - 168 * 3600 * 1e3)).toISOString();
		const { count: recent } = await supabaseAdmin.from("notifications").select("id", {
			count: "exact",
			head: true
		}).gte("created_at", since);
		const { count: unread } = await supabaseAdmin.from("notifications").select("id", {
			count: "exact",
			head: true
		}).is("read_at", null);
		notifs.push({
			id: "notif-total",
			label: "إجمالي الإشعارات المُنشأة",
			status: (total ?? 0) > 0 ? "ok" : "warn",
			detail: `${total ?? 0} إشعار في قاعدة البيانات، ${recent ?? 0} خلال آخر 7 أيام.`
		});
		notifs.push({
			id: "notif-unread",
			label: "الإشعارات غير المقروءة",
			status: "ok",
			detail: `${unread ?? 0} إشعار غير مقروء حالياً.`
		});
		const { count: logCount } = await supabaseAdmin.from("user_block_log").select("id", {
			count: "exact",
			head: true
		});
		const { count: statusNotifs } = await supabaseAdmin.from("notifications").select("id", {
			count: "exact",
			head: true
		}).eq("type", "account_status");
		const lc = logCount ?? 0;
		const sn = statusNotifs ?? 0;
		notifs.push({
			id: "notif-block-match",
			label: "تطابق إشعارات الحظر مع السجل",
			status: lc === 0 ? "ok" : sn >= lc ? "ok" : "warn",
			detail: lc === 0 ? "لا يوجد عمليات حظر بعد." : `${sn}/${lc} من عمليات الحظر/رفع الحظر رافقها إشعار للزبون.`
		});
	} catch (e) {
		notifs.push({
			id: "notif-total",
			label: "قراءة جدول الإشعارات",
			status: "fail",
			detail: e?.message || "فشل القراءة"
		});
	}
	notifs.push({
		id: "notif-transport",
		label: "نموذج التسليم",
		status: "ok",
		detail: "الإشعارات تُخزَّن في جدول notifications ويقرأها التطبيق عبر Realtime + استعلام حي (بدون Push خارجي)."
	});
	try {
		const { data, error } = await supabaseAdmin.storage.listBuckets();
		if (error) throw error;
		const names = (data || []).map((b) => b.name);
		const missing = ["product-images", "avatars"].filter((n) => !names.includes(n));
		storage.push({
			id: "storage-buckets",
			label: "خزانات الملفات",
			status: missing.length === 0 ? "ok" : "warn",
			detail: missing.length === 0 ? `متوفّرة: ${names.join(", ")}` : `ناقصة: ${missing.join(", ")}. الموجودة: ${names.join(", ") || "لا شيء"}`
		});
	} catch (e) {
		storage.push({
			id: "storage-buckets",
			label: "خزانات الملفات",
			status: "fail",
			detail: e?.message || "فشل الاتصال بالتخزين"
		});
	}
	const allChecks = [
		...auth,
		...rls,
		...notifs,
		...storage
	];
	const summary = {
		ok: allChecks.filter((c) => c.status === "ok").length,
		warn: allChecks.filter((c) => c.status === "warn").length,
		fail: allChecks.filter((c) => c.status === "fail").length
	};
	return {
		ranAt: (/* @__PURE__ */ new Date()).toISOString(),
		summary,
		sections: [
			{
				title: "المصادقة (Authentication)",
				checks: auth
			},
			{
				title: "أمان البيانات (RLS)",
				checks: rls
			},
			{
				title: "الإشعارات (Notifications)",
				checks: notifs
			},
			{
				title: "التخزين (Storage)",
				checks: storage
			}
		]
	};
});
//#endregion
export { runDiagnostics_createServerFn_handler };
