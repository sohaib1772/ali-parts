import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { F as notFound, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as productByIdQuery } from "./queries-CNdOTkej.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._id-Be5MzFca.js
var import_jsx_runtime = require_jsx_runtime();
var $$splitNotFoundComponentImporter = () => import("./product._id-B0hqY12O.mjs");
var $$splitErrorComponentImporter = () => import("./product._id-CsWThkaB.mjs");
var $$splitComponentImporter = () => import("./product._id-UytBMz0y.mjs");
var Route = createFileRoute("/product/$id")({
	loader: async ({ context, params }) => {
		await context.queryClient.ensureQueryData(productByIdQuery(params.id)).catch(() => {
			throw notFound();
		});
	},
	head: ({ params }) => ({ meta: [{ title: `المنتج · Ali Parts` }, {
		name: "description",
		content: `تفاصيل المنتج ${params.id}`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	pendingMs: 400,
	pendingMinMs: 0,
	pendingComponent: ProductPending,
	errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
function ProductPending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-[100dvh] overflow-y-auto overflow-x-hidden bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "w-full aspect-square rounded-3xl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 mt-3",
					children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-16 rounded-xl" }, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-3/4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-1/2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-1/3" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-4 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-full" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-5/6" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-4/6" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-full rounded-2xl mt-4" })
					]
				})
			]
		})
	});
}
//#endregion
export { Route as t };
