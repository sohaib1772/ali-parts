import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders_._id-BxweEGDk.js
var $$splitComponentImporter = () => import("./orders_._id-6sT1He1M.mjs");
var Route = createFileRoute("/_authenticated/orders_/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
