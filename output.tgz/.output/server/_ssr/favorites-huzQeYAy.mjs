import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { rt as Heart } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { l as favoritesQuery } from "./queries-CNdOTkej.mjs";
import { r as useStorefrontFilters, t as applyStorefrontFilters } from "./storefront-filters-DpSWbFTB.mjs";
import { n as ProductCard, t as FilterBar } from "./filter-bar-DXDobEud.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/favorites-huzQeYAy.js
var import_jsx_runtime = require_jsx_runtime();
function FavoritesPage() {
	const { userId } = useAuth();
	const { data: favs = [] } = useQuery(favoritesQuery(userId));
	const { filters } = useStorefrontFilters();
	const filtered = applyStorefrontFilters(favs.filter((f) => f.product).map((f) => f.product), filters);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "المفضلة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4",
			children: [favs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {})
			}), favs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-20 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-20 rounded-full bg-muted grid place-items-center mx-auto mb-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-10 text-muted-foreground" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold mb-2",
						children: "لا توجد مفضلات بعد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mb-6",
						children: "أضف منتجاتك المفضلة للعودة إليها لاحقاً"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex px-6 py-3 rounded-2xl bg-gradient-gold text-navy font-bold shadow-gold",
						children: "تصفح المنتجات"
					})
				]
			}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-muted-foreground text-sm py-16",
				children: "لا توجد مفضلات مطابقة للفلتر الحالي."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3",
				children: filtered.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
			})]
		})
	});
}
//#endregion
export { FavoritesPage as component };
