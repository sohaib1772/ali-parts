import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { Dt as Check, Et as ChevronDown, K as MapPin, L as Pencil, O as Search, P as Plus, f as Trash2, t as X } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { t as addressesQuery } from "./queries-CNdOTkej.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/addresses-XN4xH3b8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var IRAQ_GOVERNORATES = [
	"بغداد",
	"البصرة",
	"نينوى",
	"أربيل",
	"النجف",
	"كربلاء",
	"بابل",
	"ذي قار",
	"ديالى",
	"الأنبار",
	"صلاح الدين",
	"كركوك",
	"واسط",
	"ميسان",
	"المثنى",
	"القادسية",
	"دهوك",
	"السليمانية",
	"حلبجة"
];
var GOV_ALIASES = {
	"بغداد": ["baghdad", "العاصمة"],
	"البصرة": [
		"basra",
		"basrah",
		"بصرة"
	],
	"نينوى": [
		"nineveh",
		"mosul",
		"الموصل",
		"موصل"
	],
	"أربيل": [
		"erbil",
		"arbil",
		"hawler",
		"اربيل",
		"هولير"
	],
	"النجف": ["najaf", "نجف"],
	"كربلاء": ["karbala"],
	"بابل": [
		"babil",
		"babylon",
		"hilla",
		"الحلة",
		"حلة"
	],
	"ذي قار": [
		"thi qar",
		"dhi qar",
		"ناصرية",
		"الناصرية",
		"ذيقار"
	],
	"ديالى": [
		"diyala",
		"baquba",
		"بعقوبة"
	],
	"الأنبار": [
		"anbar",
		"الرمادي",
		"ramadi",
		"انبار"
	],
	"صلاح الدين": [
		"salah al-din",
		"salahaddin",
		"تكريت",
		"tikrit"
	],
	"كركوك": ["kirkuk"],
	"واسط": [
		"wasit",
		"الكوت",
		"kut"
	],
	"ميسان": [
		"maysan",
		"missan",
		"العمارة",
		"amara"
	],
	"المثنى": [
		"muthanna",
		"السماوة",
		"samawah",
		"مثنى"
	],
	"القادسية": [
		"qadisiyah",
		"diwaniyah",
		"الديوانية",
		"قادسية"
	],
	"دهوك": ["duhok", "dohuk"],
	"السليمانية": [
		"sulaymaniyah",
		"sulaimani",
		"سليمانية"
	],
	"حلبجة": ["halabja"]
};
function normalizeAr(s) {
	return s.toLowerCase().replace(/[\u064B-\u0652\u0670]/g, "").replace(/[إأآا]/g, "ا").replace(/ى/g, "ي").replace(/ؤ/g, "و").replace(/ئ/g, "ي").replace(/ة/g, "ه").replace(/گ/g, "ك").replace(/\s+/g, " ").trim();
}
function useGovernorateFrequency() {
	const [freq, setFreq] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem("gov-frequency");
			if (raw) setFreq(JSON.parse(raw));
		} catch {}
	}, []);
	const bump = (g) => {
		setFreq((prev) => {
			const next = {
				...prev,
				[g]: (prev[g] ?? 0) + 1
			};
			try {
				localStorage.setItem("gov-frequency", JSON.stringify(next));
			} catch {}
			return next;
		});
	};
	return {
		freq,
		bump
	};
}
function GovernoratePicker({ value, onChange }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const { freq, bump } = useGovernorateFrequency();
	const filtered = (0, import_react.useMemo)(() => {
		const s = normalizeAr(q).trim();
		if (!s) return [...IRAQ_GOVERNORATES].sort((a, b) => (freq[b] ?? 0) - (freq[a] ?? 0));
		const score = (g) => {
			const ng = normalizeAr(g);
			const f = freq[g] ?? 0;
			if (ng === s) return 1e3 + f * 10;
			if (ng.startsWith(s)) return 500 + f * 10;
			if (ng.includes(s)) return 300 + f * 10;
			const aliases = GOV_ALIASES[g] ?? [];
			let aliasScore = 0;
			for (const a of aliases) {
				const na = normalizeAr(a);
				if (na === s) aliasScore = Math.max(aliasScore, 200);
				else if (na.startsWith(s)) aliasScore = Math.max(aliasScore, 150);
				else if (na.includes(s)) aliasScore = Math.max(aliasScore, 100);
			}
			return aliasScore ? aliasScore + f * 10 : 0;
		};
		return IRAQ_GOVERNORATES.map((g) => ({
			g,
			s: score(g)
		})).filter((x) => x.s > 0).sort((a, b) => b.s - a.s || a.g.localeCompare(b.g, "ar")).map((x) => x.g);
	}, [q, freq]);
	(0, import_react.useEffect)(() => {
		if (!open) setQ("");
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setOpen(true),
		className: "h-11 w-full px-4 rounded-xl bg-card border border-border text-sm outline-none focus:border-gold flex items-center justify-between text-start",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: value ? "" : "text-muted-foreground",
			children: value || "المحافظة"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 text-muted-foreground" })]
	}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center",
		onClick: () => setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md bg-background rounded-t-3xl sm:rounded-2xl max-h-[80vh] flex flex-col animate-in slide-in-from-bottom",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 p-4 border-b border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold flex-1",
						children: "اختر المحافظة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen(false),
						className: "size-8 rounded-full bg-muted grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-3 border-b border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground absolute top-1/2 -translate-y-1/2 start-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							autoFocus: true,
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "ابحث عن محافظة...",
							className: "h-11 w-full ps-10 pe-4 rounded-xl bg-card border border-border text-sm outline-none focus:border-gold"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto p-2",
					children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-center text-sm text-muted-foreground py-8",
						children: "لا توجد نتائج"
					}) : filtered.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							onChange(g);
							bump(g);
							setOpen(false);
						},
						className: `w-full text-start px-4 py-3 rounded-xl hover:bg-muted transition flex items-center justify-between ${value === g ? "bg-gold/10 text-gold font-bold" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g }), value === g && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })]
					}, g))
				})
			]
		})
	})] });
}
function AddressesPage() {
	const { userId } = useAuth();
	const { data: addresses = [] } = useQuery(addressesQuery(userId));
	const qc = useQueryClient();
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const remove = async (id) => {
		await supabase.from("addresses").delete().eq("id", id);
		toast.success("حُذف العنوان");
		qc.invalidateQueries({ queryKey: ["addresses"] });
	};
	const makeDefault = async (id) => {
		await supabase.from("addresses").update({ is_default: false }).eq("user_id", userId);
		await supabase.from("addresses").update({ is_default: true }).eq("id", id);
		toast.success("تم تعيين العنوان الرئيسي");
		qc.invalidateQueries({ queryKey: ["addresses"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "عناويني",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 space-y-3 md:max-w-2xl md:mx-auto",
			children: [
				addresses.length === 0 && !adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-16 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-20 rounded-full bg-muted grid place-items-center mx-auto mb-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-10 text-muted-foreground" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mb-6",
						children: "لا توجد عناوين محفوظة"
					})]
				}),
				addresses.map((a) => editingId === a.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressForm, {
					onDone: () => setEditingId(null),
					addressId: a.id,
					initial: {
						full_name: a.full_name || "",
						city: a.city || "",
						area: a.area || "",
						street: a.street || "",
						phone: a.phone || "",
						phone2: a.phone2 || ""
					}
				}, a.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-card rounded-2xl border border-border p-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-9 rounded-xl bg-gold/10 text-gold grid place-items-center flex-shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-sm",
										children: a.label ?? "عنوان"
									}), a.is_default && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] px-2 py-0.5 rounded-full bg-gold/20 text-gold font-bold",
										children: "افتراضي"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm mt-1",
									children: [
										a.full_name,
										" · ",
										a.phone,
										a.phone2 ? ` · ${a.phone2}` : ""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: [
										a.city,
										" · ",
										a.area,
										a.street ? ` · ${a.street}` : ""
									]
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 mt-3",
						children: [
							!a.is_default && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => makeDefault(a.id),
								className: "flex-1 h-9 rounded-xl bg-muted text-navy text-xs font-bold flex items-center justify-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), " اجعله افتراضياً"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setEditingId(a.id),
								className: "size-9 rounded-xl bg-gold/10 text-gold grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => remove(a.id),
								className: "size-9 rounded-xl bg-destructive/10 text-destructive grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})
						]
					})]
				}, a.id)),
				adding ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddressForm, { onDone: () => setAdding(false) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setAdding(true),
					className: "w-full h-12 rounded-2xl border-2 border-dashed border-gold text-gold font-bold flex items-center justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " إضافة عنوان جديد"]
				})
			]
		})
	});
}
function AddressForm({ onDone, addressId, initial }) {
	const { userId } = useAuth();
	const qc = useQueryClient();
	const [f, setF] = (0, import_react.useState)(initial ?? {
		full_name: "",
		city: "بغداد",
		area: "",
		street: "",
		phone: "",
		phone2: ""
	});
	const save = async (e) => {
		e.preventDefault();
		if (!userId) return;
		if (addressId) {
			const { error } = await supabase.from("addresses").update(f).eq("id", addressId);
			if (error) return toast.error("تعذّر تحديث العنوان");
			toast.success("تم تحديث العنوان");
		} else {
			const { error } = await supabase.from("addresses").insert({
				...f,
				user_id: userId
			});
			if (error) return toast.error("تعذّر الحفظ");
			toast.success("تمت إضافة العنوان");
		}
		qc.invalidateQueries({ queryKey: ["addresses"] });
		onDone();
	};
	const input = (k, ph, req = true, type = "text") => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		required: req,
		type,
		placeholder: ph,
		value: f[k],
		onChange: (e) => setF({
			...f,
			[k]: e.target.value
		}),
		className: "h-11 w-full px-4 rounded-xl bg-card border border-border text-sm outline-none focus:border-gold"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: save,
		className: "bg-card rounded-2xl border border-border p-4 shadow-card space-y-2",
		children: [
			input("full_name", "الاسم"),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GovernoratePicker, {
				value: f.city,
				onChange: (v) => setF({
					...f,
					city: v
				})
			}),
			input("area", "المنطقة"),
			input("street", "أقرب نقطة دالة", false),
			input("phone", "الرقم الأول", true, "tel"),
			input("phone2", "الرقم الثاني (اختياري)", false, "tel"),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onDone,
					className: "flex-1 h-11 rounded-xl border border-border font-bold text-sm",
					children: "إلغاء"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "flex-1 h-11 rounded-xl bg-gradient-gold text-navy font-bold text-sm shadow-gold",
					children: addressId ? "تحديث" : "حفظ"
				})]
			})
		]
	});
}
//#endregion
export { AddressesPage as component };
