//#region node_modules/.nitro/vite/services/ssr/assets/phone-auth-C0NmdShV.js
/**
* Extract ASCII digits from a string while also converting
* Arabic-Indic (٠-٩) and Persian/Urdu (۰-۹) digits and stripping
* bidi/format control characters that RTL keyboards often inject.
*/
function toAsciiDigits(raw) {
	if (!raw) return "";
	let s = "";
	for (const ch of raw) {
		const c = ch.codePointAt(0);
		if (c >= 1632 && c <= 1641) s += String(c - 1632);
		else if (c >= 1776 && c <= 1785) s += String(c - 1776);
		else if (c >= 48 && c <= 57) s += ch;
	}
	return s;
}
/**
* Normalize an Iraqi mobile number to `964XXXXXXXXXX` (no `+`, 13 digits).
* Accepts input with spaces, dashes, `+`, `00964`, `964`, or a leading `0`,
* and both ASCII and Arabic-Indic digits.
*/
function normalizePhone(raw) {
	const digits = toAsciiDigits(raw ?? "");
	if (!digits) return null;
	let n = digits;
	if (n.startsWith("00964")) n = n.slice(5);
	else if (n.startsWith("964")) n = n.slice(3);
	else if (n.startsWith("0")) n = n.slice(1);
	if (n.length !== 10 || !n.startsWith("7")) return null;
	return "964" + n;
}
function phoneToEmail(phone) {
	return `p${phone}@aliparts.app`;
}
//#endregion
export { phoneToEmail as n, normalizePhone as t };
