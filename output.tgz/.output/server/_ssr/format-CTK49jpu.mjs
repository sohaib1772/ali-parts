//#region node_modules/.nitro/vite/services/ssr/assets/format-CTK49jpu.js
function formatIQD(amount) {
	const n = Number(amount ?? 0);
	if (!isFinite(n)) return "0 د.ع";
	return `${new Intl.NumberFormat("ar-IQ").format(Math.round(n))} د.ع`;
}
/** Iraqi dinar formatted with Latin (ASCII) digits — for invoices/receipts. */
function formatIQDEn(amount) {
	const n = Number(amount ?? 0);
	if (!isFinite(n)) return "0 د.ع";
	return `${new Intl.NumberFormat("en-US").format(Math.round(n))} د.ع`;
}
function formatArabicDate(iso) {
	try {
		return new Intl.DateTimeFormat("ar-IQ", {
			year: "numeric",
			month: "long",
			day: "numeric"
		}).format(new Date(iso));
	} catch {
		return iso;
	}
}
/** Date with Latin digits — used for printable invoices. */
function formatDateEn(iso) {
	try {
		return new Intl.DateTimeFormat("en-GB", {
			year: "numeric",
			month: "2-digit",
			day: "2-digit"
		}).format(new Date(iso));
	} catch {
		return iso;
	}
}
var WHATSAPP_NUMBER = "9647800000000";
/** Normalizes any Iraqi phone number into wa.me format (9647XXXXXXXX). */
function formatIraqiWhatsAppNumber(input) {
	let digits = input.replace(/\D/g, "");
	if (digits.startsWith("00964")) digits = digits.slice(2);
	if (digits.startsWith("964")) return digits;
	if (digits.startsWith("0") && digits.length === 11) return `964${digits.slice(1)}`;
	if (digits.length === 10 && digits.startsWith("7")) return `964${digits}`;
	return digits;
}
function whatsappLink(text, number) {
	const normalized = formatIraqiWhatsAppNumber(number || "9647800000000");
	return `https://wa.me/${/^9647\d{9}$/.test(normalized) ? normalized : formatIraqiWhatsAppNumber(WHATSAPP_NUMBER)}?text=${encodeURIComponent(text)}`;
}
//#endregion
export { formatIQDEn as a, formatIQD as i, formatArabicDate as n, formatIraqiWhatsAppNumber as o, formatDateEn as r, whatsappLink as s, WHATSAPP_NUMBER as t };
