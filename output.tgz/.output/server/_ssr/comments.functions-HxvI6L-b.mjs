import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { a as objectType, o as stringType, t as booleanType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/comments.functions-HxvI6L-b.js
var AddBannerCommentInput = objectType({
	bannerId: stringType().uuid(),
	content: stringType().trim().min(1).max(1e3),
	isAdminReply: booleanType().optional().default(false)
});
var addBannerComment_createServerFn_handler = createServerRpc({
	id: "a65be21a0bec8f5bb59d48e7b826841ece93c7685b2bc55d22658de1de4c9873",
	name: "addBannerComment",
	filename: "src/lib/comments.functions.ts"
}, (opts) => addBannerComment.__executeServer(opts));
var addBannerComment = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => AddBannerCommentInput.parse(data)).handler(addBannerComment_createServerFn_handler, async ({ data, context }) => {
	const content = data.content.trim();
	const { data: banner, error: bannerError } = await context.supabase.from("banners").select("id").eq("id", data.bannerId).eq("is_active", true).maybeSingle();
	if (bannerError) throw new Error(bannerError.message);
	if (!banner) throw new Error("Banner not available");
	const { data: profile, error: profileError } = await context.supabase.from("profiles").select("is_blocked").eq("id", context.userId).maybeSingle();
	if (profileError) throw new Error(profileError.message);
	if (profile?.is_blocked) throw new Error("حسابك محظور من التعليق بسبب مخالفة سابقة.");
	let isAdminReply = false;
	if (data.isAdminReply) {
		const { data: isAdmin, error } = await context.supabase.rpc("has_role", {
			_user_id: context.userId,
			_role: "admin"
		});
		if (error) throw new Error(error.message);
		isAdminReply = !!isAdmin;
	}
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { data: row, error } = await supabaseAdmin.from("banner_comments").insert({
		banner_id: data.bannerId,
		user_id: context.userId,
		content,
		is_admin_reply: isAdminReply
	}).select("*").single();
	if (error) throw new Error(error.message);
	return row;
});
//#endregion
export { addBannerComment_createServerFn_handler };
