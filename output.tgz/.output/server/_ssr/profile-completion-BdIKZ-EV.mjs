import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { I as Phone, X as LoaderCircle, o as User } from "../_libs/lucide-react.mjs";
import { g as profileQuery } from "./queries-CNdOTkej.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as normalizePhone } from "./phone-auth-C0NmdShV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-completion-BdIKZ-EV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Controlled phone-entry dialog. Saves phone (+ optional name) to profiles.
* No verification of any kind. `dismissible=false` makes it a hard gate (checkout).
*/
function ProfileCompletionDialog({ open, onOpenChange, onSaved, dismissible = true }) {
	const { userId, user } = useAuth();
	const { data: profile } = useQuery(profileQuery(userId));
	const qc = useQueryClient();
	const [phone, setPhone] = (0, import_react.useState)("");
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (open) {
			const p = profile;
			const meta = user?.user_metadata ?? {};
			setFullName(p?.full_name || meta.full_name || meta.name || "");
			setPhone(p?.phone ?? "");
		}
	}, [
		open,
		profile,
		user
	]);
	if (!open) return null;
	const save = async () => {
		if (saving) return;
		const normalized = normalizePhone(phone);
		if (!normalized) {
			toast.error("رقم الهاتف غير صحيح — مثال: 07XX XXX XXXX");
			return;
		}
		if (!userId) return;
		setSaving(true);
		const { error } = await supabase.from("profiles").update({
			phone: "+" + normalized,
			full_name: fullName.trim() || null
		}).eq("id", userId);
		if (error) {
			toast.error("تعذّر الحفظ، حاول مرة أخرى");
			setSaving(false);
			return;
		}
		await qc.invalidateQueries({ queryKey: ["profile"] });
		toast.success("تم حفظ رقمك بنجاح");
		setSaving(false);
		onSaved?.();
		onOpenChange(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		dir: "rtl",
		className: "fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm",
		onClick: () => dismissible && onOpenChange(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-[420px] rounded-3xl border border-border bg-card text-card-foreground p-6 shadow-2xl",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center mb-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto mb-3 size-12 rounded-2xl bg-gold/10 grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-6 text-gold" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-extrabold",
							children: "أكمل بياناتك"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground mt-1",
							children: "نحتاج رقم هاتفك للتوصيل فقط — لا يوجد تحقق أو رمز."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4" }),
						placeholder: "الاسم الكامل",
						value: fullName,
						onChange: setFullName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }),
						placeholder: "رقم الهاتف (07XX XXX XXXX)",
						type: "tel",
						value: phone,
						onChange: setPhone
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: save,
					disabled: saving,
					className: "mt-5 w-full h-12 rounded-2xl bg-gradient-gold text-navy font-black shadow-gold hover:brightness-105 transition disabled:opacity-50 flex items-center justify-center gap-2",
					children: [saving && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), "حفظ ومتابعة"]
				}),
				dismissible && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => onOpenChange(false),
					className: "mt-3 w-full text-center text-xs text-muted-foreground hover:text-foreground transition",
					children: "لاحقاً — تصفّح المتجر"
				})
			]
		})
	});
}
/**
* Mounted in the authenticated layout. Two jobs:
*  1) Backfill profiles.full_name from the OAuth metadata. Apple returns the
*     user's name ONLY on the first-ever sign-in (in user_metadata); persist it
*     immediately so it's never lost. Also covers Google.
*  2) Nudge the user to add a phone (dismissible — browsing is never blocked;
*     the hard requirement is enforced at checkout).
*/
function ProfilePhonePrompt() {
	const { userId, user } = useAuth();
	const { data: profile, isLoading } = useQuery(profileQuery(userId));
	const qc = useQueryClient();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [dismissed, setDismissed] = (0, import_react.useState)(false);
	const p = profile;
	const hasPhone = !!(p?.phone && String(p.phone).trim());
	const needsPhone = !!userId && !isLoading && !!p && !hasPhone;
	(0, import_react.useEffect)(() => {
		if (!userId || !p) return;
		const meta = user?.user_metadata ?? {};
		const metaName = (meta.full_name || meta.name || "").trim();
		if (metaName && !(p.full_name && p.full_name.trim())) supabase.from("profiles").update({ full_name: metaName }).eq("id", userId).then(() => qc.invalidateQueries({ queryKey: ["profile"] }));
	}, [
		userId,
		profile,
		user,
		qc
	]);
	(0, import_react.useEffect)(() => {
		if (needsPhone && !dismissed) setOpen(true);
	}, [needsPhone, dismissed]);
	if (!needsPhone) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileCompletionDialog, {
		open,
		onOpenChange: (o) => {
			setOpen(o);
			if (!o) setDismissed(true);
		},
		dismissible: true
	});
}
function Field({ icon, placeholder, value, onChange, type = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 rounded-2xl border border-border bg-muted/40 px-4 py-3 focus-within:border-gold/60 transition",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-gold/80 shrink-0",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			placeholder,
			value,
			onChange: (e) => onChange(e.target.value),
			className: "flex-1 bg-transparent outline-none text-sm placeholder:text-muted-foreground"
		})]
	});
}
//#endregion
export { ProfilePhonePrompt as n, ProfileCompletionDialog as t };
