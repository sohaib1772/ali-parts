import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as productsByCategoryQuery, s as categoriesQuery } from "./queries-CNdOTkej.mjs";
import { n as filterSearchSchema } from "./storefront-filters-DpSWbFTB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category._id-fmK_k3dB.js
var $$splitComponentImporter = () => import("./category._id-H9hNvU4T.mjs");
var Route = createFileRoute("/category/$id")({
	validateSearch: filterSearchSchema,
	loader: ({ context, params }) => {
		context.queryClient.ensureQueryData(productsByCategoryQuery(params.id));
		context.queryClient.ensureQueryData(categoriesQuery());
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
