import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { n as Capacitor, t as proxy } from "../_libs/@aparajita/capacitor-secure-storage+[...].mjs";
import { t as Preferences } from "../_libs/capacitor__preferences.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session-bootstrap-hk3NyGqS.js
function getStorageKey() {
	const url = "https://api.maktabali.com";
	try {
		return `sb-${new URL(url).hostname.split(".")[0]}-auth-token`;
	} catch {
		return null;
	}
}
async function restore() {
	if (typeof window === "undefined") return;
	if (!Capacitor.isNativePlatform()) return;
	const key = getStorageKey();
	if (!key) return;
	try {
		if (window.localStorage.getItem(key)) return;
		let value = null;
		try {
			const v = await proxy.get(key);
			if (typeof v === "string" && v.length > 0) value = v;
		} catch {}
		if (!value) try {
			const legacy = await Preferences.get({ key });
			if (legacy.value) {
				value = legacy.value;
				try {
					await proxy.set(key, value, false, false);
				} catch {}
				try {
					await Preferences.remove({ key });
				} catch {}
			}
		} catch {}
		if (!value) return;
		window.localStorage.setItem(key, value);
		try {
			const parsed = JSON.parse(value);
			if (parsed?.access_token && parsed?.refresh_token) await supabase.auth.setSession({
				access_token: parsed.access_token,
				refresh_token: parsed.refresh_token
			});
		} catch {}
	} catch {}
}
var sessionRestorePromise = restore();
//#endregion
export { sessionRestorePromise as t };
