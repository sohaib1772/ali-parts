import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { M as redirect, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as sessionRestorePromise } from "./session-bootstrap-hk3NyGqS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-C61HYUqK.js
var $$splitComponentImporter = () => import("./route-CRW3OpiI.mjs");
var Route = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		await sessionRestorePromise;
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({ to: "/auth" });
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
