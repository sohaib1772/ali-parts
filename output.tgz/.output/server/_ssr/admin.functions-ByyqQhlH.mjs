import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { k as isRedirect, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as TSS_SERVER_FUNCTION, l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { a as objectType, o as stringType, t as booleanType } from "../_libs/zod.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-ClnZ4wmJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-ByyqQhlH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var CACHE_NAME = "app-videos-v1";
var memoryBlobUrls = /* @__PURE__ */ new Map();
var inflightWarm = /* @__PURE__ */ new Set();
var prefetchQueue = [];
var prefetchRunning = 0;
var MAX_PREFETCH_CONCURRENCY = 1;
var prefetchPaused = false;
/**
* Temporarily pause background prefetching (e.g. while the active video is
* still buffering) so it doesn't compete for bandwidth and cause stutter.
*/
function setPrefetchPaused(paused) {
	prefetchPaused = paused;
	if (!paused) drainPrefetchQueue();
}
function drainPrefetchQueue() {
	if (prefetchPaused) return;
	while (prefetchRunning < MAX_PREFETCH_CONCURRENCY && prefetchQueue.length) {
		const url = prefetchQueue.shift();
		if (memoryBlobUrls.has(url)) {
			inflightWarm.delete(url);
			continue;
		}
		prefetchRunning += 1;
		fetchAndCache(url).finally(() => {
			prefetchRunning -= 1;
			inflightWarm.delete(url);
			drainPrefetchQueue();
		});
	}
}
async function clearVideoCache() {
	let count = 0;
	for (const url of memoryBlobUrls.values()) try {
		URL.revokeObjectURL(url);
	} catch {}
	memoryBlobUrls.clear();
	if (typeof window === "undefined" || !("caches" in window)) return 0;
	try {
		const cache = await caches.open(CACHE_NAME);
		const keys = await cache.keys();
		count = keys.length;
		await Promise.all(keys.map((k) => cache.delete(k)));
		await caches.delete(CACHE_NAME);
	} catch {}
	return count;
}
async function getVideoCacheSize() {
	if (typeof window === "undefined" || !("caches" in window)) return 0;
	try {
		return (await (await caches.open(CACHE_NAME)).keys()).length;
	} catch {
		return 0;
	}
}
async function readCachedBlob(url) {
	if (typeof window === "undefined" || !("caches" in window)) return null;
	try {
		const res = await (await caches.open(CACHE_NAME)).match(url);
		if (!res) return null;
		const blob = await res.blob();
		const objUrl = URL.createObjectURL(blob);
		memoryBlobUrls.set(url, objUrl);
		return objUrl;
	} catch {
		return null;
	}
}
async function fetchAndCache(url) {
	try {
		const cache = await caches.open(CACHE_NAME);
		if (await cache.match(url)) return;
		const res = await fetch(url, {
			mode: "cors",
			credentials: "omit"
		});
		if (!res.ok) return;
		if (Number(res.headers.get("content-length") ?? 0) > 25 * 1024 * 1024) return;
		await cache.put(url, res.clone());
	} catch {}
}
/**
* Eagerly prefetch a video into Cache Storage without waiting for idle time.
* Safe to call multiple times — dedupes against in-flight warms.
*/
function prefetchVideo(url) {
	if (!url) return;
	if (typeof window === "undefined" || !("caches" in window)) return;
	if (memoryBlobUrls.has(url)) return;
	if (inflightWarm.has(url)) return;
	inflightWarm.add(url);
	prefetchQueue.push(url);
	const ric = window.requestIdleCallback;
	if (ric) ric(() => drainPrefetchQueue(), { timeout: 2e3 });
	else window.setTimeout(() => drainPrefetchQueue(), 300);
}
/**
* Attach to an element to prefetch a video when it approaches the viewport.
* Uses IntersectionObserver with a generous rootMargin so the video is
* warmed BEFORE the user scrolls to it — playback starts near-instantly.
*/
function usePrefetchNearbyVideo(url, options) {
	const rootMargin = options?.rootMargin ?? "200% 0px";
	const root = options?.root ?? null;
	const observerRef = (0, import_react.useRef)(null);
	const nodeRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		return () => {
			observerRef.current?.disconnect();
			observerRef.current = null;
		};
	}, []);
	return (node) => {
		if (nodeRef.current === node) return;
		observerRef.current?.disconnect();
		nodeRef.current = node;
		if (!node || !url) return;
		if (typeof window === "undefined" || !("IntersectionObserver" in window)) {
			prefetchVideo(url);
			return;
		}
		const io = new IntersectionObserver((entries) => {
			for (const e of entries) if (e.isIntersecting) {
				prefetchVideo(url);
				io.disconnect();
				observerRef.current = null;
				break;
			}
		}, {
			root,
			rootMargin,
			threshold: 0
		});
		io.observe(node);
		observerRef.current = io;
	};
}
/**
* Smart video URL hook:
* - Returns the network URL immediately so playback starts without delay.
* - If a cached copy exists (from a prior visit), swaps to a local blob URL
*   for instant, offline-friendly playback.
* - Warms the Cache Storage entry silently during idle time so the NEXT visit
*   is instant even on weak connections.
*/
function useCachedVideo(url) {
	const [resolved, setResolved] = (0, import_react.useState)(url ?? null);
	(0, import_react.useEffect)(() => {
		if (!url) {
			setResolved(null);
			return;
		}
		const mem = memoryBlobUrls.get(url);
		if (mem) {
			setResolved(mem);
			return;
		}
		setResolved(url);
		let cancelled = false;
		readCachedBlob(url).then((blob) => {
			if (!cancelled && blob) setResolved(blob);
		});
		return () => {
			cancelled = true;
		};
	}, [url]);
	return resolved;
}
var SetPasswordInput = objectType({
	user_id: stringType().uuid(),
	password: stringType().min(6).max(72)
});
var SetBlockedInput = objectType({
	user_id: stringType().uuid(),
	blocked: booleanType(),
	reason: stringType().trim().max(500).optional()
});
var adminSetUserPassword = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => SetPasswordInput.parse(d)).handler(createSsrRpc("b34af10cfb0cf6e0465afe0ba898bf162e25ef86c235c103c7203e6db0c8ea54"));
var adminSetUserBlocked = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => SetBlockedInput.parse(d)).handler(createSsrRpc("95b6aa2b4978dfa32791d4aec5b5df227e7607e3a64ad55178ad66bc334781df"));
var adminListUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("35cf6cc28f61c798a570ec39672552de8ed250f60706565e25b34a66f0c5b240"));
var moderatorListUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("d6e6d14870d9b01fd5e0c1a5d24a1171cb6e0826067e577a07edc0da371647cf"));
//#endregion
export { clearVideoCache as a, moderatorListUsers as c, usePrefetchNearbyVideo as d, useServerFn as f, adminSetUserPassword as i, setPrefetchPaused as l, adminListUsers as n, createSsrRpc as o, adminSetUserBlocked as r, getVideoCacheSize as s, Textarea as t, useCachedVideo as u };
