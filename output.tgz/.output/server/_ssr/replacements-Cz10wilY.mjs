import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Repeat, Mt as BellRing, Nt as BellOff, O as Search, St as CircleCheck, Tt as ChevronLeft, X as LoaderCircle, gt as Clock, h as ThumbsDown, m as ThumbsUp } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/replacements-Cz10wilY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var VAPID_PUBLIC_KEY = "BERjo3yZ33zhg4Z3N9aGnDXo9gmdlxxIkUMy72o3eWy_zr-VZ8BdxJYyitMH7Rv34_jihJV50H_qIwPvU2aP4ZM";
function urlBase64ToUint8Array(base64String) {
	const base64 = (base64String + "=".repeat((4 - base64String.length % 4) % 4)).replace(/-/g, "+").replace(/_/g, "/");
	const raw = atob(base64);
	const output = new Uint8Array(raw.length);
	for (let i = 0; i < raw.length; i++) output[i] = raw.charCodeAt(i);
	return output;
}
function bufToBase64Url(buf) {
	if (!buf) return "";
	const bytes = new Uint8Array(buf);
	let s = "";
	for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
	return btoa(s).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function isPushSupported() {
	if (typeof window === "undefined") return false;
	return "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
}
async function ensureServiceWorker() {
	if (!isPushSupported()) return null;
	const existing = await navigator.serviceWorker.getRegistration("/sw.js");
	if (existing) return existing;
	return navigator.serviceWorker.register("/sw.js", { scope: "/" });
}
async function getExistingSubscription() {
	const reg = await ensureServiceWorker();
	if (!reg) return null;
	return reg.pushManager.getSubscription();
}
async function subscribeToPush() {
	try {
		if (!isPushSupported()) return {
			ok: false,
			error: "المتصفح لا يدعم الإشعارات"
		};
		if (await Notification.requestPermission() !== "granted") return {
			ok: false,
			error: "لم يتم السماح بالإشعارات"
		};
		const reg = await ensureServiceWorker();
		if (!reg) return {
			ok: false,
			error: "تعذّر تسجيل الـ Service Worker"
		};
		let sub = await reg.pushManager.getSubscription();
		if (!sub) sub = await reg.pushManager.subscribe({
			userVisibleOnly: true,
			applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY).buffer
		});
		const json = sub.toJSON();
		const p256dh = json.keys?.p256dh ?? bufToBase64Url(sub.getKey("p256dh"));
		const auth = json.keys?.auth ?? bufToBase64Url(sub.getKey("auth"));
		if (!json.endpoint || !p256dh || !auth) return {
			ok: false,
			error: "بيانات الاشتراك غير مكتملة"
		};
		const { data: userRes } = await supabase.auth.getUser();
		const userId = userRes.user?.id;
		if (!userId) return {
			ok: false,
			error: "يجب تسجيل الدخول"
		};
		const { error } = await supabase.from("push_subscriptions").upsert({
			user_id: userId,
			endpoint: json.endpoint,
			p256dh,
			auth,
			user_agent: navigator.userAgent.slice(0, 300)
		}, { onConflict: "endpoint" });
		if (error) return {
			ok: false,
			error: error.message
		};
		return { ok: true };
	} catch (e) {
		return {
			ok: false,
			error: e?.message ?? "خطأ غير معروف"
		};
	}
}
async function unsubscribeFromPush() {
	try {
		const sub = await getExistingSubscription();
		if (!sub) return { ok: true };
		const endpoint = sub.endpoint;
		await sub.unsubscribe();
		await supabase.from("push_subscriptions").delete().eq("endpoint", endpoint);
		return { ok: true };
	} catch (e) {
		return {
			ok: false,
			error: e?.message ?? "خطأ غير معروف"
		};
	}
}
function PushOptIn() {
	const [supported, setSupported] = (0, import_react.useState)(true);
	const [enabled, setEnabled] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [permission, setPermission] = (0, import_react.useState)("default");
	(0, import_react.useEffect)(() => {
		if (!isPushSupported()) {
			setSupported(false);
			return;
		}
		setPermission(Notification.permission);
		(async () => {
			const sub = await getExistingSubscription();
			setEnabled(!!sub);
		})();
	}, []);
	if (!supported) return null;
	const toggle = async () => {
		setBusy(true);
		try {
			if (enabled) {
				const res = await unsubscribeFromPush();
				if (!res.ok) toast.error(res.error ?? "تعذّر إيقاف الإشعارات");
				else {
					toast.success("تم إيقاف إشعارات الاستبدال");
					setEnabled(false);
				}
			} else {
				const res = await subscribeToPush();
				if (!res.ok) toast.error(res.error ?? "تعذّر تفعيل الإشعارات");
				else {
					toast.success("تم تفعيل إشعارات الاستبدال");
					setEnabled(true);
					setPermission(Notification.permission);
				}
			}
		} finally {
			setBusy(false);
		}
	};
	const blocked = permission === "denied";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-card border border-border rounded-2xl p-3 flex items-center gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `size-10 rounded-full grid place-items-center ${enabled ? "bg-emerald-100 text-emerald-700" : "bg-muted text-muted-foreground"}`,
				children: enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellRing, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellOff, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-bold text-navy",
					children: "إشعارات تحديث الاستبدال"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] text-muted-foreground line-clamp-2",
					children: blocked ? "تم منع الإشعارات من إعدادات المتصفح. فعّلها يدويًا لتلقّي التحديثات." : enabled ? "ستصلك رسالة عند كل تغيير في حالة طلبك." : "فعّل الإشعارات لتصلك تحديثات حالة طلب الاستبدال فورًا."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: toggle,
				disabled: busy || blocked,
				className: `h-9 px-3 rounded-full text-xs font-bold border ${enabled ? "border-border hover:bg-muted" : "bg-navy text-primary-foreground border-navy hover:bg-navy/90"} disabled:opacity-50`,
				children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : enabled ? "إيقاف" : "تفعيل"
			})
		]
	});
}
var STATUS_META = {
	pending: {
		label: "بانتظار المراجعة",
		icon: Clock,
		chip: "bg-amber-100 text-amber-800 border-amber-300"
	},
	in_review: {
		label: "قيد المراجعة",
		icon: Search,
		chip: "bg-blue-100 text-blue-800 border-blue-300"
	},
	approved: {
		label: "مقبول",
		icon: ThumbsUp,
		chip: "bg-emerald-100 text-emerald-800 border-emerald-300"
	},
	rejected: {
		label: "مرفوض",
		icon: ThumbsDown,
		chip: "bg-rose-100 text-rose-800 border-rose-300"
	},
	resolved: {
		label: "منجز",
		icon: CircleCheck,
		chip: "bg-navy text-primary-foreground border-navy"
	}
};
function ReplacementsList() {
	const { userId } = useAuth();
	const { data: rows = [], isLoading } = useQuery({
		queryKey: ["my-replacements", userId],
		enabled: !!userId,
		queryFn: async () => {
			const { data, error } = await supabase.from("replacement_requests").select("id, product_name_ar, status, created_at, reason").eq("user_id", userId).order("created_at", { ascending: false });
			if (error) throw error;
			return data ?? [];
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "طلبات الاستبدال",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 space-y-3 md:max-w-3xl md:mx-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PushOptIn, {}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "py-12 text-center text-muted-foreground text-sm",
				children: "جاري التحميل..."
			}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-20 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-20 rounded-full bg-muted grid place-items-center mx-auto mb-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-10 text-muted-foreground" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold mb-2",
						children: "لا توجد طلبات استبدال"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "يمكنك طلب استبدال من صفحة تفاصيل الطلب بعد التسليم"
					})
				]
			}) : rows.map((r) => {
				const meta = STATUS_META[r.status];
				const Icon = meta?.icon ?? Repeat;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/replacements/$id",
					params: { id: r.id },
					className: "block bg-card rounded-2xl border border-border p-4 shadow-card hover:shadow-luxe transition",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[10px] font-mono text-muted-foreground",
								children: ["#", String(r.id).slice(0, 8)]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `ms-auto text-[10px] font-bold px-2 py-1 rounded-full border inline-flex items-center gap-1 ${meta?.chip ?? ""}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3" }), meta?.label ?? r.status]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-bold text-navy line-clamp-1",
							children: r.product_name_ar ?? "منتج غير معروف"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground line-clamp-2 mt-1",
							children: r.reason
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted-foreground",
								children: new Date(r.created_at).toLocaleString("ar-IQ", {
									dateStyle: "short",
									timeStyle: "short"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4 text-muted-foreground" })]
						})
					]
				}, r.id);
			})]
		})
	});
}
//#endregion
export { ReplacementsList as component };
