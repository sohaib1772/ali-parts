import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { W as MessageCircle } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/icons-kUk6pI7L.js
var import_jsx_runtime = require_jsx_runtime();
function WhatsappIcon({ className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
		className: `object-contain ${className}`,
		"aria-label": "WhatsApp"
	});
}
//#endregion
export { WhatsappIcon as t };
