import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { n as unreadNotificationsKey } from "./notifications-DFPiacgQ.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Dt as Check, H as PackageCheck, bt as CircleX, c as Truck, jt as Bell, vt as ClipboardCheck, z as Package } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { r as statusLabel, t as statusColor } from "./order-status-Chx_uF3Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-BSv_uw8Z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function statusIcon(s) {
	switch (s) {
		case "received": return ClipboardCheck;
		case "preparing": return Package;
		case "packed": return Package;
		case "shipped": return Truck;
		case "out_for_delivery": return Truck;
		case "delivered": return PackageCheck;
		case "cancelled": return CircleX;
		default: return Bell;
	}
}
function timeAgo(iso) {
	const diff = (Date.now() - new Date(iso).getTime()) / 1e3;
	if (diff < 60) return "الآن";
	if (diff < 3600) return `منذ ${Math.floor(diff / 60)} د`;
	if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} س`;
	return `منذ ${Math.floor(diff / 86400)} ي`;
}
function NotificationsPage() {
	const { userId } = useAuth();
	const qc = useQueryClient();
	const refreshBadges = () => qc.invalidateQueries({ queryKey: unreadNotificationsKey(userId) });
	const [items, setItems] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [limit, setLimit] = (0, import_react.useState)(30);
	const [hasMore, setHasMore] = (0, import_react.useState)(false);
	const load = async () => {
		if (!userId) return;
		const { data } = await supabase.from("notifications").select("id, order_id, title, body, status, read_at, created_at").eq("user_id", userId).order("created_at", { ascending: false }).limit(limit + 1);
		const rows = data ?? [];
		setHasMore(rows.length > limit);
		setItems(rows.slice(0, limit));
		setLoading(false);
	};
	(0, import_react.useEffect)(() => {
		load();
		if (!userId) return;
		const ch = supabase.channel("notifications-user").on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "notifications",
			filter: `user_id=eq.${userId}`
		}, () => load()).subscribe();
		return () => {
			supabase.removeChannel(ch);
		};
	}, [userId, limit]);
	const markAllRead = async () => {
		if (!userId) return;
		await supabase.from("notifications").update({ read_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("user_id", userId).is("read_at", null);
		load();
		refreshBadges();
	};
	const markRead = async (id) => {
		await supabase.from("notifications").update({ read_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
		setItems((prev) => prev.map((n) => n.id === id ? {
			...n,
			read_at: (/* @__PURE__ */ new Date()).toISOString()
		} : n));
		refreshBadges();
	};
	const unread = items.filter((n) => !n.read_at).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "الإشعارات",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 pb-6 md:max-w-3xl md:mx-auto",
			children: [unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs font-bold text-muted-foreground",
					children: [unread, " إشعار غير مقروء"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: markAllRead,
					className: "inline-flex items-center gap-1 text-xs font-bold text-navy hover:text-gold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), " تعليم الكل كمقروء"]
				})]
			}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "py-12 text-center text-sm text-muted-foreground",
				children: "جاري التحميل…"
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-20 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-20 rounded-full bg-muted grid place-items-center mx-auto mb-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-10 text-muted-foreground" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold mb-2",
						children: "لا توجد إشعارات"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "ستصلك إشعارات عند تحديث حالة طلباتك"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [items.map((n) => {
					const Icon = statusIcon(n.status);
					const isUnread = !n.read_at;
					const content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `flex gap-3 rounded-2xl border p-3 shadow-card transition ${isUnread ? "bg-card border-gold/40" : "bg-muted/30 border-border"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `size-11 rounded-xl grid place-items-center flex-shrink-0 ${isUnread ? "bg-gradient-gold text-navy" : "bg-muted text-muted-foreground"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold text-foreground",
										children: n.title
									}), isUnread && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 size-2 rounded-full bg-gold flex-shrink-0" })]
								}),
								n.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground mt-0.5",
									children: n.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mt-1.5",
									children: [n.status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[10px] font-bold px-2 py-0.5 rounded-full ${statusColor(n.status)}`,
										children: statusLabel(n.status)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-muted-foreground",
										children: timeAgo(n.created_at)
									})]
								})
							]
						})]
					});
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						onClick: () => isUnread && markRead(n.id),
						children: n.order_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/orders/$id",
							params: { id: n.order_id },
							className: "block",
							children: content
						}) : content
					}, n.id);
				}), hasMore && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setLimit((n) => n + 30),
					className: "w-full h-10 rounded-xl border border-border text-xs font-bold hover:bg-muted",
					children: "تحميل المزيد"
				})]
			})]
		})
	});
}
//#endregion
export { NotificationsPage as component };
