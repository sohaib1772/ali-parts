import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as AuthProvider } from "./use-auth-TMJ5erER.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { s as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { jt as Bell, t as X, w as ShieldAlert } from "../_libs/lucide-react.mjs";
import { c as dealsQuery, h as productsInfiniteQuery, n as bannersQuery, r as bestSellersQuery, s as categoriesQuery, u as featuredProductsQuery } from "./queries-CNdOTkej.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { r as usePriceSyncListener } from "./label-DUtvElRz.mjs";
import { n as Capacitor, t as proxy } from "../_libs/@aparajita/capacitor-secure-storage+[...].mjs";
import { t as Preferences } from "../_libs/capacitor__preferences.mjs";
import { n as filterSearchSchema } from "./storefront-filters-DpSWbFTB.mjs";
import { t as Route$23 } from "./category._id-DQqQDkt6.mjs";
import { t as App } from "../_libs/capacitor__app.mjs";
import { t as Route$24 } from "./order-success._id-BBh3k7J8.mjs";
import { t as Route$25 } from "./orders_._id-BxweEGDk.mjs";
import { t as Route$26 } from "./product._id-Be5MzFca.mjs";
import { t as Route$27 } from "./replacements_._id-BREYh5lP.mjs";
import { t as Route$28 } from "./route-C61HYUqK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-EGC5gW22.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-CXGghwhA.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
var SESSION_KEY = "alsaaer_splash_shown";
var STORE_NAME = "مكتب علي شوفرليت";
var STORE_TAGLINE = "قطع أصلية · العراق";
var STORE_LOGO = "/icon-512.png";
function SplashScreen() {
	const [visible, setVisible] = (0, import_react.useState)(true);
	const [fading, setFading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const w = window;
			if (w.hideBootSplash) w.hideBootSplash();
		} catch {}
		try {
			const boot = document.getElementById("initial-boot-splash");
			if (boot) {
				boot.style.transition = "opacity .25s ease";
				boot.style.opacity = "0";
				setTimeout(() => boot.remove(), 260);
			}
		} catch {}
		let alreadyShown = false;
		try {
			alreadyShown = !!window.sessionStorage.getItem(SESSION_KEY);
		} catch {}
		if (alreadyShown) {
			setVisible(false);
			return;
		}
		const fadeAt = setTimeout(() => setFading(true), 350);
		const hideAt = setTimeout(() => {
			setVisible(false);
			try {
				window.sessionStorage.setItem(SESSION_KEY, "1");
			} catch {}
		}, 650);
		return () => {
			clearTimeout(fadeAt);
			clearTimeout(hideAt);
		};
	}, []);
	if (!visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-gradient-to-b from-[#0a1226] via-[#0f172a] to-[#020617] transition-opacity duration-300 ${fading ? "opacity-0" : "opacity-100"}`,
		dir: "rtl",
		"aria-hidden": fading,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute top-[-15%] left-[-15%] w-[60%] h-[60%] rounded-full bg-amber-500/12 blur-[140px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute bottom-[-15%] right-[-15%] w-[60%] h-[60%] rounded-full bg-blue-400/10 blur-[140px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:36px_36px] opacity-[0.03]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 inset-x-10 h-px bg-gradient-to-r from-transparent via-gold/70 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex flex-col items-center animate-[fadeInUp_600ms_ease-out_both]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mb-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -inset-6 rounded-full bg-gradient-to-tr from-amber-500/50 to-amber-200/40 blur-3xl animate-pulse" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -m-3 rounded-[2rem] border border-gold/25" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -m-6 rounded-[2.5rem] border border-gold/10" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative size-40 rounded-[1.75rem] bg-gradient-to-br from-[#1e293b] to-[#0f172a] border-2 border-gold/40 flex items-center justify-center shadow-[0_0_80px_rgba(201,162,39,0.35)] overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: STORE_LOGO,
									alt: STORE_NAME,
									className: "max-h-28 max-w-28 object-contain drop-shadow-[0_0_20px_rgba(201,162,39,0.35)]"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-luxury text-5xl font-black tracking-tight text-white text-center px-8",
						children: STORE_NAME
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-2 text-gold/90",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-8 bg-gradient-to-l from-transparent to-gold/70" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-body-lux text-sm",
								children: STORE_TAGLINE
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px w-8 bg-gradient-to-r from-transparent to-gold/70" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 h-[3px] w-52 overflow-hidden rounded-full bg-white/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-1/3 bg-gradient-to-r from-transparent via-gold to-transparent animate-[splashBar_1.4s_ease-in-out_infinite]" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 inset-x-10 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `
        @keyframes splashBar { 0% { transform: translateX(-100%); } 100% { transform: translateX(320%); } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
      ` })
		]
	});
}
function NotificationPopup() {
	const [notif, setNotif] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		let channel = null;
		let currentUid = null;
		const LAST_KEY = "notif_popup_last_seen";
		const setup = async (uid) => {
			if (channel) {
				supabase.removeChannel(channel);
				channel = null;
			}
			currentUid = uid;
			if (!uid) return;
			channel = supabase.channel(`notif-popup-${uid}-${crypto.randomUUID()}`).on("postgres_changes", {
				event: "INSERT",
				schema: "public",
				table: "notifications",
				filter: `user_id=eq.${uid}`
			}, (payload) => {
				const row = payload.new;
				if (!mounted) return;
				if (row.read_at) return;
				try {
					const last = window.localStorage.getItem(LAST_KEY);
					if (last && last >= row.created_at) return;
					window.localStorage.setItem(LAST_KEY, row.created_at);
				} catch {}
				setNotif({
					id: row.id,
					title: row.title,
					body: row.body,
					type: row.type,
					created_at: row.created_at
				});
			}).subscribe();
		};
		(async () => {
			const { data } = await supabase.auth.getSession();
			setup(data.session?.user.id ?? null);
		})();
		const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
			const uid = session?.user.id ?? null;
			if (uid !== currentUid) setup(uid);
		});
		return () => {
			mounted = false;
			sub.subscription.unsubscribe();
			if (channel) supabase.removeChannel(channel);
		};
	}, []);
	const dismiss = async () => {
		if (!notif) return;
		const id = notif.id;
		setNotif(null);
		try {
			await supabase.from("notifications").update({ read_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", id);
		} catch {}
	};
	if (!notif) return null;
	const isBlock = notif.type === "account_status" || (notif.title ?? "").includes("حظر") || (notif.body ?? "").includes("حظر");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "dialog",
		"aria-modal": "true",
		onClick: dismiss,
		className: "fixed inset-0 z-[100] bg-black/70 backdrop-blur-sm grid place-items-center px-6 animate-in fade-in duration-200",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			onClick: (e) => e.stopPropagation(),
			className: "w-full max-w-sm bg-card rounded-3xl border border-border shadow-2xl p-6 text-center relative animate-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: dismiss,
					"aria-label": "إغلاق",
					className: "absolute top-3 end-3 size-8 rounded-full grid place-items-center text-muted-foreground hover:bg-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `relative mx-auto mb-4 size-20 rounded-full grid place-items-center ${isBlock ? "bg-gradient-to-br from-red-500 via-rose-600 to-red-700 shadow-[0_10px_30px_-8px_rgba(239,68,68,0.6)]" : "bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 shadow-[0_10px_30px_-8px_rgba(245,158,11,0.6)]"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `absolute -inset-2 rounded-full blur-xl opacity-60 ${isBlock ? "bg-red-500/50" : "bg-amber-400/50"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative size-16 rounded-full bg-white/10 backdrop-blur-sm grid place-items-center border border-white/30 ring-4 ring-white/20",
						children: isBlock ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
							className: "size-9 text-white drop-shadow-lg",
							strokeWidth: 2.5
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
							className: "size-9 text-white drop-shadow-lg",
							strokeWidth: 2.5
						})
					})]
				}),
				notif.title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-extrabold text-lg text-foreground mb-2",
					children: notif.title
				}),
				notif.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground leading-relaxed",
					children: notif.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: dismiss,
					className: "mt-5 w-full rounded-full bg-primary text-primary-foreground py-2.5 font-bold text-sm",
					children: "تم"
				})
			]
		})
	});
}
function getStorageKey() {
	const url = "https://api.maktabali.com";
	try {
		return `sb-${new URL(url).hostname.split(".")[0]}-auth-token`;
	} catch {
		return null;
	}
}
async function secureGet(key) {
	try {
		const v = await proxy.get(key);
		return typeof v === "string" ? v : null;
	} catch {
		return null;
	}
}
async function secureSet(key, value) {
	try {
		await proxy.set(key, value, false, false);
	} catch {}
}
async function secureRemove(key) {
	try {
		await proxy.remove(key);
	} catch {}
}
function SessionPersistence() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		const refreshIfNeeded = async () => {
			try {
				const { data } = await supabase.auth.getSession();
				const session = data.session;
				if (!session) return;
				if ((session.expires_at ?? 0) * 1e3 - Date.now() < 6e4) await supabase.auth.refreshSession();
			} catch {}
		};
		const onVisibility = () => {
			if (document.visibilityState === "visible") refreshIfNeeded();
		};
		document.addEventListener("visibilitychange", onVisibility);
		let appListenerHandle = null;
		if (Capacitor.isNativePlatform()) App.addListener("appStateChange", ({ isActive }) => {
			if (isActive) refreshIfNeeded();
		}).then((h) => {
			appListenerHandle = h;
		}).catch(() => {});
		if (!Capacitor.isNativePlatform()) return () => {
			document.removeEventListener("visibilitychange", onVisibility);
		};
		const key = getStorageKey();
		if (!key) return () => {
			document.removeEventListener("visibilitychange", onVisibility);
			appListenerHandle?.remove().catch(() => {});
		};
		let cancelled = false;
		(async () => {
			try {
				try {
					const legacy = await Preferences.get({ key });
					if (legacy.value) {
						await secureSet(key, legacy.value);
						await Preferences.remove({ key });
					}
				} catch {}
				const local = window.localStorage.getItem(key);
				if (!local) {
					const value = await secureGet(key);
					if (cancelled || !value) return;
					window.localStorage.setItem(key, value);
					try {
						const parsed = JSON.parse(value);
						if (parsed?.access_token && parsed?.refresh_token) {
							await supabase.auth.setSession({
								access_token: parsed.access_token,
								refresh_token: parsed.refresh_token
							});
							router.invalidate();
						}
					} catch {}
				} else await secureSet(key, local);
			} catch {}
		})();
		const { data: sub } = supabase.auth.onAuthStateChange(async (event, session) => {
			try {
				if (event === "SIGNED_OUT" || !session) {
					await secureRemove(key);
					return;
				}
				const value = window.localStorage.getItem(key);
				if (value) await secureSet(key, value);
			} catch {}
		});
		return () => {
			cancelled = true;
			sub.subscription.unsubscribe();
			document.removeEventListener("visibilitychange", onVisibility);
			appListenerHandle?.remove().catch(() => {});
		};
	}, [router]);
	return null;
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$22 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover"
			},
			{ title: "Ali Parts — قطع غيار شفروليه GMC كاديلاك الأصلية في العراق" },
			{
				name: "description",
				content: "Ali Parts: متجرك الأول لقطع غيار السيارات الأصلية شفروليه، GMC، وكاديلاك داخل العراق. توصيل سريع وضمان الجودة."
			},
			{
				name: "theme-color",
				content: "#0A192F"
			},
			{
				property: "og:title",
				content: "Ali Parts — قطع غيار شفروليه GMC كاديلاك الأصلية في العراق"
			},
			{
				property: "og:description",
				content: "Ali Parts: متجرك الأول لقطع غيار السيارات الأصلية شفروليه، GMC، وكاديلاك داخل العراق. توصيل سريع وضمان الجودة."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			},
			{
				name: "twitter:title",
				content: "Ali Parts — قطع غيار شفروليه GMC كاديلاك الأصلية في العراق"
			},
			{
				name: "twitter:description",
				content: "Ali Parts: متجرك الأول لقطع غيار السيارات الأصلية شفروليه، GMC، وكاديلاك داخل العراق. توصيل سريع وضمان الجودة."
			},
			{
				property: "og:url",
				content: "https://maktabali.com/"
			},
			{
				property: "og:image",
				content: "https://maktabali.com/icon-512.png"
			},
			{
				property: "og:image:width",
				content: "512"
			},
			{
				property: "og:image:height",
				content: "512"
			},
			{
				name: "twitter:image",
				content: "https://maktabali.com/icon-512.png"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-title",
				content: "Ali Parts"
			},
			{
				name: "apple-mobile-web-app-status-bar-style",
				content: "black-translucent"
			},
			{
				name: "mobile-web-app-capable",
				content: "yes"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			},
			{
				rel: "manifest",
				href: "/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/apple-touch-icon.png"
			},
			{
				rel: "icon",
				type: "image/png",
				sizes: "192x192",
				href: "/icon-192.png"
			},
			{
				rel: "icon",
				type: "image/png",
				sizes: "512x512",
				href: "/icon-512.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "preconnect",
				href: "https://api.maktabali.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "dns-prefetch",
				href: "https://api.maktabali.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&family=Cormorant+Garamond:wght@400;500;600;700&family=Karla:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `html,body{background:#0A192F} #initial-boot-splash{position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(ellipse at top,#0f172a 0%,#0A192F 55%,#020617 100%);z-index:9999;color:#fff;font-family:system-ui,-apple-system,"Segoe UI",sans-serif} #initial-boot-splash img{width:120px;height:120px;border-radius:26px;border:2px solid rgba(201,162,39,.4);box-shadow:0 0 60px rgba(201,162,39,.35);background:#0f172a;object-fit:contain;padding:10px} #initial-boot-splash .t{margin-top:20px;font-size:24px;font-weight:800} #initial-boot-splash .s{margin-top:6px;font-size:12px;color:#C9A227} #initial-boot-splash .b{margin-top:24px;width:180px;height:3px;border-radius:999px;background:rgba(255,255,255,.1);overflow:hidden;position:relative} #initial-boot-splash .b::after{content:"";position:absolute;inset:0;width:33%;background:linear-gradient(90deg,transparent,#C9A227,transparent);animation:ibs 1.4s ease-in-out infinite} @keyframes ibs{0%{transform:translateX(-100%)}100%{transform:translateX(320%)}}` })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				id: "initial-boot-splash",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/icon-512.png",
						alt: ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "t",
						children: "مكتب علي شوفرليت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "s",
						children: "قطع أصلية · العراق"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "b" })
				]
			}),
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$22.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				richColors: true,
				closeButton: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthListener, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionPersistence, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceSync, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplashScreen, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationPermissionGate, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationPopup, {})
		] })
	});
}
function PriceSync() {
	usePriceSyncListener();
	return null;
}
function AuthListener() {
	const router = useRouter();
	const { queryClient } = Route$22.useRouteContext();
	(0, import_react.useEffect)(() => {
		let lastUserId = void 0;
		const { data } = supabase.auth.onAuthStateChange((event, session) => {
			if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
			const nextUserId = session?.user?.id ?? null;
			const identityChanged = lastUserId !== void 0 && lastUserId !== nextUserId;
			lastUserId = nextUserId;
			if (event === "SIGNED_OUT") {
				router.invalidate();
				return;
			}
			if (event === "USER_UPDATED") {
				queryClient.invalidateQueries();
				return;
			}
			if (identityChanged) router.invalidate();
		});
		return () => data.subscription.unsubscribe();
	}, [router, queryClient]);
	return null;
}
function NotificationPermissionGate() {
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		if (!("Notification" in window)) return;
		const STORAGE_KEY = "alsaaer_notif_perm_asked";
		try {
			const asked = window.localStorage.getItem(STORAGE_KEY);
			const state = Notification.permission;
			if (state === "granted" || state === "denied") {
				window.localStorage.setItem(STORAGE_KEY, state);
				return;
			}
			if (asked) return;
			const t = setTimeout(() => {
				try {
					window.localStorage.setItem(STORAGE_KEY, "asked");
					Notification.requestPermission().then((result) => {
						try {
							window.localStorage.setItem(STORAGE_KEY, result);
						} catch {}
					}).catch(() => {});
				} catch {}
			}, 5500);
			return () => clearTimeout(t);
		} catch {}
	}, []);
	return null;
}
var $$splitComponentImporter$21 = () => import("./terms-Dlv6De7c.mjs");
var Route$21 = createFileRoute("/terms")({
	head: () => ({
		meta: [
			{ title: "الشروط والأحكام — Ali Parts" },
			{
				name: "description",
				content: "الشروط والأحكام لاستخدام تطبيق Ali Parts لبيع قطع غيار السيارات في العراق."
			},
			{
				name: "robots",
				content: "index, follow"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://maktabali.com/terms"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./search-DywdX9hp.mjs");
var Route$20 = createFileRoute("/search")({
	validateSearch: filterSearchSchema,
	head: () => ({ meta: [{ title: "البحث — Ali Parts" }] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component"),
	pendingMs: 400,
	pendingMinMs: 0,
	pendingComponent: SearchPending
});
function SearchPending() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 rounded-2xl bg-muted animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 grid grid-cols-2 gap-3",
				children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rounded-2xl aspect-[3/4] bg-muted animate-pulse" }, i))
			})]
		})
	});
}
var $$splitComponentImporter$19 = () => import("./products-UeNoM8xs.mjs");
var Route$19 = createFileRoute("/products")({
	validateSearch: filterSearchSchema,
	loader: ({ context }) => {
		context.queryClient.prefetchInfiniteQuery(productsInfiniteQuery());
	},
	head: () => ({ meta: [{ title: "المنتجات | الساير" }, {
		name: "description",
		content: "تصفح جميع قطع الغيار المتوفرة في متجر الساير."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./privacy-B7AwHcMq.mjs");
var Route$18 = createFileRoute("/privacy")({
	head: () => ({
		meta: [
			{ title: "سياسة الخصوصية — Ali Parts" },
			{
				name: "description",
				content: "سياسة الخصوصية لتطبيق Ali Parts لقطع غيار السيارات في العراق: البيانات التي نجمعها وكيفية استخدامها وحمايتها."
			},
			{
				name: "robots",
				content: "index, follow"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://maktabali.com/privacy"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./offers-CYGyDV5y.mjs");
var Route$17 = createFileRoute("/offers")({
	head: () => ({ meta: [
		{ title: "العروض الحصرية — Ali Parts" },
		{
			name: "description",
			content: "شاهد ريلز العروض الحصرية، اضغط قلب، وشاركنا تعليقك."
		},
		{
			property: "og:title",
			content: "العروض الحصرية — Ali Parts"
		},
		{
			property: "og:description",
			content: "شاهد ريلز العروض الحصرية، اضغط قلب، وشاركنا تعليقك."
		}
	] }),
	loader: ({ context }) => {
		context.queryClient.ensureQueryData(bannersQuery());
	},
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./delete-account-Ds7kvUQ5.mjs");
/**
* Public account-deletion page.
*
* Google Play requires a publicly reachable URL — no login — that explains how
* to request account deletion, what is deleted and what is retained. This URL
* goes in the Play Console data-safety form. It is deliberately OUTSIDE the
* _authenticated route group so a signed-out visitor (or a Play reviewer) can
* open it.
*/
var Route$16 = createFileRoute("/delete-account")({
	head: () => ({
		meta: [
			{ title: "حذف الحساب — Ali Parts" },
			{
				name: "description",
				content: "كيفية حذف حسابك في تطبيق Ali Parts والبيانات التي يتم حذفها والاحتفاظ بها."
			},
			{
				name: "robots",
				content: "index, follow"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://maktabali.com/delete-account"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./deals-Cxpmauxg.mjs");
var Route$15 = createFileRoute("/deals")({
	validateSearch: filterSearchSchema,
	loader: ({ context }) => context.queryClient.ensureQueryData(dealsQuery()),
	head: () => ({ meta: [{ title: "عروض لفترة محدودة | الساير" }, {
		name: "description",
		content: "أسعار خاصة على قطع غيار السيارات لفترة قصيرة."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./contact-f5tXxu-3.mjs");
var Route$14 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "اتصل بنا — Ali Parts" }] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./best-sellers-BJnMgTac.mjs");
var Route$13 = createFileRoute("/best-sellers")({
	validateSearch: filterSearchSchema,
	loader: ({ context }) => context.queryClient.ensureQueryData(bestSellersQuery()),
	head: () => ({ meta: [
		{ title: "الأكثر مبيعاً | الساير" },
		{
			name: "description",
			content: "أعلى قطع الغيار مبيعاً في متجر الساير حسب المبيعات الفعلية."
		},
		{
			property: "og:title",
			content: "الأكثر مبيعاً | الساير"
		},
		{
			property: "og:description",
			content: "أعلى قطع الغيار مبيعاً في متجر الساير."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./auth-R3gIpw4A.mjs");
var Route$12 = createFileRoute("/auth")({
	ssr: false,
	head: () => ({ meta: [{ title: "تسجيل الدخول — Ali Parts" }, {
		name: "description",
		content: "سجّل الدخول إلى Ali Parts عبر حساب Google للاستفادة من كل الميزات."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./about-B41QzodY.mjs");
var Route$11 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: "من نحن — Ali Parts" }, {
		name: "description",
		content: "تعرّف على Ali Parts، وجهتك الأولى لقطع غيار السيارات الأصلية في العراق."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./routes-B6dnMAFv.mjs");
var Route$10 = createFileRoute("/")({
	validateSearch: filterSearchSchema,
	loader: ({ context }) => {
		context.queryClient.prefetchQuery(categoriesQuery());
		context.queryClient.prefetchQuery(featuredProductsQuery());
		context.queryClient.prefetchQuery(dealsQuery());
		context.queryClient.prefetchQuery(bannersQuery());
		context.queryClient.prefetchQuery(bestSellersQuery());
	},
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./replacements-Cz10wilY.mjs");
var Route$9 = createFileRoute("/_authenticated/replacements")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./orders-B3k8QfpL.mjs");
var Route$8 = createFileRoute("/_authenticated/orders")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./notifications-BSv_uw8Z.mjs");
var Route$7 = createFileRoute("/_authenticated/notifications")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./messages-jHLN-48y.mjs");
var Route$6 = createFileRoute("/_authenticated/messages")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./favorites-BTxSINl6.mjs");
var Route$5 = createFileRoute("/_authenticated/favorites")({
	validateSearch: filterSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./checkout-Cmmhu8VL.mjs");
var Route$4 = createFileRoute("/_authenticated/checkout")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./cart-CuhvO_7Y.mjs");
var Route$3 = createFileRoute("/_authenticated/cart")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./admin-D7d6Rb8m.mjs");
/**
* Staff management is HIDDEN, not deleted.
*
* createStaff() provisions a phone+password account (p<phone>@aliparts.app),
* but sign-in is Google/Apple only — there is no password login UI anywhere in
* the app. Any staff member created this way therefore CANNOT SIGN IN, and
* nothing warned the admin about it. Hiding the tab prevents creating those
* dead accounts.
*
* Nothing is removed: StaffAdmin, staff.functions.ts, the staff_permissions
* table, existing staff rows and all `staff_can()` permission checks are
* untouched — staff who already exist keep working exactly as before.
*
* TO RE-ENABLE: set this to true. Only do that once staff can actually sign
* in — i.e. after either adding an email/password login path or moving staff
* onto Google/Apple accounts.
*/
/**
* Banner video cap. Raised to 50MB now that playback is fully deferred
* (preload="none" → 0 bytes on home load) and progressive-streaming (faststart
* MP4 + HTTP range requests), so a customer only downloads what they actually
* watch after tapping — never on page load.
*/
var Route$2 = createFileRoute("/_authenticated/admin")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./addresses-XN4xH3b8.mjs");
var Route$1 = createFileRoute("/_authenticated/addresses")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./account-DgIlWgvq.mjs");
var Route = createFileRoute("/_authenticated/account")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var TermsRoute = Route$21.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$22
});
var SearchRoute = Route$20.update({
	id: "/search",
	path: "/search",
	getParentRoute: () => Route$22
});
var ProductsRoute = Route$19.update({
	id: "/products",
	path: "/products",
	getParentRoute: () => Route$22
});
var PrivacyRoute = Route$18.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$22
});
var OffersRoute = Route$17.update({
	id: "/offers",
	path: "/offers",
	getParentRoute: () => Route$22
});
var DeleteAccountRoute = Route$16.update({
	id: "/delete-account",
	path: "/delete-account",
	getParentRoute: () => Route$22
});
var DealsRoute = Route$15.update({
	id: "/deals",
	path: "/deals",
	getParentRoute: () => Route$22
});
var ContactRoute = Route$14.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$22
});
var BestSellersRoute = Route$13.update({
	id: "/best-sellers",
	path: "/best-sellers",
	getParentRoute: () => Route$22
});
var AuthRoute = Route$12.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$22
});
var AboutRoute = Route$11.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$22
});
var AuthenticatedRouteRoute = Route$28.update({
	id: "/_authenticated",
	getParentRoute: () => Route$22
});
var IndexRoute = Route$10.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$22
});
var ProductIdRoute = Route$26.update({
	id: "/product/$id",
	path: "/product/$id",
	getParentRoute: () => Route$22
});
var OrderSuccessIdRoute = Route$24.update({
	id: "/order-success/$id",
	path: "/order-success/$id",
	getParentRoute: () => Route$22
});
var CategoryIdRoute = Route$23.update({
	id: "/category/$id",
	path: "/category/$id",
	getParentRoute: () => Route$22
});
var AuthenticatedReplacementsRoute = Route$9.update({
	id: "/replacements",
	path: "/replacements",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedOrdersRoute = Route$8.update({
	id: "/orders",
	path: "/orders",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedNotificationsRoute = Route$7.update({
	id: "/notifications",
	path: "/notifications",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedMessagesRoute = Route$6.update({
	id: "/messages",
	path: "/messages",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedFavoritesRoute = Route$5.update({
	id: "/favorites",
	path: "/favorites",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCheckoutRoute = Route$4.update({
	id: "/checkout",
	path: "/checkout",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCartRoute = Route$3.update({
	id: "/cart",
	path: "/cart",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAdminRoute = Route$2.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAddressesRoute = Route$1.update({
	id: "/addresses",
	path: "/addresses",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAccountRoute = Route.update({
	id: "/account",
	path: "/account",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedReplacementsIdRoute = Route$27.update({
	id: "/replacements_/$id",
	path: "/replacements/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedAccountRoute,
	AuthenticatedAddressesRoute,
	AuthenticatedAdminRoute,
	AuthenticatedCartRoute,
	AuthenticatedCheckoutRoute,
	AuthenticatedFavoritesRoute,
	AuthenticatedMessagesRoute,
	AuthenticatedNotificationsRoute,
	AuthenticatedOrdersRoute,
	AuthenticatedReplacementsRoute,
	AuthenticatedOrdersIdRoute: Route$25.update({
		id: "/orders_/$id",
		path: "/orders/$id",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedReplacementsIdRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AboutRoute,
	AuthRoute,
	BestSellersRoute,
	ContactRoute,
	DealsRoute,
	DeleteAccountRoute,
	OffersRoute,
	PrivacyRoute,
	ProductsRoute,
	SearchRoute,
	TermsRoute,
	CategoryIdRoute,
	OrderSuccessIdRoute,
	ProductIdRoute
};
var routeTree = Route$22._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient({ defaultOptions: { queries: {
			staleTime: 6e4,
			gcTime: 10 * 6e4,
			refetchOnWindowFocus: false,
			refetchOnReconnect: false,
			retry: 1
		} } }) },
		scrollRestoration: true,
		defaultPreload: "intent",
		defaultPreloadStaleTime: 3e4,
		defaultStaleTime: 6e4,
		defaultPendingMs: 800,
		defaultPendingMinMs: 0
	});
};
//#endregion
export { getRouter };
