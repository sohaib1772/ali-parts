import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as useSetting, i as useAdjustedPrice } from "./admin-DdF3xehS.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Dt as Check, Et as ChevronDown, O as Search, b as ShoppingCart, rt as Heart, t as X } from "../_libs/lucide-react.mjs";
import { a as carModelsQuery, i as brandsQuery, s as categoriesQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD, s as whatsappLink } from "./format-CTK49jpu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as useStorefrontFilters } from "./storefront-filters-DpSWbFTB.mjs";
import { t as WhatsappIcon } from "./icons-kUk6pI7L.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/filter-bar-DFyaSNY5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Rewrite a Supabase Storage signed URL to the image-transform endpoint
* so we get a smaller, faster thumbnail instead of the full original.
*
* Signed object URL:  /storage/v1/object/sign/<bucket>/<path>?token=...
* Signed render URL:  /storage/v1/render/image/sign/<bucket>/<path>?token=...&width=...
*
* Works only on Supabase Storage URLs; anything else is returned untouched.
*/
function thumbUrl(url, opts = {}) {
	if (!url) return "";
	try {
		const u = new URL(url);
		if (!u.pathname.includes("/storage/v1/object/sign/") && !u.pathname.includes("/storage/v1/render/image/sign/")) return url;
		if (/\.(mp4|webm|mov|m4v|ogg)(\?|$)/i.test(u.pathname)) return url;
		u.pathname = u.pathname.replace("/storage/v1/object/sign/", "/storage/v1/render/image/sign/");
		const { width = 600, quality = 70, resize = "cover" } = opts;
		u.searchParams.set("width", String(width));
		u.searchParams.set("quality", String(quality));
		u.searchParams.set("resize", resize);
		return u.toString();
	} catch {
		return url;
	}
}
function ProductCard({ product }) {
	const qc = useQueryClient();
	const img = product.images?.[0];
	const imgThumb = thumbUrl(img, {
		width: 500,
		quality: 65
	});
	const waNumber = useSetting("whatsapp_number");
	const adjust = useAdjustedPrice();
	const stockQty = product.stock_qty ?? 0;
	const available = product.in_stock && stockQty > 0;
	const condition = product.condition === "used" ? "used" : "new";
	const requireAuth = async () => {
		const { data } = await supabase.auth.getSession();
		const uid = data.session?.user?.id ?? null;
		if (!uid) {
			toast.error("سجّل الدخول أولاً لإكمال هذه الخطوة");
			return null;
		}
		return uid;
	};
	const addToCart = async (e) => {
		e.preventDefault();
		e.stopPropagation();
		const userId = await requireAuth();
		if (!userId) return;
		const { data: existing } = await supabase.from("cart_items").select("id, quantity, side").eq("user_id", userId).eq("product_id", product.id).is("side", null).maybeSingle();
		if (existing && existing.quantity === 1) {
			toast.error("المنتج مضاف مسبقاً للسلة، غيّر الكمية من صفحة المنتج");
			return;
		}
		const { error } = await supabase.rpc("add_cart_item", {
			p_product_id: product.id,
			p_quantity: 1,
			p_side: null
		});
		if (error) {
			toast.error("تعذر إضافة المنتج للسلة");
			return;
		}
		window.dispatchEvent(new CustomEvent("cart:changed", { detail: {
			delta: 1,
			bump: true
		} }));
		toast.success("تمت الإضافة إلى السلة");
		qc.invalidateQueries({ queryKey: ["cart"] });
	};
	const toggleFav = async (e) => {
		e.preventDefault();
		e.stopPropagation();
		const userId = await requireAuth();
		if (!userId) return;
		const { data: existing } = await supabase.from("favorites").select("id").eq("user_id", userId).eq("product_id", product.id).maybeSingle();
		if (existing) {
			await supabase.from("favorites").delete().eq("id", existing.id);
			toast.success("أزيل من المفضلة");
		} else {
			await supabase.from("favorites").insert({
				user_id: userId,
				product_id: product.id
			});
			toast.success("أضيف للمفضلة");
		}
		qc.invalidateQueries({ queryKey: ["favorites"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/product/$id",
		params: { id: product.id },
		preload: "viewport",
		className: "group relative flex flex-col rounded-2xl bg-card border border-border/60 shadow-card overflow-hidden hover:shadow-luxe transition-all duration-300",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-square bg-muted overflow-hidden",
			children: [
				img ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: imgThumb,
					alt: product.name_ar,
					loading: "lazy",
					decoding: "async",
					fetchPriority: "low",
					width: 400,
					height: 400,
					sizes: "(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 300px",
					className: "size-full object-cover group-hover:scale-105 transition-transform duration-500"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-full bg-gradient-to-br from-muted to-secondary grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-4xl opacity-30",
						children: "⚙️"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: toggleFav,
					"aria-label": "مفضلة",
					className: "absolute top-2 start-2 size-8 rounded-full bg-card/90 backdrop-blur grid place-items-center shadow hover:bg-gold hover:text-navy transition",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "size-4" })
				}),
				product.is_deal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-2 end-2 px-2 py-0.5 rounded-full bg-gradient-gold text-navy text-[10px] font-bold shadow-gold",
					children: "عرض"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `absolute top-2 ${product.is_deal ? "end-14" : "end-2"} px-2 py-0.5 rounded-full text-[10px] font-bold shadow ${condition === "used" ? "bg-amber-500 text-white" : "bg-emerald-600 text-white"}`,
					children: condition === "used" ? "مستعمل" : "جديد"
				}),
				!available && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 bg-navy/60 grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-3 py-1 rounded-full bg-destructive text-destructive-foreground text-xs font-bold",
						children: "غير متوفر"
					})
				}),
				available && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `absolute bottom-2 start-2 px-2 py-0.5 rounded-full text-[10px] font-bold shadow ${stockQty <= 5 ? "bg-destructive text-destructive-foreground" : "bg-success text-white"}`,
					children: stockQty <= 5 ? `متبقي ${stockQty}` : `متوفر · ${stockQty}`
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-3 flex flex-col gap-2 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold line-clamp-2 leading-tight",
					children: product.name_ar
				}),
				product.oem_number && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[10px] text-muted-foreground font-mono tracking-tight",
					children: ["OEM: ", product.oem_number]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-auto space-y-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-base font-extrabold text-navy",
							children: formatIQD(adjust(product.price_iqd))
						}), available ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ms-auto text-[10px] font-bold text-success",
							children: [
								"متوفر · ",
								stockQty,
								" قطعة"
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ms-auto text-[10px] font-bold text-destructive",
							children: "غير متوفر"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 pt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: addToCart,
						disabled: !available,
						className: "flex-1 h-9 rounded-xl bg-navy text-primary-foreground text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-gold hover:text-navy disabled:opacity-50 disabled:pointer-events-none transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "size-3.5" }), "أضف للسلة"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: (e) => {
							e.preventDefault();
							e.stopPropagation();
							window.open(whatsappLink(`السلام عليكم، أرغب بالاستفسار عن: ${product.name_ar} (OEM: ${product.oem_number ?? "-"})`, waNumber), "_blank", "noopener,noreferrer");
						},
						"aria-label": "واتساب",
						className: "size-9 rounded-xl bg-whatsapp text-white grid place-items-center hover:opacity-90 transition",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappIcon, { className: "size-4" })
					})]
				})
			]
		})]
	});
}
function FilterBar({ showModel = true, categoryOverride }) {
	const [activeMenu, setActiveMenu] = (0, import_react.useState)(null);
	const [menuSearch, setMenuSearch] = (0, import_react.useState)("");
	const [viewportHeight, setViewportHeight] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined" || !activeMenu) return;
		const update = () => {
			if (window.visualViewport) setViewportHeight(window.visualViewport.height);
			else setViewportHeight(window.innerHeight);
		};
		update();
		window.visualViewport?.addEventListener("resize", update);
		window.visualViewport?.addEventListener("scroll", update);
		window.addEventListener("resize", update);
		return () => {
			window.visualViewport?.removeEventListener("resize", update);
			window.visualViewport?.removeEventListener("scroll", update);
			window.removeEventListener("resize", update);
		};
	}, [activeMenu]);
	const { data: categories = [] } = useQuery(categoriesQuery());
	const { data: brands = [] } = useQuery(brandsQuery());
	const { data: models = [] } = useQuery(carModelsQuery());
	const { filters, setFilter, clearFilters } = useStorefrontFilters();
	const categoryValue = categoryOverride ? categoryOverride.value : filters.category;
	const onSelectCategory = categoryOverride ? categoryOverride.onChange : (id) => setFilter({ category: id });
	const categoryOptions = (0, import_react.useMemo)(() => categories.map((c) => ({
		id: c.id,
		label: c.name_ar
	})), [categories]);
	const brandOptions = (0, import_react.useMemo)(() => brands.map((b) => ({
		id: b.id,
		label: b.name_ar,
		sub: b.name_en
	})), [brands]);
	const modelOptions = (0, import_react.useMemo)(() => (filters.brand ? models.filter((m) => m.brand_id === filters.brand) : models).map((m) => ({
		id: m.id,
		label: m.name_ar,
		sub: m.name_en
	})), [models, filters.brand]);
	const onSelectBrand = (id) => {
		const modelStillValid = !!filters.model && models.find((m) => m.id === filters.model)?.brand_id === id;
		setFilter({
			brand: id,
			model: id && modelStillValid ? filters.model : ""
		});
	};
	const onSelectModel = (id) => {
		const brandId = models.find((m) => m.id === id)?.brand_id ?? "";
		setFilter({
			model: id,
			...id && brandId ? { brand: brandId } : {}
		});
	};
	const selectedCategory = categoryOptions.find((c) => c.id === categoryValue);
	const selectedBrand = brandOptions.find((b) => b.id === filters.brand);
	const selectedModel = modelOptions.find((m) => m.id === filters.model);
	const hasAnyFilterActive = Boolean(categoryValue || filters.brand || filters.model);
	(0, import_react.useEffect)(() => {
		if (!activeMenu) {
			document.body.removeAttribute("data-filter-modal");
			document.body.style.overflow = "";
			document.body.style.position = "";
			document.body.style.width = "";
			document.body.style.touchAction = "";
			return;
		}
		document.body.setAttribute("data-filter-modal", "open");
		document.body.style.overflow = "hidden";
		document.body.style.position = "fixed";
		document.body.style.width = "100%";
		document.body.style.touchAction = "none";
		const onKey = (e) => {
			if (e.key === "Escape") {
				setActiveMenu(null);
				setMenuSearch("");
			}
		};
		document.addEventListener("keydown", onKey);
		return () => {
			document.body.removeAttribute("data-filter-modal");
			document.body.style.overflow = "";
			document.body.style.position = "";
			document.body.style.width = "";
			document.body.style.touchAction = "";
			document.removeEventListener("keydown", onKey);
		};
	}, [activeMenu]);
	const toggleMenu = (menu) => {
		if (activeMenu === menu) {
			setActiveMenu(null);
			setMenuSearch("");
		} else {
			setActiveMenu(menu);
			setMenuSearch("");
		}
	};
	const currentMenuConfig = (0, import_react.useMemo)(() => {
		if (activeMenu === "category") return {
			title: "اختر التصنيف",
			value: categoryValue,
			options: categoryOptions,
			onSelect: (id) => {
				onSelectCategory(id);
				setActiveMenu(null);
				setMenuSearch("");
			}
		};
		if (activeMenu === "brand") return {
			title: "اختر الماركة",
			value: filters.brand,
			options: brandOptions,
			onSelect: (id) => {
				onSelectBrand(id);
				setActiveMenu(null);
				setMenuSearch("");
			}
		};
		if (activeMenu === "model") return {
			title: "اختر نوع السيارة",
			value: filters.model,
			options: modelOptions,
			onSelect: (id) => {
				onSelectModel(id);
				setActiveMenu(null);
				setMenuSearch("");
			}
		};
		return null;
	}, [
		activeMenu,
		categoryValue,
		categoryOptions,
		filters.brand,
		brandOptions,
		filters.model,
		modelOptions
	]);
	const filteredOptions = (0, import_react.useMemo)(() => {
		if (!currentMenuConfig) return [];
		const q = menuSearch.trim().toLowerCase();
		if (!q) return currentMenuConfig.options;
		return currentMenuConfig.options.filter((o) => `${o.label} ${o.sub ?? ""}`.toLowerCase().includes(q));
	}, [currentMenuConfig, menuSearch]);
	const showSearchInMenu = (currentMenuConfig?.options.length ?? 0) > 5;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "rtl",
		className: "w-full space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `grid gap-1.5 w-full ${showModel ? "grid-cols-3" : "grid-cols-2"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggleMenu("category"),
						"aria-expanded": activeMenu === "category",
						className: `w-full min-w-0 h-10 px-2 rounded-xl border transition-all flex items-center justify-between gap-1 overflow-hidden select-none ${categoryValue ? "bg-navy border-gold/70 text-gold shadow-sm ring-1 ring-gold/40" : "bg-navy/95 border-border/40 text-primary-foreground/90 hover:bg-navy"} ${activeMenu === "category" ? "ring-2 ring-gold" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 flex items-center gap-1 overflow-hidden text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary-foreground/50 text-[10px] shrink-0 font-medium",
								children: "التصنيف:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `truncate text-xs font-bold block flex-1 ${categoryValue ? "text-gold" : "text-primary-foreground"}`,
								children: selectedCategory ? selectedCategory.label : "الكل"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-3 shrink-0 transition-transform duration-200 ${categoryValue ? "text-gold" : "text-primary-foreground/60"} ${activeMenu === "category" ? "rotate-180" : ""}` })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggleMenu("brand"),
						"aria-expanded": activeMenu === "brand",
						className: `w-full min-w-0 h-10 px-2 rounded-xl border transition-all flex items-center justify-between gap-1 overflow-hidden select-none ${filters.brand ? "bg-navy border-gold/70 text-gold shadow-sm ring-1 ring-gold/40" : "bg-navy/95 border-border/40 text-primary-foreground/90 hover:bg-navy"} ${activeMenu === "brand" ? "ring-2 ring-gold" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 flex items-center gap-1 overflow-hidden text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary-foreground/50 text-[10px] shrink-0 font-medium",
								children: "الماركة:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `truncate text-xs font-bold block flex-1 ${filters.brand ? "text-gold" : "text-primary-foreground"}`,
								children: selectedBrand ? selectedBrand.label : "الكل"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-3 shrink-0 transition-transform duration-200 ${filters.brand ? "text-gold" : "text-primary-foreground/60"} ${activeMenu === "brand" ? "rotate-180" : ""}` })]
					}),
					showModel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggleMenu("model"),
						"aria-expanded": activeMenu === "model",
						className: `w-full min-w-0 h-10 px-2 rounded-xl border transition-all flex items-center justify-between gap-1 overflow-hidden select-none ${filters.model ? "bg-navy border-gold/70 text-gold shadow-sm ring-1 ring-gold/40" : "bg-navy/95 border-border/40 text-primary-foreground/90 hover:bg-navy"} ${activeMenu === "model" ? "ring-2 ring-gold" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 flex items-center gap-1 overflow-hidden text-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary-foreground/50 text-[10px] shrink-0 font-medium",
								children: "السيارة:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `truncate text-xs font-bold block flex-1 ${filters.model ? "text-gold" : "text-primary-foreground"}`,
								children: selectedModel ? selectedModel.label : "الكل"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-3 shrink-0 transition-transform duration-200 ${filters.model ? "text-gold" : "text-primary-foreground/60"} ${activeMenu === "model" ? "rotate-180" : ""}` })]
					})
				]
			}),
			currentMenuConfig && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				"data-filter-dialog": "open",
				className: "fixed inset-0 z-[60] flex items-start pt-[calc(env(safe-area-inset-top)+1.5rem)] md:items-center md:pt-4 justify-center p-4",
				onTouchMove: (e) => {
					if (!e.target.closest("[data-scroll-region]")) e.preventDefault();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150",
					onClick: () => {
						setActiveMenu(null);
						setMenuSearch("");
					},
					onTouchMove: (e) => e.preventDefault()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					dir: "rtl",
					className: "filter-modal-card relative z-10 w-full max-w-sm flex flex-col rounded-3xl border border-border bg-card shadow-2xl overflow-hidden animate-in zoom-in-95 fade-in duration-150",
					style: {
						touchAction: "none",
						maxHeight: viewportHeight ? `${Math.max(160, viewportHeight - 48)}px` : "min(46dvh, calc(100dvh - 310px))"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between px-5 py-3 border-b border-border bg-gradient-navy text-primary-foreground shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-gold animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-bold",
									children: currentMenuConfig.title
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setActiveMenu(null);
									setMenuSearch("");
								},
								className: "size-7 rounded-full bg-white/10 hover:bg-white/20 text-white grid place-items-center transition",
								"aria-label": "إغلاق",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})]
						}),
						showSearchInMenu && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-2.5 border-b border-border bg-muted/20 shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 bg-background border border-border rounded-xl px-3 h-9 focus-within:border-gold shadow-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground shrink-0" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										autoFocus: true,
										value: menuSearch,
										onChange: (e) => setMenuSearch(e.target.value),
										placeholder: "ابحث هنا…",
										className: "flex-1 bg-transparent outline-none text-base md:text-sm font-medium"
									}),
									menuSearch && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setMenuSearch(""),
										className: "text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							"data-scroll-region": true,
							className: "overflow-y-auto py-1 divide-y divide-border/20 flex-1",
							style: {
								WebkitOverflowScrolling: "touch",
								touchAction: "pan-y",
								overscrollBehavior: "contain"
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => currentMenuConfig.onSelect(""),
									className: `w-full flex items-center justify-between gap-3 px-5 py-3 text-sm transition-colors ${!currentMenuConfig.value ? "bg-gold/10 text-gold font-extrabold" : "hover:bg-muted text-foreground"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الكل" }), !currentMenuConfig.value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "size-4 text-gold shrink-0",
										strokeWidth: 2.5
									})]
								}),
								filteredOptions.map((o) => {
									const isSelected = o.id === currentMenuConfig.value;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => currentMenuConfig.onSelect(o.id),
										className: `w-full flex items-center justify-between gap-3 px-5 py-3 text-start transition-colors ${isSelected ? "bg-gold/10 text-gold font-extrabold" : "hover:bg-muted text-foreground"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-sm font-semibold truncate",
												children: o.label
											}), o.sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-xs text-muted-foreground truncate",
												dir: "ltr",
												children: o.sub
											})]
										}), isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "size-4 shrink-0 text-gold",
											strokeWidth: 2.5
										})]
									}, o.id);
								}),
								filteredOptions.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-center text-xs text-muted-foreground py-10",
									children: "لا توجد نتائج مطابقة"
								})
							]
						})
					]
				})]
			}),
			hasAnyFilterActive && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-1.5 pt-0.5",
				children: [
					categoryValue && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onSelectCategory(""),
						className: "inline-flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-full bg-gold/15 text-gold border border-gold/30 hover:bg-gold/25 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate max-w-[8rem]",
							children: selectedCategory?.label || "التصنيف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3 shrink-0" })]
					}),
					filters.brand && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onSelectBrand(""),
						className: "inline-flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-full bg-gold/15 text-gold border border-gold/30 hover:bg-gold/25 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate max-w-[8rem]",
							children: selectedBrand?.label || "الماركة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3 shrink-0" })]
					}),
					filters.model && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onSelectModel(""),
						className: "inline-flex items-center gap-1 text-[11px] font-medium px-2.5 py-1 rounded-full bg-gold/15 text-gold border border-gold/30 hover:bg-gold/25 transition",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate max-w-[8rem]",
							children: selectedModel?.label || "نوع السيارة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3 shrink-0" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: clearFilters,
						className: "text-[10px] text-muted-foreground hover:text-destructive underline px-1 py-0.5",
						children: "مسح الكل"
					})
				]
			})
		]
	});
}
//#endregion
export { ProductCard as n, thumbUrl as r, FilterBar as t };
