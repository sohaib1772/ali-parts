import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { r as useUnreadCounts } from "./notifications-DFPiacgQ.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { $ as Inbox, At as Bike, H as PackageCheck, St as CircleCheck, Tt as ChevronLeft, bt as CircleX, c as Truck, ft as Eye, t as X, tt as House, z as Package } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { f as ordersQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD, n as formatArabicDate } from "./format-CTK49jpu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as statusIcon, r as statusLabel, t as statusColor } from "./order-status-Chx_uF3Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/orders-B3k8QfpL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TRACK_STEPS = [
	{
		key: "received",
		label: "استلام",
		icon: Inbox
	},
	{
		key: "preparing",
		label: "تجهيز",
		icon: PackageCheck
	},
	{
		key: "packed",
		label: "تغليف",
		icon: Package
	},
	{
		key: "shipped",
		label: "شحن",
		icon: Truck
	},
	{
		key: "out_for_delivery",
		label: "خرج",
		icon: Bike
	},
	{
		key: "delivered",
		label: "تسليم",
		icon: House
	}
];
function OrderTracking({ status, pulse }) {
	if (status === "cancelled") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex items-center gap-2 rounded-xl bg-red-50 border border-red-200 px-3 py-2 text-red-700",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-bold",
			children: "تم إلغاء الطلب"
		})]
	});
	if (status === "delivered") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex items-center gap-2 rounded-xl bg-emerald-50 border border-emerald-200 px-3 py-2 text-emerald-700",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-bold",
			children: "تم تسليم الطلب بنجاح"
		})]
	});
	const activeIdx = TRACK_STEPS.findIndex((s) => s.key === status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mb-1.5 h-1.5 rounded-full bg-muted overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-y-0 right-0 bg-gradient-to-l from-gold via-gold to-amber-400 rounded-full transition-all duration-700",
				style: { width: `${activeIdx < 0 ? 0 : activeIdx / (TRACK_STEPS.length - 1) * 100}%` }
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-start justify-between gap-1",
			children: TRACK_STEPS.map((s, i) => {
				const done = i <= activeIdx;
				const active = i === activeIdx;
				const Icon = s.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-1 flex-1 min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `size-6 rounded-full grid place-items-center transition ${active ? `bg-gold text-navy ring-2 ring-gold/40 shadow-sm ${pulse ? "animate-pulse" : ""}` : done ? "bg-gold/90 text-navy" : "bg-muted text-muted-foreground"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `text-[9px] font-bold leading-tight text-center truncate w-full ${active ? "text-gold" : done ? "text-navy" : "text-muted-foreground"}`,
						children: s.label
					})]
				}, s.key);
			})
		})]
	});
}
function OrdersPage() {
	const { userId } = useAuth();
	const { data: orders = [] } = useQuery(ordersQuery(userId));
	const { orderIds: unreadOrderIds } = useUnreadCounts();
	const qc = useQueryClient();
	const [cancellingId, setCancellingId] = (0, import_react.useState)(null);
	const [pulseId, setPulseId] = (0, import_react.useState)(null);
	const statusRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	(0, import_react.useEffect)(() => {
		for (const o of orders) if (!statusRef.current.has(o.id)) statusRef.current.set(o.id, o.status);
	}, [orders]);
	const cancelOrder = async (e, id) => {
		e.preventDefault();
		e.stopPropagation();
		if (!confirm("هل تريد إلغاء هذا الطلب؟")) return;
		setCancellingId(id);
		const { error } = await supabase.rpc("cancel_my_order", { p_order_id: id });
		setCancellingId(null);
		if (error) toast.error(error.message || "تعذّر إلغاء الطلب");
		else {
			toast.success("تم إلغاء الطلب");
			qc.invalidateQueries({ queryKey: ["orders", userId] });
		}
	};
	(0, import_react.useEffect)(() => {
		if (!userId) return;
		const ch = supabase.channel(`orders-${userId}`).on("postgres_changes", {
			event: "UPDATE",
			schema: "public",
			table: "orders",
			filter: `user_id=eq.${userId}`
		}, (payload) => {
			const next = payload.new;
			const prev = statusRef.current.get(next.id);
			if (prev && prev !== next.status) {
				const label = statusLabel(next.status);
				if (next.status === "cancelled") toast.error(`تم إلغاء الطلب ${next.order_number ?? ""}`);
				else toast.success(`تحديث الطلب: ${label}`);
				setPulseId(next.id);
				setTimeout(() => setPulseId((p) => p === next.id ? null : p), 3e3);
			}
			statusRef.current.set(next.id, next.status);
			qc.invalidateQueries({ queryKey: ["orders", userId] });
		}).on("postgres_changes", {
			event: "INSERT",
			schema: "public",
			table: "orders",
			filter: `user_id=eq.${userId}`
		}, () => qc.invalidateQueries({ queryKey: ["orders", userId] })).subscribe();
		return () => {
			supabase.removeChannel(ch);
		};
	}, [userId, qc]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "طلباتي",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 pt-4 space-y-3 md:max-w-3xl md:mx-auto",
			children: orders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "py-20 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-20 rounded-full bg-muted grid place-items-center mx-auto mb-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "size-10 text-muted-foreground" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold mb-2",
						children: "لا توجد طلبات بعد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mb-6",
						children: "ستظهر طلباتك هنا بعد إتمام أول عملية شراء"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex px-6 py-3 rounded-2xl bg-gradient-gold text-navy font-bold shadow-gold",
						children: "ابدأ التسوق"
					})
				]
			}) : orders.map((o) => {
				const updated = unreadOrderIds.has(o.id);
				const StatusIcon = statusIcon(o.status);
				const hasUpdateAfterCreate = !!o.updated_at && o.updated_at !== o.created_at;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `bg-card rounded-2xl border p-4 shadow-card transition ${updated ? "border-gold ring-1 ring-gold/40" : "border-border"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-mono text-muted-foreground",
									children: o.order_number
								}),
								updated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-500 text-white",
									children: "تحديث جديد"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `ms-auto inline-flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-full ${statusColor(o.status)}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusIcon, { className: "size-3" }), statusLabel(o.status)]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: formatArabicDate(o.created_at)
						}),
						hasUpdateAfterCreate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[10px] text-gold font-semibold mb-2",
							children: ["آخر تحديث: ", formatArabicDate(o.updated_at)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between items-baseline mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-black text-navy",
								children: formatIQD(o.total_iqd)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4 text-muted-foreground" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderTracking, {
							status: o.status,
							pulse: pulseId === o.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/orders/$id",
								params: { id: o.id },
								className: "flex-1 h-9 rounded-xl bg-gradient-gold text-navy text-xs font-bold flex items-center justify-center gap-1.5 shadow-gold hover:brightness-105 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" }), "عرض التفاصيل والتتبع"]
							}), (o.status === "received" || o.status === "preparing") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: (e) => cancelOrder(e, o.id),
								disabled: cancellingId === o.id,
								className: "h-9 px-3 rounded-xl border border-destructive/40 text-destructive text-xs font-bold flex items-center justify-center gap-1 hover:bg-destructive/10 disabled:opacity-50 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" }), cancellingId === o.id ? "جاري..." : "إلغاء"]
							})]
						})
					]
				}, o.id);
			})
		})
	});
}
//#endregion
export { OrdersPage as component };
