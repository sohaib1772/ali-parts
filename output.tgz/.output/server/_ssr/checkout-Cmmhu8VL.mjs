import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as useAdjustedPrice, s as usePointsConfig } from "./admin-DdF3xehS.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { K as MapPin, P as Plus, X as LoaderCircle, c as Truck, l as TriangleAlert, mt as CreditCard, v as StickyNote, y as Sparkles } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { g as profileQuery, o as cartQuery, t as addressesQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD } from "./format-CTK49jpu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as shipmentCount, t as computeShipping } from "./shipping-leVkJgrK.mjs";
import { t as ProfileCompletionDialog } from "./profile-completion-BdIKZ-EV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-Cmmhu8VL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORE_NAME = "مكتب علي شوفرليت";
var STORE_LOGO = "/icon-512.png";
function OrderSubmitSplash({ message = "جاري إرسال طلبك..." }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-gradient-to-b from-[#0a1226] via-[#0f172a] to-[#020617]",
		dir: "rtl",
		role: "status",
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute top-[-15%] left-[-15%] w-[60%] h-[60%] rounded-full bg-amber-500/12 blur-[140px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute bottom-[-15%] right-[-15%] w-[60%] h-[60%] rounded-full bg-blue-400/10 blur-[140px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:36px_36px] opacity-[0.03]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 inset-x-10 h-px bg-gradient-to-r from-transparent via-gold/70 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex flex-col items-center animate-[fadeInUp_500ms_ease-out_both]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mb-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -inset-6 rounded-full bg-gradient-to-tr from-amber-500/50 to-amber-200/40 blur-3xl animate-pulse" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -m-3 rounded-[2rem] border border-gold/25" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -m-6 rounded-[2.5rem] border border-gold/10" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative size-40 rounded-[1.75rem] bg-gradient-to-br from-[#1e293b] to-[#0f172a] border-2 border-gold/40 flex items-center justify-center shadow-[0_0_80px_rgba(201,162,39,0.35)] overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: STORE_LOGO,
									alt: STORE_NAME,
									className: "max-h-28 max-w-28 object-contain drop-shadow-[0_0_20px_rgba(201,162,39,0.35)]"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-luxury text-4xl font-black tracking-tight text-white text-center px-8",
						children: STORE_NAME
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center gap-2 text-gold/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-body-lux text-sm",
							children: message
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 h-[3px] w-52 overflow-hidden rounded-full bg-white/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-1/3 bg-gradient-to-r from-transparent via-gold to-transparent animate-[splashBar_1.4s_ease-in-out_infinite]" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 inset-x-10 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `
        @keyframes splashBar { 0% { transform: translateX(-100%); } 100% { transform: translateX(320%); } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
      ` })
		]
	});
}
function CheckoutPage() {
	const { userId } = useAuth();
	const { data: items = [] } = useQuery(cartQuery(userId));
	const { data: addresses = [] } = useQuery(addressesQuery(userId));
	const { data: profile } = useQuery(profileQuery(userId));
	const [selectedAddr, setSelectedAddr] = (0, import_react.useState)(null);
	const [payment, setPayment] = (0, import_react.useState)("cod");
	const [placing, setPlacing] = (0, import_react.useState)(false);
	const [pointsInput, setPointsInput] = (0, import_react.useState)("");
	const [orderNote, setOrderNote] = (0, import_react.useState)("");
	const navigate = useNavigate();
	const qc = useQueryClient();
	const activeAddr = addresses.find((a) => a.id === (selectedAddr ?? addresses.find((x) => x.is_default)?.id ?? addresses[0]?.id));
	const adjust = useAdjustedPrice();
	const subtotal = items.reduce((s, i) => s + adjust(i.product?.price_iqd) * i.quantity, 0);
	const shippingCost = computeShipping(items);
	const shipmentCount$1 = (0, import_react.useMemo)(() => shipmentCount(items), [items]);
	const [showSplitAlert, setShowSplitAlert] = (0, import_react.useState)(false);
	const [alertShown, setAlertShown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!alertShown && items.length > 0 && shipmentCount$1 > 1) {
			setShowSplitAlert(true);
			setAlertShown(true);
		}
	}, [
		items.length,
		shipmentCount$1,
		alertShown
	]);
	const pointsCfg = usePointsConfig();
	const pointsBalance = Number(profile?.points_balance ?? 0);
	const maxBySubtotal = Math.floor(subtotal / pointsCfg.redeemRate);
	const maxByCap = Math.floor((subtotal + shippingCost) * pointsCfg.maxRedeemPct / 100 / pointsCfg.redeemRate);
	const maxPoints = Math.max(0, Math.min(pointsBalance, maxBySubtotal, maxByCap));
	const parsedPoints = Math.max(0, Math.min(maxPoints, Math.floor(Number(pointsInput) || 0)));
	const belowMin = parsedPoints > 0 && parsedPoints < pointsCfg.minRedeem;
	const effectivePoints = belowMin ? 0 : parsedPoints;
	const pointsDiscount = effectivePoints * pointsCfg.redeemRate;
	const total = Math.max(0, subtotal + shippingCost - pointsDiscount);
	const earnPreview = Math.floor(subtotal / 1e3) * pointsCfg.earnPer1000;
	const hasPhone = !!(profile?.phone && String(profile.phone).trim());
	const [showPhoneGate, setShowPhoneGate] = (0, import_react.useState)(false);
	const placeOrder = async (skipPhoneCheck = false) => {
		if (!activeAddr) return toast.error("اختر عنواناً أولاً");
		if (items.length === 0) return toast.error("السلة فارغة");
		if (!skipPhoneCheck && !hasPhone) {
			setShowPhoneGate(true);
			return;
		}
		setPlacing(true);
		try {
			const { data: orderId, error } = await supabase.rpc("place_order", {
				p_address: {
					label: activeAddr.label,
					full_name: activeAddr.full_name,
					phone: activeAddr.phone,
					city: activeAddr.city,
					area: activeAddr.area,
					street: activeAddr.street,
					notes: activeAddr.notes
				},
				p_payment: payment,
				p_points_used: effectivePoints,
				p_notes: orderNote.trim() || ""
			});
			if (error) throw error;
			if (!orderId) throw new Error("لم يُنشأ الطلب");
			qc.invalidateQueries({ queryKey: ["cart"] });
			qc.invalidateQueries({ queryKey: ["orders"] });
			qc.invalidateQueries({ queryKey: ["profile"] });
			toast.success("تم تأكيد الطلب بنجاح");
			await navigate({
				to: "/order-success/$id",
				params: { id: orderId }
			});
		} catch (err) {
			const msg = err?.message || err?.error_description || err?.hint || "";
			console.error("place_order failed", err);
			toast.error(msg ? `تعذّر إتمام الطلب: ${msg}` : "تعذّر إتمام الطلب");
			setPlacing(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, {
		wide: true,
		title: "إتمام الطلب",
		children: [
			placing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderSubmitSplash, { message: "جاري إرسال طلبك..." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 pt-4 space-y-4 md:max-w-2xl md:mx-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "عنوان التوصيل",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-gold" }),
						children: addresses.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/addresses",
							className: "flex items-center justify-center gap-2 h-12 rounded-xl border-2 border-dashed border-gold text-gold font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " إضافة عنوان"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [addresses.map((a) => {
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setSelectedAddr(a.id),
									className: `w-full text-start rounded-xl p-3 border-2 transition ${activeAddr?.id === a.id ? "border-gold bg-gold/5" : "border-border bg-muted/30"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-bold text-sm",
										children: [
											a.full_name,
											" · ",
											a.phone
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground",
										children: [
											a.city,
											" · ",
											a.area,
											" · ",
											a.street
										]
									})]
								}, a.id);
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/addresses",
								className: "block text-xs text-gold text-center font-bold",
								children: "إدارة العناوين"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "كلفة التوصيل",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-4 text-gold" }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-muted-foreground",
							children: shippingCost > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["كلفة التوصيل: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-navy",
								children: formatIQD(shippingCost)
							})] }) : "توصيل مجاني"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "طريقة الدفع",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-4 text-gold" }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayOption, {
								active: payment === "cod",
								onClick: () => setPayment("cod"),
								label: "الدفع عند الاستلام"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayOption, {
								active: payment === "transfer",
								onClick: () => setPayment("transfer"),
								label: "حوالة"
							})]
						})
					}),
					pointsBalance > 0 && subtotal > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "استخدام نقاط الولاء",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-gold" }),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted-foreground mb-2",
								children: [
									"رصيدك: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-bold text-navy",
										children: [pointsBalance, " نقطة"]
									}),
									" (≈ ",
									formatIQD(pointsBalance * pointsCfg.redeemRate),
									") · كل نقطة = ",
									pointsCfg.redeemRate,
									" د.ع"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									inputMode: "numeric",
									min: 0,
									max: maxPoints,
									value: pointsInput,
									onChange: (e) => setPointsInput(e.target.value),
									placeholder: "0",
									className: "flex-1 h-11 rounded-xl border-2 border-border px-3 text-sm font-bold bg-background"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setPointsInput(String(maxPoints)),
									className: "px-3 h-11 rounded-xl bg-gold/10 text-gold text-xs font-bold border border-gold/30",
									children: [
										"استخدم الحد الأقصى (",
										maxPoints,
										")"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1.5 text-[11px] text-muted-foreground",
								children: [
									"الحد الأقصى لهذا الطلب: ",
									maxPoints,
									" نقطة (خصم حتى ",
									pointsCfg.maxRedeemPct,
									"% من الطلب)",
									pointsCfg.minRedeem > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										" · الحد الأدنى للاستبدال: ",
										pointsCfg.minRedeem,
										" نقطة"
									] })
								]
							}),
							belowMin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 text-xs text-destructive font-bold",
								children: [
									"الحد الأدنى للاستبدال هو ",
									pointsCfg.minRedeem,
									" نقطة — لن يُطبّق الخصم."
								]
							}),
							effectivePoints > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 text-xs text-success font-bold",
								children: ["خصم: ", formatIQD(pointsDiscount)]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "ملاحظة على الطلب",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "size-4 text-gold" }),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: orderNote,
							onChange: (e) => setOrderNote(e.target.value),
							rows: 3,
							maxLength: 500,
							placeholder: "أي تعليمات إضافية للتوصيل أو التجهيز...",
							className: "w-full rounded-xl border-2 border-border bg-background p-3 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-gold"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-card rounded-2xl border border-border p-4 shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold text-gold mb-3",
								children: "ملخص الطلب"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: [items.length, " منتج"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatIQD(subtotal) })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "التوصيل"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatIQD(shippingCost) })]
							}),
							effectivePoints > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-sm py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: [
										"خصم نقاط (",
										effectivePoints,
										")"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-success",
									children: ["- ", formatIQD(pointsDiscount)]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-border mt-2 pt-3 flex justify-between items-baseline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: "الإجمالي"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-2xl font-black text-navy",
									children: formatIQD(total)
								})]
							}),
							subtotal > 0 && earnPreview > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 text-[11px] text-muted-foreground",
								children: [
									"ستكسب ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-bold text-gold",
										children: [earnPreview, " نقطة"]
									}),
									" عند تسليم الطلب"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => placeOrder(),
						disabled: placing || items.length === 0,
						className: "w-full h-14 rounded-2xl bg-gradient-gold text-navy font-black shadow-gold flex items-center justify-center gap-2 disabled:opacity-50",
						children: [placing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin" }), "تأكيد الطلب"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileCompletionDialog, {
				open: showPhoneGate,
				onOpenChange: setShowPhoneGate,
				dismissible: false,
				onSaved: () => placeOrder(true)
			}),
			showSplitAlert && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-4",
				onClick: () => setShowSplitAlert(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					onClick: (e) => e.stopPropagation(),
					className: "w-full max-w-sm bg-card rounded-2xl border border-border shadow-card p-5 animate-in fade-in zoom-in-95",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 rounded-full bg-gold/15 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-5 text-gold" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-base font-black",
								children: "تنبيه بخصوص التوصيل"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm text-muted-foreground leading-6 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "المنتجات التي اخترتها لا يمكن شحنها ضمن شحنة واحدة حفاظًا على سلامتها أثناء النقل." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "لذلك سيتم تقسيم الطلب إلى شحنتين أو أكثر، وسيتم احتساب رسوم توصيل مستقلة لكل شحنة." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-muted-foreground/80",
									children: "يرجى العلم: هذا التنبيه يخص المنتجات الحالية في سلة التسوق فقط، ولا ينطبق على جميع المنتجات داخل التطبيق."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-bold text-foreground",
									children: "شكرًا لتفهمكم."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setShowSplitAlert(false),
							className: "mt-4 w-full h-12 rounded-2xl bg-gradient-gold text-navy font-black shadow-gold",
							children: "فهمت"
						})
					]
				})
			})
		]
	});
}
function Section({ title, icon, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-card rounded-2xl border border-border p-4 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 mb-3",
			children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-bold",
				children: title
			})]
		}), children]
	});
}
function PayOption({ active, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick,
		className: `rounded-xl p-3 border-2 text-sm font-bold transition ${active ? "border-gold bg-gold/5" : "border-border"}`,
		children: label
	});
}
//#endregion
export { CheckoutPage as component };
