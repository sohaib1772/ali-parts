import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { a as objectType, o as stringType } from "../_libs/zod.mjs";
import { n as parseExternalApiConfig, t as EXTERNAL_API_SETTING_KEYS } from "./external-api-D6j_ceOa.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import { n as requireAdminOtp } from "./require-admin-otp-DgUpC_62.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/external-api.functions-BFyrrazh.js
async function assertAdmin(ctx) {
	const { data, error } = await ctx.supabase.rpc("has_role", {
		_user_id: ctx.userId,
		_role: "admin"
	});
	if (error || !data) throw new Error("Forbidden");
}
async function loadConfig(ctx) {
	const { data, error } = await ctx.supabase.from("app_settings").select("key, value").in("key", [
		EXTERNAL_API_SETTING_KEYS.baseUrl,
		EXTERNAL_API_SETTING_KEYS.keyHeader,
		EXTERNAL_API_SETTING_KEYS.apiKey,
		EXTERNAL_API_SETTING_KEYS.endpoints
	]);
	if (error) throw new Error(error.message);
	const map = {};
	for (const row of data ?? []) map[row.key] = row.value ?? "";
	return parseExternalApiConfig(map);
}
async function executeExternalApiCall(config, endpointId, body, query) {
	const endpoint = config.endpoints.find((e) => e.id === endpointId);
	if (!endpoint) throw new Error("Endpoint not found");
	const apiKey = config.apiKey || process.env.EXTERNAL_API_KEY || "";
	if (!apiKey) throw new Error("API key not configured");
	const url = new URL(endpoint.path, config.baseUrl);
	if (query) for (const [k, v] of Object.entries(query)) url.searchParams.set(k, v);
	const headers = { "Content-Type": "application/json" };
	if (config.keyHeader.toLowerCase() === "authorization") headers[config.keyHeader] = `Bearer ${apiKey}`;
	else headers[config.keyHeader] = apiKey;
	const response = await fetch(url.toString(), {
		method: endpoint.method,
		headers,
		body: endpoint.method !== "GET" && body ? JSON.stringify(body) : void 0
	});
	let responseBody = "";
	const contentType = response.headers.get("content-type") || "";
	try {
		if (contentType.includes("application/json")) responseBody = JSON.stringify(await response.json());
		else responseBody = await response.text();
	} catch {
		responseBody = "";
	}
	return {
		status: response.status,
		ok: response.ok,
		body: responseBody
	};
}
var getExternalApiConfig_createServerFn_handler = createServerRpc({
	id: "6c49bb0238b91b871165aa77feb8aee3320ff6649c3acb78372f82b46f763ec2",
	name: "getExternalApiConfig",
	filename: "src/lib/external-api.functions.ts"
}, (opts) => getExternalApiConfig.__executeServer(opts));
var getExternalApiConfig = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getExternalApiConfig_createServerFn_handler, async ({ context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	return await loadConfig(context);
});
var TestInput = objectType({ endpointId: stringType() });
var testExternalApi_createServerFn_handler = createServerRpc({
	id: "52dc8af364db74059a235f303e6179f5005b9ae2df01dc0ac1d56a836f25d925",
	name: "testExternalApi",
	filename: "src/lib/external-api.functions.ts"
}, (opts) => testExternalApi.__executeServer(opts));
var testExternalApi = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => TestInput.parse(d)).handler(testExternalApi_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	await requireAdminOtp(context);
	return await executeExternalApiCall(await loadConfig(context), data.endpointId);
});
//#endregion
export { getExternalApiConfig_createServerFn_handler, testExternalApi_createServerFn_handler };
