import { $ as Inbox, At as Bike, H as PackageCheck, St as CircleCheck, bt as CircleX, c as Truck, yt as Circle, z as Package } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-status-Chx_uF3Y.js
function statusLabel(s) {
	return {
		received: "تم الاستلام",
		preparing: "جاري التجهيز",
		packed: "تم التغليف",
		shipped: "شحن للتوصيل",
		out_for_delivery: "خرج للتوصيل",
		delivered: "تم التسليم",
		cancelled: "ملغى"
	}[s] ?? s;
}
function statusColor(s) {
	return {
		received: "bg-blue-100 text-blue-700 border border-blue-200",
		preparing: "bg-amber-100 text-amber-700 border border-amber-200",
		packed: "bg-orange-100 text-orange-700 border border-orange-200",
		shipped: "bg-indigo-100 text-indigo-700 border border-indigo-200",
		out_for_delivery: "bg-purple-100 text-purple-700 border border-purple-200",
		delivered: "bg-emerald-100 text-emerald-700 border border-emerald-200",
		cancelled: "bg-red-100 text-red-700 border border-red-200"
	}[s] ?? "bg-muted text-navy border border-border";
}
function statusIcon(s) {
	return {
		received: Inbox,
		preparing: PackageCheck,
		packed: Package,
		shipped: Truck,
		out_for_delivery: Bike,
		delivered: CircleCheck,
		cancelled: CircleX
	}[s] ?? Circle;
}
//#endregion
export { statusIcon as n, statusLabel as r, statusColor as t };
