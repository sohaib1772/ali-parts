import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useSetting } from "./admin-DdF3xehS.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { s as whatsappLink } from "./format-CTK49jpu.mjs";
import { t as WhatsappIcon } from "./icons-kUk6pI7L.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/messages-jHLN-48y.js
var import_jsx_runtime = require_jsx_runtime();
function MessagesPage() {
	const waNumber = useSetting("whatsapp_number");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "الرسائل",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-6 pt-8 text-center md:max-w-2xl md:mx-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-20 rounded-full bg-whatsapp/10 grid place-items-center mx-auto mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappIcon, { className: "size-10 text-whatsapp" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold mb-2",
					children: "تواصل معنا مباشرة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mb-6",
					children: "فريق خدمة العملاء متاح للرد على استفساراتك عبر واتساب"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: whatsappLink("مرحباً، أحتاج للمساعدة", waNumber),
					target: "_blank",
					rel: "noreferrer",
					className: "inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-whatsapp text-white font-bold shadow-luxe",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappIcon, { className: "size-5" }), " افتح المحادثة"]
				})
			]
		})
	});
}
//#endregion
export { MessagesPage as component };
