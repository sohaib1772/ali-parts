import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as createServerRpc } from "./createServerRpc-TAUNrjZd.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { n as requireAdminOtp } from "./require-admin-otp-DgUpC_62.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/replacement-admin.functions-CTIpAoC0.js
var VALID_STATUSES = [
	"pending",
	"in_review",
	"approved",
	"rejected",
	"resolved"
];
var adminUpdateReplacementStatus_createServerFn_handler = createServerRpc({
	id: "b0a7f145ec6f9b1777b18bc17b2fe54867b63e8839a7fc7e84b771672fe5cdfa",
	name: "adminUpdateReplacementStatus",
	filename: "src/lib/replacement-admin.functions.ts"
}, (opts) => adminUpdateReplacementStatus.__executeServer(opts));
var adminUpdateReplacementStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => {
	if (!input || typeof input.id !== "string" || !input.id) throw new Error("id required");
	if (!VALID_STATUSES.includes(input.status)) throw new Error("invalid status");
	return input;
}).handler(adminUpdateReplacementStatus_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: isAdmin } = await supabase.rpc("has_role", {
		_user_id: userId,
		_role: "admin"
	});
	if (!isAdmin) throw new Error("Forbidden");
	await requireAdminOtp(context);
	const { supabaseAdmin } = await import("./client.server-oKvUI9Ey.mjs");
	const { sendReplacementPush } = await import("./web-push.server-CiXMek4O.mjs");
	const { data: updated, error } = await supabaseAdmin.from("replacement_requests").update({ status: data.status }).eq("id", data.id).select("id, user_id, product_name_ar, status").single();
	if (error || !updated) throw new Error(error?.message ?? "Update failed");
	try {
		await sendReplacementPush({
			userId: updated.user_id,
			productName: updated.product_name_ar ?? "طلب استبدال",
			status: updated.status,
			requestId: updated.id
		});
	} catch (err) {
		console.error("[push] send failed", err);
	}
	return { ok: true };
});
//#endregion
export { adminUpdateReplacementStatus_createServerFn_handler };
