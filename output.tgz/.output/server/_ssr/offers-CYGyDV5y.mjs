import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { M as require_jsx_runtime, d as DialogContent, f as DialogDescription, h as DialogTitle, l as Dialog, m as DialogPortal, p as DialogOverlay, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useSuspenseQuery, c as useQueryClient, n as useMutation, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as useAdminAccessStatus, o as useIsAdmin } from "./admin-DdF3xehS.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as Send, Dt as Check, L as Pencil, O as Search, Pt as Ban, S as Shield, Tt as ChevronLeft, W as MessageCircle, a as Users, f as Trash2, i as Volume2, r as VolumeX, rt as Heart, t as X, y as Sparkles } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { n as bannersQuery } from "./queries-CNdOTkej.mjs";
import { t as Button } from "./button-Ccjfysxk.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Bw448kqG.mjs";
import { a as objectType, o as stringType, t as booleanType } from "../_libs/zod.mjs";
import { c as moderatorListUsers, d as usePrefetchNearbyVideo, f as useServerFn, l as setPrefetchPaused, o as createSsrRpc, r as adminSetUserBlocked, t as Textarea, u as useCachedVideo } from "./admin.functions-ByyqQhlH.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/offers-CYGyDV5y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AddBannerCommentInput = objectType({
	bannerId: stringType().uuid(),
	content: stringType().trim().min(1).max(1e3),
	isAdminReply: booleanType().optional().default(false)
});
var addBannerComment = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => AddBannerCommentInput.parse(data)).handler(createSsrRpc("a65be21a0bec8f5bb59d48e7b826841ece93c7685b2bc55d22658de1de4c9873"));
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out md:max-w-md md:left-1/2 md:right-auto md:-translate-x-1/2", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute end-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
function CommentsSkeleton({ count = 5 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: Array.from({ length: count }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-9 rounded-full shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 space-y-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-24" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-3/4" })
				]
			})]
		}, i))
	});
}
function OffersPage() {
	const { data: banners } = useSuspenseQuery(bannersQuery());
	const [openCommentsFor, setOpenCommentsFor] = (0, import_react.useState)(null);
	const [activeIndex, setActiveIndex] = (0, import_react.useState)(0);
	const handleActive = (0, import_react.useCallback)((index) => {
		setActiveIndex((current) => current === index ? current : index);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, {
		showHeader: false,
		showNav: false,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-0 bg-black overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "absolute top-4 start-4 z-30 size-10 rounded-full bg-black/40 backdrop-blur text-white grid place-items-center border border-white/20",
					"aria-label": "رجوع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5 rtl:rotate-180" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-4 inset-x-0 z-20 flex justify-center pointer-events-none",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-1.5 text-[11px] font-bold text-white bg-black/40 border border-white/20 rounded-full px-3 py-1 backdrop-blur",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3" }), " ريلز العروض"]
					})
				}),
				banners.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full grid place-items-center text-white/70 text-sm",
					children: "لا توجد عروض حالياً."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full overflow-y-auto snap-y snap-mandatory scroll-smooth",
					style: { scrollbarWidth: "none" },
					children: banners.map((b, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReelItem, {
						banner: b,
						index,
						shouldLoad: Math.abs(index - activeIndex) <= 1,
						onActive: handleActive,
						onOpenComments: () => setOpenCommentsFor(b.id)
					}, b.id))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentsSheet, {
			bannerId: openCommentsFor,
			onClose: () => setOpenCommentsFor(null)
		})]
	});
}
function ReelItem({ banner, index, shouldLoad, onActive, onOpenComments }) {
	const [muted, setMuted] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return false;
		return window.sessionStorage.getItem("reels_muted") === "1";
	});
	const videoRef = (0, import_react.useRef)(null);
	const containerRef = (0, import_react.useRef)(null);
	const video = banner.video_url ?? null;
	const cachedVideo = useCachedVideo(shouldLoad ? video : null);
	const prefetchRef = usePrefetchNearbyVideo(video, { rootMargin: "120% 0px" });
	const { userId } = useAuth();
	(0, import_react.useEffect)(() => {
		const onChange = (e) => {
			const next = e.detail;
			setMuted(next);
			const el = videoRef.current;
			if (el) el.muted = next;
		};
		window.addEventListener("reels-muted-change", onChange);
		return () => window.removeEventListener("reels-muted-change", onChange);
	}, []);
	(0, import_react.useEffect)(() => {
		const box = containerRef.current;
		if (!box) return;
		const io = new IntersectionObserver((entries) => {
			for (const e of entries) if (e.isIntersecting && e.intersectionRatio > .6) {
				onActive(index);
				const el = videoRef.current;
				if (!el) return;
				el.muted = muted;
				const p = el.play();
				if (p && typeof p.catch === "function") p.catch(() => {
					el.muted = true;
					setMuted(true);
					el.play().catch(() => {});
				});
			} else videoRef.current?.pause();
		}, { threshold: [
			0,
			.6,
			1
		] });
		io.observe(box);
		return () => io.disconnect();
	}, [
		video,
		muted,
		shouldLoad,
		index,
		onActive
	]);
	const likes = useLikes(banner.id, userId, shouldLoad);
	const commentsCount = useCommentsCount(banner.id, shouldLoad);
	const lastTapRef = (0, import_react.useRef)(0);
	const [burst, setBurst] = (0, import_react.useState)(0);
	const singleTapTimerRef = (0, import_react.useRef)(null);
	const handleMediaTap = () => {
		const now = Date.now();
		if (now - lastTapRef.current < 400) {
			lastTapRef.current = 0;
			if (singleTapTimerRef.current) {
				clearTimeout(singleTapTimerRef.current);
				singleTapTimerRef.current = null;
			}
			if (!likes.liked && !likes.pending) likes.toggle();
			setBurst((b) => b + 1);
			return;
		}
		lastTapRef.current = now;
		if (singleTapTimerRef.current) clearTimeout(singleTapTimerRef.current);
		singleTapTimerRef.current = setTimeout(() => {
			const el = videoRef.current;
			if (el) if (el.paused) el.play().catch(() => {});
			else el.pause();
			singleTapTimerRef.current = null;
		}, 260);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: (node) => {
			containerRef.current = node;
			prefetchRef(node);
		},
		className: "relative w-full h-[100dvh] snap-start snap-always bg-black",
		children: [
			video && shouldLoad ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				src: cachedVideo ?? video,
				poster: banner.image_url || void 0,
				autoPlay: true,
				muted,
				loop: true,
				playsInline: true,
				preload: "auto",
				disableRemotePlayback: true,
				className: "absolute inset-0 w-full h-full object-contain",
				onClick: handleMediaTap,
				onVolumeChange: (e) => {
					const el = e.currentTarget;
					setMuted(el.muted);
				},
				onWaiting: () => setPrefetchPaused(true),
				onStalled: () => setPrefetchPaused(true),
				onPlaying: () => setPrefetchPaused(false),
				onCanPlayThrough: () => setPrefetchPaused(false),
				onPause: () => setPrefetchPaused(false)
			}) : banner.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: banner.image_url,
				alt: banner.title_ar ?? "",
				className: "absolute inset-0 w-full h-full object-contain",
				onClick: handleMediaTap
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-black" }),
			burst > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 size-32 text-red-500 fill-current drop-shadow-2xl animate-[likePop_700ms_ease-out_forwards] z-30" }, burst),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-black via-black/60 to-transparent pointer-events-none" }),
			video && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					const el = videoRef.current;
					const next = !muted;
					if (el) {
						el.muted = next;
						if (!next) {
							el.volume = 1;
							el.play().catch(() => {});
						}
					}
					setMuted(next);
					try {
						window.sessionStorage.setItem("reels_muted", next ? "1" : "0");
					} catch {}
					window.dispatchEvent(new CustomEvent("reels-muted-change", { detail: next }));
				},
				"aria-label": muted ? "تشغيل الصوت" : "كتم الصوت",
				className: "absolute top-4 end-4 z-20 size-10 rounded-full bg-black/40 backdrop-blur text-white grid place-items-center border border-white/20",
				children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute end-3 bottom-32 z-20 flex flex-col items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => likes.toggle(),
					disabled: likes.pending,
					className: "flex flex-col items-center gap-1",
					"aria-label": likes.liked ? "إلغاء الإعجاب" : "إعجاب",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `size-11 rounded-full grid place-items-center border transition ${likes.liked ? "bg-red-500/90 border-red-400 text-white" : "bg-black/40 border-white/20 text-white backdrop-blur"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: `size-5 ${likes.liked ? "fill-current" : ""}` })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-white text-[11px] font-bold drop-shadow",
						children: likes.count
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onOpenComments,
					className: "flex flex-col items-center gap-1",
					"aria-label": "التعليقات",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "size-11 rounded-full grid place-items-center bg-black/40 border border-white/20 text-white backdrop-blur",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-white text-[11px] font-bold drop-shadow",
						children: commentsCount
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 p-4 pb-6 text-white z-10",
				children: [
					banner.title_ar && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-black leading-tight drop-shadow",
						children: banner.title_ar
					}),
					banner.subtitle_ar && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-white/90 mt-1 drop-shadow",
						children: banner.subtitle_ar
					}),
					banner.link && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: banner.link,
						className: "inline-flex items-center gap-1 mt-3 bg-gold text-navy font-bold text-sm rounded-full px-4 py-1.5",
						children: "تسوّق الآن"
					})
				]
			})
		]
	});
}
function useLikes(bannerId, userId, enabled = true) {
	const qc = useQueryClient();
	const { data, isLoading } = useQuery({
		queryKey: [
			"banner_likes",
			bannerId,
			userId
		],
		enabled,
		staleTime: 3e4,
		queryFn: async () => {
			const { count } = await supabase.from("banner_likes").select("banner_id", {
				count: "exact",
				head: true
			}).eq("banner_id", bannerId);
			let liked = false;
			if (userId) {
				const { data } = await supabase.from("banner_likes").select("banner_id").eq("banner_id", bannerId).eq("user_id", userId).maybeSingle();
				liked = !!data;
			}
			return {
				count: count ?? 0,
				liked
			};
		}
	});
	const m = useMutation({
		mutationFn: async () => {
			if (!userId) throw new Error("auth");
			if (data?.liked) {
				const { error } = await supabase.from("banner_likes").delete().eq("banner_id", bannerId).eq("user_id", userId);
				if (error) throw error;
			} else {
				const { error } = await supabase.from("banner_likes").insert({
					banner_id: bannerId,
					user_id: userId
				});
				if (error) throw error;
			}
		},
		onSuccess: () => qc.invalidateQueries({ queryKey: ["banner_likes", bannerId] }),
		onError: (e) => {
			if (e.message === "auth") toast.error("سجّل الدخول أولاً");
			else toast.error("تعذر تنفيذ الإجراء");
		}
	});
	return {
		liked: !!data?.liked,
		count: data?.count ?? 0,
		toggle: () => m.mutate(),
		pending: m.isPending || isLoading
	};
}
function useCommentsCount(bannerId, enabled = true) {
	const { data } = useQuery({
		queryKey: ["banner_comments_count", bannerId],
		enabled,
		staleTime: 3e4,
		queryFn: async () => {
			const { count } = await supabase.from("banner_comments").select("id", {
				count: "exact",
				head: true
			}).eq("banner_id", bannerId);
			return count ?? 0;
		}
	});
	return data ?? 0;
}
function CommentsSheet({ bannerId, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: !!bannerId,
		onOpenChange: (v) => {
			if (!v) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
			side: "bottom",
			className: "h-[85dvh] p-0 rounded-t-3xl flex flex-col",
			children: bannerId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentsSheetContent, { bannerId })
		})
	});
}
function CommentsSheetContent({ bannerId }) {
	const isAdmin = useIsAdmin();
	const { canBlock } = useAdminAccessStatus();
	const canModerate = isAdmin || canBlock;
	const [tab, setTab] = (0, import_react.useState)("comments");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, {
		className: "px-4 pt-4 pb-2 border-b",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
			className: "text-base flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tab === "comments" ? "التعليقات" : "المستخدمون" }), canModerate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "inline-flex rounded-lg border border-border overflow-hidden text-[11px] font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab("comments"),
					className: `px-3 py-1.5 flex items-center gap-1 ${tab === "comments" ? "bg-gold text-navy" : "bg-transparent text-muted-foreground"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-3.5" }), " تعليقات"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab("users"),
					className: `px-3 py-1.5 flex items-center gap-1 ${tab === "users" ? "bg-gold text-navy" : "bg-transparent text-muted-foreground"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5" }), " مستخدمون"]
				})]
			})]
		})
	}), tab === "comments" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentsBody, { bannerId }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersPanel, {})] });
}
function UsersPanel() {
	const qc = useQueryClient();
	const [search, setSearch] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [detail, setDetail] = (0, import_react.useState)(null);
	const { data, isLoading, isFetching, refetch } = useQuery({
		queryKey: ["moderator", "users"],
		queryFn: () => moderatorListUsers(),
		staleTime: 3e4
	});
	const users = data?.users ?? [];
	const filtered = (() => {
		const s = search.trim().toLowerCase();
		let out = users;
		if (filter === "blocked") out = out.filter((u) => u.is_blocked);
		else if (filter === "active") out = out.filter((u) => u.is_active);
		if (!s) return out;
		return out.filter((u) => [
			u.full_name,
			u.email,
			u.phone,
			u.profile_phone
		].filter(Boolean).some((v) => String(v).toLowerCase().includes(s)));
	})();
	const block = useMutation({
		mutationFn: async ({ uid, blocked }) => {
			await adminSetUserBlocked({ data: {
				user_id: uid,
				blocked,
				reason: blocked ? "تم حظرك بسبب مخالفة قوانين المجتمع. يرجى الالتزام بالكلام المحترم." : "تم رفع الحظر عن حسابك، يمكنك الآن التعليق بشكل طبيعي."
			} });
		},
		onSuccess: (_d, vars) => {
			qc.invalidateQueries({ queryKey: ["moderator", "users"] });
			qc.invalidateQueries({ queryKey: ["banner_comments"] });
			setDetail((prev) => prev ? {
				...prev,
				is_blocked: vars.blocked
			} : prev);
			toast.success(vars.blocked ? "تم حظر المستخدم" : "تم رفع الحظر");
		},
		onError: (e) => toast.error(e.message || "تعذر التنفيذ")
	});
	const fmt = (iso) => {
		if (!iso) return "—";
		try {
			return new Date(iso).toLocaleString("ar-IQ", {
				dateStyle: "short",
				timeStyle: "short"
			});
		} catch {
			return iso;
		}
	};
	const chip = (v, label, count) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setFilter(v),
		className: `px-3 py-1.5 rounded-full text-[11px] font-bold border transition ${filter === v ? "bg-gold text-navy border-gold" : "bg-card text-muted-foreground border-border"}`,
		children: [label, typeof count === "number" ? ` (${count})` : ""]
	});
	const blockedCount = users.filter((u) => u.is_blocked).length;
	const activeCount = users.filter((u) => u.is_active).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex-1 overflow-y-auto px-4 py-3 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 bg-card border border-border rounded-xl px-3 py-2 focus-within:border-gold",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: search,
						onChange: (e) => setSearch(e.target.value),
						placeholder: "ابحث بالاسم أو الهاتف أو الإيميل…",
						className: "flex-1 bg-transparent outline-none text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => refetch(),
						className: "text-xs text-gold font-bold px-2 disabled:opacity-50",
						disabled: isFetching,
						children: isFetching ? "…" : "تحديث"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 flex-wrap",
				children: [
					chip("all", "الكل", users.length),
					chip("active", "متصلون", activeCount),
					chip("blocked", "محظورون", blockedCount)
				]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "جاري التحميل…"
			}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-sm text-muted-foreground py-8",
				children: "لا يوجد مستخدمون مطابقون"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: filtered.map((u) => {
					const displayPhone = u.profile_phone || u.phone;
					const label = u.full_name || (displayPhone ? `+${String(displayPhone).replace(/\D/g, "")}` : u.email ?? "بلا اسم");
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setDetail(u),
						className: "w-full text-start bg-card border border-border rounded-2xl p-3 flex items-center gap-3 hover:border-gold/50 transition",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `size-11 rounded-full grid place-items-center font-black text-lg shrink-0 ${u.is_blocked ? "bg-destructive/15 text-destructive" : u.is_active ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`,
								children: (label[0] ?? "?").toUpperCase()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-bold truncate flex items-center gap-1.5",
									children: [
										label,
										u.is_blocked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-0.5 text-[9px] font-black text-destructive bg-destructive/10 px-1.5 py-0.5 rounded-full",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-2.5" }), " محظور"]
										}),
										u.is_active && !u.is_blocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] font-black text-success bg-success/10 px-1.5 py-0.5 rounded-full",
											children: "متصل"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] text-muted-foreground",
									children: ["آخر دخول: ", fmt(u.last_sign_in_at)]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-gold font-bold",
								children: "تفاصيل"
							})
						]
					}, u.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: !!detail,
				onOpenChange: (v) => {
					if (!v) setDetail(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					side: "bottom",
					className: "rounded-t-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
						className: "text-base",
						children: "تفاصيل المستخدم"
					}) }), detail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 space-y-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `size-14 rounded-full grid place-items-center font-black text-xl ${detail.is_blocked ? "bg-destructive/15 text-destructive" : "bg-muted"}`,
									children: ((detail.full_name || detail.email || "?")[0] ?? "?").toUpperCase()
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-black truncate",
										children: detail.full_name || "بلا اسم"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground truncate",
										dir: "ltr",
										children: detail.profile_phone || detail.phone ? `+${String(detail.profile_phone || detail.phone).replace(/\D/g, "")}` : detail.email ?? "—"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-[12px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-card border border-border rounded-xl p-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-muted-foreground",
											children: "الحالة"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold",
											children: detail.is_blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-destructive",
												children: "محظور"
											}) : detail.is_active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-success",
												children: "متصل الآن"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "غير متصل"
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-card border border-border rounded-xl p-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-muted-foreground",
											children: "تاريخ الإنشاء"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold",
											children: fmt(detail.created_at)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-card border border-border rounded-xl p-2 col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-muted-foreground",
											children: "آخر دخول"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold",
											children: fmt(detail.last_sign_in_at)
										})]
									}),
									detail.email && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-card border border-border rounded-xl p-2 col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] text-muted-foreground",
											children: "البريد"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold truncate",
											dir: "ltr",
											children: detail.email
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: detail.is_blocked ? "outline" : "destructive",
								className: "w-full",
								disabled: block.isPending,
								onClick: () => block.mutate({
									uid: detail.id,
									blocked: !detail.is_blocked
								}),
								children: detail.is_blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 me-1" }), " رفع الحظر"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4 me-1" }), " حظر المستخدم"] })
							})
						]
					})]
				})
			})
		]
	});
}
function CommentsBody({ bannerId }) {
	const { userId } = useAuth();
	const isAdmin = useIsAdmin();
	const { canBlock } = useAdminAccessStatus();
	const qc = useQueryClient();
	const [text, setText] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [asAdmin, setAsAdmin] = (0, import_react.useState)(false);
	const PAGE_SIZE = 10;
	const [limit, setLimit] = (0, import_react.useState)(PAGE_SIZE);
	const addBannerCommentFn = useServerFn(addBannerComment);
	const { data, isLoading, isFetching } = useQuery({
		queryKey: [
			"banner_comments",
			bannerId,
			limit
		],
		queryFn: async () => {
			const { data, error, count } = await supabase.from("banner_comments").select("*", { count: "exact" }).eq("banner_id", bannerId).order("created_at", { ascending: false }).range(0, limit - 1);
			if (error) throw error;
			const rows = data ?? [];
			const ids = Array.from(new Set(rows.map((r) => r.user_id)));
			if (ids.length) {
				const { data: profs } = await supabase.rpc("get_public_profiles", { _ids: ids });
				const map = new Map((profs ?? []).map((p) => [p.id, p]));
				for (const r of rows) r.profile = map.get(r.user_id) ?? null;
			}
			return {
				rows,
				total: count ?? rows.length
			};
		},
		placeholderData: (prev) => prev
	});
	const comments = data?.rows ?? [];
	const total = data?.total ?? 0;
	const hasMore = comments.length < total;
	const loadingMore = isFetching && !isLoading;
	(0, import_react.useEffect)(() => {
		const channel = supabase.channel(`banner_comments:${bannerId}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "banner_comments",
			filter: `banner_id=eq.${bannerId}`
		}, () => {
			qc.invalidateQueries({ queryKey: ["banner_comments", bannerId] });
			qc.invalidateQueries({ queryKey: ["banner_comments_count", bannerId] });
		}).subscribe();
		return () => {
			supabase.removeChannel(channel);
		};
	}, [bannerId, qc]);
	const addOrEdit = useMutation({
		mutationFn: async (vars) => {
			const body = vars.body;
			if (!body) throw new Error("empty");
			if (!userId) throw new Error("auth");
			const { containsProfanity } = await import("./profanity-yxzDpQKi.mjs");
			if (containsProfanity(body)) throw new Error("profanity");
			if (vars.editingId) {
				const { error } = await supabase.from("banner_comments").update({ content: body }).eq("id", vars.editingId);
				if (error) throw error;
			} else await addBannerCommentFn({ data: {
				bannerId,
				content: body,
				isAdminReply: isAdmin && vars.asAdmin
			} });
		},
		onMutate: async (vars) => {
			const body = vars.body;
			if (!body || !userId) return;
			const key = [
				"banner_comments",
				bannerId,
				limit
			];
			await qc.cancelQueries({ queryKey: key });
			const previous = qc.getQueryData(key);
			if (vars.editingId) qc.setQueryData(key, (d) => d ? {
				...d,
				rows: d.rows.map((r) => r.id === vars.editingId ? {
					...r,
					content: body
				} : r)
			} : d);
			else {
				const prevProfile = (previous?.rows ?? []).find((r) => r.user_id === userId)?.profile ?? null;
				const optimistic = {
					id: `optimistic-${Date.now()}`,
					banner_id: bannerId,
					user_id: userId,
					parent_id: null,
					content: body,
					is_admin_reply: isAdmin && vars.asAdmin,
					created_at: (/* @__PURE__ */ new Date()).toISOString(),
					updated_at: (/* @__PURE__ */ new Date()).toISOString(),
					profile: prevProfile
				};
				qc.setQueryData(key, (d) => d ? {
					rows: [optimistic, ...d.rows],
					total: d.total + 1
				} : {
					rows: [optimistic],
					total: 1
				});
				qc.setQueryData(["banner_comments_count", bannerId], (n) => (n ?? 0) + 1);
			}
			setText("");
			setEditingId(null);
			setAsAdmin(false);
			return {
				previous,
				isEdit: !!vars.editingId
			};
		},
		onSuccess: (_data, _vars, ctx) => {
			qc.invalidateQueries({ queryKey: ["banner_comments", bannerId] });
			qc.invalidateQueries({ queryKey: ["banner_comments_count", bannerId] });
			toast.success(ctx?.isEdit ? "تم تحديث التعليق" : "تم نشر تعليقك");
		},
		onError: (e, _vars, ctx) => {
			if (ctx?.previous) qc.setQueryData([
				"banner_comments",
				bannerId,
				limit
			], ctx.previous);
			qc.invalidateQueries({ queryKey: ["banner_comments_count", bannerId] });
			if (e.message === "auth") toast.error("سجّل الدخول لكتابة تعليق");
			else if (e.message === "profanity") toast.error("تعليقك يحتوي كلمات مسيئة. يرجى الالتزام بالاحترام.");
			else if (e.message !== "empty") {
				const msg = e.message?.trim();
				toast.error(msg && msg.length < 200 ? msg : "تعذر الإرسال");
			}
		}
	});
	const del = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("banner_comments").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["banner_comments", bannerId] });
			qc.invalidateQueries({ queryKey: ["banner_comments_count", bannerId] });
			toast.success("تم الحذف");
		},
		onError: () => toast.error("تعذر الحذف")
	});
	const block = useMutation({
		mutationFn: async ({ uid, blocked }) => {
			await adminSetUserBlocked({ data: {
				user_id: uid,
				blocked,
				reason: blocked ? "تم حظرك بسبب تعليق مخالف لقوانين المجتمع. يرجى الالتزام بالكلام المحترم وتجنب الإساءة أو السبام أو المحتوى غير اللائق." : "تم رفع الحظر عن حسابك، يمكنك الآن التعليق والتفاعل بشكل طبيعي مع الالتزام بالقوانين."
			} });
		},
		onSuccess: (_data, vars) => {
			qc.invalidateQueries({ queryKey: ["banner_comments", bannerId] });
			qc.invalidateQueries({ queryKey: ["admin", "block-log"] });
			qc.invalidateQueries({ queryKey: ["admin", "blocked-users"] });
			toast.success(vars.blocked ? "تم حظر المستخدم وإرسال الإشعار" : "تم رفع الحظر عن المستخدم");
		},
		onError: (e) => toast.error(e.message || "تعذر الحظر")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex-1 overflow-y-auto px-4 py-3 space-y-4",
		children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentsSkeleton, { count: 5 }) : comments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center text-sm text-muted-foreground py-10",
			children: "لا توجد تعليقات بعد — كن أول من يعلّق!"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			comments.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentRowView, {
				c,
				currentUserId: userId,
				isAdmin,
				canBlock,
				onEdit: () => {
					setEditingId(c.id);
					setText(c.content);
				},
				onDelete: () => del.mutate(c.id),
				onBlock: () => {
					const next = !!!c.profile?.is_blocked;
					if (block.isPending) return;
					block.mutate({
						uid: c.user_id,
						blocked: next
					});
				}
			}, c.id)),
			loadingMore && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommentsSkeleton, { count: 3 }),
			hasMore && !loadingMore && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pt-1 pb-3 flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					size: "sm",
					onClick: () => setLimit((n) => n + PAGE_SIZE),
					children: [
						"عرض المزيد (",
						total - comments.length,
						")"
					]
				})
			})
		] })
	}), userId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t p-3 space-y-2 bg-background",
		children: [isAdmin && !editingId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-2 text-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				checked: asAdmin,
				onChange: (e) => setAsAdmin(e.target.checked),
				className: "size-4"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-3 text-gold" }), " نشر كردّ رسمي من الإدارة"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: editingId ? "تعديل التعليق…" : "أضف تعليقاً…",
					className: "min-h-[42px] max-h-32 resize-none flex-1",
					maxLength: 1e3
				}),
				editingId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon",
					onClick: () => {
						setEditingId(null);
						setText("");
					},
					"aria-label": "إلغاء",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "icon",
					onClick: () => addOrEdit.mutate({
						body: text.trim(),
						editingId,
						asAdmin
					}),
					disabled: addOrEdit.isPending || !text.trim(),
					"aria-label": "إرسال",
					children: editingId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
				})
			]
		})]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-t p-4 text-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/auth",
			className: "text-sm font-bold text-gold underline",
			children: "سجّل الدخول للتعليق"
		})
	})] });
}
function CommentRowView({ c, currentUserId, isAdmin, canBlock, onEdit, onDelete, onBlock }) {
	const mine = currentUserId === c.user_id;
	const name = c.profile?.full_name || (c.is_admin_reply ? "الإدارة" : "مستخدم");
	const initials = (name || "?").slice(0, 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "size-9 rounded-full bg-muted grid place-items-center text-sm font-bold overflow-hidden shrink-0",
			children: c.profile?.avatar_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: c.profile.avatar_url,
				alt: "",
				className: "w-full h-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: initials })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-bold",
							children: name
						}),
						c.is_admin_reply && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 text-[10px] font-bold text-gold bg-gold/10 border border-gold/30 rounded-full px-1.5 py-0.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-2.5" }), " الإدارة"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground",
							children: new Date(c.created_at).toLocaleDateString("ar-IQ")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm mt-0.5 whitespace-pre-wrap break-words",
					children: c.content
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 mt-1 text-[11px] text-muted-foreground",
					children: [
						mine && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onEdit,
							className: "inline-flex items-center gap-1 hover:text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3" }), " تعديل"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onDelete,
							className: "inline-flex items-center gap-1 hover:text-destructive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), " حذف"]
						})] }),
						!mine && isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onDelete,
							className: "inline-flex items-center gap-1 hover:text-destructive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" }), " حذف"]
						}),
						!mine && canBlock && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onBlock,
							className: `inline-flex items-center gap-1 ${c.profile?.is_blocked ? "hover:text-success" : "hover:text-destructive"}`,
							children: [c.profile?.is_blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-3" }), c.profile?.is_blocked ? "رفع الحظر" : "حظر المستخدم"]
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { OffersPage as component };
