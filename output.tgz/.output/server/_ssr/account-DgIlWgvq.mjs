import { o as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Q2B4x7UN.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as useAuth } from "./use-auth-TMJ5erER.mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { c as useQueryClient, o as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as useAdminAccessStatus, s as usePointsConfig } from "./admin-DdF3xehS.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ShieldCheck, Dt as Check, K as MapPin, L as Pencil, Ot as Camera, Q as Info, S as Shield, Tt as ChevronLeft, W as MessageCircle, X as LoaderCircle, Y as LogOut, f as Trash2, jt as Bell, k as ScrollText, rt as Heart, t as X, y as Sparkles, z as Package } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { g as profileQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD } from "./format-CTK49jpu.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-DTjZvKIx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as imageCompression } from "../_libs/browser-image-compression.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-DgIlWgvq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SIGNED_TTL_SECONDS = 3600 * 24 * 365 * 5;
/**
* Upload a user avatar to the private `avatars` bucket and return a signed URL
* suitable for direct use in <img src>. Stored path is `<uid>/avatar-<ts>.<ext>`.
*/
async function uploadAvatar(userId, file) {
	if (!userId) throw new Error("Not signed in");
	let toUpload = file;
	let contentType = file.type || "image/jpeg";
	let ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
	try {
		toUpload = await imageCompression(file, {
			maxWidthOrHeight: 400,
			maxSizeMB: .15,
			useWebWorker: true,
			fileType: "image/webp",
			initialQuality: .82
		});
		contentType = "image/webp";
		ext = "webp";
	} catch {}
	const path = `${userId}/avatar-${Date.now()}.${ext}`;
	const { error: upErr } = await supabase.storage.from("avatars").upload(path, toUpload, {
		cacheControl: "3600",
		upsert: true,
		contentType
	});
	if (upErr) throw upErr;
	const { data: signed, error: signErr } = await supabase.storage.from("avatars").createSignedUrl(path, SIGNED_TTL_SECONDS);
	if (signErr || !signed?.signedUrl) throw signErr ?? /* @__PURE__ */ new Error("تعذر توليد رابط الصورة");
	return signed.signedUrl;
}
function AccountPage() {
	const { user, userId } = useAuth();
	const { data: profile } = useQuery(profileQuery(userId));
	const { hasAnyAccess, isLoading: adminAccessLoading } = useAdminAccessStatus();
	const pointsCfg = usePointsConfig();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const fileInputRef = (0, import_react.useRef)(null);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [deleteOpen, setDeleteOpen] = (0, import_react.useState)(false);
	const [deleteConfirm, setDeleteConfirm] = (0, import_react.useState)("");
	const [deleting, setDeleting] = (0, import_react.useState)(false);
	const [editingName, setEditingName] = (0, import_react.useState)(false);
	const [nameDraft, setNameDraft] = (0, import_react.useState)("");
	const [savingName, setSavingName] = (0, import_react.useState)(false);
	const startEditName = () => {
		setNameDraft(profile?.full_name ?? "");
		setEditingName(true);
	};
	const saveName = async () => {
		if (!userId) return;
		const trimmed = nameDraft.trim();
		if (trimmed.length < 2) {
			toast.error("الاسم قصير جداً");
			return;
		}
		if (trimmed.length > 60) {
			toast.error("الاسم طويل جداً");
			return;
		}
		setSavingName(true);
		try {
			const { error } = await supabase.from("profiles").update({ full_name: trimmed }).eq("id", userId);
			if (error) throw error;
			await supabase.auth.updateUser({ data: { full_name: trimmed } });
			qc.invalidateQueries({ queryKey: ["profile", userId] });
			toast.success("تم تحديث الاسم");
			setEditingName(false);
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "تعذر تحديث الاسم");
		} finally {
			setSavingName(false);
		}
	};
	const onPickAvatar = async (file) => {
		if (!userId) return;
		if (!file.type.startsWith("image/")) {
			toast.error("يرجى اختيار صورة");
			return;
		}
		if (file.size > 5 * 1024 * 1024) {
			toast.error("الحد الأقصى ٥ ميغابايت");
			return;
		}
		setUploading(true);
		try {
			const url = await uploadAvatar(userId, file);
			const { error } = await supabase.from("profiles").update({ avatar_url: url }).eq("id", userId);
			if (error) throw error;
			qc.invalidateQueries({ queryKey: ["profile", userId] });
			toast.success("تم تحديث صورتك");
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "تعذر رفع الصورة");
		} finally {
			setUploading(false);
		}
	};
	const signOut = async () => {
		await qc.cancelQueries();
		qc.clear();
		await supabase.auth.signOut();
		toast.success("تم تسجيل الخروج");
		navigate({
			to: "/auth",
			replace: true
		});
	};
	const CONFIRM_WORD = "حذف";
	const deleteAccount = async () => {
		if (deleteConfirm.trim() !== CONFIRM_WORD) return;
		setDeleting(true);
		try {
			const avatarPath = profile?.avatar_url;
			if (userId && avatarPath && avatarPath.includes("/avatars/")) {
				const key = avatarPath.split("/avatars/")[1]?.split("?")[0];
				if (key) await supabase.storage.from("avatars").remove([key]).catch(() => {});
			}
			const { error } = await supabase.rpc("delete_my_account");
			if (error) throw error;
			await qc.cancelQueries();
			qc.clear();
			await supabase.auth.signOut();
			toast.success("تم حذف حسابك", { description: "نأسف لرحيلك." });
			navigate({
				to: "/auth",
				replace: true
			});
		} catch (e) {
			console.error("[account] delete failed", e);
			toast.error("تعذّر حذف الحساب", {
				description: e?.message ? String(e.message).slice(0, 140) : "يرجى المحاولة مرة أخرى أو التواصل معنا.",
				duration: 7e3
			});
			setDeleting(false);
		}
	};
	const links = [
		...hasAnyAccess ? [{
			to: "/admin",
			label: "لوحة الإدارة",
			icon: ShieldCheck
		}] : [],
		{
			to: "/orders",
			label: "طلباتي السابقة",
			icon: Package
		},
		{
			to: "/favorites",
			label: "المفضلة",
			icon: Heart
		},
		{
			to: "/addresses",
			label: "العناوين",
			icon: MapPin
		},
		{
			to: "/notifications",
			label: "الإشعارات",
			icon: Bell
		},
		{
			to: "/contact",
			label: "اتصل بنا",
			icon: MessageCircle
		},
		{
			to: "/about",
			label: "من نحن",
			icon: Info
		},
		{
			to: "/privacy",
			label: "سياسة الخصوصية",
			icon: Shield
		},
		{
			to: "/terms",
			label: "الشروط والأحكام",
			icon: ScrollText
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, {
		wide: true,
		title: "حسابي",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-4 md:max-w-2xl md:mx-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-gradient-navy text-primary-foreground rounded-3xl p-5 shadow-luxe",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => fileInputRef.current?.click(),
								disabled: uploading,
								"aria-label": "تغيير الصورة الشخصية",
								className: "relative size-16 rounded-full overflow-hidden bg-gradient-gold text-navy font-black text-2xl grid place-items-center shadow-gold group",
								children: [
									profile?.avatar_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: profile.avatar_url,
										alt: "",
										className: "absolute inset-0 w-full h-full object-cover"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: (profile?.full_name?.[0] ?? user?.email?.[0] ?? "?").toUpperCase() }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition grid place-items-center",
										children: uploading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 text-white animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-5 text-white" })
									}),
									uploading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute inset-0 bg-black/50 grid place-items-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 text-white animate-spin" })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileInputRef,
								type: "file",
								accept: "image/*",
								className: "hidden",
								onChange: (e) => {
									const f = e.target.files?.[0];
									if (f) onPickAvatar(f);
									e.target.value = "";
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [
									editingName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												autoFocus: true,
												value: nameDraft,
												onChange: (e) => setNameDraft(e.target.value),
												onKeyDown: (e) => {
													if (e.key === "Enter") saveName();
													if (e.key === "Escape") setEditingName(false);
												},
												maxLength: 60,
												placeholder: "اسمك الكامل",
												className: "flex-1 min-w-0 bg-white/10 border border-gold/40 rounded-lg px-2 py-1 text-sm font-bold text-primary-foreground placeholder:text-primary-foreground/50 outline-none focus:border-gold"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: saveName,
												disabled: savingName,
												"aria-label": "حفظ",
												className: "size-7 rounded-lg bg-gold text-navy grid place-items-center disabled:opacity-60",
												children: savingName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setEditingName(false),
												"aria-label": "إلغاء",
												className: "size-7 rounded-lg bg-white/10 text-primary-foreground grid place-items-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
											})
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-extrabold text-lg truncate",
											children: profile?.full_name ?? "عميل Ali Parts"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: startEditName,
											"aria-label": "تعديل الاسم",
											className: "size-6 rounded-md bg-white/10 hover:bg-white/20 text-gold grid place-items-center shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-gold truncate",
										children: user?.email
									}),
									profile?.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-primary-foreground/70",
										children: profile.phone
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => fileInputRef.current?.click(),
										disabled: uploading,
										className: "mt-1 inline-flex items-center gap-1 text-[11px] text-gold hover:underline disabled:opacity-60",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3" }),
											" ",
											profile?.avatar_url ? "تغيير الصورة" : "إضافة صورة شخصية"
										]
									})
								]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 bg-gradient-gold text-navy rounded-2xl p-4 shadow-gold flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-11 rounded-full bg-navy/10 grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold opacity-70",
								children: "رصيد نقاطك"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-2xl font-black leading-tight",
								children: [
									profile?.points_balance ?? 0,
									" نقطة",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs font-bold opacity-70",
										children: [" ≈ ", formatIQD(Number(profile?.points_balance ?? 0) * pointsCfg.redeemRate)]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] opacity-70",
								children: pointsCfg.cardText
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 bg-card rounded-2xl border border-border shadow-card overflow-hidden",
					children: [adminAccessLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-4 py-3.5 border-b border-border text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-9 rounded-xl bg-gold/10 text-gold grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold flex-1",
							children: "جاري التحقق من صلاحيات الإدارة…"
						})]
					}), links.map((l, i) => {
						const Icon = l.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: l.to,
							className: `flex items-center gap-3 px-4 py-3.5 hover:bg-muted transition ${i < links.length - 1 ? "border-b border-border" : ""}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-9 rounded-xl bg-gold/10 text-gold grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-semibold flex-1",
									children: l.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4 text-muted-foreground" })
							]
						}, l.to);
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: signOut,
					className: "w-full mt-4 h-12 rounded-2xl border border-destructive/40 text-destructive font-bold flex items-center justify-center gap-2 hover:bg-destructive/5 transition",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), " تسجيل الخروج"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						setDeleteConfirm("");
						setDeleteOpen(true);
					},
					className: "w-full mt-3 mb-2 h-11 rounded-2xl text-destructive/80 text-sm font-bold flex items-center justify-center gap-2 hover:bg-destructive/5 transition",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " حذف الحساب"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
			open: deleteOpen,
			onOpenChange: (o) => {
				if (!deleting) setDeleteOpen(o);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
				dir: "rtl",
				className: "max-w-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-12 rounded-full bg-destructive/15 grid place-items-center mb-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-6 text-destructive" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
							className: "text-base",
							children: "حذف الحساب نهائياً"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs leading-relaxed space-y-2 text-start",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "لا يمكن التراجع عن هذا الإجراء." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-destructive mb-1",
										children: "سيتم حذف:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "list-disc ps-5 space-y-0.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "بياناتك الشخصية (الاسم، الهاتف، الصورة)" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "عناوين التوصيل المحفوظة" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "السلة والمفضلة" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الإشعارات ونقاط الولاء" })
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold mb-1",
										children: "سيتم الاحتفاظ به:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "list-disc ps-5 space-y-0.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "سجلّات طلباتك السابقة تُحفظ للأغراض المحاسبية والقانونية، بعد فصلها عن حسابك (لن تبقى مرتبطة بك)." })
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "pt-1",
										children: [
											"للتأكيد، اكتب ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
												className: "text-destructive",
												children: "حذف"
											}),
											" في الحقل أدناه."
										]
									})
								]
							})
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: deleteConfirm,
						onChange: (e) => setDeleteConfirm(e.target.value),
						placeholder: "حذف",
						disabled: deleting,
						className: "text-center",
						"aria-label": "تأكيد الحذف"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, {
						className: "gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
							disabled: deleting,
							children: "إلغاء"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
							onClick: (e) => {
								e.preventDefault();
								deleteAccount();
							},
							disabled: deleting || deleteConfirm.trim() !== "حذف",
							className: "bg-destructive text-destructive-foreground hover:bg-destructive/90 disabled:opacity-50",
							children: deleting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin me-1" }), " جاري الحذف…"] }) : "حذف حسابي نهائياً"
						})]
					})
				]
			})
		})]
	});
}
//#endregion
export { AccountPage as component };
