import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as useInfiniteQuery } from "../_libs/tanstack__react-query.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Tt as ChevronLeft, ot as Flame } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { h as productsInfiniteQuery } from "./queries-CNdOTkej.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as useStorefrontFilters, t as applyStorefrontFilters } from "./storefront-filters-DpSWbFTB.mjs";
import { n as ProductCard, t as FilterBar } from "./filter-bar-DFyaSNY5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products-eFtLmCul.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTER_OPTIONS = [
	{
		value: "all",
		label: "الكل"
	},
	{
		value: "new",
		label: "جديد"
	},
	{
		value: "used",
		label: "مستعمل"
	}
];
function AllProductsPage() {
	const [condition, setCondition] = (0, import_react.useState)("all");
	const [autoLoadAll, setAutoLoadAll] = (0, import_react.useState)(false);
	const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isPending, isError, error, isFetchNextPageError, refetch } = useInfiniteQuery(productsInfiniteQuery(condition === "all" ? null : condition));
	const loadMoreRef = (0, import_react.useRef)(null);
	const { filters } = useStorefrontFilters();
	const anyFilter = !!(filters.category || filters.brand || filters.model || filters.q.trim());
	const products = applyStorefrontFilters(data?.pages.flat() ?? [], filters);
	(0, import_react.useEffect)(() => {
		if (anyFilter && hasNextPage && !isFetchingNextPage && !isFetchNextPageError) setAutoLoadAll(true);
	}, [
		anyFilter,
		hasNextPage,
		isFetchingNextPage,
		isFetchNextPageError
	]);
	(0, import_react.useEffect)(() => {
		if (isFetchNextPageError && error) {
			console.error("[products] فشل تحميل الدفعة التالية", error);
			toast.error("تعذّر تحميل المزيد من المنتجات", {
				description: "يرجى التحقق من الاتصال بالإنترنت والمحاولة مرة أخرى.",
				action: {
					label: "إعادة المحاولة",
					onClick: () => {
						setAutoLoadAll(true);
						fetchNextPage();
					}
				}
			});
		}
	}, [
		isFetchNextPageError,
		error,
		fetchNextPage
	]);
	(0, import_react.useEffect)(() => {
		if (!autoLoadAll) return;
		if (hasNextPage && !isFetchingNextPage && !isFetchNextPageError) fetchNextPage();
	}, [
		autoLoadAll,
		hasNextPage,
		isFetchingNextPage,
		isFetchNextPageError,
		fetchNextPage
	]);
	(0, import_react.useEffect)(() => {
		const el = loadMoreRef.current;
		if (!el) return;
		const observer = new IntersectionObserver((entries) => {
			if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage && !isFetchNextPageError && !autoLoadAll) setAutoLoadAll(true);
		}, { rootMargin: "200px" });
		observer.observe(el);
		return () => observer.disconnect();
	}, [
		hasNextPage,
		isFetchingNextPage,
		fetchNextPage,
		isFetchNextPageError,
		autoLoadAll
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		wide: true,
		title: "المنتجات",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex items-center gap-1 text-xs text-muted-foreground mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-3.5 rotate-180" }), " الرئيسية"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 mb-4 p-3 rounded-2xl bg-destructive/10 border border-destructive/20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-10 rounded-xl bg-destructive/20 border border-destructive/30 grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-5 text-destructive" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-base font-extrabold leading-tight",
							children: "جميع المنتجات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground",
							children: isPending ? "جاري التحميل..." : `جميع المنتجات المتوفرة (${products.length})`
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 mb-4",
					children: FILTER_OPTIONS.map((opt) => {
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								setCondition(opt.value);
								setAutoLoadAll(false);
							},
							className: `flex-1 h-9 rounded-xl text-xs font-bold border transition ${condition === opt.value ? "bg-navy text-primary-foreground border-navy" : "bg-card text-muted-foreground border-border hover:border-navy/50"}`,
							children: opt.label
						}, opt.value);
					})
				}),
				isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 pb-8",
					children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rounded-2xl bg-muted h-64 animate-pulse" }, i))
				}) : isError && products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center py-16 px-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold text-destructive mb-2",
							children: "تعذّر تحميل المنتجات"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground mb-4",
							children: "حدث خطأ أثناء جلب المنتجات. يرجى التحقق من الاتصال والمحاولة مجدداً."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => refetch(),
							className: "h-9 px-4 rounded-xl bg-navy text-primary-foreground text-xs font-bold",
							children: "إعادة المحاولة"
						})
					]
				}) : products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center text-muted-foreground text-sm py-16",
					children: "لا توجد منتجات حالياً في هذا الفلتر."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 pb-8",
					children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: loadMoreRef,
					className: "h-16 flex items-center justify-center text-xs text-muted-foreground",
					children: isFetchingNextPage ? autoLoadAll ? "جاري تحميل باقي المنتجات..." : "جاري تحميل المزيد..." : isFetchNextPageError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setAutoLoadAll(true);
							fetchNextPage();
						},
						className: "text-destructive font-bold underline underline-offset-4",
						children: "فشل التحميل — اضغط لإعادة المحاولة"
					}) : hasNextPage ? "مرر للأسفل لعرض المزيد" : "وصلت إلى نهاية المنتجات"
				})] })
			]
		})
	});
}
//#endregion
export { AllProductsPage as component };
