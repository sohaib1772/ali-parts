import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { M as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useSuspenseQuery, t as useInfiniteQuery } from "../_libs/tanstack__react-query.mjs";
import { c as useSetting, i as useAdjustedPrice } from "./admin-DdF3xehS.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as Play, Tt as ChevronLeft, i as Volume2, ot as Flame, p as Timer, r as VolumeX, xt as CircleDot, y as Sparkles } from "../_libs/lucide-react.mjs";
import { t as PageShell } from "./page-shell-F-TIhBMg.mjs";
import { c as dealsQuery, h as productsInfiniteQuery, n as bannersQuery, r as bestSellersQuery, s as categoriesQuery, u as featuredProductsQuery } from "./queries-CNdOTkej.mjs";
import { i as formatIQD, s as whatsappLink } from "./format-CTK49jpu.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as useStorefrontFilters, t as applyStorefrontFilters } from "./storefront-filters-DpSWbFTB.mjs";
import { t as WhatsappIcon } from "./icons-kUk6pI7L.mjs";
import { n as ProductCard, r as thumbUrl, t as FilterBar } from "./filter-bar-DFyaSNY5.mjs";
import { t as useEmblaCarousel } from "../_libs/embla-carousel-react+[...].mjs";
import { t as Autoplay } from "../_libs/embla-carousel-autoplay.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DnHo6mrC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* The button is viewport-anchored, so it has to clear BottomNav twice over:
* the 5rem offset clears the nav's own height, and the safe-area inset clears
* the Android system nav bar that the nav reserves through its own
* `pb-[env(safe-area-inset-bottom)]`. With a bare `bottom-20` the button lands
* inside that reserved strip and disappears behind the nav on a device with
* 3-button navigation. z-50 keeps it above BottomNav (z-40), which previously
* won purely on DOM order.
*/
function FloatingWhatsapp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: whatsappLink("السلام عليكم، أرغب بالاستفسار عن قطعة", useSetting("whatsapp_number")),
		target: "_blank",
		rel: "noreferrer",
		"aria-label": "تواصل واتساب",
		className: "floating-whatsapp-btn fixed z-50 bottom-[calc(5rem+env(safe-area-inset-bottom))] start-4 size-14 rounded-full bg-whatsapp text-white grid place-items-center shadow-luxe animate-pulse hover:animate-none hover:scale-105 transition",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappIcon, { className: "size-7" })
	});
}
function HomePage() {
	const { data: categories } = useSuspenseQuery(categoriesQuery());
	const { data: featured } = useSuspenseQuery(featuredProductsQuery());
	const { data: deals } = useSuspenseQuery(dealsQuery());
	const { data: banners } = useSuspenseQuery(bannersQuery());
	const { data: bestSellers } = useSuspenseQuery(bestSellersQuery());
	const { filters } = useStorefrontFilters();
	const filteredDeals = applyStorefrontFilters(deals, filters);
	const dealIds = new Set(filteredDeals.slice(0, 4).map((p) => p.id));
	const filteredFeatured = applyStorefrontFilters(featured, filters).filter((p) => !dealIds.has(p.id));
	const filteredBestSellers = applyStorefrontFilters(bestSellers, filters);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroCarousel, { banners }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "الأقسام",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleDot, { className: "size-4 text-gold" }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-3 px-4",
					children: categories.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/category/$id",
						params: { id: c.id },
						className: "group flex flex-col items-center gap-2.5 p-3 rounded-2xl bg-card border border-border/60 shadow-card hover:shadow-luxe hover:-translate-y-0.5 transition-all active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-full aspect-square rounded-xl bg-gradient-to-br from-muted/80 to-background flex items-center justify-center overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryIcon, {
								category: c,
								index: i
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-bold text-center leading-tight text-foreground line-clamp-2 min-h-[2rem] flex items-center justify-center",
							children: c.name_ar
						})]
					}, c.id))
				})
			}),
			filteredDeals.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LimitedOffers, { deals: filteredDeals }),
			filteredFeatured.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "منتجات مميزة",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-gold" }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 px-4",
					children: filteredFeatured.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				})
			}),
			filteredBestSellers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "الأكثر مبيعاً",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, { className: "size-4 text-destructive" }),
				href: "/best-sellers",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 px-4",
					children: filteredBestSellers.slice(0, 6).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllProductsInfinite, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingWhatsapp, {})
		]
	});
}
function AllProductsInfinite() {
	const [enabled, setEnabled] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const t = window.setTimeout(() => setEnabled(true), 1800);
		return () => window.clearTimeout(t);
	}, []);
	const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isFetchNextPageError, error } = useInfiniteQuery({
		...productsInfiniteQuery(),
		enabled
	});
	const sentinelRef = (0, import_react.useRef)(null);
	const { filters } = useStorefrontFilters();
	const anyFilter = !!(filters.category || filters.brand || filters.model || filters.q.trim());
	const raw = data?.pages.flat() ?? [];
	const products = applyStorefrontFilters(raw, filters);
	(0, import_react.useEffect)(() => {
		if (anyFilter && hasNextPage && !isFetchingNextPage && !isFetchNextPageError) fetchNextPage();
	}, [
		anyFilter,
		hasNextPage,
		isFetchingNextPage,
		isFetchNextPageError,
		fetchNextPage
	]);
	(0, import_react.useEffect)(() => {
		if (isFetchNextPageError && error) {
			console.error("[home:allProducts] فشل تحميل الدفعة التالية", error);
			toast.error("تعذّر تحميل المزيد من المنتجات", {
				description: "يرجى التحقق من الاتصال بالإنترنت والمحاولة مرة أخرى.",
				action: {
					label: "إعادة المحاولة",
					onClick: () => fetchNextPage()
				}
			});
		}
	}, [
		isFetchNextPageError,
		error,
		fetchNextPage
	]);
	(0, import_react.useEffect)(() => {
		const el = sentinelRef.current;
		if (!el) return;
		const io = new IntersectionObserver((entries) => {
			if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage && !isFetchNextPageError) fetchNextPage();
		}, { rootMargin: "400px" });
		io.observe(el);
		return () => io.disconnect();
	}, [
		hasNextPage,
		isFetchingNextPage,
		fetchNextPage,
		isFetchNextPageError
	]);
	if (!enabled || raw.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
		title: "جميع المنتجات",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-gold" }),
		children: [products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "px-4 text-center text-muted-foreground text-sm py-8",
			children: "لا توجد منتجات مطابقة للفلتر الحالي."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 px-4",
			children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: sentinelRef,
			className: "h-16 flex items-center justify-center text-xs text-muted-foreground",
			children: isFetchingNextPage ? "جاري تحميل المزيد..." : isFetchNextPageError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => fetchNextPage(),
				className: "text-destructive font-bold underline underline-offset-4",
				children: "فشل التحميل — اضغط لإعادة المحاولة"
			}) : hasNextPage ? "مرر للأسفل لعرض المزيد" : "وصلت إلى نهاية المنتجات"
		})]
	});
}
function Section({ title, href, icon, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 flex items-center gap-2 mb-3",
			children: [
				icon,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-extrabold",
					children: title
				}),
				href && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: href,
					className: "ms-auto text-xs font-semibold text-gold flex items-center gap-0.5",
					children: ["الكل ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-3.5" })]
				})
			]
		}), children]
	});
}
function categoryBg(index) {
	const styles = [
		"bg-gradient-to-br from-amber-50 to-amber-100 text-amber-600",
		"bg-gradient-to-br from-rose-50 to-rose-100 text-rose-600",
		"bg-gradient-to-br from-slate-50 to-slate-100 text-slate-600",
		"bg-gradient-to-br from-yellow-50 to-yellow-100 text-yellow-600",
		"bg-gradient-to-br from-sky-50 to-sky-100 text-sky-600",
		"bg-gradient-to-br from-emerald-50 to-emerald-100 text-emerald-600",
		"bg-gradient-to-br from-indigo-50 to-indigo-100 text-indigo-600",
		"bg-gradient-to-br from-orange-50 to-orange-100 text-orange-600",
		"bg-gradient-to-br from-violet-50 to-violet-100 text-violet-600",
		"bg-gradient-to-br from-teal-50 to-teal-100 text-teal-600"
	];
	return styles[index % styles.length];
}
function CategoryIcon({ category, index }) {
	if (category.image_url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: thumbUrl(category.image_url, {
			width: 240,
			quality: 70
		}),
		alt: category.name_ar,
		className: "w-full h-full object-cover transition-transform group-hover:scale-105",
		loading: "lazy"
	});
	const key = category.icon?.toLowerCase() ?? "";
	const emojiMap = {
		engine: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "⚙️"
		}),
		disc: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🛞"
		}),
		brake: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🛞"
		}),
		braking: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🛞"
		}),
		suspension: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🔩"
		}),
		zap: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "⚡"
		}),
		electrical: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "⚡"
		}),
		electronics: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🔋"
		}),
		filter: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🌀"
		}),
		filters: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🌀"
		}),
		oil: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🛢️"
		}),
		droplet: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🛢️"
		}),
		car: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🚗"
		}),
		body: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🚙"
		}),
		circle: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "⭕"
		}),
		tire: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🛞"
		}),
		wheel: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🛞"
		}),
		wiper: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🌧️"
		}),
		windshield: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🌧️"
		}),
		gift: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🎁"
		}),
		offer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🎁"
		}),
		deal: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🎁"
		}),
		tool: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🛠️"
		}),
		tools: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🛠️"
		}),
		gear: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "⚙️"
		}),
		battery: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🔋"
		}),
		light: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "💡"
		}),
		lights: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "💡"
		}),
		radiator: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "❄️"
		}),
		cooling: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "❄️"
		})
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `w-full h-full flex items-center justify-center ${categoryBg(index)}`,
		children: emojiMap[key] ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-4xl drop-shadow-sm",
			children: "🔧"
		})
	});
}
function HeroCarousel({ banners }) {
	const [muted, setMuted] = (0, import_react.useState)(true);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [inView, setInView] = (0, import_react.useState)(false);
	const [videoReady, setVideoReady] = (0, import_react.useState)(false);
	const [videoFailed, setVideoFailed] = (0, import_react.useState)(false);
	const [started, setStarted] = (0, import_react.useState)(false);
	const current = banners.find((b) => !!b.video_url) ?? null;
	const videoUrl = current?.video_url;
	const videoRef = (0, import_react.useRef)(null);
	const heroRef = (0, import_react.useRef)(null);
	const userWantsSoundRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	(0, import_react.useEffect)(() => {
		const box = heroRef.current;
		if (!box) return;
		const io = new IntersectionObserver((entries) => {
			for (const e of entries) {
				const el = videoRef.current;
				if (!e.isIntersecting || e.intersectionRatio < .5) {
					setInView(false);
					setMuted(true);
					if (el) {
						el.muted = true;
						el.pause();
					}
				} else {
					setInView(true);
					if (userWantsSoundRef.current) setMuted(false);
					if (el && startedRef.current) {
						el.muted = !userWantsSoundRef.current;
						if (userWantsSoundRef.current) el.volume = 1;
						el.play().catch(() => {});
					}
				}
			}
		}, { threshold: [
			0,
			.5,
			1
		] });
		io.observe(box);
		return () => io.disconnect();
	}, []);
	const startedRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		startedRef.current = started;
	}, [started]);
	(0, import_react.useEffect)(() => {
		const el = videoRef.current;
		if (!el) return;
		el.muted = muted;
		if (!started) return;
		const p = el.play();
		if (p && typeof p.catch === "function") p.catch(() => {});
	}, [
		muted,
		current?.id,
		started
	]);
	if (!current) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 mt-4",
		ref: heroRef,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/offers",
			"aria-label": "فتح العروض",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-3xl bg-gradient-hero text-primary-foreground shadow-luxe aspect-[16/10]",
				children: [
					current.image_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: thumbUrl(current.image_url, {
							width: 1200,
							quality: 75
						}),
						alt: current.title_ar ?? "",
						decoding: "async",
						fetchPriority: "low",
						className: "absolute inset-0 w-full h-full object-cover"
					}),
					mounted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: videoRef,
						src: videoUrl,
						poster: current.image_url || "/icon-512.png",
						muted,
						loop: true,
						playsInline: true,
						preload: "none",
						disableRemotePlayback: true,
						className: "absolute inset-0 w-full h-full object-cover cursor-pointer",
						onCanPlay: () => setVideoReady(true),
						onPlaying: () => setVideoReady(true),
						onWaiting: () => setVideoReady(false),
						onStalled: () => setVideoReady(false),
						onError: () => setVideoFailed(true),
						onVolumeChange: (e) => {
							const el = e.currentTarget;
							setMuted(el.muted);
							if (!el.muted) userWantsSoundRef.current = true;
						}
					}),
					mounted && !started && !videoFailed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: (e) => {
							e.preventDefault();
							e.stopPropagation();
							setStarted(true);
							const el = videoRef.current;
							if (el) {
								el.muted = muted;
								const p = el.play();
								if (p && typeof p.catch === "function") p.catch(() => {});
							}
						},
						"aria-label": "تشغيل الفيديو",
						className: "absolute inset-0 grid place-items-center bg-navy/35 backdrop-blur-[1px] transition hover:bg-navy/45 group",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-16 rounded-full bg-gradient-gold text-navy grid place-items-center shadow-gold transition group-hover:scale-105",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "size-7 ms-1",
								fill: "currentColor"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute bottom-14 text-[11px] font-bold text-white/85 bg-black/40 backdrop-blur-md rounded-full px-3 py-1",
							children: "اضغط لتشغيل الفيديو"
						})]
					}),
					mounted && started && !videoReady && !videoFailed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 grid place-items-center bg-navy/40 backdrop-blur-[2px] pointer-events-none",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-10 rounded-full border-2 border-white/25 border-t-gold animate-spin" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy/90 via-navy/40 to-transparent pointer-events-none" }),
					mounted && started && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: (e) => {
							e.preventDefault();
							e.stopPropagation();
							setMuted((m) => {
								const next = !m;
								userWantsSoundRef.current = !next;
								const el = videoRef.current;
								if (el) {
									el.muted = next;
									if (!next) {
										el.volume = 1;
										const p = el.play();
										if (p && typeof p.catch === "function") p.catch(() => {});
									}
								}
								return next;
							});
						},
						"aria-label": muted ? "تشغيل الصوت" : "كتم الصوت",
						className: "absolute top-3 end-3 size-9 rounded-full bg-black/45 backdrop-blur-md text-white grid place-items-center border border-white/20 hover:bg-black/60 transition",
						children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-x-0 bottom-0 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5 text-[11px] font-bold text-gold bg-gold/10 border border-gold/30 rounded-full px-3 py-1 mb-2 hover:bg-gold/20 transition",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5" }), " عروض حصرية · شاهد الكل"]
							}),
							current.expires_at && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, { to: current.expires_at })
							}),
							current.title_ar && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-xl font-black leading-tight mb-1 text-primary-foreground",
								children: current.title_ar
							}),
							current.subtitle_ar && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-primary-foreground/85 mb-2",
								children: current.subtitle_ar
							})
						]
					})
				]
			})
		})
	});
}
function Countdown({ to }) {
	const target = new Date(to).getTime();
	const [now, setNow] = (0, import_react.useState)(() => target);
	(0, import_react.useEffect)(() => {
		setNow(Date.now());
		const t = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(t);
	}, []);
	const diff = Math.max(0, target - now);
	if (diff <= 0) return null;
	const s = Math.floor(diff / 1e3);
	const d = Math.floor(s / 86400);
	const h = Math.floor(s % 86400 / 3600);
	const m = Math.floor(s % 3600 / 60);
	const sec = s % 60;
	const Box = ({ v, l }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center px-2 py-1 rounded-lg bg-gold/20 border border-gold/40 min-w-[38px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-black text-gold leading-none tabular-nums",
			children: String(v).padStart(2, "0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[8px] text-gold/80 mt-0.5",
			children: l
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "inline-flex items-center gap-1.5",
		dir: "ltr",
		children: [
			d > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
				v: d,
				l: "يوم"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
				v: h,
				l: "ساعة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
				v: m,
				l: "دقيقة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
				v: sec,
				l: "ثانية"
			})
		]
	});
}
function MiniCountdown({ to }) {
	const target = new Date(to).getTime();
	const [now, setNow] = (0, import_react.useState)(() => target);
	(0, import_react.useEffect)(() => {
		setNow(Date.now());
		const t = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(t);
	}, []);
	const diff = Math.max(0, target - now);
	if (diff <= 0) return null;
	const s = Math.floor(diff / 1e3);
	const d = Math.floor(s / 86400);
	const h = Math.floor(s % 86400 / 3600);
	const m = Math.floor(s % 3600 / 60);
	const sec = s % 60;
	const label = d > 0 ? `${d}ي ${h}س` : `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold shadow-sm",
		dir: "ltr",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: label
		})]
	});
}
function LimitedOffers({ deals }) {
	const [emblaRef, embla] = useEmblaCarousel({
		loop: true,
		align: "start",
		direction: "rtl"
	}, [Autoplay({
		delay: 3500,
		stopOnInteraction: false,
		stopOnMouseEnter: true
	})]);
	const [selected, setSelected] = (0, import_react.useState)(0);
	const [snaps, setSnaps] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!embla) return;
		const onSelect = () => setSelected(embla.selectedScrollSnap());
		setSnaps(embla.scrollSnapList());
		embla.on("select", onSelect);
		embla.on("reInit", () => setSnaps(embla.scrollSnapList()));
		onSelect();
	}, [embla]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 mx-4 rounded-3xl bg-card border border-border/60 shadow-card overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 px-4 pt-4 pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-10 rounded-xl bg-gold/15 border border-gold/30 grid place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-5 text-gold" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-extrabold leading-tight",
							children: "عروض لفترة محدودة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted-foreground",
							children: "أسعار خاصة لفترة قصيرة"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/deals",
						className: "text-xs font-semibold text-gold flex items-center gap-0.5",
						children: ["عرض الكل ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-3.5" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "border-t border-border/60" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden",
					ref: emblaRef,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex",
						children: deals.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "shrink-0 grow-0 basis-1/2 p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfferCard, { product: p })
						}, p.id))
					})
				}), embla && snaps.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "السابق",
					onClick: () => embla.scrollPrev(),
					className: "absolute top-1/2 -translate-y-1/2 start-2 size-9 rounded-full bg-card border border-border shadow-card grid place-items-center hover:bg-gold hover:text-navy transition",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4 rotate-180" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "التالي",
					onClick: () => embla.scrollNext(),
					className: "absolute top-1/2 -translate-y-1/2 end-2 size-9 rounded-full bg-card border border-border shadow-card grid place-items-center hover:bg-gold hover:text-navy transition",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
				})] })]
			}),
			snaps.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center gap-1.5 pb-4 pt-1",
				children: snaps.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => embla?.scrollTo(i),
					"aria-label": `slide ${i + 1}`,
					className: `h-1.5 rounded-full transition-all ${i === selected ? "w-6 bg-gold" : "w-1.5 bg-muted-foreground/30"}`
				}, i))
			})
		]
	});
}
function OfferCard({ product }) {
	const img = product.images?.[0];
	const imgThumb = thumbUrl(img, {
		width: 500,
		quality: 65
	});
	const adjust = useAdjustedPrice();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/product/$id",
		params: { id: product.id },
		className: "group flex flex-col rounded-2xl bg-card border border-border/60 overflow-hidden hover:shadow-luxe transition-all",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-square bg-muted overflow-hidden",
			children: [
				img ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: imgThumb,
					alt: product.name_ar,
					loading: "lazy",
					decoding: "async",
					width: 400,
					height: 400,
					sizes: "(max-width: 640px) 50vw, 300px",
					className: "size-full object-cover group-hover:scale-105 transition-transform duration-500"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-full grid place-items-center text-4xl opacity-30",
					children: "⚙️"
				}),
				product.deal_expires_at && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-2 start-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniCountdown, { to: product.deal_expires_at })
				}),
				!product.in_stock && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 bg-navy/60 grid place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-2 py-0.5 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold",
						children: "غير متوفر"
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-3 flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-semibold line-clamp-2 leading-tight min-h-[2.5rem]",
				children: product.name_ar
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-base font-extrabold text-navy",
					children: formatIQD(adjust(product.price_iqd))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] font-bold px-2.5 py-1 rounded-lg bg-muted text-foreground/80 group-hover:bg-gold group-hover:text-navy transition",
					children: "عرض التفاصيل"
				})]
			})]
		})]
	});
}
//#endregion
export { HomePage as component };
