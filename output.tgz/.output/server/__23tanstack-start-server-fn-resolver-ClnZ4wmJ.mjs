//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-ClnZ4wmJ.js
var manifest = {
	"35cf6cc28f61c798a570ec39672552de8ed250f60706565e25b34a66f0c5b240": {
		functionName: "adminListUsers_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-BAJfHN1_.mjs")
	},
	"52dc8af364db74059a235f303e6179f5005b9ae2df01dc0ac1d56a836f25d925": {
		functionName: "testExternalApi_createServerFn_handler",
		importer: () => import("./_ssr/external-api.functions-BFyrrazh.mjs")
	},
	"6b480379be9faee628a1ae09930e0d23e93af156b0dc47bfbe8800f864a21dc0": {
		functionName: "listAdminOtpEvents_createServerFn_handler",
		importer: () => import("./_ssr/admin-otp.functions-CpVaP7L6.mjs")
	},
	"6c49bb0238b91b871165aa77feb8aee3320ff6649c3acb78372f82b46f763ec2": {
		functionName: "getExternalApiConfig_createServerFn_handler",
		importer: () => import("./_ssr/external-api.functions-BFyrrazh.mjs")
	},
	"954ddf5580f8b50b7142bf512d02f1885aa19e6737aad84b9b959c7c55e1079d": {
		functionName: "adminOtpStatus_createServerFn_handler",
		importer: () => import("./_ssr/admin-otp.functions-CpVaP7L6.mjs")
	},
	"9578f35c0a244bf95606fdaac6fc342dde46ab59add0f88b90c0327138436385": {
		functionName: "listStaff_createServerFn_handler",
		importer: () => import("./_ssr/staff.functions-W5OM9rBZ.mjs")
	},
	"95b6aa2b4978dfa32791d4aec5b5df227e7607e3a64ad55178ad66bc334781df": {
		functionName: "adminSetUserBlocked_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-BAJfHN1_.mjs")
	},
	"a378f291c8f7c7a43a7fa2bdf4564adccf7089e2734323ad3067a50c0680b3a3": {
		functionName: "deleteStaff_createServerFn_handler",
		importer: () => import("./_ssr/staff.functions-W5OM9rBZ.mjs")
	},
	"a65be21a0bec8f5bb59d48e7b826841ece93c7685b2bc55d22658de1de4c9873": {
		functionName: "addBannerComment_createServerFn_handler",
		importer: () => import("./_ssr/comments.functions-HxvI6L-b.mjs")
	},
	"b0a7f145ec6f9b1777b18bc17b2fe54867b63e8839a7fc7e84b771672fe5cdfa": {
		functionName: "adminUpdateReplacementStatus_createServerFn_handler",
		importer: () => import("./_ssr/replacement-admin.functions-CTIpAoC0.mjs")
	},
	"b34af10cfb0cf6e0465afe0ba898bf162e25ef86c235c103c7203e6db0c8ea54": {
		functionName: "adminSetUserPassword_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-BAJfHN1_.mjs")
	},
	"b9e529f0850c2850bc6f721791444437b5b772c146c5078346159706e568634b": {
		functionName: "broadcastBannerPush_createServerFn_handler",
		importer: () => import("./_ssr/banner-push.functions-1tljRZ1U.mjs")
	},
	"bc748e03115448b8d6104579748f984dfee1b28b5bb7fe47d0603e7a9fcb2e37": {
		functionName: "sendAdminBroadcast_createServerFn_handler",
		importer: () => import("./_ssr/broadcast.functions-BQ8WQArZ.mjs")
	},
	"ce0a7596eda4f8af2410edf3c2a1dc6998869fc66949677095980a93f4f36224": {
		functionName: "createStaff_createServerFn_handler",
		importer: () => import("./_ssr/staff.functions-W5OM9rBZ.mjs")
	},
	"d6e6d14870d9b01fd5e0c1a5d24a1171cb6e0826067e577a07edc0da371647cf": {
		functionName: "moderatorListUsers_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-BAJfHN1_.mjs")
	},
	"e9609cac5294c8f30c4907805bb986c53cdef123f23e21f6511a6689f7883a79": {
		functionName: "verifyAdminOtp_createServerFn_handler",
		importer: () => import("./_ssr/admin-otp.functions-CpVaP7L6.mjs")
	},
	"ea9d5bed95151a7f8492684ea3271028165a9bc6902355796758b7de4a06fa27": {
		functionName: "adminBroadcastAudienceCount_createServerFn_handler",
		importer: () => import("./_ssr/broadcast.functions-BQ8WQArZ.mjs")
	},
	"ebebbf17c1cd8b4c15de47bc9272ddf865e3cb26202367c75e382b3cb1f9918a": {
		functionName: "updateStaff_createServerFn_handler",
		importer: () => import("./_ssr/staff.functions-W5OM9rBZ.mjs")
	},
	"eccc50d0c1265695454be6c92edd19ad35bed234a6f04e5f9417c322311058bb": {
		functionName: "requestAdminOtp_createServerFn_handler",
		importer: () => import("./_ssr/admin-otp.functions-CpVaP7L6.mjs")
	},
	"ed83d164a000008d15ac777f49b39247f1ec8df8ace47eb0795109e67db92d76": {
		functionName: "runDiagnostics_createServerFn_handler",
		importer: () => import("./_ssr/diagnostics.functions-DtBJ7_eH.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
