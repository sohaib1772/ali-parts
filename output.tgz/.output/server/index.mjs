globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"6b8e-tur4fXo+62NSui1H9seFPUxb2QA\"",
		"mtime": "2026-08-23T18:02:38.667Z",
		"size": 27534,
		"path": "../public/apple-touch-icon.png"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"60d-pAcVv+Vc8ZT3QWSVU2dkb6gCG7Y\"",
		"mtime": "2026-08-23T18:02:38.668Z",
		"size": 1549,
		"path": "../public/favicon.png"
	},
	"/icon-192.png": {
		"type": "image/png",
		"etag": "\"78ae-2ODhbTPTwaEV4gPXISUy87AZ8GA\"",
		"mtime": "2026-08-23T18:02:38.679Z",
		"size": 30894,
		"path": "../public/icon-192.png"
	},
	"/manifest.webmanifest": {
		"type": "application/manifest+json",
		"etag": "\"27b-7hRt7vvU5ivOl9Yqn7iJF9Hcbf0\"",
		"mtime": "2026-08-23T18:02:38.682Z",
		"size": 635,
		"path": "../public/manifest.webmanifest"
	},
	"/assets/about-CcAXDwRR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1574-aoZl+edzcNrpbM/s7ixC6x1fjtM\"",
		"mtime": "2026-08-25T19:08:23.018Z",
		"size": 5492,
		"path": "../public/assets/about-CcAXDwRR.js"
	},
	"/assets/account-r5WGT2EC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fdd3-fKKwxVLeHCrPjtdsg08zP0tx230\"",
		"mtime": "2026-08-25T19:08:23.019Z",
		"size": 64979,
		"path": "../public/assets/account-r5WGT2EC.js"
	},
	"/assets/addresses-Dnc8s3Wd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2616-fhNTiAuULXM1iAC7nu6X4rEx53k\"",
		"mtime": "2026-08-25T19:08:23.021Z",
		"size": 9750,
		"path": "../public/assets/addresses-Dnc8s3Wd.js"
	},
	"/assets/admin-DUXxVDnr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1655-+aet3rFX1paDd9MQUDxZog004Gw\"",
		"mtime": "2026-08-25T19:08:23.022Z",
		"size": 5717,
		"path": "../public/assets/admin-DUXxVDnr.js"
	},
	"/icon-512.png": {
		"type": "image/png",
		"etag": "\"333a2-WUMfh864M1hsPFGY1ZWRGmS/bLE\"",
		"mtime": "2026-08-23T18:02:38.681Z",
		"size": 209826,
		"path": "../public/icon-512.png"
	},
	"/assets/admin.functions-3e2CciRl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f58-VSMYb/PBJf0E8L0aHqF/aleT8vY\"",
		"mtime": "2026-08-25T19:08:23.023Z",
		"size": 8024,
		"path": "../public/assets/admin.functions-3e2CciRl.js"
	},
	"/assets/alert-dialog-F3zDgjtb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"eaa-o8t+qi82nKQe7BOCj/PUxspA6iA\"",
		"mtime": "2026-08-25T19:08:23.023Z",
		"size": 3754,
		"path": "../public/assets/alert-dialog-F3zDgjtb.js"
	},
	"/assets/arrow-right-J5nX3CGR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-/tri+EnTNnVWQcbirruRxADswKs\"",
		"mtime": "2026-08-25T19:08:23.024Z",
		"size": 165,
		"path": "../public/assets/arrow-right-J5nX3CGR.js"
	},
	"/assets/auth-D1P60aEc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d94-3DJ7pBjE7sLwn33EjjyQN44oYXw\"",
		"mtime": "2026-08-25T19:08:23.024Z",
		"size": 7572,
		"path": "../public/assets/auth-D1P60aEc.js"
	},
	"/assets/admin-ezBo_6cg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d534-/fugH/I6myd/1+hj9QK/k7isH5I\"",
		"mtime": "2026-08-25T19:08:23.022Z",
		"size": 185652,
		"path": "../public/assets/admin-ezBo_6cg.js"
	},
	"/assets/banner-push.functions-D4H5gY-l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-o/1SupLrqJEIH41kGJ+mrEY4taw\"",
		"mtime": "2026-08-25T19:08:23.024Z",
		"size": 250,
		"path": "../public/assets/banner-push.functions-D4H5gY-l.js"
	},
	"/assets/base-DH8mVfgE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e9-/gHAYsQcPREC/b46orNXVfqhYaM\"",
		"mtime": "2026-08-25T19:08:23.025Z",
		"size": 2537,
		"path": "../public/assets/base-DH8mVfgE.js"
	},
	"/assets/best-sellers-Dxs-B7wz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b57-IEOKu+3odGxxE3joXGgScw5XqT0\"",
		"mtime": "2026-08-25T19:08:23.028Z",
		"size": 2903,
		"path": "../public/assets/best-sellers-Dxs-B7wz.js"
	},
	"/assets/cart-V2u_7dEj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"244b-wenjWgWZaB5054JisJ0wVRTRuvk\"",
		"mtime": "2026-08-25T19:08:23.029Z",
		"size": 9291,
		"path": "../public/assets/cart-V2u_7dEj.js"
	},
	"/assets/category._id-Dy9XliT8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"488-xeSyKtl7DWVhegJwvzyOSY/nrpI\"",
		"mtime": "2026-08-25T19:08:23.029Z",
		"size": 1160,
		"path": "../public/assets/category._id-Dy9XliT8.js"
	},
	"/assets/check-CcphccHU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-XLyDqi4OvqEjLCoTlpnKzomOt2s\"",
		"mtime": "2026-08-25T19:08:23.029Z",
		"size": 124,
		"path": "../public/assets/check-CcphccHU.js"
	},
	"/assets/button-ClAQp897.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7552-vVdV0xPXWbmgDJsQGL1K112akts\"",
		"mtime": "2026-08-25T19:08:23.028Z",
		"size": 30034,
		"path": "../public/assets/button-ClAQp897.js"
	},
	"/assets/checkout-B3B1efhX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3326-6g/tdgJ1zwF34vb+9PCfpHokgv4\"",
		"mtime": "2026-08-25T19:08:23.090Z",
		"size": 13094,
		"path": "../public/assets/checkout-B3B1efhX.js"
	},
	"/assets/chevron-down-i4ntKBo0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"80-wOAyzRAeSLp8snyXDal469i/uLk\"",
		"mtime": "2026-08-25T19:08:23.090Z",
		"size": 128,
		"path": "../public/assets/chevron-down-i4ntKBo0.js"
	},
	"/sw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"66b-BoIJzog+SYaL5m6Im/6yKQKkfZI\"",
		"mtime": "2026-08-23T18:02:38.682Z",
		"size": 1643,
		"path": "../public/sw.js"
	},
	"/icon-1024.png": {
		"type": "image/png",
		"etag": "\"e8d4f-AWjFcX+v3nOZZ/PUQQ0u7llpJrI\"",
		"mtime": "2026-08-23T18:02:38.678Z",
		"size": 953679,
		"path": "../public/icon-1024.png"
	},
	"/assets/chevron-left-C55aE8RO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82-6GdzYA74uLhv9niPGq/Mtny29FY\"",
		"mtime": "2026-08-25T19:08:23.091Z",
		"size": 130,
		"path": "../public/assets/chevron-left-C55aE8RO.js"
	},
	"/assets/circle-x-BxLkF9Le.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-ceVyXRf+0vlhLVIzQYjsZQYPpWw\"",
		"mtime": "2026-08-25T19:08:23.091Z",
		"size": 207,
		"path": "../public/assets/circle-x-BxLkF9Le.js"
	},
	"/assets/circle-check-PcKFb5ZE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-fvwczDCFIuN2mcZo7cOM7DKL/xw\"",
		"mtime": "2026-08-25T19:08:23.091Z",
		"size": 178,
		"path": "../public/assets/circle-check-PcKFb5ZE.js"
	},
	"/assets/clock-BwhGQEZ9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-VbuG4kU409MdXNpfVHjb9P3IU6I\"",
		"mtime": "2026-08-25T19:08:23.093Z",
		"size": 169,
		"path": "../public/assets/clock-BwhGQEZ9.js"
	},
	"/assets/contact-CM3wr5m1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"801-PgYerFD98VxtdAo6pIwT4XEdfmo\"",
		"mtime": "2026-08-25T19:08:23.093Z",
		"size": 2049,
		"path": "../public/assets/contact-CM3wr5m1.js"
	},
	"/assets/createLucideIcon-f_8Qggt1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a91b-wDA/bqPBP4fcNfJGn7Obw/Scmts\"",
		"mtime": "2026-08-25T19:08:23.093Z",
		"size": 43291,
		"path": "../public/assets/createLucideIcon-f_8Qggt1.js"
	},
	"/assets/client-VpccseFy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"31bc9-7/ccS2wJ475Ek7yZcy91qLD83FE\"",
		"mtime": "2026-08-25T19:08:23.092Z",
		"size": 203721,
		"path": "../public/assets/client-VpccseFy.js"
	},
	"/assets/deals-CClf_tVU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6e0-hPhogpy2QN4o8XHbTNhtPO5qWPU\"",
		"mtime": "2026-08-25T19:08:23.118Z",
		"size": 1760,
		"path": "../public/assets/deals-CClf_tVU.js"
	},
	"/assets/delete-account-BaDNP-OD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12c9-3b66AVJnl0MkLrZiDLWjk3oi1bI\"",
		"mtime": "2026-08-25T19:08:23.119Z",
		"size": 4809,
		"path": "../public/assets/delete-account-BaDNP-OD.js"
	},
	"/assets/dist-CfS4U4qI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"46b-3quxW0TVn4dmRBisrd1FxIRAgkg\"",
		"mtime": "2026-08-25T19:08:23.120Z",
		"size": 1131,
		"path": "../public/assets/dist-CfS4U4qI.js"
	},
	"/assets/dist-iSjKo4yw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f37-YiCCoiaUPrm15gRgtPYJyfQkhYY\"",
		"mtime": "2026-08-25T19:08:23.120Z",
		"size": 7991,
		"path": "../public/assets/dist-iSjKo4yw.js"
	},
	"/assets/es-C_Ha8SM2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33be-r0M5/VZDerxHkUlLViA2uVgz6RI\"",
		"mtime": "2026-08-25T19:08:23.120Z",
		"size": 13246,
		"path": "../public/assets/es-C_Ha8SM2.js"
	},
	"/assets/esm-5zjhkOtI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-krZE9Hf/pm+rP9FFJ1ubI+9UZMw\"",
		"mtime": "2026-08-25T19:08:23.120Z",
		"size": 385,
		"path": "../public/assets/esm-5zjhkOtI.js"
	},
	"/assets/esm-BSUtDBFM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"66-TkzmMPOuUjNkWdHP4fa8URrSqlU\"",
		"mtime": "2026-08-25T19:08:23.121Z",
		"size": 102,
		"path": "../public/assets/esm-BSUtDBFM.js"
	},
	"/assets/esm-BT1_fQqw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-2LUhO20yw1IYvG2KSB1cs1csyik\"",
		"mtime": "2026-08-25T19:08:23.121Z",
		"size": 385,
		"path": "../public/assets/esm-BT1_fQqw.js"
	},
	"/assets/esm-Dd0fk4Jg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb-HOW9wy9LsEigXB/DSaSrqJQb2wU\"",
		"mtime": "2026-08-25T19:08:23.122Z",
		"size": 251,
		"path": "../public/assets/esm-Dd0fk4Jg.js"
	},
	"/assets/esm-DlEcpp0G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"595-E5ewG1TTExp/j6wPb5ZnxAEuDLI\"",
		"mtime": "2026-08-25T19:08:23.131Z",
		"size": 1429,
		"path": "../public/assets/esm-DlEcpp0G.js"
	},
	"/assets/favorites-4NmhPuaB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"652-mxz8SH6FahUZxpJ1UlOGV+Sa9P0\"",
		"mtime": "2026-08-25T19:08:23.132Z",
		"size": 1618,
		"path": "../public/assets/favorites-4NmhPuaB.js"
	},
	"/assets/filter-bar-BAX1Jf2O.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b3c-V6RrzcjStbIwFL+UsngBOUepDEs\"",
		"mtime": "2026-08-25T19:08:23.132Z",
		"size": 15164,
		"path": "../public/assets/filter-bar-BAX1Jf2O.js"
	},
	"/assets/flame-ELqmm_W6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c7-NIfZHEuCpNpTH6i8c6uQrOdWSNY\"",
		"mtime": "2026-08-25T19:08:23.133Z",
		"size": 199,
		"path": "../public/assets/flame-ELqmm_W6.js"
	},
	"/assets/format-tzvdlX4z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a4-is9P6m/J2LSseqtZTt+GPjjkcAc\"",
		"mtime": "2026-08-25T19:08:23.133Z",
		"size": 932,
		"path": "../public/assets/format-tzvdlX4z.js"
	},
	"/assets/icons-CA6I3S0M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e1-19kh76YykABlQNT15BPsRUF0vts\"",
		"mtime": "2026-08-25T19:08:23.134Z",
		"size": 225,
		"path": "../public/assets/icons-CA6I3S0M.js"
	},
	"/assets/image-BxDDW7HN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d-ixkI/RwSvYtOsTmxCWd2ZyaVPvA\"",
		"mtime": "2026-08-25T19:08:23.135Z",
		"size": 269,
		"path": "../public/assets/image-BxDDW7HN.js"
	},
	"/assets/html2canvas-BfZ04V3R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30b99-oSXtJ7yui3fRH2awJKTqZXftx2Y\"",
		"mtime": "2026-08-25T19:08:23.134Z",
		"size": 199577,
		"path": "../public/assets/html2canvas-BfZ04V3R.js"
	},
	"/assets/index-DycdnOaE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"68980-sRHF/M5lY5ogt94YeKV0GoTVWsA\"",
		"mtime": "2026-08-25T19:08:23.017Z",
		"size": 428416,
		"path": "../public/assets/index-DycdnOaE.js"
	},
	"/assets/index.es-DYERYDqN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24f5e-hKbuSo9LC2WdYivxkiIjrA3eWKM\"",
		"mtime": "2026-08-25T19:08:23.135Z",
		"size": 151390,
		"path": "../public/assets/index.es-DYERYDqN.js"
	},
	"/assets/input-itgtTWqB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f7-5PKmkFLR37FLdpRUC4On5c7IybE\"",
		"mtime": "2026-08-25T19:08:23.146Z",
		"size": 1015,
		"path": "../public/assets/input-itgtTWqB.js"
	},
	"/assets/invariant-DEEwAagU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c-eVh/3DMi1s3cxf4N/OJar+ew1jA\"",
		"mtime": "2026-08-25T19:08:23.147Z",
		"size": 60,
		"path": "../public/assets/invariant-DEEwAagU.js"
	},
	"/assets/jspdf.es.min-C8ykbm0_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"61951-iOp7TlXrsZt2VvBT7HtCR+H3MUo\"",
		"mtime": "2026-08-25T19:08:23.147Z",
		"size": 399697,
		"path": "../public/assets/jspdf.es.min-C8ykbm0_.js"
	},
	"/assets/jsx-runtime-By8HlURe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b3-IA0XiFuRY0cUsIlFJWjLIFoOPrI\"",
		"mtime": "2026-08-25T19:08:23.148Z",
		"size": 435,
		"path": "../public/assets/jsx-runtime-By8HlURe.js"
	},
	"/assets/legal-contact-Cdm2Ut2W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6c1-57AGINlprTErTaUBikvsVbXdv+4\"",
		"mtime": "2026-08-25T19:08:23.148Z",
		"size": 1729,
		"path": "../public/assets/legal-contact-Cdm2Ut2W.js"
	},
	"/assets/loader-circle-CqlDARXt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-tkptQeRzJNCAis5N5HNtxAEihwo\"",
		"mtime": "2026-08-25T19:08:23.149Z",
		"size": 144,
		"path": "../public/assets/loader-circle-CqlDARXt.js"
	},
	"/assets/map-pin-CofDtUxA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"103-UrqmAUJskIzbxsWib/CbYzvevPc\"",
		"mtime": "2026-08-25T19:08:23.149Z",
		"size": 259,
		"path": "../public/assets/map-pin-CofDtUxA.js"
	},
	"/assets/messages-Z8QTRdGe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"481-gJuoiGcAchKzqkgjfMyo8g0arbQ\"",
		"mtime": "2026-08-25T19:08:23.149Z",
		"size": 1153,
		"path": "../public/assets/messages-Z8QTRdGe.js"
	},
	"/assets/minus-CDQjQ1Ts.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75-4Z00GVzmbsidsWWHaurMLewxDec\"",
		"mtime": "2026-08-25T19:08:23.150Z",
		"size": 117,
		"path": "../public/assets/minus-CDQjQ1Ts.js"
	},
	"/assets/native-DeQuYG3e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d6-z1k6exP8mCZzhnFJbc2mLn3uWgc\"",
		"mtime": "2026-08-25T19:08:23.161Z",
		"size": 726,
		"path": "../public/assets/native-DeQuYG3e.js"
	},
	"/assets/native-oauth-BzYpzG3d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"776-maz3B0INedfJP/mlOF876cfPzRw\"",
		"mtime": "2026-08-25T19:08:23.162Z",
		"size": 1910,
		"path": "../public/assets/native-oauth-BzYpzG3d.js"
	},
	"/assets/notifications-BgcEaYmA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"133b-V2+I3VcTvVPVIzD0POvFLZihFiE\"",
		"mtime": "2026-08-25T19:08:23.162Z",
		"size": 4923,
		"path": "../public/assets/notifications-BgcEaYmA.js"
	},
	"/assets/notifications-By7rSmcl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"725-DKUDZtFQVO/zwDZJ92UDE9XtBRc\"",
		"mtime": "2026-08-25T19:08:23.164Z",
		"size": 1829,
		"path": "../public/assets/notifications-By7rSmcl.js"
	},
	"/assets/offers-BjPTCdif.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7413-oGudYmZBiPk/fRmYWm91TfG0tSw\"",
		"mtime": "2026-08-25T19:08:23.164Z",
		"size": 29715,
		"path": "../public/assets/offers-BjPTCdif.js"
	},
	"/assets/order-status-B0RdXWHt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7ee-Z8hwSu1eo9gKM78VexCVS1XGBR8\"",
		"mtime": "2026-08-25T19:08:23.165Z",
		"size": 2030,
		"path": "../public/assets/order-status-B0RdXWHt.js"
	},
	"/assets/order-success._id-D5QLGSbe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7e0-oh5fH8s1F/u8W2x4uivJN2M4CFY\"",
		"mtime": "2026-08-25T19:08:23.165Z",
		"size": 2016,
		"path": "../public/assets/order-success._id-D5QLGSbe.js"
	},
	"/assets/orders-D0I4252y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b5d-PPofwiouCmBefybaW5ufVwEuq24\"",
		"mtime": "2026-08-25T19:08:23.166Z",
		"size": 7005,
		"path": "../public/assets/orders-D0I4252y.js"
	},
	"/assets/orders_._id-C0cVvqV4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36af-YWja9qF9cHzyqbMIzVxgXEj60Xs\"",
		"mtime": "2026-08-25T19:08:23.166Z",
		"size": 13999,
		"path": "../public/assets/orders_._id-C0cVvqV4.js"
	},
	"/assets/package-8YJfeI7L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"174-qY9k5L0zK50bm8jLl4GFhphzhJA\"",
		"mtime": "2026-08-25T19:08:23.413Z",
		"size": 372,
		"path": "../public/assets/package-8YJfeI7L.js"
	},
	"/assets/page-shell-DWJdFFTU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23f1-kgulFUC6fuo8rzHkYLVvLE3MAQ4\"",
		"mtime": "2026-08-25T19:08:23.414Z",
		"size": 9201,
		"path": "../public/assets/page-shell-DWJdFFTU.js"
	},
	"/assets/pencil-DQ8tsBin.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"114-uPVO2lcu7tv9757hZbzipQSSLDo\"",
		"mtime": "2026-08-25T19:08:23.414Z",
		"size": 276,
		"path": "../public/assets/pencil-DQ8tsBin.js"
	},
	"/assets/phone-auth-CnyemZ4I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18e-uUiA0rUKwEfIZ+YJO9NjHFJvfKQ\"",
		"mtime": "2026-08-25T19:08:23.433Z",
		"size": 398,
		"path": "../public/assets/phone-auth-CnyemZ4I.js"
	},
	"/assets/phone-D0zusc0M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-jtew3WeUKm5oJJ8+kymaEMZraIU\"",
		"mtime": "2026-08-25T19:08:23.415Z",
		"size": 322,
		"path": "../public/assets/phone-D0zusc0M.js"
	},
	"/assets/plus-Bb-qvJcA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-PISmWnF6w8ftfaxmVo6EM7Uazcc\"",
		"mtime": "2026-08-25T19:08:23.433Z",
		"size": 153,
		"path": "../public/assets/plus-Bb-qvJcA.js"
	},
	"/assets/preload-helper-CZgWQFsJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4e8-074MSUArFcMGbNIntmhcTcVu9/k\"",
		"mtime": "2026-08-25T19:08:23.434Z",
		"size": 1256,
		"path": "../public/assets/preload-helper-CZgWQFsJ.js"
	},
	"/assets/privacy-DXAk2N10.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24ad-SaafAekFHE0D9OdF3egdH/kFHAA\"",
		"mtime": "2026-08-25T19:08:23.440Z",
		"size": 9389,
		"path": "../public/assets/privacy-DXAk2N10.js"
	},
	"/assets/printable-invoice-WhU6hmJU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5aea-hYSg9IanMluqVRXRYb/EM4SGzc4\"",
		"mtime": "2026-08-25T19:08:23.434Z",
		"size": 23274,
		"path": "../public/assets/printable-invoice-WhU6hmJU.js"
	},
	"/assets/product._id-DdL7DgyH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b6-NBjE+MgjLRQBQYfzT6fqcYMTI6M\"",
		"mtime": "2026-08-25T19:08:23.441Z",
		"size": 182,
		"path": "../public/assets/product._id-DdL7DgyH.js"
	},
	"/assets/product._id-DwK1NYM_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1fd-bWjN2NixExO93guiA4P/GF7MJDA\"",
		"mtime": "2026-08-25T19:08:23.442Z",
		"size": 509,
		"path": "../public/assets/product._id-DwK1NYM_.js"
	},
	"/assets/product._id-GDZg_9Ph.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6838-36v1fuvRfRM44zD+T3k1qvGjtN0\"",
		"mtime": "2026-08-25T19:08:23.442Z",
		"size": 26680,
		"path": "../public/assets/product._id-GDZg_9Ph.js"
	},
	"/assets/products-DRgvdzmi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11de-tcYvUahMFjvBY4UVC67tOB0LTSg\"",
		"mtime": "2026-08-25T19:08:23.442Z",
		"size": 4574,
		"path": "../public/assets/products-DRgvdzmi.js"
	},
	"/assets/profanity-Bl0NHGZ0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"556-tJ0AmtoGkutkzoC65DkMUdEmbV4\"",
		"mtime": "2026-08-25T19:08:23.443Z",
		"size": 1366,
		"path": "../public/assets/profanity-Bl0NHGZ0.js"
	},
	"/assets/profile-completion-DFVZ4mFm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f5d-Vuy/jQRdYNveqtfGWZF9R4qGXto\"",
		"mtime": "2026-08-25T19:08:23.443Z",
		"size": 3933,
		"path": "../public/assets/profile-completion-DFVZ4mFm.js"
	},
	"/assets/queryOptions-Dfvzj6n2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26-swOrbCYhZ0gnyks4Amdj937R/Ts\"",
		"mtime": "2026-08-25T19:08:23.445Z",
		"size": 38,
		"path": "../public/assets/queryOptions-Dfvzj6n2.js"
	},
	"/assets/progress-BZBzG2K1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"91f-lA0Ty4qF1uIxDdSP/diKq4m/NkY\"",
		"mtime": "2026-08-25T19:08:23.444Z",
		"size": 2335,
		"path": "../public/assets/progress-BZBzG2K1.js"
	},
	"/assets/purify.es-DuRL7t6i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"68ff-UzqdquwlS23jMr/0lDNWmxy5AL0\"",
		"mtime": "2026-08-25T19:08:23.444Z",
		"size": 26879,
		"path": "../public/assets/purify.es-DuRL7t6i.js"
	},
	"/assets/refresh-cw-DAGPGNqb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"141-6tyLG+jEeCZa3TcSYMargu0k37Q\"",
		"mtime": "2026-08-25T19:08:23.446Z",
		"size": 321,
		"path": "../public/assets/refresh-cw-DAGPGNqb.js"
	},
	"/assets/redirect-DCb_aIiF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"271-AJO48VqfkUfrNYq6mvZqsvvYRKY\"",
		"mtime": "2026-08-25T19:08:23.445Z",
		"size": 625,
		"path": "../public/assets/redirect-DCb_aIiF.js"
	},
	"/assets/repeat-DUaClw__.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"110-sbAVjM9Rd/Ime/g87MzS76kUzn4\"",
		"mtime": "2026-08-25T19:08:23.446Z",
		"size": 272,
		"path": "../public/assets/repeat-DUaClw__.js"
	},
	"/assets/rolldown-runtime-QTnfLwEv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b6-wnqLLSlp3SaE+lbe74bKNe5Rpds\"",
		"mtime": "2026-08-25T19:08:23.468Z",
		"size": 694,
		"path": "../public/assets/rolldown-runtime-QTnfLwEv.js"
	},
	"/assets/replacements-Dt9SUVLb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f87-l0MZeBGDNATkDkE0PLtxcejkSyc\"",
		"mtime": "2026-08-25T19:08:23.465Z",
		"size": 8071,
		"path": "../public/assets/replacements-Dt9SUVLb.js"
	},
	"/assets/replacements_._id-5bGJ2Qsb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36b8-j13cr0WFalZV9MuO3CuW0k9rRl0\"",
		"mtime": "2026-08-25T19:08:23.467Z",
		"size": 14008,
		"path": "../public/assets/replacements_._id-5bGJ2Qsb.js"
	},
	"/assets/route-CGqadjC5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b2-Uq2B+Q3oP0x+/BpbG/wO+ATN+uw\"",
		"mtime": "2026-08-25T19:08:23.468Z",
		"size": 1970,
		"path": "../public/assets/route-CGqadjC5.js"
	},
	"/assets/routes-DrmFkp8S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9dd8-3BK2fIeSnr0N8U952SdEmcJB6jw\"",
		"mtime": "2026-08-25T19:08:23.469Z",
		"size": 40408,
		"path": "../public/assets/routes-DrmFkp8S.js"
	},
	"/assets/search-D6ZIT_St.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f8d-ga4rBb3flVw+OaOWUhsOz3LHRa0\"",
		"mtime": "2026-08-25T19:08:23.469Z",
		"size": 3981,
		"path": "../public/assets/search-D6ZIT_St.js"
	},
	"/assets/search-mOfzf65C.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-doGteT6LNBV8dMZMT3ujA1LYpmM\"",
		"mtime": "2026-08-25T19:08:23.469Z",
		"size": 174,
		"path": "../public/assets/search-mOfzf65C.js"
	},
	"/assets/shield-Bo4X6h5j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"110-J4xuj0iaV2xku4Xm5qMWpz2AhF0\"",
		"mtime": "2026-08-25T19:08:23.469Z",
		"size": 272,
		"path": "../public/assets/shield-Bo4X6h5j.js"
	},
	"/assets/shipping-BZRBFfJB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29e-n5PXK8T1C/pBGy5+DNrCIVv4iCk\"",
		"mtime": "2026-08-25T19:08:23.470Z",
		"size": 670,
		"path": "../public/assets/shipping-BZRBFfJB.js"
	},
	"/assets/shopping-cart-DZhrArPu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a3-MOQOvkKizXgGRXJb6DveYs6zRog\"",
		"mtime": "2026-08-25T19:08:23.471Z",
		"size": 675,
		"path": "../public/assets/shopping-cart-DZhrArPu.js"
	},
	"/assets/sparkles-CYbbP3SJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-ar6MNrA4sPTaUHIL7v+ADiWl5UA\"",
		"mtime": "2026-08-25T19:08:23.471Z",
		"size": 494,
		"path": "../public/assets/sparkles-CYbbP3SJ.js"
	},
	"/assets/sticky-note-CCuMKTkb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"118-/EOSkp4hz7nNxjC7BbBJ2kf9spE\"",
		"mtime": "2026-08-25T19:08:23.471Z",
		"size": 280,
		"path": "../public/assets/sticky-note-CCuMKTkb.js"
	},
	"/assets/thumbs-up-DgN90jV9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"228-jPVyFJxBxRcBL4S2V4+vaWpIeI4\"",
		"mtime": "2026-08-25T19:08:23.472Z",
		"size": 552,
		"path": "../public/assets/thumbs-up-DgN90jV9.js"
	},
	"/assets/terms-CXsqGWeD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"247f-Ds2RcJmErEYK9eyGp7eHclnEKD8\"",
		"mtime": "2026-08-25T19:08:23.471Z",
		"size": 9343,
		"path": "../public/assets/terms-CXsqGWeD.js"
	},
	"/assets/timer-sAiIQFvn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ee-+92rqUHlvie2VVJY16UlYg73+oE\"",
		"mtime": "2026-08-25T19:08:23.472Z",
		"size": 238,
		"path": "../public/assets/timer-sAiIQFvn.js"
	},
	"/assets/trash-2-DD2Sw6vV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"148-YUCqpa3n0oEedOMJ5R2YSis+Pdo\"",
		"mtime": "2026-08-25T19:08:23.473Z",
		"size": 328,
		"path": "../public/assets/trash-2-DD2Sw6vV.js"
	},
	"/assets/triangle-alert-wXn2wjyc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"109-/30lVo2BT47cK7gxHTBaL1rplA4\"",
		"mtime": "2026-08-25T19:08:23.473Z",
		"size": 265,
		"path": "../public/assets/triangle-alert-wXn2wjyc.js"
	},
	"/assets/styles-DaCoxaFz.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"264d0-nVstP/E4AnJluOLFMOYtPJZzvjM\"",
		"mtime": "2026-08-25T19:08:23.484Z",
		"size": 156880,
		"path": "../public/assets/styles-DaCoxaFz.css"
	},
	"/assets/truck-D_xSh_mV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"196-CQ2LpkWZuIY5si1tWD0xjfmo3V4\"",
		"mtime": "2026-08-25T19:08:23.473Z",
		"size": 406,
		"path": "../public/assets/truck-D_xSh_mV.js"
	},
	"/assets/typeof-B5XbjTb1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10f-yPXEOGyFHb1Ws7OoWyWNEEBz4mQ\"",
		"mtime": "2026-08-25T19:08:23.474Z",
		"size": 271,
		"path": "../public/assets/typeof-B5XbjTb1.js"
	},
	"/assets/upload-C7VWcwDR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-rt4zkecbd/1wB9ECfnK20YseH8Q\"",
		"mtime": "2026-08-25T19:08:23.474Z",
		"size": 230,
		"path": "../public/assets/upload-C7VWcwDR.js"
	},
	"/assets/upload-with-progress-CkcOrscr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"448-s7K3USELE22jg0Ke8ibzrMS5M50\"",
		"mtime": "2026-08-25T19:08:23.475Z",
		"size": 1096,
		"path": "../public/assets/upload-with-progress-CkcOrscr.js"
	},
	"/assets/useBaseQuery-DT6aQ9Dw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22c4-jTSpMq9wl8E+h5nxJLoG4yQMWE0\"",
		"mtime": "2026-08-25T19:08:23.476Z",
		"size": 8900,
		"path": "../public/assets/useBaseQuery-DT6aQ9Dw.js"
	},
	"/assets/useInfiniteQuery-CiyuczXW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48e-X3YtE9G9uM92XONM1ceId/reMLY\"",
		"mtime": "2026-08-25T19:08:23.476Z",
		"size": 1166,
		"path": "../public/assets/useInfiniteQuery-CiyuczXW.js"
	},
	"/assets/useMatch-4yPsuliU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ca-OjB7r7d/DyNaZr8Rs/qI1uJzLxU\"",
		"mtime": "2026-08-25T19:08:23.476Z",
		"size": 714,
		"path": "../public/assets/useMatch-4yPsuliU.js"
	},
	"/assets/useNavigate-D0psL8lk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e9-FdOBNccF3s1OqdpPll2jAiQ9Ub8\"",
		"mtime": "2026-08-25T19:08:23.478Z",
		"size": 233,
		"path": "../public/assets/useNavigate-D0psL8lk.js"
	},
	"/assets/useQuery-BT8RoC8n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"60-UjJDY8Wra98oBcbCMzUGtVp4uHo\"",
		"mtime": "2026-08-25T19:08:23.479Z",
		"size": 96,
		"path": "../public/assets/useQuery-BT8RoC8n.js"
	},
	"/assets/user-C5O8iIYO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4-Ysao4183EiqQdDWCJo4DgdIFtGI\"",
		"mtime": "2026-08-25T19:08:23.480Z",
		"size": 196,
		"path": "../public/assets/user-C5O8iIYO.js"
	},
	"/assets/useRouter-CAlSMMd6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dbf-1h7KwnEcJjaVQmxtEADTXktjFa0\"",
		"mtime": "2026-08-25T19:08:23.479Z",
		"size": 7615,
		"path": "../public/assets/useRouter-CAlSMMd6.js"
	},
	"/assets/users-BAPjvcGw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-8A3BziPoQcE7aOVjdmEtVj0qJ8I\"",
		"mtime": "2026-08-25T19:08:23.481Z",
		"size": 306,
		"path": "../public/assets/users-BAPjvcGw.js"
	},
	"/assets/useSearch-8NWoXOsk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"da-WXXlAx7EKq6FViliDcylxBMdc+g\"",
		"mtime": "2026-08-25T19:08:23.480Z",
		"size": 218,
		"path": "../public/assets/useSearch-8NWoXOsk.js"
	},
	"/assets/useSuspenseQuery-DdvbYil_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-HqBc2ZW4nT7YxD71/8jhS25kBxI\"",
		"mtime": "2026-08-25T19:08:23.480Z",
		"size": 174,
		"path": "../public/assets/useSuspenseQuery-DdvbYil_.js"
	},
	"/assets/utils-B6KiDbIe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a7d-iNkBSvaSyIjvZOzWoTvEa49qwcI\"",
		"mtime": "2026-08-25T19:08:23.481Z",
		"size": 27261,
		"path": "../public/assets/utils-B6KiDbIe.js"
	},
	"/assets/volume-x-DtBIPOg9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d7-mNMlbIQK0YO4xsGqKLUm0Nfhdvw\"",
		"mtime": "2026-08-25T19:08:23.481Z",
		"size": 727,
		"path": "../public/assets/volume-x-DtBIPOg9.js"
	},
	"/assets/web-BTgg8XI0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16c-wcG0l8fKsCX1wgK1/uhAufsqdh4\"",
		"mtime": "2026-08-25T19:08:23.481Z",
		"size": 364,
		"path": "../public/assets/web-BTgg8XI0.js"
	},
	"/assets/web-BU4E6wEE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34b-HR7NgMsPImGrP3rempwCqLB5tww\"",
		"mtime": "2026-08-25T19:08:23.482Z",
		"size": 843,
		"path": "../public/assets/web-BU4E6wEE.js"
	},
	"/assets/web-C3VMymT7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"212c-brp3KIRsJlRF9BfHlQV0GRkXPLY\"",
		"mtime": "2026-08-25T19:08:23.482Z",
		"size": 8492,
		"path": "../public/assets/web-C3VMymT7.js"
	},
	"/assets/web-DmK04iAh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"169-Iz3yeqUqXJEYD9mPLFNawScfsuA\"",
		"mtime": "2026-08-25T19:08:23.483Z",
		"size": 361,
		"path": "../public/assets/web-DmK04iAh.js"
	},
	"/assets/web-DVw6vnQO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f9-RgFTCofC6ZSGIn9dwHxDToxPAzE\"",
		"mtime": "2026-08-25T19:08:23.482Z",
		"size": 761,
		"path": "../public/assets/web-DVw6vnQO.js"
	},
	"/assets/web-mcNnWSUR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a7-nPXifNktGrf9veC+Di+T9eux7W0\"",
		"mtime": "2026-08-25T19:08:23.483Z",
		"size": 1191,
		"path": "../public/assets/web-mcNnWSUR.js"
	},
	"/assets/web-vlIvnWZ_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2dc-npapsSLFhVY1aynsv54VkpoKoAU\"",
		"mtime": "2026-08-25T19:08:23.484Z",
		"size": 732,
		"path": "../public/assets/web-vlIvnWZ_.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_3QbIaZ = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_3QbIaZ
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
