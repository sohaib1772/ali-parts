globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"60d-pAcVv+Vc8ZT3QWSVU2dkb6gCG7Y\"",
		"mtime": "2026-08-23T18:02:38.668Z",
		"size": 1549,
		"path": "../public/favicon.png"
	},
	"/icon-192.png": {
		"type": "image/png",
		"etag": "\"78ae-2ODhbTPTwaEV4gPXISUy87AZ8GA\"",
		"mtime": "2026-08-23T18:02:38.679Z",
		"size": 30894,
		"path": "../public/icon-192.png"
	},
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"6b8e-tur4fXo+62NSui1H9seFPUxb2QA\"",
		"mtime": "2026-08-23T18:02:38.667Z",
		"size": 27534,
		"path": "../public/apple-touch-icon.png"
	},
	"/assets/about-5a5iKoOo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1574-RxMexe7ohQiMC+30x6NTzWxQRH0\"",
		"mtime": "2026-08-25T17:40:06.615Z",
		"size": 5492,
		"path": "../public/assets/about-5a5iKoOo.js"
	},
	"/assets/addresses-CSHTwAu2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2616-X5SMp7ZeTXONrFcEqR7Hyvwu+h0\"",
		"mtime": "2026-08-25T17:40:06.622Z",
		"size": 9750,
		"path": "../public/assets/addresses-CSHTwAu2.js"
	},
	"/manifest.webmanifest": {
		"type": "application/manifest+json",
		"etag": "\"27b-7hRt7vvU5ivOl9Yqn7iJF9Hcbf0\"",
		"mtime": "2026-08-23T18:02:38.682Z",
		"size": 635,
		"path": "../public/manifest.webmanifest"
	},
	"/assets/account-1jO71RJg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fdd3-G5Va0xhYnV5lxYxV109wwkNbur4\"",
		"mtime": "2026-08-25T17:40:06.615Z",
		"size": 64979,
		"path": "../public/assets/account-1jO71RJg.js"
	},
	"/assets/admin-aWQvFR15.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1655-F0QVXGm/JWIkCoXlVK/j6WVMpVs\"",
		"mtime": "2026-08-25T17:40:06.686Z",
		"size": 5717,
		"path": "../public/assets/admin-aWQvFR15.js"
	},
	"/assets/admin.functions-OpS0ceh0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f58-ivZYliLtYZqtEcD68Ft1fb+uiBQ\"",
		"mtime": "2026-08-25T17:40:06.696Z",
		"size": 8024,
		"path": "../public/assets/admin.functions-OpS0ceh0.js"
	},
	"/assets/alert-dialog-C8qumA91.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"eaa-8GDGyLAS49GsPH3ewTfalpbGK1Y\"",
		"mtime": "2026-08-25T17:40:06.697Z",
		"size": 3754,
		"path": "../public/assets/alert-dialog-C8qumA91.js"
	},
	"/assets/arrow-right-BxvmY4ka.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-msWOUy2LDYvsx2LMU0DpCPHYcK0\"",
		"mtime": "2026-08-25T17:40:06.700Z",
		"size": 165,
		"path": "../public/assets/arrow-right-BxvmY4ka.js"
	},
	"/icon-512.png": {
		"type": "image/png",
		"etag": "\"333a2-WUMfh864M1hsPFGY1ZWRGmS/bLE\"",
		"mtime": "2026-08-23T18:02:38.681Z",
		"size": 209826,
		"path": "../public/icon-512.png"
	},
	"/assets/auth-C_2I060w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d94-hmJqC8OcX9FV37NNrMGs+zBXo88\"",
		"mtime": "2026-08-25T17:40:06.702Z",
		"size": 7572,
		"path": "../public/assets/auth-C_2I060w.js"
	},
	"/assets/banner-push.functions-DVJzG70C.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-v0fztISeguckHAj2pleRXtg3dCE\"",
		"mtime": "2026-08-25T17:40:06.702Z",
		"size": 250,
		"path": "../public/assets/banner-push.functions-DVJzG70C.js"
	},
	"/assets/admin-Cmx1Lanl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d534-DiC8Ofq7b4gWeWoUxnEBLWUx0Ws\"",
		"mtime": "2026-08-25T17:40:06.643Z",
		"size": 185652,
		"path": "../public/assets/admin-Cmx1Lanl.js"
	},
	"/assets/base-CFxP9oKc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9e9-p1IlDxdmLOkQwP4yIfQ2oS5cSiY\"",
		"mtime": "2026-08-25T17:40:06.816Z",
		"size": 2537,
		"path": "../public/assets/base-CFxP9oKc.js"
	},
	"/assets/best-sellers-DbXZektk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b57-XFYmAXyJyEamhZLfOR6ZCvAEcuI\"",
		"mtime": "2026-08-25T17:40:06.816Z",
		"size": 2903,
		"path": "../public/assets/best-sellers-DbXZektk.js"
	},
	"/assets/button-BShFJ25x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7552-vj0k45VPvTdS4v7Nes14XrFidWU\"",
		"mtime": "2026-08-25T17:40:06.816Z",
		"size": 30034,
		"path": "../public/assets/button-BShFJ25x.js"
	},
	"/assets/cart-CYDtssn4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"244b-VGVozEIDYKePjF7TfKSI1CKqvJw\"",
		"mtime": "2026-08-25T17:40:06.819Z",
		"size": 9291,
		"path": "../public/assets/cart-CYDtssn4.js"
	},
	"/assets/category._id-CVxuZEck.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"488-6jvfGLqeAyzJyoqjpkWrCESIwhs\"",
		"mtime": "2026-08-25T17:40:06.886Z",
		"size": 1160,
		"path": "../public/assets/category._id-CVxuZEck.js"
	},
	"/assets/check-Dt23P7tX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-n6IqcDQwW2smjKAz9vAYiS/o3Pc\"",
		"mtime": "2026-08-25T17:40:06.886Z",
		"size": 124,
		"path": "../public/assets/check-Dt23P7tX.js"
	},
	"/assets/checkout-DRmke_JA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3326-9QbeKkMSTcIeCcw2Le9QnOpxp2I\"",
		"mtime": "2026-08-25T17:40:06.891Z",
		"size": 13094,
		"path": "../public/assets/checkout-DRmke_JA.js"
	},
	"/assets/chevron-down-Bqab7lOs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"80-qNR5uH/jN2mYG4U9SyDjlpm2wqY\"",
		"mtime": "2026-08-25T17:40:06.896Z",
		"size": 128,
		"path": "../public/assets/chevron-down-Bqab7lOs.js"
	},
	"/sw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"66b-BoIJzog+SYaL5m6Im/6yKQKkfZI\"",
		"mtime": "2026-08-23T18:02:38.682Z",
		"size": 1643,
		"path": "../public/sw.js"
	},
	"/icon-1024.png": {
		"type": "image/png",
		"etag": "\"e8d4f-AWjFcX+v3nOZZ/PUQQ0u7llpJrI\"",
		"mtime": "2026-08-23T18:02:38.678Z",
		"size": 953679,
		"path": "../public/icon-1024.png"
	},
	"/assets/chevron-left-DsluPFea.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82-oaajuFmdNn4UY901FN082P42eHc\"",
		"mtime": "2026-08-25T17:40:06.902Z",
		"size": 130,
		"path": "../public/assets/chevron-left-DsluPFea.js"
	},
	"/assets/circle-x-CaQbGP3Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-Po/46gSyYgO+yNKOuxJv2FPWF7A\"",
		"mtime": "2026-08-25T17:40:06.917Z",
		"size": 207,
		"path": "../public/assets/circle-x-CaQbGP3Q.js"
	},
	"/assets/clock-Cl0q345K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-jT2Qy53PH7lH7W2c6/uSvmpb2AY\"",
		"mtime": "2026-08-25T17:40:06.921Z",
		"size": 169,
		"path": "../public/assets/clock-Cl0q345K.js"
	},
	"/assets/circle-check-CK6z1Nju.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-ZTno0/TNtkAuzAzMvzRm1eNjzqI\"",
		"mtime": "2026-08-25T17:40:06.904Z",
		"size": 178,
		"path": "../public/assets/circle-check-CK6z1Nju.js"
	},
	"/assets/contact-32F9uGOc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"801-ADIMT5Hwgatauy7l+clFyh6Glno\"",
		"mtime": "2026-08-25T17:40:06.922Z",
		"size": 2049,
		"path": "../public/assets/contact-32F9uGOc.js"
	},
	"/assets/client-VpccseFy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"31bc9-7/ccS2wJ475Ek7yZcy91qLD83FE\"",
		"mtime": "2026-08-25T17:40:06.919Z",
		"size": 203721,
		"path": "../public/assets/client-VpccseFy.js"
	},
	"/assets/createLucideIcon-CX0ia4Xd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8fa-eRpM3Z5/jaXF8d4Nmg/PBvJyYfA\"",
		"mtime": "2026-08-25T17:40:06.922Z",
		"size": 43258,
		"path": "../public/assets/createLucideIcon-CX0ia4Xd.js"
	},
	"/assets/deals-Bs9lqbaJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6e0-k8HYy0aqoFcoXlHCEIzTmgzMS18\"",
		"mtime": "2026-08-25T17:40:06.962Z",
		"size": 1760,
		"path": "../public/assets/deals-Bs9lqbaJ.js"
	},
	"/assets/delete-account-CH2nP5TC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"12c9-NCCx9tf5cutTg2o05NVMJ9qyfOQ\"",
		"mtime": "2026-08-25T17:40:06.963Z",
		"size": 4809,
		"path": "../public/assets/delete-account-CH2nP5TC.js"
	},
	"/assets/dist-CfS4U4qI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"46b-3quxW0TVn4dmRBisrd1FxIRAgkg\"",
		"mtime": "2026-08-25T17:40:06.963Z",
		"size": 1131,
		"path": "../public/assets/dist-CfS4U4qI.js"
	},
	"/assets/dist-iSjKo4yw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f37-YiCCoiaUPrm15gRgtPYJyfQkhYY\"",
		"mtime": "2026-08-25T17:40:06.964Z",
		"size": 7991,
		"path": "../public/assets/dist-iSjKo4yw.js"
	},
	"/assets/es-C_Ha8SM2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"33be-r0M5/VZDerxHkUlLViA2uVgz6RI\"",
		"mtime": "2026-08-25T17:40:06.964Z",
		"size": 13246,
		"path": "../public/assets/es-C_Ha8SM2.js"
	},
	"/assets/esm-5zjhkOtI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-krZE9Hf/pm+rP9FFJ1ubI+9UZMw\"",
		"mtime": "2026-08-25T17:40:06.965Z",
		"size": 385,
		"path": "../public/assets/esm-5zjhkOtI.js"
	},
	"/assets/esm-BSUtDBFM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"66-TkzmMPOuUjNkWdHP4fa8URrSqlU\"",
		"mtime": "2026-08-25T17:40:06.966Z",
		"size": 102,
		"path": "../public/assets/esm-BSUtDBFM.js"
	},
	"/assets/esm-BT1_fQqw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-2LUhO20yw1IYvG2KSB1cs1csyik\"",
		"mtime": "2026-08-25T17:40:06.966Z",
		"size": 385,
		"path": "../public/assets/esm-BT1_fQqw.js"
	},
	"/assets/esm-Dd0fk4Jg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb-HOW9wy9LsEigXB/DSaSrqJQb2wU\"",
		"mtime": "2026-08-25T17:40:06.967Z",
		"size": 251,
		"path": "../public/assets/esm-Dd0fk4Jg.js"
	},
	"/assets/esm-DlEcpp0G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"595-E5ewG1TTExp/j6wPb5ZnxAEuDLI\"",
		"mtime": "2026-08-25T17:40:06.972Z",
		"size": 1429,
		"path": "../public/assets/esm-DlEcpp0G.js"
	},
	"/assets/favorites-CL15clFd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"652-8VoVTuBEtuw7xwqblBEaxcEMaWg\"",
		"mtime": "2026-08-25T17:40:07.127Z",
		"size": 1618,
		"path": "../public/assets/favorites-CL15clFd.js"
	},
	"/assets/flame-COs47oVf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c7-pam9bou//MqLvZa/BXDoaiy744Q\"",
		"mtime": "2026-08-25T17:40:07.130Z",
		"size": 199,
		"path": "../public/assets/flame-COs47oVf.js"
	},
	"/assets/format-tzvdlX4z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a4-is9P6m/J2LSseqtZTt+GPjjkcAc\"",
		"mtime": "2026-08-25T17:40:07.130Z",
		"size": 932,
		"path": "../public/assets/format-tzvdlX4z.js"
	},
	"/assets/filter-bar-DsjIh-E1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3ed4-qFaFL8UgQIWiVe6YM3Hz7LvQCNI\"",
		"mtime": "2026-08-25T17:40:07.128Z",
		"size": 16084,
		"path": "../public/assets/filter-bar-DsjIh-E1.js"
	},
	"/assets/html2canvas-BfZ04V3R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30b99-oSXtJ7yui3fRH2awJKTqZXftx2Y\"",
		"mtime": "2026-08-25T17:40:07.144Z",
		"size": 199577,
		"path": "../public/assets/html2canvas-BfZ04V3R.js"
	},
	"/assets/icons-tqznr91k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e1-ycmzwnJf3KlmS/j50bR+z+fT8QY\"",
		"mtime": "2026-08-25T17:40:07.145Z",
		"size": 225,
		"path": "../public/assets/icons-tqznr91k.js"
	},
	"/assets/image-De9brycf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10d-dO8ZeUisUpr7IDaH0tEytSVHrBc\"",
		"mtime": "2026-08-25T17:40:07.145Z",
		"size": 269,
		"path": "../public/assets/image-De9brycf.js"
	},
	"/assets/index-Bja7kB1u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6897f-D9ARHJGwKbf5q3il/ItuhOFkzII\"",
		"mtime": "2026-08-25T17:40:06.614Z",
		"size": 428415,
		"path": "../public/assets/index-Bja7kB1u.js"
	},
	"/assets/input-C5BeVnhO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f7-Z7Lsw37w4xb9YgGDv9CSB6bEJ1o\"",
		"mtime": "2026-08-25T17:40:07.147Z",
		"size": 1015,
		"path": "../public/assets/input-C5BeVnhO.js"
	},
	"/assets/invariant-DEEwAagU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c-eVh/3DMi1s3cxf4N/OJar+ew1jA\"",
		"mtime": "2026-08-25T17:40:07.148Z",
		"size": 60,
		"path": "../public/assets/invariant-DEEwAagU.js"
	},
	"/assets/jsx-runtime-By8HlURe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b3-IA0XiFuRY0cUsIlFJWjLIFoOPrI\"",
		"mtime": "2026-08-25T17:40:07.151Z",
		"size": 435,
		"path": "../public/assets/jsx-runtime-By8HlURe.js"
	},
	"/assets/loader-circle-BsKZP6Nl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-tZQw+8pyCT50nzwbPTuaTmFx5ZM\"",
		"mtime": "2026-08-25T17:40:07.151Z",
		"size": 144,
		"path": "../public/assets/loader-circle-BsKZP6Nl.js"
	},
	"/assets/legal-contact-jl7PC0sY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6c1-tSO85S3LOjbOgxb+Jjv/ZFe0MUI\"",
		"mtime": "2026-08-25T17:40:07.151Z",
		"size": 1729,
		"path": "../public/assets/legal-contact-jl7PC0sY.js"
	},
	"/assets/map-pin-7amS918F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"103-ftFAkq/YRGDgJ/rl7DUIHHmwU3Y\"",
		"mtime": "2026-08-25T17:40:07.153Z",
		"size": 259,
		"path": "../public/assets/map-pin-7amS918F.js"
	},
	"/assets/jspdf.es.min-C8ykbm0_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"61951-iOp7TlXrsZt2VvBT7HtCR+H3MUo\"",
		"mtime": "2026-08-25T17:40:07.150Z",
		"size": 399697,
		"path": "../public/assets/jspdf.es.min-C8ykbm0_.js"
	},
	"/assets/messages-Ciw1mG64.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"481-/H41hiyq/zroS99KecYL3g1djhc\"",
		"mtime": "2026-08-25T17:40:07.206Z",
		"size": 1153,
		"path": "../public/assets/messages-Ciw1mG64.js"
	},
	"/assets/index.es-DYERYDqN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24f5e-hKbuSo9LC2WdYivxkiIjrA3eWKM\"",
		"mtime": "2026-08-25T17:40:07.146Z",
		"size": 151390,
		"path": "../public/assets/index.es-DYERYDqN.js"
	},
	"/assets/minus-J2I3ovAm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75-xL/ksJY3ERBGmrb+BuJX5smYHEc\"",
		"mtime": "2026-08-25T17:40:07.207Z",
		"size": 117,
		"path": "../public/assets/minus-J2I3ovAm.js"
	},
	"/assets/native-oauth-CSUbvlNg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"776-LmSSx+xnNPCEsj/Ojl9EG3/cbkw\"",
		"mtime": "2026-08-25T17:40:07.264Z",
		"size": 1910,
		"path": "../public/assets/native-oauth-CSUbvlNg.js"
	},
	"/assets/native-BS26JCkj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d6-isP6jVOggP/VLtmEL0g66zWXi6Q\"",
		"mtime": "2026-08-25T17:40:07.263Z",
		"size": 726,
		"path": "../public/assets/native-BS26JCkj.js"
	},
	"/assets/notifications-RufoZV13.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"725-oVh20hX1HPB0We9XM7/3yo6mo94\"",
		"mtime": "2026-08-25T17:40:07.266Z",
		"size": 1829,
		"path": "../public/assets/notifications-RufoZV13.js"
	},
	"/assets/notifications-CMuLhzyr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"133b-tB5CEjcqk0tl0MW7ehdjgdbvZg8\"",
		"mtime": "2026-08-25T17:40:07.265Z",
		"size": 4923,
		"path": "../public/assets/notifications-CMuLhzyr.js"
	},
	"/assets/offers-uvh0O5Xn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7413-NKDOn0Yw6Y9fWULLqp7GLv4a8HU\"",
		"mtime": "2026-08-25T17:40:07.267Z",
		"size": 29715,
		"path": "../public/assets/offers-uvh0O5Xn.js"
	},
	"/assets/order-status-BF-ev-l8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7ee-fUbJvO+Z887MFYkmnGNrCEisU+A\"",
		"mtime": "2026-08-25T17:40:07.273Z",
		"size": 2030,
		"path": "../public/assets/order-status-BF-ev-l8.js"
	},
	"/assets/order-success._id-DDBkgG1A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7e0-/I48qf8LRGBtAAdbRN2nptzdYuc\"",
		"mtime": "2026-08-25T17:40:07.274Z",
		"size": 2016,
		"path": "../public/assets/order-success._id-DDBkgG1A.js"
	},
	"/assets/orders-BFNN71lf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b5d-wTVoa2/kPkYBk2NBEYo8IJZCxdY\"",
		"mtime": "2026-08-25T17:40:07.275Z",
		"size": 7005,
		"path": "../public/assets/orders-BFNN71lf.js"
	},
	"/assets/orders_._id-4Em3uaBL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36af-gwvsCxDovdNH3fLYmro4iTWLjCg\"",
		"mtime": "2026-08-25T17:40:07.277Z",
		"size": 13999,
		"path": "../public/assets/orders_._id-4Em3uaBL.js"
	},
	"/assets/package-Kj9pavVQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"174-+qewDA+FszPpJdPYrMlh/qLl8jg\"",
		"mtime": "2026-08-25T17:40:07.304Z",
		"size": 372,
		"path": "../public/assets/package-Kj9pavVQ.js"
	},
	"/assets/page-shell-BhxUdECv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23f1-sPjJPdlPxEAIxhXLP4Qleh1N5uQ\"",
		"mtime": "2026-08-25T17:40:07.306Z",
		"size": 9201,
		"path": "../public/assets/page-shell-BhxUdECv.js"
	},
	"/assets/pencil-BkbtG3dg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"114-k7POQ8E7ljX0uedu2RWaNsDiCy0\"",
		"mtime": "2026-08-25T17:40:07.308Z",
		"size": 276,
		"path": "../public/assets/pencil-BkbtG3dg.js"
	},
	"/assets/phone-auth-CnyemZ4I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18e-uUiA0rUKwEfIZ+YJO9NjHFJvfKQ\"",
		"mtime": "2026-08-25T17:40:07.309Z",
		"size": 398,
		"path": "../public/assets/phone-auth-CnyemZ4I.js"
	},
	"/assets/phone-UntyVTdD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-D63QYC9Nl/J8l62/X/e8MWZJs8s\"",
		"mtime": "2026-08-25T17:40:07.308Z",
		"size": 322,
		"path": "../public/assets/phone-UntyVTdD.js"
	},
	"/assets/plus-mC44SyWK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-GhWb3E2Vnn33R078Ts3gHaffWBg\"",
		"mtime": "2026-08-25T17:40:07.309Z",
		"size": 153,
		"path": "../public/assets/plus-mC44SyWK.js"
	},
	"/assets/preload-helper-CZgWQFsJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4e8-074MSUArFcMGbNIntmhcTcVu9/k\"",
		"mtime": "2026-08-25T17:40:07.310Z",
		"size": 1256,
		"path": "../public/assets/preload-helper-CZgWQFsJ.js"
	},
	"/assets/printable-invoice-Daj4mlyK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5aea-yUtCiavGdiKe6e09JhHqdZaYRK4\"",
		"mtime": "2026-08-25T17:40:07.312Z",
		"size": 23274,
		"path": "../public/assets/printable-invoice-Daj4mlyK.js"
	},
	"/assets/privacy-BSbxvqbo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24ad-/ERSp0l8J8QhXbyWsHqbfjWKcsE\"",
		"mtime": "2026-08-25T17:40:07.313Z",
		"size": 9389,
		"path": "../public/assets/privacy-BSbxvqbo.js"
	},
	"/assets/product._id-DdL7DgyH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b6-NBjE+MgjLRQBQYfzT6fqcYMTI6M\"",
		"mtime": "2026-08-25T17:40:07.349Z",
		"size": 182,
		"path": "../public/assets/product._id-DdL7DgyH.js"
	},
	"/assets/product._id-B5-d7Qna.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6838-SXQFLObK5dlF2Xk8PRvAUMwbPSA\"",
		"mtime": "2026-08-25T17:40:07.347Z",
		"size": 26680,
		"path": "../public/assets/product._id-B5-d7Qna.js"
	},
	"/assets/product._id-DwK1NYM_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1fd-bWjN2NixExO93guiA4P/GF7MJDA\"",
		"mtime": "2026-08-25T17:40:07.350Z",
		"size": 509,
		"path": "../public/assets/product._id-DwK1NYM_.js"
	},
	"/assets/products-BBoTqzER.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11de-7Kfrbz3kQgLuJPYKpz/t9/dnsxY\"",
		"mtime": "2026-08-25T17:40:07.350Z",
		"size": 4574,
		"path": "../public/assets/products-BBoTqzER.js"
	},
	"/assets/profile-completion-CiJbVuwn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f5d-dVxBE0JZqJzEYNiMqBhciEqRxU4\"",
		"mtime": "2026-08-25T17:40:07.351Z",
		"size": 3933,
		"path": "../public/assets/profile-completion-CiJbVuwn.js"
	},
	"/assets/profanity-Bl0NHGZ0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"556-tJ0AmtoGkutkzoC65DkMUdEmbV4\"",
		"mtime": "2026-08-25T17:40:07.351Z",
		"size": 1366,
		"path": "../public/assets/profanity-Bl0NHGZ0.js"
	},
	"/assets/purify.es-DuRL7t6i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"68ff-UzqdquwlS23jMr/0lDNWmxy5AL0\"",
		"mtime": "2026-08-25T17:40:07.352Z",
		"size": 26879,
		"path": "../public/assets/purify.es-DuRL7t6i.js"
	},
	"/assets/progress-BGFxdca5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"91f-3RjxgVvb1A3udtM+5sXRbgxoPuY\"",
		"mtime": "2026-08-25T17:40:07.352Z",
		"size": 2335,
		"path": "../public/assets/progress-BGFxdca5.js"
	},
	"/assets/redirect-DCb_aIiF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"271-AJO48VqfkUfrNYq6mvZqsvvYRKY\"",
		"mtime": "2026-08-25T17:40:07.354Z",
		"size": 625,
		"path": "../public/assets/redirect-DCb_aIiF.js"
	},
	"/assets/queryOptions-Dfvzj6n2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26-swOrbCYhZ0gnyks4Amdj937R/Ts\"",
		"mtime": "2026-08-25T17:40:07.352Z",
		"size": 38,
		"path": "../public/assets/queryOptions-Dfvzj6n2.js"
	},
	"/assets/repeat-C3d4Cia4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"110-Shg6GCISqYQbSZ6tCLvj0dqd0Zo\"",
		"mtime": "2026-08-25T17:40:07.354Z",
		"size": 272,
		"path": "../public/assets/repeat-C3d4Cia4.js"
	},
	"/assets/refresh-cw-CQf63W6J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"141-J3PKHUt2+eQNHJj7NRiSGB8sWwk\"",
		"mtime": "2026-08-25T17:40:07.354Z",
		"size": 321,
		"path": "../public/assets/refresh-cw-CQf63W6J.js"
	},
	"/assets/replacements-CI0Aq8AG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f87-iSwPuaTdeNACvzBHoOiFUvr8m6A\"",
		"mtime": "2026-08-25T17:40:07.355Z",
		"size": 8071,
		"path": "../public/assets/replacements-CI0Aq8AG.js"
	},
	"/assets/replacements_._id-CF56rX2s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36b8-lsazKhYXxbV65UOYEZTSNBuhEzE\"",
		"mtime": "2026-08-25T17:40:07.355Z",
		"size": 14008,
		"path": "../public/assets/replacements_._id-CF56rX2s.js"
	},
	"/assets/rolldown-runtime-QTnfLwEv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b6-wnqLLSlp3SaE+lbe74bKNe5Rpds\"",
		"mtime": "2026-08-25T17:40:07.356Z",
		"size": 694,
		"path": "../public/assets/rolldown-runtime-QTnfLwEv.js"
	},
	"/assets/routes-CspAfm6F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9dd8-kOD87ZQgmgq2MDv3KNNW1Ykkuks\"",
		"mtime": "2026-08-25T17:40:07.357Z",
		"size": 40408,
		"path": "../public/assets/routes-CspAfm6F.js"
	},
	"/assets/route-BQQQeJsq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b2-ksxMdvQe5yFkCRFTgUBejBTpDzU\"",
		"mtime": "2026-08-25T17:40:07.356Z",
		"size": 1970,
		"path": "../public/assets/route-BQQQeJsq.js"
	},
	"/assets/search-BLKqA7CN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-hxSZVYFk8yGlZdbxcVLSq245quo\"",
		"mtime": "2026-08-25T17:40:07.394Z",
		"size": 174,
		"path": "../public/assets/search-BLKqA7CN.js"
	},
	"/assets/shield-CGTxnVNi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"110-/lfqSpRTTEBCjAi+iI1gJaNDGH0\"",
		"mtime": "2026-08-25T17:40:07.643Z",
		"size": 272,
		"path": "../public/assets/shield-CGTxnVNi.js"
	},
	"/assets/search-DKD4BStU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d2b-4gv4exMlQrmsMDDZfUQxiFN8OUU\"",
		"mtime": "2026-08-25T17:40:07.643Z",
		"size": 3371,
		"path": "../public/assets/search-DKD4BStU.js"
	},
	"/assets/shipping-BZRBFfJB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29e-n5PXK8T1C/pBGy5+DNrCIVv4iCk\"",
		"mtime": "2026-08-25T17:40:07.644Z",
		"size": 670,
		"path": "../public/assets/shipping-BZRBFfJB.js"
	},
	"/assets/shopping-cart-OVGA1WVK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a3-rTcazhpZ4y3oeWFPqvq77zAUrBA\"",
		"mtime": "2026-08-25T17:40:07.644Z",
		"size": 675,
		"path": "../public/assets/shopping-cart-OVGA1WVK.js"
	},
	"/assets/sparkles-BEYgNBKF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-PtvzT1vHowf0K+faX7uyI22sVCM\"",
		"mtime": "2026-08-25T17:40:07.645Z",
		"size": 494,
		"path": "../public/assets/sparkles-BEYgNBKF.js"
	},
	"/assets/sticky-note-KFqXFJrx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"118-TaoINuXfeFFvVVAM6goYLuR3xjY\"",
		"mtime": "2026-08-25T17:40:07.645Z",
		"size": 280,
		"path": "../public/assets/sticky-note-KFqXFJrx.js"
	},
	"/assets/thumbs-up-DBYFGh6s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"228-+JiL7rKUfTnPbiDf6Si9FrEmmlo\"",
		"mtime": "2026-08-25T17:40:07.645Z",
		"size": 552,
		"path": "../public/assets/thumbs-up-DBYFGh6s.js"
	},
	"/assets/timer-Dhvn_t3B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ee-DQHHu/vfjle7F7F9rdNegHGLEeA\"",
		"mtime": "2026-08-25T17:40:07.646Z",
		"size": 238,
		"path": "../public/assets/timer-Dhvn_t3B.js"
	},
	"/assets/trash-2-Bc4A27_9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"148-GJU1T/4SRu2c3FGdysOwRwAZJ/Q\"",
		"mtime": "2026-08-25T17:40:07.646Z",
		"size": 328,
		"path": "../public/assets/trash-2-Bc4A27_9.js"
	},
	"/assets/triangle-alert-CXE0Ni_i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"109-kPb1hzOiKg4STwPL/nkiqTeUBw4\"",
		"mtime": "2026-08-25T17:40:07.647Z",
		"size": 265,
		"path": "../public/assets/triangle-alert-CXE0Ni_i.js"
	},
	"/assets/truck-DmOmjpyY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"196-zfs625rLuGix5KPlHY2IjS/tOOw\"",
		"mtime": "2026-08-25T17:40:07.649Z",
		"size": 406,
		"path": "../public/assets/truck-DmOmjpyY.js"
	},
	"/assets/typeof-B5XbjTb1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10f-yPXEOGyFHb1Ws7OoWyWNEEBz4mQ\"",
		"mtime": "2026-08-25T17:40:07.650Z",
		"size": 271,
		"path": "../public/assets/typeof-B5XbjTb1.js"
	},
	"/assets/upload-P_j2OCqa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-5LrPKTi+ZEffDQ4Q3buudPPxe1Q\"",
		"mtime": "2026-08-25T17:40:07.650Z",
		"size": 230,
		"path": "../public/assets/upload-P_j2OCqa.js"
	},
	"/assets/styles-BQJvFxyU.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"264ef-4s+lGyUi0+g3WRYqU9nXZSARw48\"",
		"mtime": "2026-08-25T17:40:07.815Z",
		"size": 156911,
		"path": "../public/assets/styles-BQJvFxyU.css"
	},
	"/assets/upload-with-progress-CkcOrscr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"448-s7K3USELE22jg0Ke8ibzrMS5M50\"",
		"mtime": "2026-08-25T17:40:07.650Z",
		"size": 1096,
		"path": "../public/assets/upload-with-progress-CkcOrscr.js"
	},
	"/assets/terms-CsNzARth.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"247f-KHgpxB2cqZMAiTOUF1s0in+0YII\"",
		"mtime": "2026-08-25T17:40:07.645Z",
		"size": 9343,
		"path": "../public/assets/terms-CsNzARth.js"
	},
	"/assets/useBaseQuery-CJiZPpEJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22ba-w2AVMObslBVhggRkPQKhOjeZRB8\"",
		"mtime": "2026-08-25T17:40:07.651Z",
		"size": 8890,
		"path": "../public/assets/useBaseQuery-CJiZPpEJ.js"
	},
	"/assets/useInfiniteQuery-D_ODyn2g.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48e-7MHN2wVUMFAW01orQVlTqpGYYPo\"",
		"mtime": "2026-08-25T17:40:07.652Z",
		"size": 1166,
		"path": "../public/assets/useInfiniteQuery-D_ODyn2g.js"
	},
	"/assets/useNavigate-D0psL8lk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e9-FdOBNccF3s1OqdpPll2jAiQ9Ub8\"",
		"mtime": "2026-08-25T17:40:07.803Z",
		"size": 233,
		"path": "../public/assets/useNavigate-D0psL8lk.js"
	},
	"/assets/useMatch-BeSSgiG8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ca-ACI5TCq4ARSaMDRC5IKekchQ12s\"",
		"mtime": "2026-08-25T17:40:07.652Z",
		"size": 714,
		"path": "../public/assets/useMatch-BeSSgiG8.js"
	},
	"/assets/useQuery-DbH1JsXj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"60-5Oqx8ZV2GSwW6UkFgtsmBDzJcjM\"",
		"mtime": "2026-08-25T17:40:07.805Z",
		"size": 96,
		"path": "../public/assets/useQuery-DbH1JsXj.js"
	},
	"/assets/user-PiYxEYaO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4-N3R7YADCQGMTT0QtuIMh8EQ8tr0\"",
		"mtime": "2026-08-25T17:40:07.807Z",
		"size": 196,
		"path": "../public/assets/user-PiYxEYaO.js"
	},
	"/assets/useRouter-CAlSMMd6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dbf-1h7KwnEcJjaVQmxtEADTXktjFa0\"",
		"mtime": "2026-08-25T17:40:07.805Z",
		"size": 7615,
		"path": "../public/assets/useRouter-CAlSMMd6.js"
	},
	"/assets/users-COEBE2Sx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-X22C3q10GHKnfDmfxhWc26YD0SI\"",
		"mtime": "2026-08-25T17:40:07.809Z",
		"size": 306,
		"path": "../public/assets/users-COEBE2Sx.js"
	},
	"/assets/useSearch-CqUcoHIE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"da-/ykJ5NW/61WjJD8UAXogUyQ0pMk\"",
		"mtime": "2026-08-25T17:40:07.806Z",
		"size": 218,
		"path": "../public/assets/useSearch-CqUcoHIE.js"
	},
	"/assets/useSuspenseQuery-nUG1NUxc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-xPuX8/LnZpH5QRFwnQLSO+coEC8\"",
		"mtime": "2026-08-25T17:40:07.807Z",
		"size": 174,
		"path": "../public/assets/useSuspenseQuery-nUG1NUxc.js"
	},
	"/assets/utils-B6KiDbIe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a7d-iNkBSvaSyIjvZOzWoTvEa49qwcI\"",
		"mtime": "2026-08-25T17:40:07.810Z",
		"size": 27261,
		"path": "../public/assets/utils-B6KiDbIe.js"
	},
	"/assets/volume-x-9jMCUmgC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d7-r6TY/Vzy6sG63WsW4+p+3ghm0MI\"",
		"mtime": "2026-08-25T17:40:07.810Z",
		"size": 727,
		"path": "../public/assets/volume-x-9jMCUmgC.js"
	},
	"/assets/web-Bb6nlQXU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f9-MyBMEJI2KOOeW0CrRcpb0L3xoqo\"",
		"mtime": "2026-08-25T17:40:07.812Z",
		"size": 761,
		"path": "../public/assets/web-Bb6nlQXU.js"
	},
	"/assets/web-BTgg8XI0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16c-wcG0l8fKsCX1wgK1/uhAufsqdh4\"",
		"mtime": "2026-08-25T17:40:07.811Z",
		"size": 364,
		"path": "../public/assets/web-BTgg8XI0.js"
	},
	"/assets/web-BU4E6wEE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34b-HR7NgMsPImGrP3rempwCqLB5tww\"",
		"mtime": "2026-08-25T17:40:07.812Z",
		"size": 843,
		"path": "../public/assets/web-BU4E6wEE.js"
	},
	"/assets/web-DmK04iAh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"169-Iz3yeqUqXJEYD9mPLFNawScfsuA\"",
		"mtime": "2026-08-25T17:40:07.813Z",
		"size": 361,
		"path": "../public/assets/web-DmK04iAh.js"
	},
	"/assets/web-C3VMymT7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"212c-brp3KIRsJlRF9BfHlQV0GRkXPLY\"",
		"mtime": "2026-08-25T17:40:07.813Z",
		"size": 8492,
		"path": "../public/assets/web-C3VMymT7.js"
	},
	"/assets/web-mcNnWSUR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a7-nPXifNktGrf9veC+Di+T9eux7W0\"",
		"mtime": "2026-08-25T17:40:07.814Z",
		"size": 1191,
		"path": "../public/assets/web-mcNnWSUR.js"
	},
	"/assets/web-vlIvnWZ_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2dc-npapsSLFhVY1aynsv54VkpoKoAU\"",
		"mtime": "2026-08-25T17:40:07.814Z",
		"size": 732,
		"path": "../public/assets/web-vlIvnWZ_.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_3QbIaZ = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_3QbIaZ
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
