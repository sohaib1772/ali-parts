//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B7qPIgSy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/react/ali-parts-pro/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/auth",
			"/best-sellers",
			"/contact",
			"/deals",
			"/delete-account",
			"/offers",
			"/privacy",
			"/products",
			"/search",
			"/terms",
			"/category/$id",
			"/order-success/$id",
			"/product/$id"
		],
		preloads: [
			"/assets/index-DycdnOaE.js",
			"/assets/rolldown-runtime-QTnfLwEv.js",
			"/assets/useRouter-CAlSMMd6.js",
			"/assets/createLucideIcon-f_8Qggt1.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/redirect-DCb_aIiF.js",
			"/assets/jsx-runtime-By8HlURe.js",
			"/assets/useMatch-4yPsuliU.js",
			"/assets/useSearch-8NWoXOsk.js",
			"/assets/useNavigate-D0psL8lk.js",
			"/assets/client-VpccseFy.js",
			"/assets/preload-helper-CZgWQFsJ.js",
			"/assets/queryOptions-Dfvzj6n2.js",
			"/assets/dist-iSjKo4yw.js",
			"/assets/utils-B6KiDbIe.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DycdnOaE.js"
		} }]
	},
	"/": {
		filePath: "C:/react/ali-parts-pro/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DrmFkp8S.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useInfiniteQuery-CiyuczXW.js",
			"/assets/useSuspenseQuery-DdvbYil_.js",
			"/assets/chevron-left-C55aE8RO.js",
			"/assets/flame-ELqmm_W6.js",
			"/assets/sparkles-CYbbP3SJ.js",
			"/assets/timer-sAiIQFvn.js",
			"/assets/volume-x-DtBIPOg9.js",
			"/assets/admin-DUXxVDnr.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/filter-bar-BAX1Jf2O.js",
			"/assets/icons-CA6I3S0M.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/account",
			"/_authenticated/addresses",
			"/_authenticated/admin",
			"/_authenticated/cart",
			"/_authenticated/checkout",
			"/_authenticated/favorites",
			"/_authenticated/messages",
			"/_authenticated/notifications",
			"/_authenticated/orders",
			"/_authenticated/replacements",
			"/_authenticated/orders_/$id",
			"/_authenticated/replacements_/$id"
		],
		preloads: ["/assets/route-CGqadjC5.js", "/assets/profile-completion-DFVZ4mFm.js"]
	},
	"/about": {
		filePath: "C:/react/ali-parts-pro/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-CcAXDwRR.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/clock-BwhGQEZ9.js",
			"/assets/map-pin-CofDtUxA.js",
			"/assets/shield-Bo4X6h5j.js",
			"/assets/truck-D_xSh_mV.js",
			"/assets/users-BAPjvcGw.js",
			"/assets/admin-DUXxVDnr.js"
		]
	},
	"/auth": {
		filePath: "C:/react/ali-parts-pro/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-D1P60aEc.js",
			"/assets/arrow-right-J5nX3CGR.js",
			"/assets/loader-circle-CqlDARXt.js",
			"/assets/admin-DUXxVDnr.js"
		]
	},
	"/best-sellers": {
		filePath: "C:/react/ali-parts-pro/src/routes/best-sellers.tsx",
		children: void 0,
		preloads: [
			"/assets/best-sellers-Dxs-B7wz.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useSuspenseQuery-DdvbYil_.js",
			"/assets/chevron-left-C55aE8RO.js",
			"/assets/flame-ELqmm_W6.js",
			"/assets/filter-bar-BAX1Jf2O.js"
		]
	},
	"/contact": {
		filePath: "C:/react/ali-parts-pro/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-CM3wr5m1.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/map-pin-CofDtUxA.js",
			"/assets/phone-D0zusc0M.js",
			"/assets/admin-DUXxVDnr.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/icons-CA6I3S0M.js"
		]
	},
	"/deals": {
		filePath: "C:/react/ali-parts-pro/src/routes/deals.tsx",
		children: void 0,
		preloads: [
			"/assets/deals-CClf_tVU.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useSuspenseQuery-DdvbYil_.js",
			"/assets/chevron-left-C55aE8RO.js",
			"/assets/timer-sAiIQFvn.js",
			"/assets/filter-bar-BAX1Jf2O.js"
		]
	},
	"/delete-account": {
		filePath: "C:/react/ali-parts-pro/src/routes/delete-account.tsx",
		children: void 0,
		preloads: [
			"/assets/delete-account-BaDNP-OD.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/shopping-cart-DZhrArPu.js",
			"/assets/trash-2-DD2Sw6vV.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-Cdm2Ut2W.js"
		]
	},
	"/offers": {
		filePath: "C:/react/ali-parts-pro/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-BjPTCdif.js",
			"/assets/admin.functions-3e2CciRl.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/useSuspenseQuery-DdvbYil_.js",
			"/assets/check-CcphccHU.js",
			"/assets/chevron-left-C55aE8RO.js",
			"/assets/shopping-cart-DZhrArPu.js",
			"/assets/pencil-DQ8tsBin.js",
			"/assets/search-mOfzf65C.js",
			"/assets/shield-Bo4X6h5j.js",
			"/assets/sparkles-CYbbP3SJ.js",
			"/assets/trash-2-DD2Sw6vV.js",
			"/assets/users-BAPjvcGw.js",
			"/assets/volume-x-DtBIPOg9.js",
			"/assets/admin-DUXxVDnr.js",
			"/assets/button-ClAQp897.js"
		]
	},
	"/privacy": {
		filePath: "C:/react/ali-parts-pro/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-DXAk2N10.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/shopping-cart-DZhrArPu.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-Cdm2Ut2W.js"
		]
	},
	"/products": {
		filePath: "C:/react/ali-parts-pro/src/routes/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DRgvdzmi.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useInfiniteQuery-CiyuczXW.js",
			"/assets/chevron-left-C55aE8RO.js",
			"/assets/flame-ELqmm_W6.js",
			"/assets/filter-bar-BAX1Jf2O.js"
		]
	},
	"/search": {
		filePath: "C:/react/ali-parts-pro/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-D6ZIT_St.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/refresh-cw-DAGPGNqb.js",
			"/assets/search-mOfzf65C.js",
			"/assets/filter-bar-BAX1Jf2O.js"
		]
	},
	"/terms": {
		filePath: "C:/react/ali-parts-pro/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-CXsqGWeD.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/shopping-cart-DZhrArPu.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-Cdm2Ut2W.js"
		]
	},
	"/_authenticated/account": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-r5WGT2EC.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/check-CcphccHU.js",
			"/assets/chevron-left-C55aE8RO.js",
			"/assets/shopping-cart-DZhrArPu.js",
			"/assets/loader-circle-CqlDARXt.js",
			"/assets/map-pin-CofDtUxA.js",
			"/assets/package-8YJfeI7L.js",
			"/assets/pencil-DQ8tsBin.js",
			"/assets/input-itgtTWqB.js",
			"/assets/shield-Bo4X6h5j.js",
			"/assets/sparkles-CYbbP3SJ.js",
			"/assets/trash-2-DD2Sw6vV.js",
			"/assets/admin-DUXxVDnr.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-F3zDgjtb.js"
		]
	},
	"/_authenticated/addresses": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/addresses.tsx",
		children: void 0,
		preloads: [
			"/assets/addresses-Dnc8s3Wd.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/check-CcphccHU.js",
			"/assets/chevron-down-i4ntKBo0.js",
			"/assets/map-pin-CofDtUxA.js",
			"/assets/pencil-DQ8tsBin.js",
			"/assets/plus-Bb-qvJcA.js",
			"/assets/search-mOfzf65C.js",
			"/assets/trash-2-DD2Sw6vV.js"
		]
	},
	"/_authenticated/admin": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-ezBo_6cg.js",
			"/assets/admin.functions-3e2CciRl.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/order-status-B0RdXWHt.js",
			"/assets/check-CcphccHU.js",
			"/assets/chevron-down-i4ntKBo0.js",
			"/assets/circle-check-PcKFb5ZE.js",
			"/assets/circle-x-BxLkF9Le.js",
			"/assets/clock-BwhGQEZ9.js",
			"/assets/printable-invoice-WhU6hmJU.js",
			"/assets/image-BxDDW7HN.js",
			"/assets/loader-circle-CqlDARXt.js",
			"/assets/map-pin-CofDtUxA.js",
			"/assets/package-8YJfeI7L.js",
			"/assets/pencil-DQ8tsBin.js",
			"/assets/phone-D0zusc0M.js",
			"/assets/plus-Bb-qvJcA.js",
			"/assets/refresh-cw-DAGPGNqb.js",
			"/assets/repeat-DUaClw__.js",
			"/assets/search-mOfzf65C.js",
			"/assets/input-itgtTWqB.js",
			"/assets/sparkles-CYbbP3SJ.js",
			"/assets/sticky-note-CCuMKTkb.js",
			"/assets/trash-2-DD2Sw6vV.js",
			"/assets/triangle-alert-wXn2wjyc.js",
			"/assets/upload-C7VWcwDR.js",
			"/assets/user-C5O8iIYO.js",
			"/assets/users-BAPjvcGw.js",
			"/assets/admin-DUXxVDnr.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/dist-CfS4U4qI.js",
			"/assets/button-ClAQp897.js",
			"/assets/alert-dialog-F3zDgjtb.js"
		]
	},
	"/_authenticated/cart": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/cart.tsx",
		children: void 0,
		preloads: [
			"/assets/cart-V2u_7dEj.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/minus-CDQjQ1Ts.js",
			"/assets/plus-Bb-qvJcA.js",
			"/assets/sticky-note-CCuMKTkb.js",
			"/assets/trash-2-DD2Sw6vV.js",
			"/assets/admin-DUXxVDnr.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/shipping-BZRBFfJB.js"
		]
	},
	"/_authenticated/checkout": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-B3B1efhX.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/loader-circle-CqlDARXt.js",
			"/assets/map-pin-CofDtUxA.js",
			"/assets/plus-Bb-qvJcA.js",
			"/assets/sparkles-CYbbP3SJ.js",
			"/assets/sticky-note-CCuMKTkb.js",
			"/assets/triangle-alert-wXn2wjyc.js",
			"/assets/truck-D_xSh_mV.js",
			"/assets/admin-DUXxVDnr.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/shipping-BZRBFfJB.js"
		]
	},
	"/_authenticated/favorites": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/favorites.tsx",
		children: void 0,
		preloads: [
			"/assets/favorites-4NmhPuaB.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/shopping-cart-DZhrArPu.js",
			"/assets/filter-bar-BAX1Jf2O.js"
		]
	},
	"/_authenticated/messages": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/messages.tsx",
		children: void 0,
		preloads: [
			"/assets/messages-Z8QTRdGe.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/admin-DUXxVDnr.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/icons-CA6I3S0M.js"
		]
	},
	"/_authenticated/notifications": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-BgcEaYmA.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/order-status-B0RdXWHt.js",
			"/assets/check-CcphccHU.js",
			"/assets/circle-x-BxLkF9Le.js",
			"/assets/notifications-By7rSmcl.js",
			"/assets/package-8YJfeI7L.js",
			"/assets/truck-D_xSh_mV.js"
		]
	},
	"/_authenticated/orders": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/orders.tsx",
		children: void 0,
		preloads: [
			"/assets/orders-D0I4252y.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/order-status-B0RdXWHt.js",
			"/assets/chevron-left-C55aE8RO.js",
			"/assets/circle-check-PcKFb5ZE.js",
			"/assets/circle-x-BxLkF9Le.js",
			"/assets/notifications-By7rSmcl.js",
			"/assets/package-8YJfeI7L.js",
			"/assets/truck-D_xSh_mV.js",
			"/assets/format-tzvdlX4z.js"
		]
	},
	"/_authenticated/replacements": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/replacements.tsx",
		children: void 0,
		preloads: [
			"/assets/replacements-Dt9SUVLb.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/chevron-left-C55aE8RO.js",
			"/assets/circle-check-PcKFb5ZE.js",
			"/assets/clock-BwhGQEZ9.js",
			"/assets/loader-circle-CqlDARXt.js",
			"/assets/repeat-DUaClw__.js",
			"/assets/search-mOfzf65C.js",
			"/assets/thumbs-up-DgN90jV9.js"
		]
	},
	"/category/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/category.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/category._id-Dy9XliT8.js",
			"/assets/page-shell-DWJdFFTU.js",
			"/assets/useSuspenseQuery-DdvbYil_.js",
			"/assets/filter-bar-BAX1Jf2O.js"
		]
	},
	"/order-success/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/order-success.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/order-success._id-D5QLGSbe.js",
			"/assets/useSuspenseQuery-DdvbYil_.js",
			"/assets/circle-check-PcKFb5ZE.js",
			"/assets/package-8YJfeI7L.js",
			"/assets/format-tzvdlX4z.js"
		]
	},
	"/product/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/product.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/product._id-DdL7DgyH.js",
			"/assets/product._id-DwK1NYM_.js",
			"/assets/product._id-GDZg_9Ph.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/useSuspenseQuery-DdvbYil_.js",
			"/assets/arrow-right-J5nX3CGR.js",
			"/assets/circle-check-PcKFb5ZE.js",
			"/assets/circle-x-BxLkF9Le.js",
			"/assets/clock-BwhGQEZ9.js",
			"/assets/shopping-cart-DZhrArPu.js",
			"/assets/loader-circle-CqlDARXt.js",
			"/assets/minus-CDQjQ1Ts.js",
			"/assets/progress-BZBzG2K1.js",
			"/assets/plus-Bb-qvJcA.js",
			"/assets/refresh-cw-DAGPGNqb.js",
			"/assets/shield-Bo4X6h5j.js",
			"/assets/trash-2-DD2Sw6vV.js",
			"/assets/truck-D_xSh_mV.js",
			"/assets/upload-with-progress-CkcOrscr.js",
			"/assets/admin-DUXxVDnr.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-F3zDgjtb.js",
			"/assets/icons-CA6I3S0M.js"
		]
	},
	"/_authenticated/orders_/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/orders_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/orders_._id-C0cVvqV4.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/arrow-right-J5nX3CGR.js",
			"/assets/order-status-B0RdXWHt.js",
			"/assets/circle-x-BxLkF9Le.js",
			"/assets/printable-invoice-WhU6hmJU.js",
			"/assets/notifications-By7rSmcl.js",
			"/assets/map-pin-CofDtUxA.js",
			"/assets/package-8YJfeI7L.js",
			"/assets/refresh-cw-DAGPGNqb.js",
			"/assets/sticky-note-CCuMKTkb.js",
			"/assets/truck-D_xSh_mV.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-F3zDgjtb.js"
		]
	},
	"/_authenticated/replacements_/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/replacements_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/replacements_._id-5bGJ2Qsb.js",
			"/assets/useQuery-BT8RoC8n.js",
			"/assets/arrow-right-J5nX3CGR.js",
			"/assets/circle-check-PcKFb5ZE.js",
			"/assets/clock-BwhGQEZ9.js",
			"/assets/image-BxDDW7HN.js",
			"/assets/loader-circle-CqlDARXt.js",
			"/assets/progress-BZBzG2K1.js",
			"/assets/repeat-DUaClw__.js",
			"/assets/search-mOfzf65C.js",
			"/assets/sticky-note-CCuMKTkb.js",
			"/assets/thumbs-up-DgN90jV9.js",
			"/assets/upload-C7VWcwDR.js",
			"/assets/upload-with-progress-CkcOrscr.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
