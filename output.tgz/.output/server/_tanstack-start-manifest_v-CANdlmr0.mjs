//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CANdlmr0.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/react/ali-parts-pro/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/auth",
			"/best-sellers",
			"/contact",
			"/deals",
			"/delete-account",
			"/offers",
			"/privacy",
			"/products",
			"/search",
			"/terms",
			"/category/$id",
			"/order-success/$id",
			"/product/$id"
		],
		preloads: [
			"/assets/index-mwvVGelf.js",
			"/assets/rolldown-runtime-QTnfLwEv.js",
			"/assets/useRouter-CAlSMMd6.js",
			"/assets/createLucideIcon-CX0ia4Xd.js",
			"/assets/invariant-DEEwAagU.js",
			"/assets/redirect-DCb_aIiF.js",
			"/assets/jsx-runtime-By8HlURe.js",
			"/assets/useMatch-BeSSgiG8.js",
			"/assets/useSearch-CqUcoHIE.js",
			"/assets/useNavigate-D0psL8lk.js",
			"/assets/client-VpccseFy.js",
			"/assets/preload-helper-CZgWQFsJ.js",
			"/assets/queryOptions-Dfvzj6n2.js",
			"/assets/dist-iSjKo4yw.js",
			"/assets/utils-B6KiDbIe.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-mwvVGelf.js"
		} }]
	},
	"/": {
		filePath: "C:/react/ali-parts-pro/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DSn43k7l.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useInfiniteQuery-D_ODyn2g.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/flame-COs47oVf.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/timer-Dhvn_t3B.js",
			"/assets/volume-x-9jMCUmgC.js",
			"/assets/admin-DSe3Bspf.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/filter-bar-CW64zsT-.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/account",
			"/_authenticated/addresses",
			"/_authenticated/admin",
			"/_authenticated/cart",
			"/_authenticated/checkout",
			"/_authenticated/favorites",
			"/_authenticated/messages",
			"/_authenticated/notifications",
			"/_authenticated/orders",
			"/_authenticated/replacements",
			"/_authenticated/orders_/$id",
			"/_authenticated/replacements_/$id"
		],
		preloads: ["/assets/route-CJjmydJS.js", "/assets/profile-completion-BxPO9xsY.js"]
	},
	"/about": {
		filePath: "C:/react/ali-parts-pro/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about--AYfWmuJ.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/users-COEBE2Sx.js",
			"/assets/admin-DSe3Bspf.js"
		]
	},
	"/auth": {
		filePath: "C:/react/ali-parts-pro/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BQtTIbTY.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/admin-DSe3Bspf.js"
		]
	},
	"/best-sellers": {
		filePath: "C:/react/ali-parts-pro/src/routes/best-sellers.tsx",
		children: void 0,
		preloads: [
			"/assets/best-sellers-Kvdc175M.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/flame-COs47oVf.js",
			"/assets/filter-bar-CW64zsT-.js"
		]
	},
	"/contact": {
		filePath: "C:/react/ali-parts-pro/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-C5xkJzL5.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/phone-UntyVTdD.js",
			"/assets/admin-DSe3Bspf.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/deals": {
		filePath: "C:/react/ali-parts-pro/src/routes/deals.tsx",
		children: void 0,
		preloads: [
			"/assets/deals-D0uvgkxG.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/timer-Dhvn_t3B.js",
			"/assets/filter-bar-CW64zsT-.js"
		]
	},
	"/delete-account": {
		filePath: "C:/react/ali-parts-pro/src/routes/delete-account.tsx",
		children: void 0,
		preloads: [
			"/assets/delete-account-BPIDzzyI.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-CeSSiuOO.js"
		]
	},
	"/offers": {
		filePath: "C:/react/ali-parts-pro/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-C1GcZfxF.js",
			"/assets/admin.functions-BheXu954.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/users-COEBE2Sx.js",
			"/assets/volume-x-9jMCUmgC.js",
			"/assets/admin-DSe3Bspf.js",
			"/assets/button-Du6S86Zp.js"
		]
	},
	"/privacy": {
		filePath: "C:/react/ali-parts-pro/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-CcwdpCHB.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-CeSSiuOO.js"
		]
	},
	"/products": {
		filePath: "C:/react/ali-parts-pro/src/routes/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-Dp4nJXBD.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useInfiniteQuery-D_ODyn2g.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/flame-COs47oVf.js",
			"/assets/filter-bar-CW64zsT-.js"
		]
	},
	"/search": {
		filePath: "C:/react/ali-parts-pro/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-CHCwXYit.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/filter-bar-CW64zsT-.js"
		]
	},
	"/terms": {
		filePath: "C:/react/ali-parts-pro/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-DdeVGJ77.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/legal-contact-CeSSiuOO.js"
		]
	},
	"/_authenticated/account": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-Ckqe8t60.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/input-C5BeVnhO.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/admin-DSe3Bspf.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-EXrwU4Ge.js"
		]
	},
	"/_authenticated/addresses": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/addresses.tsx",
		children: void 0,
		preloads: [
			"/assets/addresses-C_nClWio.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-down-Bqab7lOs.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/trash-2-Bc4A27_9.js"
		]
	},
	"/_authenticated/admin": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-Dn-GuzeO.js",
			"/assets/admin.functions-BheXu954.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/chevron-down-Bqab7lOs.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/printable-invoice-D-IVJ5Jg.js",
			"/assets/image-De9brycf.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/pencil-BkbtG3dg.js",
			"/assets/phone-UntyVTdD.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/refresh-cw-CQf63W6J.js",
			"/assets/repeat-C3d4Cia4.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/input-C5BeVnhO.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/triangle-alert-CXE0Ni_i.js",
			"/assets/upload-P_j2OCqa.js",
			"/assets/user-PiYxEYaO.js",
			"/assets/users-COEBE2Sx.js",
			"/assets/admin-DSe3Bspf.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/dist-CfS4U4qI.js",
			"/assets/button-Du6S86Zp.js",
			"/assets/alert-dialog-EXrwU4Ge.js"
		]
	},
	"/_authenticated/cart": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/cart.tsx",
		children: void 0,
		preloads: [
			"/assets/cart-9dZ0QAfW.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/minus-J2I3ovAm.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/admin-DSe3Bspf.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/shipping-BZRBFfJB.js"
		]
	},
	"/_authenticated/checkout": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-D44xW3tJ.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/sparkles-BEYgNBKF.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/triangle-alert-CXE0Ni_i.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/admin-DSe3Bspf.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/shipping-BZRBFfJB.js"
		]
	},
	"/_authenticated/favorites": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/favorites.tsx",
		children: void 0,
		preloads: [
			"/assets/favorites-h0IBr7gd.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/filter-bar-CW64zsT-.js"
		]
	},
	"/_authenticated/messages": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/messages.tsx",
		children: void 0,
		preloads: [
			"/assets/messages-DTOtiD_f.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/admin-DSe3Bspf.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/icons-tqznr91k.js"
		]
	},
	"/_authenticated/notifications": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-DBASFVyg.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/check-Dt23P7tX.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/notifications-DNty9A36.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/truck-DmOmjpyY.js"
		]
	},
	"/_authenticated/orders": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/orders.tsx",
		children: void 0,
		preloads: [
			"/assets/orders-Dsf2mnn3.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/notifications-DNty9A36.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/format-tzvdlX4z.js"
		]
	},
	"/_authenticated/replacements": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/replacements.tsx",
		children: void 0,
		preloads: [
			"/assets/replacements-Clhw-hE_.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/chevron-left-DsluPFea.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/repeat-C3d4Cia4.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/thumbs-up-DBYFGh6s.js"
		]
	},
	"/category/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/category.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/category._id-DFgdhSEl.js",
			"/assets/page-shell-CcVjzeWk.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/filter-bar-CW64zsT-.js"
		]
	},
	"/order-success/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/order-success.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/order-success._id-ks9OLrCo.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/format-tzvdlX4z.js"
		]
	},
	"/product/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/product.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/product._id-4I0LbaK-.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/useSuspenseQuery-nUG1NUxc.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/shopping-cart-OVGA1WVK.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/minus-J2I3ovAm.js",
			"/assets/progress-BGIoXt3D.js",
			"/assets/plus-mC44SyWK.js",
			"/assets/refresh-cw-CQf63W6J.js",
			"/assets/shield-CGTxnVNi.js",
			"/assets/trash-2-Bc4A27_9.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/upload-with-progress-CkcOrscr.js",
			"/assets/admin-DSe3Bspf.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-EXrwU4Ge.js",
			"/assets/icons-tqznr91k.js",
			"/assets/product._id-DdL7DgyH.js",
			"/assets/product._id-DwK1NYM_.js"
		]
	},
	"/_authenticated/orders_/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/orders_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/orders_._id-BClAq8ev.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/order-status-BF-ev-l8.js",
			"/assets/circle-x-CaQbGP3Q.js",
			"/assets/printable-invoice-D-IVJ5Jg.js",
			"/assets/notifications-DNty9A36.js",
			"/assets/map-pin-7amS918F.js",
			"/assets/package-Kj9pavVQ.js",
			"/assets/refresh-cw-CQf63W6J.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/truck-DmOmjpyY.js",
			"/assets/format-tzvdlX4z.js",
			"/assets/alert-dialog-EXrwU4Ge.js"
		]
	},
	"/_authenticated/replacements_/$id": {
		filePath: "C:/react/ali-parts-pro/src/routes/_authenticated/replacements_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/replacements_._id-6DjfQLa8.js",
			"/assets/useQuery-DbH1JsXj.js",
			"/assets/arrow-right-BxvmY4ka.js",
			"/assets/circle-check-CK6z1Nju.js",
			"/assets/clock-Cl0q345K.js",
			"/assets/image-De9brycf.js",
			"/assets/loader-circle-BsKZP6Nl.js",
			"/assets/progress-BGIoXt3D.js",
			"/assets/repeat-C3d4Cia4.js",
			"/assets/search-BLKqA7CN.js",
			"/assets/sticky-note-KFqXFJrx.js",
			"/assets/thumbs-up-DBYFGh6s.js",
			"/assets/upload-P_j2OCqa.js",
			"/assets/upload-with-progress-CkcOrscr.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
