//#region node_modules/webpush-webcrypto/lib/util.js
/**
* Browsers don't have a built-in API for base64 URL encoding
* so we need to provide one.
* @param {ArrayBuffer | string} arrayBufferOrString
* @returns {string}
*/
function base64urlEncode(arrayBufferOrString) {
	let source = arrayBufferOrString;
	if (typeof source === "string") source = new TextEncoder().encode(source);
	let result = "";
	new Uint8Array(source).forEach((value) => {
		result += String.fromCharCode(value);
	});
	return btoa(result).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
/**
* Similar to the encoder, there's no built in functionality for
* base64 URL decoding, so we'll provide one.
* @param {string} string
* @returns {ArrayBuffer}
*/
function decodeBase64URL(string) {
	let deURLed = string.replace(/\-/g, "+").replace(/_/g, "/");
	const pad = 4 - deURLed.length % 4;
	if (pad !== 4) for (let i = 0; i < pad; i++) deURLed += "=";
	if (deURLed.length % 4 !== 0) throw new Error("Decoded to incorrect length");
	const decoded = atob(deURLed);
	const array = new Uint8Array(decoded.length);
	for (let i = 0; i < decoded.length; i++) array[i] = decoded.charCodeAt(i);
	return array.buffer;
}
/**
* Node has Buffer.concat, browsers do not. So we'll use this.
* @param {Uint8Array[]} arrays
* @returns {Uint8Array}
*/
function concatTypedArrays(arrays) {
	const totalLength = arrays.reduce((prev, curr) => prev + curr.byteLength, 0);
	let index = 0;
	const targetArray = new Uint8Array(totalLength);
	for (const array of arrays) {
		targetArray.set(array, index);
		index += array.byteLength;
	}
	return targetArray;
}
/** @type {Crypto | undefined} */
var cryptoInstance = void 0;
if (typeof self !== "undefined") cryptoInstance = self.crypto;
var crypto = {
	get subtle() {
		if (!cryptoInstance) throw new Error("Could not find global Crypto module. Please set it with the setCrypto method.");
		return cryptoInstance.subtle;
	},
	/**
	*
	* @param {ArrayBufferView} target
	* @returns
	*/
	getRandomValues(target) {
		if (!cryptoInstance) throw new Error("Could not find global Crypto module. Please set it with the setCrypto method.");
		return cryptoInstance.getRandomValues(target);
	}
};
/**
*
* @param {Crypto} newCrypto
*/
function setWebCrypto(newCrypto) {
	cryptoInstance = newCrypto;
}
//#endregion
//#region node_modules/webpush-webcrypto/lib/constants.js
var textEncoder = new TextEncoder();
var AUTH_ENCODING_HEADER = textEncoder.encode("Content-Encoding: auth\0");
var CONTEXT_KEY_LABEL = textEncoder.encode("P-256\0");
var NONCE_ENCODING_HEADER = textEncoder.encode("Content-Encoding: nonce\0");
var CONTENT_ENCRYPTION_KEY_HEADER = textEncoder.encode("Content-Encoding: aesgcm\0");
//#endregion
//#region node_modules/webpush-webcrypto/lib/jwt.js
var JWT_INFO = {
	typ: "JWT",
	alg: "ES256"
};
/**
* @param {{publicKey?: CryptoKey, privateKey?: CryptoKey}} keyPair
* @param {{aud: string, sub: string}} data
*/
async function createJWT(keyPair, data) {
	if (!keyPair.privateKey || !keyPair.publicKey) throw new Error("Missing public or private key");
	const exp = Math.floor(Date.now() / 1e3) + 720 * 60;
	const dataWithExp = {
		aud: data.aud,
		exp,
		sub: data.sub
	};
	const base64Info = base64urlEncode(JSON.stringify(JWT_INFO));
	const base64Data = base64urlEncode(JSON.stringify(dataWithExp));
	const unsignedToken = base64Info + "." + base64Data;
	const sig = base64urlEncode(await crypto.subtle.sign({
		name: "ECDSA",
		hash: { name: "SHA-256" }
	}, keyPair.privateKey, new TextEncoder().encode(unsignedToken)));
	return base64Info + "." + base64Data + "." + sig;
}
//#endregion
//#region node_modules/webpush-webcrypto/lib/payload.js
/**
* @typedef {import('./application-server-keys.js').ApplicationServerKeys} ApplicationServerKeys
*
* @typedef SerializedClientKeys
* @property {string} p256dh
* @property {string} auth
*
* @typedef PushTarget
* @property {string} endpoint
* @property {SerializedClientKeys} keys
*
* @typedef PushOptions
* @property {string | Uint8Array} payload
* @property {ApplicationServerKeys} applicationServerKeys
* @property {PushTarget} target
* @property {string} adminContact
* @property {number} ttl
* @property {string} [topic]
* @property {"very-low" | "low" | "normal" | "high"} [urgency]
*/
/**
* A JSON-serialized PushSubscription contains p256 and auth keys
* as base64URL-encoded strings. They need to be converted in order
* to be usable.
* @param {SerializedClientKeys} keys
* @returns {Promise<{auth: ArrayBuffer, p256: CryptoKey}>}
*/
async function importClientKeys(keys) {
	const auth = decodeBase64URL(keys.auth);
	if (auth.byteLength !== 16) throw new Error(`incorrect auth length, expected 16 bytes got ${auth.byteLength}`);
	return {
		auth,
		p256: await crypto.subtle.importKey("raw", decodeBase64URL(keys.p256dh), {
			name: "ECDH",
			namedCurve: "P-256"
		}, true, [])
	};
}
/**
* The shared secret is calculated by both the sender and receiver. ECDH allows this
* because a combination of device A's public key and device B's private key will
* derive the same secret as device B's public key and device A's private key.
* @param {CryptoKey} clientPublicKey
* @param {CryptoKey} localPrivateKey
*/
async function deriveSharedSecret(clientPublicKey, localPrivateKey) {
	const sharedSecretBytes = await crypto.subtle.deriveBits({
		name: "ECDH",
		public: clientPublicKey
	}, localPrivateKey, 256);
	return crypto.subtle.importKey("raw", sharedSecretBytes, { name: "HKDF" }, false, ["deriveBits", "deriveKey"]);
}
/**
* We use our shared secret HKDF key to make a more crytographically strong
* psuedo random key.
*
* @param {ArrayBuffer} auth
* @param {CryptoKey} sharedSecret
* @returns {Promise<CryptoKey>}
*/
async function derivePsuedoRandomKey(auth, sharedSecret) {
	const pseudoRandomKeyBytes = await crypto.subtle.deriveBits({
		name: "HKDF",
		hash: "SHA-256",
		salt: auth,
		info: AUTH_ENCODING_HEADER
	}, sharedSecret, 256);
	return crypto.subtle.importKey("raw", pseudoRandomKeyBytes, "HKDF", false, ["deriveBits"]);
}
/**
* The context is used when creating our nonce and content encryption key. I'm not
* totally sure *why* it has to include what it does, but it does.
*
* @param {CryptoKey} clientPublicKey The browser's p256dh key
* @param {CryptoKey} localPublicKey Our locally generated public key
* @returns {Promise<Uint8Array>}
*/
async function createContext(clientPublicKey, localPublicKey) {
	const clientKeyBytes = await crypto.subtle.exportKey("raw", clientPublicKey);
	const localKeyBytes = await crypto.subtle.exportKey("raw", localPublicKey);
	return concatTypedArrays([
		CONTEXT_KEY_LABEL,
		new Uint8Array([0, clientKeyBytes.byteLength]),
		new Uint8Array(clientKeyBytes),
		new Uint8Array([0, localKeyBytes.byteLength]),
		new Uint8Array(localKeyBytes)
	]);
}
/**
* "A nonce is a value that prevents replay attacks as it should only be used once."
* https://en.wikipedia.org/wiki/Cryptographic_nonce
*
* Since our salt is unique for each push this nonce value will be, too.
*
* @param {CryptoKey} pseudoRandomKey
* @param {ArrayBuffer} salt
* @param {Uint8Array} context
* @returns {Promise<ArrayBuffer>}
*/
async function deriveNonce(pseudoRandomKey, salt, context) {
	const nonceInfo = concatTypedArrays([NONCE_ENCODING_HEADER, context]);
	return crypto.subtle.deriveBits({
		name: "HKDF",
		hash: "SHA-256",
		salt,
		info: nonceInfo
	}, pseudoRandomKey, 96);
}
/**
* We're finally here! We get to generate a key that we will actually finally use
* to encrypt the payload of our push message.
*
* @param {CryptoKey} pseudoRandomKey
* @param {ArrayBuffer} salt
* @param {Uint8Array} context
* @returns {Promise<CryptoKey>}
*/
async function deriveContentEncryptionKey(pseudoRandomKey, salt, context) {
	const cekInfo = concatTypedArrays([CONTENT_ENCRYPTION_KEY_HEADER, context]);
	const bits = await crypto.subtle.deriveBits({
		name: "HKDF",
		hash: "SHA-256",
		salt,
		info: cekInfo
	}, pseudoRandomKey, 128);
	return crypto.subtle.importKey("raw", bits, "AES-GCM", false, ["encrypt"]);
}
/**
* It's possible that the size of any given web push payload could give away
* its contents (or at least what category of content it is), given that a lot
* of data can be fixed length. In order to disguise pushes we add some 0-byte
* padding. We prefix this padding with a Uint16 saying how long the padding is.
*
* @param {Uint8Array} payload
*/
function padPayload(payload) {
	const MAX_PAYLOAD_SIZE = 4078;
	let paddingSize = Math.round(Math.random() * 100);
	const payloadSizeWithPadding = payload.byteLength + 2 + paddingSize;
	if (payloadSizeWithPadding > MAX_PAYLOAD_SIZE) paddingSize -= payloadSizeWithPadding - MAX_PAYLOAD_SIZE;
	const paddingArray = new Uint8Array(2 + paddingSize);
	new DataView(paddingArray.buffer).setUint16(0, paddingSize);
	return concatTypedArrays([paddingArray, payload]);
}
/**
* @typedef HeaderOptions
* @property {PushOptions} options
* @property {number} payloadLength
* @property {ArrayBuffer} salt
* @property {CryptoKey} localPublicKey
*/
/**
* Calculate the HTTP headers we need to attach to the request in order for it to
* send successfully.
* @param {HeaderOptions} options
* @returns {Promise<Record<string,string>>}
*/
async function getHeaders({ options, payloadLength, salt, localPublicKey }) {
	const localPublicKeyBytes = await crypto.subtle.exportKey("raw", localPublicKey);
	const appKey = await crypto.subtle.exportKey("raw", options.applicationServerKeys.publicKey);
	const localPublicKeyB64 = base64urlEncode(localPublicKeyBytes);
	const appKeyB64 = base64urlEncode(appKey);
	const endpointURL = new URL(options.target.endpoint);
	const jwt = await createJWT(options.applicationServerKeys, {
		aud: endpointURL.origin,
		sub: options.adminContact
	});
	const headers = {
		Encryption: `salt=${base64urlEncode(salt)}`,
		"Crypto-Key": `dh=${localPublicKeyB64};p256ecdsa=${appKeyB64}`,
		"Content-Length": payloadLength.toString(),
		"Content-Type": "application/octet-stream",
		"Content-Encoding": "aesgcm",
		Authorization: `WebPush ${jwt}`,
		TTL: options.ttl.toString()
	};
	if (options.topic) headers["Topic"] = options.topic;
	if (options.urgency) headers["Urgency"] = options.urgency;
	return headers;
}
/**
* Our payload can either be a string or a Uint8Array. Let's normalize
* that
* @param {Uint8Array | string} payload
* @returns {Uint8Array}
*/
function encodePayloadIfNecessary(payload) {
	if (typeof payload === "string") return new TextEncoder().encode(payload);
	return payload;
}
/**
* Encrypt a push payload and calculate the various HTTP headers required to successfully
* send a push.
* @param {PushOptions} options
* @returns {Promise<{headers: Record<string,string>, body: ArrayBuffer, endpoint: string}>}
*/
async function generatePushHTTPRequest(options) {
	const localKeys = await crypto.subtle.generateKey({
		name: "ECDH",
		namedCurve: "P-256"
	}, true, ["deriveBits"]);
	if (!localKeys.privateKey || !localKeys.publicKey) throw new Error("Local key generation failed");
	const clientKeys = await importClientKeys(options.target.keys);
	const sharedSecret = await deriveSharedSecret(clientKeys.p256, localKeys.privateKey);
	const pseudoRandomKey = await derivePsuedoRandomKey(clientKeys.auth, sharedSecret);
	const context = await createContext(clientKeys.p256, localKeys.publicKey);
	const salt = /* @__PURE__ */ new Uint8Array(16);
	crypto.getRandomValues(salt);
	const nonce = await deriveNonce(pseudoRandomKey, salt, context);
	const contentEncryptionKey = await deriveContentEncryptionKey(pseudoRandomKey, salt, context);
	const paddedPayload = padPayload(encodePayloadIfNecessary(options.payload));
	/** @type ArrayBuffer */
	const encryptedPayload = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv: nonce
	}, contentEncryptionKey, paddedPayload);
	return {
		headers: await getHeaders({
			options,
			payloadLength: encryptedPayload.byteLength,
			salt,
			localPublicKey: localKeys.publicKey
		}),
		body: encryptedPayload,
		endpoint: options.target.endpoint
	};
}
//#endregion
//#region node_modules/webpush-webcrypto/lib/application-server-keys.js
/**
* @typedef JSONSerializedKeys
* @property {string} publicKey
* @property {string} privateKey
*/
var ApplicationServerKeys = class ApplicationServerKeys {
	/**
	* You aren't likely to want to construct ApplicationServerKeys directly. Use generate()
	* from fromJSON() instead.
	* @param {CryptoKey} publicKey
	* @param {CryptoKey} privateKey
	*/
	constructor(publicKey, privateKey) {
		this.publicKey = publicKey;
		this.privateKey = privateKey;
	}
	/**
	* You'll need to use the same application server key whenever you want to send a message.
	* This method provides an export of the keys that can you can more easily persist to storage
	* (e.g. IndexedDB) more easily.
	* @returns {Promise<JSONSerializedKeys>}
	*/
	async toJSON() {
		const publicKey = await crypto.subtle.exportKey("raw", this.publicKey);
		const privateKey = await crypto.subtle.exportKey("pkcs8", this.privateKey);
		return {
			publicKey: base64urlEncode(publicKey),
			privateKey: base64urlEncode(privateKey)
		};
	}
	/**
	* Counterpart to toJSON(). This will take previously seralized application server keys and
	* restore them into a form actually usable for encryption.
	* @param {JSONSerializedKeys} keys
	*/
	static async fromJSON(keys) {
		const publicKey = await crypto.subtle.importKey("raw", decodeBase64URL(keys.publicKey), {
			name: "ECDSA",
			namedCurve: "P-256"
		}, true, []);
		const privateKey = await crypto.subtle.importKey("pkcs8", decodeBase64URL(keys.privateKey), {
			name: "ECDSA",
			namedCurve: "P-256"
		}, true, ["sign"]);
		return new ApplicationServerKeys(publicKey, privateKey);
	}
	static async generate() {
		const newApplicationKey = await crypto.subtle.generateKey({
			name: "ECDSA",
			namedCurve: "P-256"
		}, true, ["sign"]);
		if (!newApplicationKey.publicKey || !newApplicationKey.privateKey) throw new Error("Did not generate both public and private key somehow");
		return new ApplicationServerKeys(newApplicationKey.publicKey, newApplicationKey.privateKey);
	}
};
//#endregion
export { generatePushHTTPRequest as n, setWebCrypto as r, ApplicationServerKeys as t };
