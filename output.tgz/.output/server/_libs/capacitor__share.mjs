import { r as __exportAll } from "../_runtime.mjs";
import { o as registerPlugin, r as WebPlugin } from "./@aparajita/capacitor-secure-storage+[...].mjs";
//#region node_modules/@capacitor/share/dist/esm/index.js
var esm_exports = /* @__PURE__ */ __exportAll({ Share: () => Share });
var Share = registerPlugin("Share", { web: () => Promise.resolve().then(() => web_exports).then((m) => new m.ShareWeb()) });
//#endregion
//#region node_modules/@capacitor/share/dist/esm/web.js
var web_exports = /* @__PURE__ */ __exportAll({ ShareWeb: () => ShareWeb });
var ShareWeb = class extends WebPlugin {
	async canShare() {
		if (typeof navigator === "undefined" || !navigator.share) return { value: false };
		else return { value: true };
	}
	async share(options) {
		if (typeof navigator === "undefined" || !navigator.share) throw this.unavailable("Share API not available in this browser");
		await navigator.share({
			title: options.title,
			text: options.text,
			url: options.url
		});
		return {};
	}
};
//#endregion
export { esm_exports as t };
