import { r as __exportAll } from "../_runtime.mjs";
import { o as registerPlugin } from "./@aparajita/capacitor-secure-storage+[...].mjs";
//#region node_modules/@capacitor/push-notifications/dist/esm/index.js
var esm_exports = /* @__PURE__ */ __exportAll({ PushNotifications: () => PushNotifications });
var PushNotifications = registerPlugin("PushNotifications", {});
//#endregion
export { esm_exports as t };
