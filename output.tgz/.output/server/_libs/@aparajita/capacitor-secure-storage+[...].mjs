import { r as __exportAll } from "../../_runtime.mjs";
//#region node_modules/@capacitor/core/dist/index.js
var dist_exports = /* @__PURE__ */ __exportAll({
	Capacitor: () => Capacitor,
	CapacitorException: () => CapacitorException,
	ExceptionCode: () => ExceptionCode,
	SystemBarType: () => SystemBarType,
	SystemBarsStyle: () => SystemBarsStyle,
	WebPlugin: () => WebPlugin,
	buildRequestInit: () => buildRequestInit,
	registerPlugin: () => registerPlugin
});
/*! Capacitor: https://capacitorjs.com/ - MIT License */
var ExceptionCode;
(function(ExceptionCode) {
	/**
	* API is not implemented.
	*
	* This usually means the API can't be used because it is not implemented for
	* the current platform.
	*/
	ExceptionCode["Unimplemented"] = "UNIMPLEMENTED";
	/**
	* API is not available.
	*
	* This means the API can't be used right now because:
	*   - it is currently missing a prerequisite, such as network connectivity
	*   - it requires a particular platform or browser version
	*/
	ExceptionCode["Unavailable"] = "UNAVAILABLE";
})(ExceptionCode || (ExceptionCode = {}));
var CapacitorException = class extends Error {
	constructor(message, code, data) {
		super(message);
		this.message = message;
		this.code = code;
		this.data = data;
	}
};
var getPlatformId = (win) => {
	var _a, _b;
	if (win === null || win === void 0 ? void 0 : win.androidBridge) return "android";
	else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) return "ios";
	else return "web";
};
var createCapacitor = (win) => {
	const capCustomPlatform = win.CapacitorCustomPlatform || null;
	const cap = win.Capacitor || {};
	const Plugins = cap.Plugins = cap.Plugins || {};
	const getPlatform = () => {
		return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
	};
	const isNativePlatform = () => getPlatform() !== "web";
	const isPluginAvailable = (pluginName) => {
		const plugin = registeredPlugins.get(pluginName);
		if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) return true;
		if (getPluginHeader(pluginName)) return true;
		return false;
	};
	const getPluginHeader = (pluginName) => {
		var _a;
		return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find((h) => h.name === pluginName);
	};
	const handleError = (err) => win.console.error(err);
	const registeredPlugins = /* @__PURE__ */ new Map();
	const registerPlugin = (pluginName, jsImplementations = {}) => {
		const registeredPlugin = registeredPlugins.get(pluginName);
		if (registeredPlugin) {
			console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
			return registeredPlugin.proxy;
		}
		const platform = getPlatform();
		const pluginHeader = getPluginHeader(pluginName);
		let jsImplementation;
		const loadPluginImplementation = async () => {
			if (!jsImplementation && platform in jsImplementations) jsImplementation = typeof jsImplementations[platform] === "function" ? jsImplementation = await jsImplementations[platform]() : jsImplementation = jsImplementations[platform];
			else if (capCustomPlatform !== null && !jsImplementation && "web" in jsImplementations) jsImplementation = typeof jsImplementations["web"] === "function" ? jsImplementation = await jsImplementations["web"]() : jsImplementation = jsImplementations["web"];
			return jsImplementation;
		};
		const createPluginMethod = (impl, prop) => {
			var _a, _b;
			if (pluginHeader) {
				const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find((m) => prop === m.name);
				if (methodHeader) if (methodHeader.rtype === "promise") return (options) => cap.nativePromise(pluginName, prop.toString(), options);
				else return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
				else if (impl) return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
			} else if (impl) return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
			else throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
		};
		const createPluginMethodWrapper = (prop) => {
			let remove;
			const wrapper = (...args) => {
				const p = loadPluginImplementation().then((impl) => {
					const fn = createPluginMethod(impl, prop);
					if (fn) {
						const p = fn(...args);
						remove = p === null || p === void 0 ? void 0 : p.remove;
						return p;
					} else throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
				});
				if (prop === "addListener") p.remove = async () => remove();
				return p;
			};
			wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
			Object.defineProperty(wrapper, "name", {
				value: prop,
				writable: false,
				configurable: false
			});
			return wrapper;
		};
		const addListener = createPluginMethodWrapper("addListener");
		const removeListener = createPluginMethodWrapper("removeListener");
		const addListenerNative = (eventName, callback) => {
			const call = addListener({ eventName }, callback);
			const remove = async () => {
				const callbackId = await call;
				removeListener({
					eventName,
					callbackId
				}, callback);
			};
			const p = new Promise((resolve) => call.then(() => resolve({ remove })));
			p.remove = async () => {
				console.warn(`Using addListener() without 'await' is deprecated.`);
				await remove();
			};
			return p;
		};
		const proxy = new Proxy({}, { get(_, prop) {
			switch (prop) {
				case "$$typeof": return;
				case "toJSON": return () => ({});
				case "addListener": return pluginHeader ? addListenerNative : addListener;
				case "removeListener": return removeListener;
				default: return createPluginMethodWrapper(prop);
			}
		} });
		Plugins[pluginName] = proxy;
		registeredPlugins.set(pluginName, {
			name: pluginName,
			proxy,
			platforms: /* @__PURE__ */ new Set([...Object.keys(jsImplementations), ...pluginHeader ? [platform] : []])
		});
		return proxy;
	};
	if (!cap.convertFileSrc) cap.convertFileSrc = (filePath) => filePath;
	cap.getPlatform = getPlatform;
	cap.handleError = handleError;
	cap.isNativePlatform = isNativePlatform;
	cap.isPluginAvailable = isPluginAvailable;
	cap.registerPlugin = registerPlugin;
	cap.Exception = CapacitorException;
	cap.DEBUG = !!cap.DEBUG;
	cap.isLoggingEnabled = !!cap.isLoggingEnabled;
	return cap;
};
var initCapacitorGlobal = (win) => win.Capacitor = createCapacitor(win);
var Capacitor = /*#__PURE__*/ initCapacitorGlobal(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
var registerPlugin = Capacitor.registerPlugin;
/**
* Base class web plugins should extend.
*/
var WebPlugin = class {
	constructor() {
		this.listeners = {};
		this.retainedEventArguments = {};
		this.windowListeners = {};
	}
	addListener(eventName, listenerFunc) {
		let firstListener = false;
		if (!this.listeners[eventName]) {
			this.listeners[eventName] = [];
			firstListener = true;
		}
		this.listeners[eventName].push(listenerFunc);
		const windowListener = this.windowListeners[eventName];
		if (windowListener && !windowListener.registered) this.addWindowListener(windowListener);
		if (firstListener) this.sendRetainedArgumentsForEvent(eventName);
		const remove = async () => this.removeListener(eventName, listenerFunc);
		return Promise.resolve({ remove });
	}
	async removeAllListeners() {
		this.listeners = {};
		for (const listener in this.windowListeners) this.removeWindowListener(this.windowListeners[listener]);
		this.windowListeners = {};
	}
	notifyListeners(eventName, data, retainUntilConsumed) {
		const listeners = this.listeners[eventName];
		if (!listeners) {
			if (retainUntilConsumed) {
				let args = this.retainedEventArguments[eventName];
				if (!args) args = [];
				args.push(data);
				this.retainedEventArguments[eventName] = args;
			}
			return;
		}
		listeners.forEach((listener) => listener(data));
	}
	hasListeners(eventName) {
		var _a;
		return !!((_a = this.listeners[eventName]) === null || _a === void 0 ? void 0 : _a.length);
	}
	registerWindowListener(windowEventName, pluginEventName) {
		this.windowListeners[pluginEventName] = {
			registered: false,
			windowEventName,
			pluginEventName,
			handler: (event) => {
				this.notifyListeners(pluginEventName, event);
			}
		};
	}
	unimplemented(msg = "not implemented") {
		return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
	}
	unavailable(msg = "not available") {
		return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
	}
	async removeListener(eventName, listenerFunc) {
		const listeners = this.listeners[eventName];
		if (!listeners) return;
		const index = listeners.indexOf(listenerFunc);
		this.listeners[eventName].splice(index, 1);
		if (!this.listeners[eventName].length) this.removeWindowListener(this.windowListeners[eventName]);
	}
	addWindowListener(handle) {
		window.addEventListener(handle.windowEventName, handle.handler);
		handle.registered = true;
	}
	removeWindowListener(handle) {
		if (!handle) return;
		window.removeEventListener(handle.windowEventName, handle.handler);
		handle.registered = false;
	}
	sendRetainedArgumentsForEvent(eventName) {
		const args = this.retainedEventArguments[eventName];
		if (!args) return;
		delete this.retainedEventArguments[eventName];
		args.forEach((arg) => {
			this.notifyListeners(eventName, arg);
		});
	}
};
/******** END WEB VIEW PLUGIN ********/
/******** COOKIES PLUGIN ********/
/**
* Safely web encode a string value (inspired by js-cookie)
* @param str The string value to encode
*/
var encode = (str) => encodeURIComponent(str).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
/**
* Safely web decode a string value (inspired by js-cookie)
* @param str The string value to decode
*/
var decode = (str) => str.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
var CapacitorCookiesPluginWeb = class extends WebPlugin {
	async getCookies() {
		const cookies = document.cookie;
		const cookieMap = {};
		cookies.split(";").forEach((cookie) => {
			if (cookie.length <= 0) return;
			let [key, value] = cookie.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE");
			key = decode(key).trim();
			value = decode(value).trim();
			cookieMap[key] = value;
		});
		return cookieMap;
	}
	async setCookie(options) {
		try {
			const encodedKey = encode(options.key);
			const encodedValue = encode(options.value);
			const expires = options.expires ? `; expires=${options.expires.replace("expires=", "")}` : "";
			const path = (options.path || "/").replace("path=", "");
			const domain = options.url != null && options.url.length > 0 ? `domain=${options.url}` : "";
			document.cookie = `${encodedKey}=${encodedValue || ""}${expires}; path=${path}; ${domain};`;
		} catch (error) {
			return Promise.reject(error);
		}
	}
	async deleteCookie(options) {
		try {
			document.cookie = `${options.key}=; Max-Age=0`;
		} catch (error) {
			return Promise.reject(error);
		}
	}
	async clearCookies() {
		try {
			const cookies = document.cookie.split(";") || [];
			for (const cookie of cookies) document.cookie = cookie.replace(/^ +/, "").replace(/=.*/, `=;expires=${(/* @__PURE__ */ new Date()).toUTCString()};path=/`);
		} catch (error) {
			return Promise.reject(error);
		}
	}
	async clearAllCookies() {
		try {
			await this.clearCookies();
		} catch (error) {
			return Promise.reject(error);
		}
	}
};
registerPlugin("CapacitorCookies", { web: () => new CapacitorCookiesPluginWeb() });
/**
* Read in a Blob value and return it as a base64 string
* @param blob The blob value to convert to a base64 string
*/
var readBlobAsBase64 = async (blob) => new Promise((resolve, reject) => {
	const reader = new FileReader();
	reader.onload = () => {
		const base64String = reader.result;
		resolve(base64String.indexOf(",") >= 0 ? base64String.split(",")[1] : base64String);
	};
	reader.onerror = (error) => reject(error);
	reader.readAsDataURL(blob);
});
/**
* Normalize an HttpHeaders map by lowercasing all of the values
* @param headers The HttpHeaders object to normalize
*/
var normalizeHttpHeaders = (headers = {}) => {
	const originalKeys = Object.keys(headers);
	return Object.keys(headers).map((k) => k.toLocaleLowerCase()).reduce((acc, key, index) => {
		acc[key] = headers[originalKeys[index]];
		return acc;
	}, {});
};
/**
* Builds a string of url parameters that
* @param params A map of url parameters
* @param shouldEncode true if you should encodeURIComponent() the values (true by default)
*/
var buildUrlParams = (params, shouldEncode = true) => {
	if (!params) return null;
	return Object.entries(params).reduce((accumulator, entry) => {
		const [key, value] = entry;
		let encodedValue;
		let item;
		if (Array.isArray(value)) {
			item = "";
			value.forEach((str) => {
				encodedValue = shouldEncode ? encodeURIComponent(str) : str;
				item += `${key}=${encodedValue}&`;
			});
			item.slice(0, -1);
		} else {
			encodedValue = shouldEncode ? encodeURIComponent(value) : value;
			item = `${key}=${encodedValue}`;
		}
		return `${accumulator}&${item}`;
	}, "").substr(1);
};
/**
* Build the RequestInit object based on the options passed into the initial request
* @param options The Http plugin options
* @param extra Any extra RequestInit values
*/
var buildRequestInit = (options, extra = {}) => {
	const output = Object.assign({
		method: options.method || "GET",
		headers: options.headers
	}, extra);
	const type = normalizeHttpHeaders(options.headers)["content-type"] || "";
	if (typeof options.data === "string") output.body = options.data;
	else if (type.includes("application/x-www-form-urlencoded")) {
		const params = new URLSearchParams();
		for (const [key, value] of Object.entries(options.data || {})) params.set(key, value);
		output.body = params.toString();
	} else if (type.includes("multipart/form-data") || options.data instanceof FormData) {
		const form = new FormData();
		if (options.data instanceof FormData) options.data.forEach((value, key) => {
			form.append(key, value);
		});
		else for (const key of Object.keys(options.data)) form.append(key, options.data[key]);
		output.body = form;
		const headers = new Headers(output.headers);
		headers.delete("content-type");
		output.headers = headers;
	} else if (type.includes("application/json") || typeof options.data === "object") output.body = JSON.stringify(options.data);
	return output;
};
var CapacitorHttpPluginWeb = class extends WebPlugin {
	/**
	* Perform an Http request given a set of options
	* @param options Options to build the HTTP request
	*/
	async request(options) {
		const requestInit = buildRequestInit(options, options.webFetchExtra);
		const urlParams = buildUrlParams(options.params, options.shouldEncodeUrlParams);
		const url = urlParams ? `${options.url}?${urlParams}` : options.url;
		const response = await fetch(url, requestInit);
		const contentType = response.headers.get("content-type") || "";
		let { responseType = "text" } = response.ok ? options : {};
		if (contentType.includes("application/json")) responseType = "json";
		let data;
		let blob;
		switch (responseType) {
			case "arraybuffer":
			case "blob":
				blob = await response.blob();
				data = await readBlobAsBase64(blob);
				break;
			case "json":
				data = await response.json();
				break;
			default: data = await response.text();
		}
		const headers = {};
		response.headers.forEach((value, key) => {
			headers[key] = value;
		});
		return {
			data,
			headers,
			status: response.status,
			url: response.url
		};
	}
	/**
	* Perform an Http GET request given a set of options
	* @param options Options to build the HTTP request
	*/
	async get(options) {
		return this.request(Object.assign(Object.assign({}, options), { method: "GET" }));
	}
	/**
	* Perform an Http POST request given a set of options
	* @param options Options to build the HTTP request
	*/
	async post(options) {
		return this.request(Object.assign(Object.assign({}, options), { method: "POST" }));
	}
	/**
	* Perform an Http PUT request given a set of options
	* @param options Options to build the HTTP request
	*/
	async put(options) {
		return this.request(Object.assign(Object.assign({}, options), { method: "PUT" }));
	}
	/**
	* Perform an Http PATCH request given a set of options
	* @param options Options to build the HTTP request
	*/
	async patch(options) {
		return this.request(Object.assign(Object.assign({}, options), { method: "PATCH" }));
	}
	/**
	* Perform an Http DELETE request given a set of options
	* @param options Options to build the HTTP request
	*/
	async delete(options) {
		return this.request(Object.assign(Object.assign({}, options), { method: "DELETE" }));
	}
};
registerPlugin("CapacitorHttp", { web: () => new CapacitorHttpPluginWeb() });
/******** END HTTP PLUGIN ********/
/******** SYSTEM BARS PLUGIN ********/
/**
* Available status bar styles.
*/
var SystemBarsStyle;
(function(SystemBarsStyle) {
	/**
	* Light system bar content on a dark background.
	*
	* @since 8.0.0
	*/
	SystemBarsStyle["Dark"] = "DARK";
	/**
	* For dark system bar content on a light background.
	*
	* @since 8.0.0
	*/
	SystemBarsStyle["Light"] = "LIGHT";
	/**
	* The style is based on the device appearance or the underlying content.
	* If the device is using Dark mode, the system bars content will be light.
	* If the device is using Light mode, the system bars content will be dark.
	*
	* @since 8.0.0
	*/
	SystemBarsStyle["Default"] = "DEFAULT";
})(SystemBarsStyle || (SystemBarsStyle = {}));
/**
* Available system bar types.
*/
var SystemBarType;
(function(SystemBarType) {
	/**
	* The top status bar on both Android and iOS.
	*
	* @since 8.0.0
	*/
	SystemBarType["StatusBar"] = "StatusBar";
	/**
	* The navigation bar (or gesture bar on iOS) on both Android and iOS.
	*
	* @since 8.0.0
	*/
	SystemBarType["NavigationBar"] = "NavigationBar";
})(SystemBarType || (SystemBarType = {}));
var SystemBarsPluginWeb = class extends WebPlugin {
	async setStyle() {
		this.unavailable("not available for web");
	}
	async setAnimation() {
		this.unavailable("not available for web");
	}
	async show() {
		this.unavailable("not available for web");
	}
	async hide() {
		this.unavailable("not available for web");
	}
};
registerPlugin("SystemBars", { web: () => new SystemBarsPluginWeb() });
//#endregion
//#region node_modules/@aparajita/capacitor-secure-storage/dist/esm/definitions.js
/**
* When one of the storage functions throws, the thrown StorageError
* will have a .code property that contains one of these values.
*
* @modified 5.0.0
*/
var StorageErrorType;
(function(StorageErrorType) {
	/**
	* The key is null or empty.
	*/
	StorageErrorType["missingKey"] = "missingKey";
	/**
	* `get()` found the data, but it is corrupted.
	*/
	StorageErrorType["invalidData"] = "invalidData";
	/**
	* A system-level error occurred when getting/setting data from/to the store.
	*/
	StorageErrorType["osError"] = "osError";
	/**
	* An unclassified system-level error occurred.
	*/
	StorageErrorType["unknownError"] = "unknownError";
})(StorageErrorType || (StorageErrorType = {}));
/**
* iOS only
*
* The keychain access option for the storage. The default is
* `whenUnlocked`. For more information, see:
* https://developer.apple.com/documentation/security/keychain_services/keychain_items/item_attribute_keys_and_values#1679100
*/
var KeychainAccess;
(function(KeychainAccess) {
	/**
	The data in the keychain item can be accessed only while the device is
	unlocked by the user.
	
	This is recommended for items that need to be accessible only while the
	application is in the foreground. Items with this attribute migrate to
	a new device when using encrypted backups.
	
	This is the default value for keychain items added without explicitly
	setting an accessibility constant.
	*/
	KeychainAccess[KeychainAccess["whenUnlocked"] = 0] = "whenUnlocked";
	/**
	The data in the keychain item can be accessed only while the device is
	unlocked by the user.
	
	This is recommended for items that need to be accessible only while the
	application is in the foreground. Items with this attribute do not migrate
	to a new device. Thus, after restoring from a backup of a different device,
	these items will not be present.
	*/
	KeychainAccess[KeychainAccess["whenUnlockedThisDeviceOnly"] = 1] = "whenUnlockedThisDeviceOnly";
	/**
	The data in the keychain item cannot be accessed after a restart until the
	device has been unlocked once by the user.
	
	After the first unlock, the data remains accessible until the next restart.
	This is recommended for items that need to be accessed by background
	applications. Items with this attribute migrate to a new device when using
	encrypted backups.
	*/
	KeychainAccess[KeychainAccess["afterFirstUnlock"] = 2] = "afterFirstUnlock";
	/**
	The data in the keychain item cannot be accessed after a restart until
	the device has been unlocked once by the user.
	
	After the first unlock, the data remains accessible until the next restart.
	This is recommended for items that need to be accessed by background
	applications. Items with this attribute do not migrate to a new device.
	Thus, after restoring from a backup of a different device, these items
	will not be present.
	*/
	KeychainAccess[KeychainAccess["afterFirstUnlockThisDeviceOnly"] = 3] = "afterFirstUnlockThisDeviceOnly";
	/**
	The data in the keychain can only be accessed when the device is unlocked.
	Only available if a passcode is set on the device.
	
	This is recommended for items that only need to be accessible while the
	application is in the foreground. Items with this attribute never migrate
	to a new device. After a backup is restored to a new device, these items
	are missing. No items can be stored in this class on devices without a
	passcode. Disabling the device passcode causes all items in this class to
	be deleted.
	*/
	KeychainAccess[KeychainAccess["whenPasscodeSetThisDeviceOnly"] = 4] = "whenPasscodeSetThisDeviceOnly";
})(KeychainAccess || (KeychainAccess = {}));
/**
* If one of the storage functions throws, it will throw a StorageError which
* will have a .code property that can be tested against StorageErrorType,
* and a .message property will have a message suitable for debugging purposes.
*
* @modified 5.0.0
*/
var StorageError = class extends Error {
	constructor(message, code) {
		super(message);
		this.name = "StorageError";
		this.code = code;
	}
};
//#endregion
//#region node_modules/@aparajita/capacitor-secure-storage/dist/esm/index.js
var proxy = registerPlugin("SecureStorage", {
	web: async () => {
		return new (await (Promise.resolve().then(() => web_exports))).SecureStorageWeb();
	},
	ios: async () => {
		return new (await (Promise.resolve().then(() => native_exports))).SecureStorageNative(proxy);
	},
	android: async () => {
		return new (await (Promise.resolve().then(() => native_exports))).SecureStorageNative(proxy);
	}
});
//#endregion
//#region node_modules/@aparajita/capacitor-secure-storage/dist/esm/base.js
function isStorageErrorType(value) {
	return value !== void 0 && Object.keys(StorageErrorType).includes(value);
}
var SecureStorageBase = class SecureStorageBase extends WebPlugin {
	constructor() {
		super(...arguments);
		this.prefix = "capacitor-storage_";
		this.sync = false;
		this.access = KeychainAccess.whenUnlocked;
	}
	async setSynchronize(sync) {
		this.sync = sync;
		if (Capacitor.getPlatform() === "ios") return this.setSynchronizeKeychain({ sync });
	}
	async getSynchronize() {
		return this.sync;
	}
	async setDefaultKeychainAccess(access) {
		this.access = access;
	}
	async tryOperation(operation) {
		try {
			return await operation();
		} catch (error) {
			if (error instanceof CapacitorException && isStorageErrorType(error.code)) throw new StorageError(error.message, error.code);
			throw error;
		}
	}
	async get(key, convertDate = true, sync) {
		if (key) {
			const { data } = await this.tryOperation(async () => this.internalGetItem({
				prefixedKey: this.prefixedKey(key),
				sync: sync !== null && sync !== void 0 ? sync : this.sync
			}));
			if (data === null) return null;
			if (convertDate) {
				const date = parseISODate(data);
				if (date) return date;
			}
			try {
				return JSON.parse(data);
			} catch (_a) {
				throw new StorageError("Invalid data", StorageErrorType.invalidData);
			}
		}
		return SecureStorageBase.missingKey();
	}
	async getItem(key) {
		if (key) {
			const { data } = await this.tryOperation(async () => this.internalGetItem({
				prefixedKey: this.prefixedKey(key),
				sync: this.sync
			}));
			return data;
		}
		return null;
	}
	async set(key, data, convertDate = true, sync, access) {
		if (key) {
			let convertedData = data;
			if (convertDate && data instanceof Date) convertedData = data.toISOString();
			return this.tryOperation(async () => this.internalSetItem({
				prefixedKey: this.prefixedKey(key),
				data: JSON.stringify(convertedData),
				sync: sync !== null && sync !== void 0 ? sync : this.sync,
				access: access !== null && access !== void 0 ? access : this.access
			}));
		}
		return SecureStorageBase.missingKey();
	}
	async setItem(key, value) {
		if (key) return this.tryOperation(async () => this.internalSetItem({
			prefixedKey: this.prefixedKey(key),
			data: value,
			sync: this.sync,
			access: this.access
		}));
		return SecureStorageBase.missingKey();
	}
	async remove(key, sync) {
		if (key) {
			const { success } = await this.tryOperation(async () => this.internalRemoveItem({
				prefixedKey: this.prefixedKey(key),
				sync: sync !== null && sync !== void 0 ? sync : this.sync
			}));
			return success;
		}
		return SecureStorageBase.missingKey();
	}
	async removeItem(key) {
		if (key) {
			await this.tryOperation(async () => this.internalRemoveItem({
				prefixedKey: this.prefixedKey(key),
				sync: this.sync
			}));
			return;
		}
		SecureStorageBase.missingKey();
	}
	async keys(sync) {
		const { keys } = await this.tryOperation(async () => this.getPrefixedKeys({
			prefix: this.prefix,
			sync: sync !== null && sync !== void 0 ? sync : this.sync
		}));
		const prefixLength = this.prefix.length;
		return keys.map((key) => key.slice(prefixLength));
	}
	async getKeyPrefix() {
		return this.prefix;
	}
	async setKeyPrefix(prefix) {
		this.prefix = prefix;
	}
	prefixedKey(key) {
		return this.prefix + key;
	}
	static missingKey() {
		throw new StorageError("No key provided", StorageErrorType.missingKey);
	}
};
var isoDateRE = /^"(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}).(\d{3})Z"$/u;
function parseISODate(isoDate) {
	const match = isoDateRE.exec(isoDate);
	if (match) {
		const year = Number.parseInt(match[1], 10);
		const month = Number.parseInt(match[2], 10) - 1;
		const day = Number.parseInt(match[3], 10);
		const hour = Number.parseInt(match[4], 10);
		const minute = Number.parseInt(match[5], 10);
		const second = Number.parseInt(match[6], 10);
		const millis = Number.parseInt(match[7], 10);
		return new Date(Date.UTC(year, month, day, hour, minute, second, millis));
	}
	return null;
}
//#endregion
//#region node_modules/@aparajita/capacitor-secure-storage/dist/esm/native.js
var native_exports = /* @__PURE__ */ __exportAll({ SecureStorageNative: () => SecureStorageNative });
var SecureStorageNative = class extends SecureStorageBase {
	constructor(capProxy) {
		super();
		const proxy = capProxy;
		this.setSynchronizeKeychain = proxy.setSynchronizeKeychain;
		this.internalGetItem = proxy.internalGetItem;
		this.internalSetItem = proxy.internalSetItem;
		this.internalRemoveItem = proxy.internalRemoveItem;
		this.clearItemsWithPrefix = proxy.clearItemsWithPrefix;
		this.getPrefixedKeys = proxy.getPrefixedKeys;
	}
	async setSynchronizeKeychain(_options) {}
	async internalGetItem(_options) {
		return { data: "" };
	}
	async internalSetItem(_options) {}
	async internalRemoveItem(_options) {
		return { success: true };
	}
	async clear(sync) {
		return this.tryOperation(async () => this.clearItemsWithPrefix({
			prefix: this.prefix,
			sync: sync !== null && sync !== void 0 ? sync : this.sync
		}));
	}
	async clearItemsWithPrefix(_options) {}
	async getPrefixedKeys(_options) {
		return { keys: [] };
	}
};
//#endregion
//#region node_modules/@aparajita/capacitor-secure-storage/dist/esm/web.js
var web_exports = /* @__PURE__ */ __exportAll({ SecureStorageWeb: () => SecureStorageWeb });
var SecureStorageWeb = class extends SecureStorageBase {
	async setSynchronizeKeychain(_options) {}
	async internalGetItem(options) {
		return { data: localStorage.getItem(options.prefixedKey) };
	}
	async internalSetItem(options) {
		localStorage.setItem(options.prefixedKey, options.data);
	}
	async internalRemoveItem(options) {
		if (localStorage.getItem(options.prefixedKey) !== null) {
			localStorage.removeItem(options.prefixedKey);
			return { success: true };
		}
		return { success: false };
	}
	async clear() {
		const { keys } = await this.getPrefixedKeys({ prefix: this.prefix });
		for (const key of keys) localStorage.removeItem(key);
	}
	async clearItemsWithPrefix(_options) {
		console.warn("clearItemsWithPrefix is native only");
	}
	async getPrefixedKeys(options) {
		const keys = [];
		for (let i = 0; i < localStorage.length; i++) {
			const key = localStorage.key(i);
			if (key === null || key === void 0 ? void 0 : key.startsWith(options.prefix)) keys.push(key);
		}
		return { keys };
	}
};
//#endregion
export { dist_exports as a, buildRequestInit as i, Capacitor as n, registerPlugin as o, WebPlugin as r, proxy as t };
