import { r as __exportAll } from "../_runtime.mjs";
import { o as registerPlugin, r as WebPlugin } from "./@aparajita/capacitor-secure-storage+[...].mjs";
//#region node_modules/@capacitor-community/media/dist/esm/index.js
var esm_exports = /* @__PURE__ */ __exportAll({ Media: () => Media });
var Media = registerPlugin("Media", { web: () => Promise.resolve().then(() => web_exports).then((m) => new m.MediaWeb()) });
//#endregion
//#region node_modules/@capacitor-community/media/dist/esm/web.js
var web_exports = /* @__PURE__ */ __exportAll({ MediaWeb: () => MediaWeb });
var MediaWeb = class extends WebPlugin {
	getMedias(options) {
		console.log("getMedias", options);
		throw this.unimplemented("Not implemented on web.");
	}
	getMediaByIdentifier(options) {
		console.log("getMediaByIdentifier", options);
		throw this.unimplemented("Not implemented on web.");
	}
	getAlbums() {
		throw this.unimplemented("Not implemented on web.");
	}
	savePhoto(options) {
		console.log("savePhoto", options);
		throw this.unimplemented("Not implemented on web.");
	}
	saveVideo(options) {
		console.log("saveVideo", options);
		throw this.unimplemented("Not implemented on web.");
	}
	createAlbum(options) {
		console.log("createAlbum", options);
		throw this.unimplemented("Not implemented on web.");
	}
	getAlbumsPath() {
		console.log("getAlbumsPath");
		throw this.unimplemented("Not implemented on web.");
	}
};
//#endregion
export { esm_exports as t };
